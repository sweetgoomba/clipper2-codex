import { Injectable, NotFoundException, Optional } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import type { DataSource, EntityManager } from 'typeorm';
import type {
  UserOnboardingJob,
  UserOnboardingJobKind,
  UserOnboardingJobStatus,
} from '../domain/user-onboarding-job.model.js';
import { UserOnboardingJobsRepository } from '../domain/user-onboarding-jobs.repository.js';

@Injectable()
export class TypeOrmUserOnboardingJobsRepository extends UserOnboardingJobsRepository {
  constructor(
    @InjectDataSource('user') private readonly dataSource: DataSource,
    @Optional() private readonly manager?: EntityManager,
  ) {
    super();
  }

  bind(manager: EntityManager): UserOnboardingJobsRepository {
    return new TypeOrmUserOnboardingJobsRepository(this.dataSource, manager);
  }

  async createPending(
    userId: string,
    kind: UserOnboardingJobKind,
    nextAttemptAt: Date,
    signupIntent?: { ticketId: string; promotionCode: string | null },
  ): Promise<UserOnboardingJob> {
    const result = await this.executor().query<unknown>(
      `
        INSERT INTO user_onboarding_jobs (
          user_id, kind, status, attempt_count, next_attempt_at, signup_ticket_id, promotion_code
        )
        VALUES ($1, $2, 'pending', 0, $3, $4, $5)
        ON CONFLICT (user_id, kind) DO NOTHING
        RETURNING *
      `,
      [userId, kind, nextAttemptAt, signupIntent?.ticketId ?? null, signupIntent?.promotionCode ?? null],
    );
    const rows = decodeWriteRows<UserOnboardingJobRow>(result);
    if (rows[0]) return this.toJob(rows[0]);

    const winner = await this.findByUserAndKind(userId, kind);
    if (!winner) throw new NotFoundException('user onboarding job not found');
    return winner;
  }

  async updateSignupIntent(userId: string, ticketId: string, promotionCode: string | null, at: Date): Promise<UserOnboardingJob | undefined> {
    const result = await this.executor().query<unknown>(`
      UPDATE user_onboarding_jobs SET signup_ticket_id = $2, promotion_code = $3::varchar(20),
        status = 'pending', lease_until = NULL, next_attempt_at = $4,
        attempt_count = CASE WHEN promotion_code IS DISTINCT FROM $3::varchar(20) THEN 0 ELSE attempt_count END,
        last_error_code = NULL, updated_at = $4
      WHERE user_id = $1 AND kind = 'free_trial_provisioning'
        AND signup_ticket_id IS NOT NULL AND status <> 'completed'
        AND (status <> 'processing' OR lease_until <= $4)
      RETURNING *
    `, [userId, ticketId, promotionCode, at]);
    const rows = decodeWriteRows<UserOnboardingJobRow>(result);
    return rows[0] ? this.toJob(rows[0]) : undefined;
  }

  async findByUserAndKind(
    userId: string,
    kind: UserOnboardingJobKind,
  ): Promise<UserOnboardingJob | undefined> {
    const rows = await this.executor().query<UserOnboardingJobRow[]>(
      `
        SELECT *
        FROM user_onboarding_jobs
        WHERE user_id = $1 AND kind = $2
        LIMIT 1
      `,
      [userId, kind],
    );
    return rows[0] ? this.toJob(rows[0]) : undefined;
  }

  async claimDue(
    kind: UserOnboardingJobKind,
    at: Date,
    leaseUntil: Date,
    limit: number,
  ): Promise<UserOnboardingJob[]> {
    const result = await this.executor().query<unknown>(
      `
        WITH candidates AS (
          SELECT id
          FROM user_onboarding_jobs
          WHERE kind = $1
            AND next_attempt_at <= $2
            AND (
              status IN ('pending', 'retryable_failed')
              OR (status = 'processing' AND lease_until <= $2)
            )
          ORDER BY next_attempt_at ASC, id ASC
          FOR UPDATE SKIP LOCKED
          LIMIT $3
        )
        UPDATE user_onboarding_jobs jobs
        SET status = 'processing',
            attempt_count = jobs.attempt_count + 1,
            lease_until = $4,
            updated_at = $2
        FROM candidates
        WHERE jobs.id = candidates.id
        RETURNING jobs.*
      `,
      [kind, at, limit, leaseUntil],
    );
    const rows = decodeWriteRows<UserOnboardingJobRow>(result);
    return rows.map((row) => this.toJob(row));
  }

  async claimForUser(
    userId: string,
    kind: UserOnboardingJobKind,
    at: Date,
    leaseUntil: Date,
  ): Promise<UserOnboardingJob | undefined> {
    const result = await this.executor().query<unknown>(
      `
        WITH candidate AS (
          SELECT id
          FROM user_onboarding_jobs
          WHERE user_id = $1
            AND kind = $2
            AND (
              status IN ('pending', 'retryable_failed')
              OR (status = 'processing' AND lease_until <= $3)
            )
          FOR UPDATE SKIP LOCKED
          LIMIT 1
        )
        UPDATE user_onboarding_jobs jobs
        SET status = 'processing',
            attempt_count = jobs.attempt_count + 1,
            lease_until = $4,
            updated_at = $3
        FROM candidate
        WHERE jobs.id = candidate.id
        RETURNING jobs.*
      `,
      [userId, kind, at, leaseUntil],
    );
    const rows = decodeWriteRows<UserOnboardingJobRow>(result);
    return rows[0] ? this.toJob(rows[0]) : undefined;
  }

  async markCompleted(
    id: string,
    attemptCount: number,
    at: Date,
  ): Promise<UserOnboardingJob> {
    return this.updateOne(
      `
        UPDATE user_onboarding_jobs
        SET status = 'completed',
            lease_until = NULL,
            last_error_code = NULL,
            completed_at = $3,
            updated_at = $3
        WHERE id = $1
          AND status = 'processing'
          AND attempt_count = $2
        RETURNING *
      `,
      [id, attemptCount, at],
    );
  }

  async markRetryableFailed(
    id: string,
    attemptCount: number,
    nextAttemptAt: Date,
    errorCode: string,
    at: Date,
  ): Promise<UserOnboardingJob> {
    return this.updateOne(
      `
        UPDATE user_onboarding_jobs
        SET status = 'retryable_failed',
            next_attempt_at = $3,
            lease_until = NULL,
            last_error_code = $4,
            completed_at = NULL,
            updated_at = $5
        WHERE id = $1
          AND status = 'processing'
          AND attempt_count = $2
        RETURNING *
      `,
      [id, attemptCount, nextAttemptAt, errorCode, at],
    );
  }

  async markManualReview(
    id: string,
    attemptCount: number,
    errorCode: string,
    at: Date,
  ): Promise<UserOnboardingJob> {
    return this.updateOne(
      `
        UPDATE user_onboarding_jobs
        SET status = 'manual_review',
            lease_until = NULL,
            last_error_code = $3,
            completed_at = NULL,
            updated_at = $4
        WHERE id = $1
          AND status = 'processing'
          AND attempt_count = $2
        RETURNING *
      `,
      [id, attemptCount, errorCode, at],
    );
  }

  private executor(): EntityManager {
    return this.manager ?? this.dataSource.manager;
  }

  private async updateOne(
    sql: string,
    parameters: unknown[],
  ): Promise<UserOnboardingJob> {
    const result = await this.executor().query<unknown>(
      sql,
      parameters,
    );
    const rows = decodeWriteRows<UserOnboardingJobRow>(result);
    if (!rows[0]) throw new NotFoundException('user onboarding job not found');
    return this.toJob(rows[0]);
  }

  private toJob(row: UserOnboardingJobRow): UserOnboardingJob {
    return {
      id: row.id,
      userId: row.user_id,
      signupTicketId: row.signup_ticket_id,
      promotionCode: row.promotion_code,
      kind: row.kind,
      status: row.status,
      attemptCount: Number(row.attempt_count),
      nextAttemptAt: this.asDate(row.next_attempt_at),
      leaseUntil: row.lease_until ? this.asDate(row.lease_until) : null,
      lastErrorCode: row.last_error_code,
      completedAt: row.completed_at ? this.asDate(row.completed_at) : null,
      createdAt: this.asDate(row.created_at),
      updatedAt: this.asDate(row.updated_at),
    };
  }

  private asDate(value: Date | string): Date {
    return value instanceof Date ? value : new Date(value);
  }
}

function decodeWriteRows<Row extends object>(result: unknown): Row[] {
  if (!Array.isArray(result)) {
    throw new Error('invalid TypeORM write result');
  }

  let rows: unknown[] = result;
  if (
    result.length === 2 &&
    Array.isArray(result[0]) &&
    Number.isInteger(result[1])
  ) {
    rows = result[0] as unknown[];
    if (rows.length !== result[1]) {
      throw new Error('invalid TypeORM write result');
    }
  }
  if (
    rows.some(
      (row) => row === null || typeof row !== 'object' || Array.isArray(row),
    )
  ) {
    throw new Error('invalid TypeORM write result');
  }
  return rows as Row[];
}

interface UserOnboardingJobRow {
  id: string;
  user_id: string;
  signup_ticket_id: string | null;
  promotion_code: string | null;
  kind: UserOnboardingJobKind;
  status: UserOnboardingJobStatus;
  attempt_count: number | string;
  next_attempt_at: Date | string;
  lease_until: Date | string | null;
  last_error_code: string | null;
  completed_at: Date | string | null;
  created_at: Date | string;
  updated_at: Date | string;
}
