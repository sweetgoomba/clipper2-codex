import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import type {
  UserOnboardingJobKind,
  UserOnboardingJobStatus,
} from '../domain/user-onboarding-job.model.js';

@Entity('user_onboarding_jobs')
@Index(['userId', 'kind'], { unique: true })
export class UserOnboardingJobEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ name: 'user_id', type: 'uuid' }) userId!: string;
  @Column({ name: 'signup_ticket_id', type: 'uuid', nullable: true }) signupTicketId!: string | null;
  @Column({ name: 'promotion_code', type: 'varchar', length: 20, nullable: true }) promotionCode!: string | null;
  @Column({ type: 'varchar', length: 50 }) kind!: UserOnboardingJobKind;
  @Column({ type: 'varchar', length: 30 }) status!: UserOnboardingJobStatus;
  @Column({ name: 'claim_generation', type: 'int', default: 0 }) claimGeneration!: number;
  @Column({ name: 'attempt_count', type: 'int' }) attemptCount!: number;
  @Column({ name: 'next_attempt_at', type: 'timestamptz' })
  nextAttemptAt!: Date;
  @Column({ name: 'lease_until', type: 'timestamptz', nullable: true })
  leaseUntil!: Date | null;
  @Column({ name: 'last_error_code', type: 'varchar', length: 120, nullable: true })
  lastErrorCode!: string | null;
  @Column({ name: 'completed_at', type: 'timestamptz', nullable: true })
  completedAt!: Date | null;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' })
  createdAt!: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' })
  updatedAt!: Date;
}
