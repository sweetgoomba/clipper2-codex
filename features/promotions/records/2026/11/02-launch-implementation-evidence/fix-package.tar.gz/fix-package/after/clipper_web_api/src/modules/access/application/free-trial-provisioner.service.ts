import { Injectable } from '@nestjs/common';
import type { EntityManager } from 'typeorm';
import { AdminTransactionRunner } from '../../../core/database/admin-transaction.runner.js';
import { CreditsRepository } from '../../credits/domain/credits.repository.js';
import { UsersService } from '../../users/application/users.service.js';
import { exactDaysAfter } from '../../../shared/time/exact-duration.js';
import type { User } from '../../users/domain/user.model.js';
import { AccessRepository } from '../domain/access.repository.js';
import type { UserFreeTrial } from '../domain/free-trial.model.js';
import { FreeTrialsRepository } from '../domain/free-trials.repository.js';

@Injectable()
export class FreeTrialProvisioner {
  constructor(
    private readonly users: UsersService,
    private readonly access: AccessRepository,
    private readonly trials: FreeTrialsRepository,
    private readonly credits: CreditsRepository,
    private readonly transactions: AdminTransactionRunner,
  ) {}

  findUserForProvisioning(userId: string): Promise<User | undefined> {
    return this.users.findById(userId);
  }

  async ensureForUser(
    userId: string,
    at: Date,
    manager?: EntityManager,
    knownUser?: User | null,
  ): Promise<UserFreeTrial | null> {
    const user = knownUser === undefined ? await this.findUserForProvisioning(userId) : knownUser;
    if (!user) return null;

    if (manager) return this.ensureWithManager(user, at, manager);
    return this.transactions.run((transactionManager) =>
      this.ensureWithManager(user, at, transactionManager),
    );
  }

  private ensureWithManager(
    user: User,
    at: Date,
    manager: EntityManager,
  ): Promise<UserFreeTrial | null> {
    const access = this.access.bind(manager);
    const trials = this.trials.bind(manager);
    const credits = this.credits.bind(manager);

    return access.withUserLock(user.id, async () => {
      const policy = await trials.lockPolicy();
      const existing = await trials.findByUserId(user.id);
      if (existing) return existing;
      if (!policy.isEnabled) return null;

      const idempotencyKey = `free-trial:${user.id}`;
      const expiresAt = exactDaysAfter(user.createdAt, policy.validityDays);
      const grant = await credits.createGrant({
        userId: user.id,
        source: 'free_trial',
        initialCredits: policy.initialCredits,
        remainingCredits: policy.initialCredits,
        grantedAt: user.createdAt,
        expiresAt,
        status: expiresAt <= at ? 'expired' : 'active',
        accessGrantId: null,
        subscriptionId: null,
        paymentOrderId: null,
        operatorId: null,
        reason: 'one-time free trial',
        idempotencyKey,
      });
      await credits.appendLedger({
        creditGrantId: grant.id,
        userId: user.id,
        type: 'grant',
        deltaCredits: policy.initialCredits,
        balanceAfter: policy.initialCredits,
        operationRunId: null,
        paymentOrderId: null,
        referenceKey: idempotencyKey,
        reason: 'one-time free trial',
      });
      return trials.createParticipation({
        userId: user.id,
        planTierId: policy.tierId,
        creditGrantId: grant.id,
        issuedAt: user.createdAt,
      });
    });
  }
}
