import type { EntityManager } from 'typeorm';
import type {
  UserOnboardingJob,
  UserOnboardingJobKind,
} from './user-onboarding-job.model.js';

export abstract class UserOnboardingJobsRepository {
  abstract bind(manager: EntityManager): UserOnboardingJobsRepository;
  /** Hold the job row lock through admin effects and acknowledgement; superseded claims do nothing. */
  abstract withClaim(job: UserOnboardingJob, work: (jobs: UserOnboardingJobsRepository) => Promise<void>): Promise<void>;
  abstract createPending(
    userId: string,
    kind: UserOnboardingJobKind,
    nextAttemptAt: Date,
    signupIntent?: { ticketId: string; promotionCode: string | null },
  ): Promise<UserOnboardingJob>;
  /** Only an unfinished new-signup job may change its selected code. Active leases are never overwritten. */
  abstract updateSignupIntent(userId: string, ticketId: string, promotionCode: string | null, at: Date): Promise<UserOnboardingJob | undefined>;
  abstract findByUserAndKind(
    userId: string,
    kind: UserOnboardingJobKind,
    lock?: boolean,
  ): Promise<UserOnboardingJob | undefined>;
  abstract claimDue(
    kind: UserOnboardingJobKind,
    at: Date,
    leaseUntil: Date,
    limit: number,
  ): Promise<UserOnboardingJob[]>;
  abstract claimForUser(
    userId: string,
    kind: UserOnboardingJobKind,
    at: Date,
    leaseUntil: Date,
  ): Promise<UserOnboardingJob | undefined>;
  abstract markCompleted(
    id: string,
    claimGeneration: number,
    at: Date,
  ): Promise<UserOnboardingJob>;
  abstract markRetryableFailed(
    id: string,
    claimGeneration: number,
    nextAttemptAt: Date,
    errorCode: string,
    at: Date,
  ): Promise<UserOnboardingJob>;
  abstract markManualReview(
    id: string,
    claimGeneration: number,
    errorCode: string,
    at: Date,
  ): Promise<UserOnboardingJob>;
}
