import { TypeOrmSignupCompletionRepository } from './typeorm-signup-completion.repository.js';
import { SignupTicketAlreadyUsedError, type SignupCompletionInput } from '../domain/signup-completion.repository.js';

const AT = new Date('2026-10-08T00:00:00.000Z');
const INPUT: SignupCompletionInput = {
  ticketId: 'jti-1',
  profile: { sub: 'g-1', email: 'gildong@gmail.com', name: '홍길동' },
  agreedAt: AT,
  clientKind: 'web',
  documentVersions: { terms: 't-1', privacy: 'p-1' },
  ipHash: 'hash',
  userAgent: 'UA',
};
const EXISTING = { id: 'usr_old', googleSub: 'g-1', email: 'gildong@gmail.com', name: '홍길동', avatarUrl: null, createdAt: AT };

function setup(opts: { redeemed?: unknown; existing?: typeof EXISTING | null } = {}) {
  const usersRepo = {
    findOne: jest.fn(async () => opts.existing ?? null),
    create: jest.fn((v: object) => v),
    save: jest.fn(async (v: object) => ({ ...v, id: 'usr_new', createdAt: AT })),
  };
  const manager = {
    query: jest.fn(async () => opts.redeemed ?? [{ jti: 'jti-1' }]),
    getRepository: jest.fn(() => usersRepo),
  };
  const dataSource = { transaction: jest.fn(async (work: (m: unknown) => unknown) => work(manager)) };
  const onboarding = { bind: jest.fn(), createPending: jest.fn(async () => ({})), findByUserAndKind: jest.fn(async () => undefined), updateSignupIntent: jest.fn(async () => ({})) };
  onboarding.bind.mockReturnValue(onboarding);
  const consents = { bind: jest.fn(), insertMany: jest.fn(async () => undefined) };
  consents.bind.mockReturnValue(consents);
  const repo = new TypeOrmSignupCompletionRepository(dataSource as never, onboarding as never, consents as never, { appliedCode: jest.fn(async () => null) } as never);
  return { repo, manager, usersRepo, onboarding, consents, dataSource };
}

describe('TypeOrmSignupCompletionRepository', () => {
  it('creates a new user with its free-trial job and three consent rows in one transaction', async () => {
    const t = setup();
    const result = await t.repo.complete(INPUT);
    expect(t.dataSource.transaction).toHaveBeenCalledTimes(1);
    expect(t.manager.query).toHaveBeenCalledWith(expect.stringContaining('INSERT INTO signup_ticket_redemptions'), ['jti-1']);
    expect(t.usersRepo.save).toHaveBeenCalledWith(expect.objectContaining({ googleSub: 'g-1', email: 'gildong@gmail.com', avatarUrl: null }));
    expect(t.onboarding.bind).toHaveBeenCalledWith(t.manager);
    expect(t.onboarding.createPending).toHaveBeenCalledWith('usr_new', 'free_trial_provisioning', AT, { ticketId: 'jti-1', promotionCode: null });
    expect(t.consents.bind).toHaveBeenCalledWith(t.manager);
    const base = { userId: 'usr_new', agreedAt: AT, clientKind: 'web', ipHash: 'hash', userAgent: 'UA' };
    expect(t.consents.insertMany).toHaveBeenCalledWith([
      { ...base, consentType: 'age_14_plus', documentVersion: null },
      { ...base, consentType: 'terms', documentVersion: 't-1' },
      { ...base, consentType: 'privacy', documentVersion: 'p-1' },
    ]);
    expect(result).toEqual({ user: expect.objectContaining({ id: 'usr_new' }), created: true });
  });

  it('stores the optional code in the new member durable intent, not in a login-only field', async () => {
    const t = setup();
    await t.repo.complete({ ...INPUT, promotionCode: 'BOOTH2026' });
    expect(t.onboarding.createPending).toHaveBeenCalledWith('usr_new', 'free_trial_provisioning', AT,
      { ticketId: 'jti-1', promotionCode: 'BOOTH2026' });
  });

  it('resumes the same consumed ticket only for its unfinished signup job without duplicate consents', async () => {
    const t = setup({ existing: EXISTING, redeemed: [] });
    t.onboarding.findByUserAndKind.mockResolvedValue({ signupTicketId: 'jti-1', promotionCode: 'BOOTH2026', status: 'retryable_failed' } as never);
    await expect(t.repo.complete({ ...INPUT, promotionCode: 'BOOTH2026' })).resolves.toMatchObject({ created: false });
    expect(t.onboarding.createPending).not.toHaveBeenCalled();
    expect(t.consents.insertMany).not.toHaveBeenCalled();
  });

  it('does not resume a completed signup even for the original consumed ticket', async () => {
    const t = setup({ existing: EXISTING, redeemed: [] });
    t.onboarding.findByUserAndKind.mockResolvedValue({ signupTicketId: 'jti-1', status: 'completed' } as never);
    await expect(t.repo.complete(INPUT)).rejects.toThrow('SIGNUP_ALREADY_COMPLETED');
  });

  it('only appends consent rows for an existing user', async () => {
    const t = setup({ existing: EXISTING });
    const result = await t.repo.complete(INPUT);
    expect(t.usersRepo.save).not.toHaveBeenCalled();
    expect(t.onboarding.createPending).not.toHaveBeenCalled();
    expect(t.consents.insertMany).toHaveBeenCalledWith(expect.arrayContaining([expect.objectContaining({ userId: 'usr_old' })]));
    expect(result.created).toBe(false);
  });

  it.each([[[]], [[[], 0]]])('refuses a ticket that was already redeemed (driver result %j)', async (redeemed) => {
    const t = setup({ redeemed });
    await expect(t.repo.complete(INPUT)).rejects.toBeInstanceOf(SignupTicketAlreadyUsedError);
    expect(t.usersRepo.save).not.toHaveBeenCalled();
    expect(t.consents.insertMany).not.toHaveBeenCalled();
  });
});
