import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import type { EntityManager } from 'typeorm';
import { AdminTransactionRunner } from '../../../core/database/admin-transaction.runner.js';
import { exactDaysAfter } from '../../../shared/time/exact-duration.js';
import { AccessRepository } from '../../access/domain/access.repository.js';
import type { CreditGrant } from '../../credits/domain/credit.model.js';
import { CreditsRepository } from '../../credits/domain/credits.repository.js';
import { normalizePromotionCode, PROMOTION_CODE_PATTERN } from '../domain/promotion-code.js';
import { promotionRegistrationBlock } from '../domain/promotion-policy.js';
import { PromotionsRepository } from '../domain/promotions.repository.js';

/** Called only by the durable new-signup job, never by a member redemption route. */
@Injectable()
export class SignupPromotionCreditProvisioner {
  constructor(
    private readonly promotions: PromotionsRepository,
    private readonly access: AccessRepository,
    private readonly credits: CreditsRepository,
    private readonly transactions: AdminTransactionRunner,
  ) {}

  async validate(rawCode: string, at: Date): Promise<string> {
    const code = this.normalize(rawCode);
    await this.transactions.run(async (manager) => {
      await this.eligibleCode(this.promotions.bind(manager), code, null, at);
    });
    return code;
  }

  ensureForUser(userId: string, rawCode: string, at: Date, manager?: EntityManager): Promise<CreditGrant> {
    if (!manager) return this.transactions.run((transaction) => this.ensureForUser(userId, rawCode, at, transaction));
    const promotions = this.promotions.bind(manager);
    const credits = this.credits.bind(manager);
    return this.access.bind(manager).withUserLock(userId, async () => {
      const idempotencyKey = `signup-promotion:${userId}`;
      const existing = await credits.findGrantByIdempotencyKey(idempotencyKey);
      if (existing) return existing;
      const { campaign, code } = await this.eligibleCode(promotions, this.normalize(rawCode), userId, at);
      const redemptionId = randomUUID();
      await promotions.createRedemption({ id: redemptionId, campaignId: campaign.id, codeId: code.id, userId, grantedAt: at });
      const grant = await credits.createGrant({
        userId, source: 'promotion', initialCredits: campaign.creditAmount, remainingCredits: campaign.creditAmount,
        grantedAt: at, expiresAt: exactDaysAfter(at, campaign.creditValidityDays), status: 'active',
        accessGrantId: null, promotionRedemptionId: redemptionId, subscriptionId: null,
        paymentOrderId: null, operatorId: null, reason: 'signup promotion credits', idempotencyKey,
      });
      await credits.appendLedger({
        creditGrantId: grant.id, userId, type: 'grant', deltaCredits: campaign.creditAmount,
        balanceAfter: campaign.creditAmount, operationRunId: null, paymentOrderId: null,
        referenceKey: idempotencyKey, reason: 'signup promotion credits',
      });
      await promotions.incrementCount(campaign.id);
      return grant;
    });
  }

  private normalize(value: string): string {
    const code = normalizePromotionCode(value);
    if (!PROMOTION_CODE_PATTERN.test(code)) throw new BadRequestException('PROMOTION_CODE_INVALID');
    return code;
  }

  private async eligibleCode(repository: PromotionsRepository, value: string, userId: string | null, at: Date) {
    const found = await repository.lockCodeAndCampaign(value);
    if (!found) throw new NotFoundException('PROMOTION_CODE_NOT_FOUND');
    const { campaign, code } = found;
    if (campaign.benefitKind !== 'signup_credits') throw new ConflictException('PROMOTION_SIGNUP_CREDITS_REQUIRED');
    const history = userId ? await repository.memberHistory(userId, campaign.id, code.id)
      : { paid: false, admin_plan: false, sameCampaign: false, sameCode: false };
    const block = promotionRegistrationBlock({
      campaign, codeIsActive: code.isActive,
      codeRedeemedCount: await repository.countCodeRedemptions(code.id), history,
      hasSameCampaignRedemption: history.sameCampaign, hasSameCodeRedemption: history.sameCode,
      hasCurrentOrScheduledPrimary: false, at,
    });
    if (block) throw new ConflictException(block);
    return { campaign, code };
  }
}
