import { ConflictException, Injectable, ServiceUnavailableException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import type { DataSource, EntityManager } from 'typeorm';
import {
  SignupCompletionRepository,
  SignupTicketAlreadyUsedError,
  type SignupCompletionInput,
  type SignupCompletionResult,
} from '../domain/signup-completion.repository.js';
import { UserOnboardingJobsRepository } from '../../users/domain/user-onboarding-jobs.repository.js';
import { UserConsentsRepository } from '../../consents/domain/user-consents.repository.js';
import { UserEntity } from '../../users/infrastructure/user.entity.js';
import { insertUserWithOnboarding, toUserModel } from '../../users/infrastructure/typeorm-users.repository.js';

@Injectable()
export class TypeOrmSignupCompletionRepository extends SignupCompletionRepository {
  constructor(
    @InjectDataSource('user') private readonly dataSource: DataSource,
    private readonly onboardingJobs: UserOnboardingJobsRepository,
    private readonly consents: UserConsentsRepository,
  ) {
    super();
  }

  complete(input: SignupCompletionInput): Promise<SignupCompletionResult> {
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const redeemed = await manager.query(
        'INSERT INTO signup_ticket_redemptions (jti) VALUES ($1) ON CONFLICT (jti) DO NOTHING RETURNING jti',
        [input.ticketId],
      );
      const firstUse = returnedRowCount(redeemed) === 1;
      const existing = await manager.getRepository(UserEntity).findOne({
        where: { googleSub: input.profile.sub }, lock: { mode: 'pessimistic_write' },
      });
      const jobs = this.onboardingJobs.bind(manager);
      const job = existing ? await jobs.findByUserAndKind(existing.id, 'free_trial_provisioning') : undefined;
      const pending = job?.signupTicketId && job.status !== 'completed' ? job : undefined;
      if (!firstUse && (!pending || pending.signupTicketId !== input.ticketId)) throw new SignupTicketAlreadyUsedError();
      if (existing && !pending && input.promotionCode) throw new ConflictException('SIGNUP_PROMOTION_NEW_MEMBERS_ONLY');
      if (pending && (pending.promotionCode !== (input.promotionCode ?? null) || pending.signupTicketId !== input.ticketId)) {
        const changed = await jobs.updateSignupIntent(existing!.id, input.ticketId, input.promotionCode ?? null, input.agreedAt);
        if (!changed) throw new ServiceUnavailableException('SIGNUP_BENEFITS_PROCESSING');
      }
      const user = existing
        ? toUserModel(existing)
        : await insertUserWithOnboarding(manager, this.onboardingJobs, {
            googleSub: input.profile.sub,
            email: input.profile.email,
            name: input.profile.name,
            avatarUrl: input.profile.avatarUrl,
          }, { ticketId: input.ticketId, promotionCode: input.promotionCode ?? null });

      // A retry of the same unfinished signup does not append consent rows again.
      if (!firstUse) return { user, created: false };

      const base = {
        userId: user.id,
        agreedAt: input.agreedAt,
        clientKind: input.clientKind,
        ipHash: input.ipHash,
        userAgent: input.userAgent,
      };
      await this.consents.bind(manager).insertMany([
        { ...base, consentType: 'age_14_plus', documentVersion: null },
        { ...base, consentType: 'terms', documentVersion: input.documentVersions.terms },
        { ...base, consentType: 'privacy', documentVersion: input.documentVersions.privacy },
      ]);
      return { user, created: !existing };
    });
  }
}

/** TypeORM postgres는 RETURNING 결과를 rows 또는 [rows, affected]로 돌려준다 — 둘 다 받는다. */
function returnedRowCount(result: unknown): number {
  if (Array.isArray(result) && result.length === 2 && Array.isArray(result[0]) && Number.isInteger(result[1])) {
    return (result[0] as unknown[]).length;
  }
  return Array.isArray(result) ? result.length : 0;
}
