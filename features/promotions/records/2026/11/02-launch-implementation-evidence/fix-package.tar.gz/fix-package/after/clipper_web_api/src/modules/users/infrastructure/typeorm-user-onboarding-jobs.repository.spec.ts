import type { DataSource, EntityManager } from 'typeorm';
import { TypeOrmUserOnboardingJobsRepository } from './typeorm-user-onboarding-jobs.repository.js';

const row = {
  id: 'job-1',
  user_id: 'user-1',
  kind: 'free_trial_provisioning',
  status: 'pending',
  attempt_count: 0,
  claim_generation: 0,
  next_attempt_at: new Date('2026-08-31T00:00:00.000Z'),
  lease_until: null,
  last_error_code: null,
  completed_at: null,
  created_at: new Date('2026-08-31T00:00:00.000Z'),
  updated_at: new Date('2026-08-31T00:00:00.000Z'),
};

describe('TypeOrmUserOnboardingJobsRepository', () => {
  it('creates one pending job per user and kind through the bound manager', async () => {
    const dataSourceQuery = jest.fn();
    const queries: Array<{ sql: string; parameters?: unknown[] }> = [];
    const query = jest.fn((sql: string, parameters?: unknown[]) => {
      queries.push({ sql: sql.replace(/\s+/g, ' ').trim(), parameters });
      return Promise.resolve([row]);
    });
    const repository = new TypeOrmUserOnboardingJobsRepository({
      manager: { query: dataSourceQuery },
    } as unknown as DataSource).bind({ query } as unknown as EntityManager);

    await expect(
      repository.createPending(
        'user-1',
        'free_trial_provisioning',
        row.next_attempt_at,
      null, null,
      ),
    ).resolves.toEqual({
      id: 'job-1',
      userId: 'user-1',
      kind: 'free_trial_provisioning',
      status: 'pending',
      attemptCount: 0,
      claimGeneration: 0,
      nextAttemptAt: row.next_attempt_at,
      leaseUntil: null,
      lastErrorCode: null,
      completedAt: null,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    });

    expect(dataSourceQuery).not.toHaveBeenCalled();
    expect(queries[0].sql).toContain('ON CONFLICT (user_id, kind) DO NOTHING');
    expect(queries[0].parameters).toEqual([
      'user-1',
      'free_trial_provisioning',
      row.next_attempt_at,
      null, null,
    ]);
  });

  it('claims due jobs with row locking so workers cannot process the same job', async () => {
    const queries: Array<{ sql: string; parameters?: unknown[] }> = [];
    const processingRow = {
      ...row,
      status: 'processing',
      attempt_count: 1,
      lease_until: new Date('2026-08-31T00:02:00.000Z'),
    };
    const query = jest.fn((sql: string, parameters?: unknown[]) => {
      queries.push({ sql: sql.replace(/\s+/g, ' ').trim(), parameters });
      return Promise.resolve([processingRow]);
    });
    const repository = new TypeOrmUserOnboardingJobsRepository({
      manager: { query },
    } as unknown as DataSource);
    const at = new Date('2026-08-31T00:01:00.000Z');
    const leaseUntil = new Date('2026-08-31T00:02:00.000Z');

    await expect(
      repository.claimDue('free_trial_provisioning', at, leaseUntil, 20),
    ).resolves.toEqual([
      expect.objectContaining({
        id: 'job-1',
        status: 'processing',
        attemptCount: 1,
        leaseUntil,
      }),
    ]);

    expect(queries[0].sql).toContain('FOR UPDATE SKIP LOCKED');
    expect(queries[0].sql).toContain("status IN ('pending', 'retryable_failed')");
    expect(queries[0].sql).toContain("status = 'processing'");
    expect(queries[0].sql).toContain('lease_until <= $2');
    expect(queries[0].sql).toContain('attempt_count = jobs.attempt_count + 1');
    expect(queries[0].parameters).toEqual([
      'free_trial_provisioning',
      at,
      20,
      leaseUntil,
    ]);
  });

  it('claims one user immediately without waiting for the scheduled retry time', async () => {
    const query = jest.fn(() =>
      Promise.resolve([{ ...row, status: 'processing', attempt_count: 2 }]),
    );
    const repository = new TypeOrmUserOnboardingJobsRepository({
      manager: { query },
    } as unknown as DataSource);
    const at = new Date('2026-08-31T00:01:00.000Z');
    const leaseUntil = new Date('2026-08-31T00:06:00.000Z');

    await repository.claimForUser(
      'user-1',
      'free_trial_provisioning',
      at,
      leaseUntil,
    );

    const sql = String(query.mock.calls[0][0]).replace(/\s+/g, ' ');
    expect(sql).toContain('FOR UPDATE SKIP LOCKED');
    expect(sql).not.toContain('next_attempt_at <=');
    expect(query.mock.calls[0][1]).toEqual([
      'user-1',
      'free_trial_provisioning',
      at,
      leaseUntil,
    ]);
  });

  it('decodes the TypeORM UPDATE RETURNING tuple used by PostgreSQL', async () => {
    const processingRow = {
      ...row,
      status: 'processing',
      attempt_count: 1,
      lease_until: new Date('2026-08-31T00:06:00.000Z'),
    };
    const query = jest.fn(() => Promise.resolve([[processingRow], 1]));
    const repository = new TypeOrmUserOnboardingJobsRepository({
      manager: { query },
    } as unknown as DataSource);

    await expect(
      repository.claimForUser(
        'user-1',
        'free_trial_provisioning',
        new Date('2026-08-31T00:01:00.000Z'),
        processingRow.lease_until,
      ),
    ).resolves.toEqual(
      expect.objectContaining({
        id: 'job-1',
        status: 'processing',
        attemptCount: 1,
        leaseUntil: processingRow.lease_until,
      }),
    );
  });

  it('persists only fixed safe error codes for retry and manual review', async () => {
    const query = jest.fn(() => Promise.resolve([row]));
    const repository = new TypeOrmUserOnboardingJobsRepository({
      manager: { query },
    } as unknown as DataSource);
    const retryAt = new Date('2026-08-31T00:05:00.000Z');

    await repository.markRetryableFailed(
      'job-1',
      2,
      retryAt,
      'FREE_TRIAL_PROVISIONING_FAILED',
      row.updated_at,
    );
    await repository.markManualReview(
      'job-1',
      2,
      'FREE_TRIAL_PROVISIONING_FAILED',
      row.updated_at,
    );
    await repository.markCompleted('job-1', 2, row.updated_at);

    const statements = query.mock.calls.map(([sql]) =>
      String(sql).replace(/\s+/g, ' '),
    );
    expect(statements[0]).toContain("status = 'retryable_failed'");
    expect(statements[1]).toContain("status = 'manual_review'");
    expect(statements[2]).toContain("status = 'completed'");
    for (const statement of statements) {
      expect(statement).toContain("status = 'processing'");
      expect(statement).toContain('claim_generation = $2');
    }
    expect(query.mock.calls[0][1]).toEqual([
      'job-1',
      2,
      retryAt,
      'FREE_TRIAL_PROVISIONING_FAILED',
      row.updated_at,
    ]);
  });
});
