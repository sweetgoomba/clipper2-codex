import { BadRequestException, ConflictException, Inject, Injectable, Optional } from '@nestjs/common';
import { SignupTicketService, type SignupTicketTarget } from './signup-ticket.service.js';
import { AuthSessionService, type AuthSessionClientMetadata, type AuthTokenBundle } from './auth-session.service.js';
import { ConsentsService } from '../../consents/application/consents.service.js';
import type { RequiredDocument } from '../../consents/domain/required-consents.js';
import type { ConsentClientKind } from '../../consents/domain/consent-types.js';
import { UsersService } from '../../users/application/users.service.js';
import type { User } from '../../users/domain/user.model.js';
import { FreeTrialOnboardingService } from '../../access/application/free-trial-onboarding.service.js';
import { SignupPromotionCreditProvisioner } from '../../promotions/application/signup-promotion-credit-provisioner.service.js';
import {
  SignupCompletionRepository,
  SignupTicketAlreadyUsedError,
  type SignupCompletionInput,
  type SignupCompletionResult,
} from '../domain/signup-completion.repository.js';

export const SIGNUP_CLOCK = Symbol('SIGNUP_CLOCK');
export interface SignupClock {
  now(): Date;
}

export interface SignupPreviewResult {
  email: string;
  name: string;
  avatarUrl: string | null;
  isExistingUser: boolean;
  isSignupPending: boolean;
  signupPromotionCode: string | null;
  clientKind: ConsentClientKind;
  documents: RequiredDocument[];
}

export interface SignupCompleteInput {
  ticket: string;
  ageOver14: boolean;
  termsVersion: string;
  privacyVersion: string;
  promotionCode?: string;
  sessionMetadata: AuthSessionClientMetadata;
  userAgent: string | null;
}

export type SignupCompleteResult =
  | { clientKind: 'web'; bundle: AuthTokenBundle; returnPath: string }
  | { clientKind: 'desktop'; desktopRedirectUrl: string };

/** 동의 화면의 두 API. spec §4.4 */
@Injectable()
export class SignupService {
  constructor(
    private readonly tickets: SignupTicketService,
    private readonly consents: ConsentsService,
    private readonly users: UsersService,
    private readonly completion: SignupCompletionRepository,
    private readonly sessions: AuthSessionService,
    private readonly benefits: FreeTrialOnboardingService,
    private readonly promotion: SignupPromotionCreditProvisioner,
    @Optional() @Inject(SIGNUP_CLOCK) private readonly clock?: SignupClock,
  ) {}

  async preview(ticket: string): Promise<SignupPreviewResult> {
    const { profile, target } = this.tickets.verify(ticket);
    const existing = await this.users.findByGoogleSub(profile.sub);
    const pending = existing ? await this.benefits.pendingSignup(existing.id) : undefined;
    return {
      email: profile.email,
      name: profile.name,
      avatarUrl: profile.avatarUrl ?? null,
      isExistingUser: Boolean(existing),
      isSignupPending: Boolean(pending),
      signupPromotionCode: pending?.promotionCode ?? null,
      clientKind: clientKindOf(target),
      documents: this.consents.requiredDocuments(),
    };
  }

  async requiresSignupCompletion(userId: string): Promise<boolean> {
    return Boolean(await this.benefits.pendingSignup(userId));
  }

  async complete(input: SignupCompleteInput): Promise<SignupCompleteResult> {
    const claims = this.tickets.verify(input.ticket);
    if (input.ageOver14 !== true) throw new BadRequestException('age_confirmation_required');
    const versions = currentVersions(this.consents.requiredDocuments());
    if (input.termsVersion !== versions.terms || input.privacyVersion !== versions.privacy) {
      throw new ConflictException('consent_version_outdated');
    }
    const at = this.clock?.now() ?? new Date();
    const existing = await this.users.findByGoogleSub(claims.profile.sub);
    const pending = existing ? await this.benefits.pendingSignup(existing.id) : undefined;
    const rawCode = input.promotionCode?.trim();
    if (rawCode && existing && !pending) throw new ConflictException('SIGNUP_PROMOTION_NEW_MEMBERS_ONLY');
    // An already committed bonus must remain recoverable after its code expires.
    // The durable provisioner rechecks availability only when no grant exists yet.
    const normalized = rawCode?.toUpperCase();
    const promotionCode = rawCode
      ? pending?.promotionCode === normalized ? normalized : await this.promotion.validate(rawCode, at)
      : null;
    const { user, created } = await this.completeOnce({
      ticketId: claims.ticketId,
      profile: claims.profile,
      agreedAt: at,
      promotionCode,
      clientKind: clientKindOf(claims.target),
      documentVersions: versions,
      ipHash: input.sessionMetadata.ipHash ?? null,
      userAgent: input.userAgent,
    });
    if (created || pending || await this.benefits.pendingSignup(user.id)) {
      await this.benefits.ensureReadyForLogin(user.id, at);
    }
    return this.continueLogin(user, claims.target, input.sessionMetadata);
  }

  /** 같은 Google 계정의 동시 가입은 users.google_sub unique에서 한쪽이 진다 — 다시 하면 기존 회원으로 처리된다. */
  private async completeOnce(input: SignupCompletionInput): Promise<SignupCompletionResult> {
    try {
      return await this.completion.complete(input);
    } catch (err) {
      if (err instanceof SignupTicketAlreadyUsedError) throw new ConflictException('signup_ticket_used');
      if (!isUniqueViolation(err)) throw err;
      try {
        return await this.completion.complete(input);
      } catch (retryErr) {
        if (retryErr instanceof SignupTicketAlreadyUsedError) throw new ConflictException('signup_ticket_used');
        throw retryErr;
      }
    }
  }

  private async continueLogin(
    user: User,
    target: SignupTicketTarget,
    metadata: AuthSessionClientMetadata,
  ): Promise<SignupCompleteResult> {
    if (target.client === 'web') {
      return { clientKind: 'web', bundle: await this.sessions.issueSession(user, metadata), returnPath: target.webReturnPath };
    }
    if (target.client === 'desktop') {
      const issued = await this.sessions.issueDesktopAuthCode(user, target.binding);
      return {
        clientKind: 'desktop',
        desktopRedirectUrl: `${target.desktopReturnUrl}?code=${encodeURIComponent(issued.code)}&requestId=${encodeURIComponent(target.binding.requestId)}`,
      };
    }
    const issued = await this.sessions.issueLegacyDesktopAuthCode(user);
    return { clientKind: 'desktop', desktopRedirectUrl: `${target.desktopReturnUrl}?code=${encodeURIComponent(issued.code)}` };
  }
}

function clientKindOf(target: SignupTicketTarget): ConsentClientKind {
  return target.client === 'web' ? 'web' : 'desktop';
}

function currentVersions(documents: RequiredDocument[]): { terms: string; privacy: string } {
  const find = (type: RequiredDocument['type']) => {
    const doc = documents.find((d) => d.type === type);
    if (!doc) throw new Error(`missing_required_document_${type}`);
    return doc.version;
  };
  return { terms: find('terms'), privacy: find('privacy') };
}

function isUniqueViolation(err: unknown): boolean {
  if (typeof err !== 'object' || err === null) return false;
  const e = err as { code?: unknown; driverError?: { code?: unknown } };
  return e.code === '23505' || e.driverError?.code === '23505';
}
