import { BadRequestException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { SignupService } from './signup.service.js';
import { SignupTicketAlreadyUsedError } from '../domain/signup-completion.repository.js';
import type { SignupTicketClaims } from './signup-ticket.service.js';

const AT = new Date('2026-10-08T00:00:00.000Z');
const PROFILE = { sub: 'g-1', email: 'gildong@gmail.com', name: '홍길동' };
const USER = { id: 'usr_1', email: PROFILE.email, name: PROFILE.name, googleSub: 'g-1', createdAt: AT };
const BINDING = {
  desktopTarget: 'production' as const,
  requestId: '5b2318e0-6597-4c3d-89a1-d0cf678935c4',
  codeChallenge: 'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM',
};
const BUNDLE = {
  accessToken: 'a.jwt', accessTokenExpiresAt: '2026-10-08T00:30:00.000Z', refreshToken: 'r',
  refreshTokenExpiresAt: '2026-11-07T00:00:00.000Z', sessionId: 'ses', user: { id: 'usr_1', email: PROFILE.email, name: PROFILE.name },
};
const DOCS = [{ type: 'terms' as const, version: 't-1' }, { type: 'privacy' as const, version: 'p-1' }];
const META = { clientKind: 'web', deviceLabel: 'Chrome on macOS', ipHash: 'hash' };

function setup(claims: Partial<SignupTicketClaims> = {}) {
  const tickets = {
    verify: jest.fn((): SignupTicketClaims => ({
      ticketId: 'jti-1', profile: PROFILE, target: { client: 'web', webReturnPath: '/pricing?subscribe=pro_monthly' }, ...claims,
    })),
  };
  const consents = { requiredDocuments: jest.fn(() => DOCS) };
  const users = { findByGoogleSub: jest.fn(async () => undefined) };
  const completion = { complete: jest.fn(async () => ({ user: USER, created: true })) };
  const sessions = {
    issueSession: jest.fn(async () => BUNDLE),
    issueDesktopAuthCode: jest.fn(async () => ({ code: 'code/1', expiresAt: AT })),
    issueLegacyDesktopAuthCode: jest.fn(async () => ({ code: 'legacy', expiresAt: AT })),
  };
  const benefits = { completedSignupTicket: jest.fn(async () => undefined), pendingSignup: jest.fn(async () => undefined), ensureReadyForLogin: jest.fn(async () => undefined) };
  const promotion = { validate: jest.fn(async (code: string) => code.toUpperCase()) };
  const service = new SignupService(
    tickets as never, consents as never, users as never, completion as never, sessions as never, benefits as never, promotion as never, { now: () => AT },
  );
  return { service, tickets, consents, users, completion, sessions, benefits, promotion };
}
const COMPLETE = { ticket: 't', ageOver14: true, termsVersion: 't-1', privacyVersion: 'p-1', sessionMetadata: META, userAgent: 'UA' };

describe('SignupService.preview', () => {
  it('shows a new account with the documents to agree to', async () => {
    const t = setup();
    expect(await t.service.preview('t')).toEqual({
      email: PROFILE.email, name: PROFILE.name, avatarUrl: null, isExistingUser: false, isSignupPending: false, signupPromotionCode: null, clientKind: 'web', documents: DOCS,
    });
  });

  it('marks an existing account and a desktop login', async () => {
    const t = setup({ target: { client: 'desktop', binding: BINDING, desktopReturnUrl: 'clipperstudio://auth/callback' } });
    t.users.findByGoogleSub.mockResolvedValue(USER as never);
    expect(await t.service.preview('t')).toEqual(expect.objectContaining({ isExistingUser: true, clientKind: 'desktop' }));
  });
});

describe('SignupService.complete', () => {
  it('validates and persists an optional code before issuing a session with ready benefits', async () => {
    const t = setup();
    await t.service.complete({ ...COMPLETE, promotionCode: 'booth2026' });
    expect(t.promotion.validate).toHaveBeenCalledWith('booth2026', AT);
    expect(t.completion.complete).toHaveBeenCalledWith(expect.objectContaining({ promotionCode: 'BOOTH2026' }));
    expect(t.benefits.ensureReadyForLogin).toHaveBeenCalledWith(USER.id, AT);
    expect(t.benefits.ensureReadyForLogin.mock.invocationCallOrder[0]).toBeLessThan(t.sessions.issueSession.mock.invocationCallOrder[0]);
  });

  it('issues no login session when benefit provisioning fails after user creation', async () => {
    const t = setup();
    t.benefits.ensureReadyForLogin.mockRejectedValue(new Error('SIGNUP_BENEFITS_PROCESSING'));
    await expect(t.service.complete({ ...COMPLETE, promotionCode: 'BOOTH2026' })).rejects.toThrow('SIGNUP_BENEFITS_PROCESSING');
    expect(t.sessions.issueSession).not.toHaveBeenCalled();
  });

  it('recovers a pending committed grant without rejecting a code that expired after commit', async () => {
    const t = setup();
    t.users.findByGoogleSub.mockResolvedValue(USER as never);
    t.benefits.pendingSignup.mockResolvedValue({ promotionCode: 'BOOTH2026' } as never);
    t.promotion.validate.mockRejectedValue(new Error('PROMOTION_ENDED'));
    await expect(t.service.complete({ ...COMPLETE, promotionCode: 'booth2026' })).resolves.toMatchObject({ clientKind: 'web' });
    expect(t.promotion.validate).not.toHaveBeenCalled();
    expect(t.benefits.ensureReadyForLogin).toHaveBeenCalledWith(USER.id, AT);
  });

  it('does not accept a signup bonus for a real existing member reconsenting', async () => {
    const t = setup();
    t.users.findByGoogleSub.mockResolvedValue(USER as never);
    await expect(t.service.complete({ ...COMPLETE, promotionCode: 'BOOTH2026' })).rejects.toThrow('SIGNUP_PROMOTION_NEW_MEMBERS_ONLY');
    expect(t.completion.complete).not.toHaveBeenCalled();
  });

  it('leaves the ticket and user unconsumed when the input code is invalid', async () => {
    const t = setup();
    t.promotion.validate.mockRejectedValue(new Error('PROMOTION_CODE_NOT_FOUND'));
    await expect(t.service.complete({ ...COMPLETE, promotionCode: 'WRONG' })).rejects.toThrow('PROMOTION_CODE_NOT_FOUND');
    expect(t.completion.complete).not.toHaveBeenCalled();
  });

  it('records consent and opens a web session back to the original screen', async () => {
    const t = setup();
    const result = await t.service.complete(COMPLETE);
    expect(t.completion.complete).toHaveBeenCalledWith({
      ticketId: 'jti-1', profile: PROFILE, agreedAt: AT, clientKind: 'web',
      documentVersions: { terms: 't-1', privacy: 'p-1' }, ipHash: 'hash', userAgent: 'UA', promotionCode: null,
    });
    expect(t.sessions.issueSession).toHaveBeenCalledWith(USER, META);
    expect(result).toEqual({ clientKind: 'web', bundle: BUNDLE, returnPath: '/pricing?subscribe=pro_monthly' });
  });

  it('issues a bound desktop code and the deep link for a desktop login', async () => {
    const t = setup({ target: { client: 'desktop', binding: BINDING, desktopReturnUrl: 'clipperstudio://auth/callback' } });
    const result = await t.service.complete(COMPLETE);
    expect(t.completion.complete).toHaveBeenCalledWith(expect.objectContaining({ clientKind: 'desktop' }));
    expect(t.sessions.issueDesktopAuthCode).toHaveBeenCalledWith(USER, BINDING);
    expect(t.sessions.issueSession).not.toHaveBeenCalled();
    expect(result).toEqual({
      clientKind: 'desktop',
      desktopRedirectUrl: `clipperstudio://auth/callback?code=code%2F1&requestId=${BINDING.requestId}`,
    });
  });

  it('continues the legacy desktop flow', async () => {
    const t = setup({ target: { client: 'desktop-legacy', desktopReturnUrl: 'clipper://auth/callback' } });
    expect(await t.service.complete(COMPLETE)).toEqual({ clientKind: 'desktop', desktopRedirectUrl: 'clipper://auth/callback?code=legacy' });
    expect(t.sessions.issueLegacyDesktopAuthCode).toHaveBeenCalledWith(USER);
  });

  it('refuses without the age confirmation and stores nothing', async () => {
    const t = setup();
    await expect(t.service.complete({ ...COMPLETE, ageOver14: false })).rejects.toThrow(new BadRequestException('age_confirmation_required'));
    expect(t.completion.complete).not.toHaveBeenCalled();
  });

  it.each([['terms', { termsVersion: 'old' }], ['privacy', { privacyVersion: 'old' }]])(
    'asks to reload when the %s version changed',
    async (_label, patch) => {
      const t = setup();
      await expect(t.service.complete({ ...COMPLETE, ...patch })).rejects.toThrow(new ConflictException('consent_version_outdated'));
      expect(t.completion.complete).not.toHaveBeenCalled();
    },
  );

  it('passes an invalid ticket through as 401 and stores nothing', async () => {
    const t = setup();
    t.tickets.verify.mockImplementation(() => { throw new UnauthorizedException('signup_ticket_invalid'); });
    await expect(t.service.complete(COMPLETE)).rejects.toThrow(UnauthorizedException);
    expect(t.completion.complete).not.toHaveBeenCalled();
  });

  it('reports a second use of the same ticket as 409', async () => {
    const t = setup();
    t.completion.complete.mockRejectedValue(new SignupTicketAlreadyUsedError());
    await expect(t.service.complete(COMPLETE)).rejects.toThrow(new ConflictException('signup_ticket_used'));
    expect(t.sessions.issueSession).not.toHaveBeenCalled();
  });

  it('retries once when the same Google account signed up concurrently', async () => {
    const t = setup();
    t.completion.complete
      .mockRejectedValueOnce(Object.assign(new Error('duplicate key'), { code: '23505' }))
      .mockResolvedValueOnce({ user: USER, created: false });
    expect((await t.service.complete(COMPLETE)).clientKind).toBe('web');
    expect(t.completion.complete).toHaveBeenCalledTimes(2);
  });
});
