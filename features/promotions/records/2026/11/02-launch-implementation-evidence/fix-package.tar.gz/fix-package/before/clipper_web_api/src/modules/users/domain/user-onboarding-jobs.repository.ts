import type { EntityManager } from 'typeorm';
import type {
  UserOnboardingJob,
  UserOnboardingJobKind,
} from './user-onboarding-job.model.js';

export abstract class UserOnboardingJobsRepository {
  abstract bind(manager: EntityManager): UserOnboardingJobsRepository;
  abstract createPending(
    userId: string,
    kind: UserOnboardingJobKind,
    nextAttemptAt: Date,
    signupIntent?: { ticketId: string; promotionCode: string | null },
  ): Promise<UserOnboardingJob>;
  /** Only an unfinished new-signup job may change its selected code. Active leases are never overwritten. */
  abstract updateSignupIntent(userId: string, ticketId: string, promotionCode: string | null, at: Date): Promise<UserOnboardingJob | undefined>;
  abstract findByUserAndKind(
    userId: string,
    kind: UserOnboardingJobKind,
  ): Promise<UserOnboardingJob | undefined>;
  abstract claimDue(
    kind: UserOnboardingJobKind,
    at: Date,
    leaseUntil: Date,
    limit: number,
  ): Promise<UserOnboardingJob[]>;
  abstract claimForUser(
    userId: string,
    kind: UserOnboardingJobKind,
    at: Date,
    leaseUntil: Date,
  ): Promise<UserOnboardingJob | undefined>;
  abstract markCompleted(
    id: string,
    attemptCount: number,
    at: Date,
  ): Promise<UserOnboardingJob>;
  abstract markRetryableFailed(
    id: string,
    attemptCount: number,
    nextAttemptAt: Date,
    errorCode: string,
    at: Date,
  ): Promise<UserOnboardingJob>;
  abstract markManualReview(
    id: string,
    attemptCount: number,
    errorCode: string,
    at: Date,
  ): Promise<UserOnboardingJob>;
}
