import { randomUUID } from 'node:crypto';
import { DataSource } from 'typeorm';
import adminDefinition from '../../../core/database/admin.datasource.js';
import userDefinition from '../../../core/database/user.datasource.js';
import { AdminTransactionRunner } from '../../../core/database/admin-transaction.runner.js';
import { TypeOrmAccessRepository } from '../../access/infrastructure/typeorm-access.repository.js';
import { TypeOrmFreeTrialsRepository } from '../../access/infrastructure/typeorm-free-trials.repository.js';
import { FreeTrialProvisioner } from '../../access/application/free-trial-provisioner.service.js';
import { FreeTrialOnboardingService } from '../../access/application/free-trial-onboarding.service.js';
import { EffectiveAccessService } from '../../access/application/effective-access.service.js';
import { TypeOrmCreditsRepository } from '../../credits/infrastructure/typeorm-credits.repository.js';
import { CreditGrantsService } from '../../credits/application/credit-grants.service.js';
import { TypeOrmUsersRepository } from '../../users/infrastructure/typeorm-users.repository.js';
import { TypeOrmUserOnboardingJobsRepository } from '../../users/infrastructure/typeorm-user-onboarding-jobs.repository.js';
import { UserEntity } from '../../users/infrastructure/user.entity.js';
import { UsersService } from '../../users/application/users.service.js';
import { TypeOrmUserConsentsRepository } from '../../consents/infrastructure/typeorm-user-consents.repository.js';
import { TypeOrmSignupCompletionRepository } from '../../auth/infrastructure/typeorm-signup-completion.repository.js';
import { TypeOrmProductCatalogRepository } from '../../catalog/infrastructure/typeorm-product-catalog.repository.js';
import { ProductCatalogService } from '../../catalog/application/product-catalog.service.js';
import { TypeOrmPromotionsRepository } from '../infrastructure/typeorm-promotions.repository.js';
import { SignupPromotionCreditProvisioner } from './signup-promotion-credit-provisioner.service.js';
import { SignupService } from '../../auth/application/signup.service.js';
import { pluginHierarchyViolation } from '../../catalog/domain/plan-plugin-hierarchy.js';
import { PlanTierEntity } from '../../catalog/infrastructure/plan-tier.entity.js';
import { PlanPluginEntitlementEntity } from '../../catalog/infrastructure/plan-plugin-entitlement.entity.js';
import { BillingProductEntity } from '../../catalog/infrastructure/billing-product.entity.js';
import { CreditProductEntity } from '../../catalog/infrastructure/credit-product.entity.js';
import { CatalogPresentationSettingEntity } from '../../catalog/infrastructure/catalog-presentation-setting.entity.js';
import { OperationsService } from '../../operations/application/operations.service.js';
import { TypeOrmOperationsRepository } from '../../operations/infrastructure/typeorm-operations.repository.js';
import { OperationPolicyEntity } from '../../operations/infrastructure/operation-policy.entity.js';
import { OperationRunEntity } from '../../operations/infrastructure/operation-run.entity.js';
import { OPERATION_DEFINITIONS } from '../../operations/domain/operation-definitions.js';

// Explicitly opt in to the disposable container; never read normal local/remote DB settings.
const integration = process.env.SIGNUP_INTEGRATION_DB_PORT === '15437' ? describe : describe.skip;
integration('durable signup benefits against two isolated PostgreSQL databases', () => {
  const connection = { host: '127.0.0.1', port: 15437, username: 'clipper', password: 'clipper' };
  const admin = new DataSource({ ...adminDefinition.options, ...connection, database: 'clipper_admin',
    entities: [PlanTierEntity, PlanPluginEntitlementEntity, BillingProductEntity, CreditProductEntity, CatalogPresentationSettingEntity, OperationPolicyEntity, OperationRunEntity] } as never);
  const user = new DataSource({ ...userDefinition.options, ...connection, database: 'clipper_user' } as never);
  const at = () => new Date();
  const jobs = new TypeOrmUserOnboardingJobsRepository(user);
  const usersRepository = new TypeOrmUsersRepository(user.getRepository(UserEntity), jobs);
  const users = new UsersService(usersRepository);
  const access = new TypeOrmAccessRepository(admin);
  const credits = new TypeOrmCreditsRepository(admin);
  const trials = new TypeOrmFreeTrialsRepository(admin);
  const promotions = new TypeOrmPromotionsRepository(admin);
  const transactions = new AdminTransactionRunner(admin);
  const free = new FreeTrialProvisioner(users, access, trials, credits, transactions);
  const bonus = new SignupPromotionCreditProvisioner(promotions, access, credits, transactions);
  const onboarding = new FreeTrialOnboardingService(jobs, free, bonus, transactions);
  const completion = new TypeOrmSignupCompletionRepository(user, jobs, new TypeOrmUserConsentsRepository(user), bonus);
  const catalogRepository = new TypeOrmProductCatalogRepository(admin);
  const catalog = new ProductCatalogService(catalogRepository);
  const effective = new EffectiveAccessService(access, trials, catalog);
  const creditService = new CreditGrantsService(credits, transactions, access, {} as never, usersRepository);

  beforeAll(async () => {
    await Promise.all([admin.initialize(), user.initialize()]);
    await user.runMigrations();
    await admin.query('UPDATE free_trial_policies SET initial_credits = 400, is_enabled = true WHERE id = 1');
  });
  afterAll(async () => { await Promise.all([admin, user].filter((db) => db.isInitialized).map((db) => db.destroy())); });

  async function campaign(cap: number | null = null) {
    const now = at();
    const row = await promotions.createCampaign({
      benefitKind: 'signup_credits', name: `integration-${randomUUID()}`, status: 'active',
      startsAt: new Date(now.getTime() - 86_400_000), endsAt: new Date(now.getTime() + 86_400_000),
      maxRedemptionsPerCode: cap, planTierId: null, durationMonths: null, monthlyCredits: null,
      creditAmount: 200, creditValidityDays: 30, historyExclusions: [],
    });
    const code = `T${randomUUID().slice(0, 8).toUpperCase()}`;
    await promotions.saveCode(row.id, code, 'Integration referrer');
    return { ...row, code };
  }
  function input(code: string | null) {
    const id = randomUUID();
    return { ticketId: randomUUID(), profile: { sub: id, email: `${id}@example.test`, name: 'Signup test' },
      agreedAt: at(), clientKind: 'web' as const, documentVersions: { terms: 't-1', privacy: 'p-1' },
      ipHash: null, userAgent: null, promotionCode: code };
  }
  async function grants(userId: string) {
    return admin.query('SELECT source, initial_credits, remaining_credits FROM credit_grants WHERE user_id = $1 ORDER BY source', [userId]);
  }
  async function assertOnce(userId: string, expectedBalance = 600) {
    const rows = await grants(userId);
    expect(rows).toHaveLength(expectedBalance === 400 ? 1 : 2);
    expect((await creditService.summary(userId, at())).spendableBalance).toBe(expectedBalance);
    const ledger = await admin.query('SELECT count(*)::int AS count FROM credit_ledger_entries WHERE user_id = $1 AND type = $2', [userId, 'grant']);
    expect(ledger[0].count).toBe(rows.length);
    const redemption = await admin.query('SELECT access_grant_id FROM promotion_redemptions WHERE user_id = $1', [userId]);
    expect(redemption).toHaveLength(expectedBalance === 400 ? 0 : 1);
    if (redemption.length) expect(redemption[0].access_grant_id).toBeNull();
  }

  it('returns a ready first login with separate 400 + 200 grants, no access pass, and participant history', async () => {
    const promo = await campaign(); const signup = input(promo.code);
    const sessions = { issueSession: jest.fn(async (member) => {
      await assertOnce(member.id);
      return { accessToken: 'ready', user: member };
    }) };
    const service = new SignupService({ verify: () => ({ ...signup, target: { client: 'web', webReturnPath: '/my' } }) } as never,
      { requiredDocuments: () => [{ type: 'terms', version: 't-1' }, { type: 'privacy', version: 'p-1' }] } as never,
      users, completion, sessions as never, onboarding, bonus);
    await expect(service.complete({ ticket: 'signed-test-ticket', ageOver14: true, termsVersion: 't-1', privacyVersion: 'p-1',
      promotionCode: promo.code.toLowerCase(), sessionMetadata: {} as never, userAgent: null })).resolves.toMatchObject({ clientKind: 'web' });
    const member = await users.findByGoogleSub(signup.profile.sub);
    expect((await effective.resolve(member!.id, at()))?.tierCode).toBe('free');
    expect(await promotions.listMemberHistory(member!.id, at())).toEqual([expect.objectContaining({ benefitKind: 'signup_credits', creditAmount: 200, status: 'using' })]);
    expect((await promotions.listRedemptions(promo.id, 0, 50))[0].userId).toBe(member!.id);
  });

  it('retries a user-DB commit after an admin failure without creating duplicate grants', async () => {
    const promo = await campaign(); const signup = input(promo.code);
    const member = (await completion.complete(signup)).user;
    const unavailable = new FreeTrialOnboardingService(jobs, free, bonus,
      { run: async () => { throw new Error('admin unavailable'); } } as never);
    await expect(unavailable.ensureReadyForLogin(member.id, at())).rejects.toThrow('SIGNUP_BENEFITS_PROCESSING');
    expect(await grants(member.id)).toHaveLength(0);
    await onboarding.ensureReadyForLogin(member.id, at());
    await assertOnce(member.id);
  });

  it('preserves committed benefits across session issuance failure and a fresh Google signup ticket', async () => {
    const promo = await campaign(); const signup = input(promo.code);
    const claims = { ...signup, target: { client: 'web', webReturnPath: '/my' } };
    const sessions = { issueSession: jest.fn().mockRejectedValueOnce(new Error('session response unavailable')).mockResolvedValue({ accessToken: 'ready' }) };
    const service = new SignupService({ verify: () => claims } as never,
      { requiredDocuments: () => [{ type: 'terms', version: 't-1' }, { type: 'privacy', version: 'p-1' }] } as never,
      users, completion, sessions as never, onboarding, bonus);
    const request = { ticket: 'signed-test-ticket', ageOver14: true, termsVersion: 't-1', privacyVersion: 'p-1',
      promotionCode: promo.code, sessionMetadata: {} as never, userAgent: null };
    await expect(service.complete(request)).rejects.toThrow('session response unavailable');
    const member = (await users.findByGoogleSub(signup.profile.sub))!;
    await assertOnce(member.id);
    claims.ticketId = randomUUID();
    expect(await service.preview('fresh-ticket')).toMatchObject({ isExistingUser: true, isSignupPending: false });
    await expect(service.complete({ ...request, ticket: 'fresh-ticket', promotionCode: undefined })).resolves.toMatchObject({ clientKind: 'web' });
    await assertOnce(member.id);
  });

  it('returns completed-ticket recovery after session failure with the same preserved code', async () => {
    const promo = await campaign(); const signup = input(promo.code);
    const sessions = { issueSession: jest.fn().mockRejectedValue(new Error('session response unavailable')) };
    const service = new SignupService({ verify: () => ({ ...signup, target: { client: 'web', webReturnPath: '/my' } }) } as never,
      { requiredDocuments: () => [{ type: 'terms', version: 't-1' }, { type: 'privacy', version: 'p-1' }] } as never,
      users, completion, sessions as never, onboarding, bonus);
    const request = { ticket: 'same-ticket', ageOver14: true, termsVersion: 't-1', privacyVersion: 'p-1',
      promotionCode: promo.code, sessionMetadata: {} as never, userAgent: null };
    await expect(service.complete(request)).rejects.toThrow('session response unavailable');
    await expect(service.complete(request)).rejects.toThrow('SIGNUP_ALREADY_COMPLETED');
    await assertOnce((await users.findByGoogleSub(signup.profile.sub))!.id);
    expect(sessions.issueSession).toHaveBeenCalledTimes(1);
  });

  it.each(['changed', 'removed'])('preserves applied code A when %s after admin acknowledgement loss', async (edit) => {
    const a = await campaign(); const b = await campaign();
    await admin.query('UPDATE promotion_campaigns SET credit_amount = 900 WHERE id = $1', [b.id]);
    const signup = input(a.code); const member = (await completion.complete(signup)).user;
    // Admin commit succeeded; the user-side completion acknowledgement did not arrive.
    await transactions.run(async manager => {
      await free.ensureForUser(member.id, at(), manager);
      await bonus.ensureForUser(member.id, a.code, at(), manager);
    });
    await expect(completion.complete({ ...signup, promotionCode: edit === 'changed' ? b.code : null }))
      .rejects.toThrow('SIGNUP_PROMOTION_ALREADY_APPLIED');
    expect((await jobs.findByUserAndKind(member.id, 'free_trial_provisioning'))?.promotionCode).toBe(a.code);
    await onboarding.ensureReadyForLogin(member.id, at());
    await assertOnce(member.id);
    expect((await promotions.listCodes(b.id))[0].redeemedCount).toBe(0);
  });

  it.each([false, true])('fences expired workers (old promotion: %s) from a replacement intent even when retry attempt numbers repeat', async (withOldPromotion) => {
    const a = await campaign(); const b = await campaign(); const signup = input(withOldPromotion ? a.code : null);
    const member = (await completion.complete(signup)).user;
    const now = at(); const expired = new Date(now.getTime() - 1);
    const old = (await jobs.claimForUser(member.id, 'free_trial_provisioning', now, expired))!;
    await completion.complete({ ...signup, agreedAt: now, promotionCode: b.code });
    const replacement = (await jobs.claimForUser(member.id, 'free_trial_provisioning', now, new Date(now.getTime() + 300000)))!;
    expect(replacement.attemptCount).toBe(old.attemptCount);
    for (const staleWrite of [
      () => jobs.markCompleted(old.id, old.claimGeneration, now),
      () => jobs.markRetryableFailed(old.id, old.claimGeneration, now, 'STALE', now),
      () => jobs.markManualReview(old.id, old.claimGeneration, 'STALE', now),
    ]) await expect(staleWrite()).rejects.toThrow('user onboarding job not found');
    await onboarding.process(old, now);
    expect(await grants(member.id)).toHaveLength(0);
    const unavailable = new FreeTrialOnboardingService(jobs, free, bonus,
      { run: async () => { throw new Error('admin unavailable'); } } as never);
    await unavailable.process(replacement, now);
    expect((await jobs.findByUserAndKind(member.id, 'free_trial_provisioning'))?.status).toBe('retryable_failed');
    expect((await jobs.findByUserAndKind(member.id, 'free_trial_provisioning'))?.promotionCode).toBe(b.code);
    expect((await promotions.listCodes(a.id))[0].redeemedCount).toBe(0);
    await admin.query('UPDATE promotion_campaigns SET status = $2 WHERE id = $1', [b.id, 'inactive']);
    await expect(onboarding.ensureReadyForLogin(member.id, now)).rejects.toThrow('PROMOTION_INACTIVE');
    expect(await grants(member.id)).toHaveLength(0);
  });

  it('serializes an expired in-flight admin commit against edits and background scans', async () => {
    const a = await campaign(); const b = await campaign(); const signup = input(a.code);
    const member = (await completion.complete(signup)).user; const now = at();
    const old = (await jobs.claimForUser(member.id, 'free_trial_provisioning', now, new Date(now.getTime() - 1)))!;
    let release!: () => void; let committed!: () => void;
    const pause = new Promise<void>(resolve => { release = resolve; });
    const entered = new Promise<void>(resolve => { committed = resolve; });
    const delayed = new FreeTrialOnboardingService(jobs, free, bonus, { run: async (work) => {
      const result = await transactions.run(work); committed(); await pause; return result;
    } } as never);
    const worker = delayed.process(old, now);
    await entered;
    const edit = completion.complete({ ...signup, agreedAt: at(), promotionCode: b.code });
    // Attach rejection immediately while observing the real blocked database query.
    const outcome = edit.then(() => null, error => error);
    try {
      let blocked = false;
      for (let i = 0; i < 100 && !blocked; i++) {
        const rows = await user.query(`SELECT pid FROM pg_stat_activity
          WHERE datname = current_database() AND wait_event_type = 'Lock' AND query LIKE '%user_onboarding_jobs%'`);
        blocked = rows.length > 0;
        if (!blocked) await new Promise(resolve => setTimeout(resolve, 10));
      }
      expect(blocked).toBe(true);
      expect((await jobs.claimDue('free_trial_provisioning', now, new Date(now.getTime() + 300000), 1000))
        .some(candidate => candidate.id === old.id)).toBe(false);
      expect(await jobs.claimForUser(member.id, 'free_trial_provisioning', now, new Date(now.getTime() + 300000))).toBeUndefined();
    } finally { release(); }
    await worker;
    expect((await outcome)?.message).toBe('SIGNUP_ALREADY_COMPLETED');
    expect((await jobs.findByUserAndKind(member.id, 'free_trial_provisioning'))?.promotionCode).toBe(a.code);
    await assertOnce(member.id);
    expect((await promotions.listCodes(b.id))[0].redeemedCount).toBe(0);
  });

  it('recovers an unknown admin commit at the retry budget without a permanent manual-review lockout', async () => {
    const promo = await campaign(); const signup = input(promo.code);
    const member = (await completion.complete(signup)).user;
    await user.query('UPDATE user_onboarding_jobs SET attempt_count = 5 WHERE user_id = $1', [member.id]);
    const uncertain = new FreeTrialOnboardingService(jobs, free, bonus, { run: async (work) => {
      await transactions.run(work); throw new Error('commit response lost');
    } } as never);
    await expect(uncertain.ensureReadyForLogin(member.id, at())).rejects.toThrow('SIGNUP_BENEFITS_PROCESSING');
    expect((await jobs.findByUserAndKind(member.id, 'free_trial_provisioning'))?.status).toBe('manual_review');
    await assertOnce(member.id);
    await onboarding.ensureReadyForLogin(member.id, at());
    await assertOnce(member.id);
  });

  it('completes more concurrent signups than the one-connection user pool without nested borrowing', async () => {
    const single = new DataSource({ ...userDefinition.options, ...connection, database: 'clipper_user',
      extra: { max: 1, connectionTimeoutMillis: 1000 } } as never);
    await single.initialize();
    try {
      const limitedJobs = new TypeOrmUserOnboardingJobsRepository(single);
      const limitedUsers = new UsersService(new TypeOrmUsersRepository(single.getRepository(UserEntity), limitedJobs));
      const limitedFree = new FreeTrialProvisioner(limitedUsers, access, trials, credits, transactions);
      const limited = new FreeTrialOnboardingService(limitedJobs, limitedFree, bonus, transactions);
      const promo = await campaign();
      const members = await Promise.all(Array.from({ length: 3 }, async () => (await completion.complete(input(promo.code))).user));
      await Promise.all(members.map(member => limited.ensureReadyForLogin(member.id, at())));
      for (const member of members) await assertOnce(member.id);
    } finally { await single.destroy(); }
  });

  it('rolls back the signup grant too when the promotion ledger write fails inside the same admin transaction', async () => {
    const promo = await campaign(); const member = (await completion.complete(input(promo.code))).user;
    const originalBind = credits.bind.bind(credits);
    const bind = jest.spyOn(credits, 'bind').mockImplementation((manager) => {
      const bound = originalBind(manager);
      const append = bound.appendLedger.bind(bound);
      bound.appendLedger = async (entry) => {
        if (entry.referenceKey.startsWith('signup-promotion:')) throw new Error('ledger unavailable');
        return append(entry);
      };
      return bound;
    });
    await expect(onboarding.ensureReadyForLogin(member.id, at())).rejects.toThrow('SIGNUP_BENEFITS_PROCESSING');
    bind.mockRestore();
    expect(await grants(member.id)).toHaveLength(0);
    await onboarding.ensureReadyForLogin(member.id, at());
    await assertOnce(member.id);
  });

  it('recovers an admin commit lost before the user job acknowledgement, even after campaign expiry', async () => {
    const promo = await campaign(); const signup = input(promo.code);
    const member = (await completion.complete(signup)).user;
    const acknowledge = jest.spyOn(TypeOrmUserOnboardingJobsRepository.prototype, 'markCompleted').mockRejectedValueOnce(new Error('user ack unavailable'));
    await expect(onboarding.ensureReadyForLogin(member.id, at())).rejects.toThrow('SIGNUP_BENEFITS_PROCESSING');
    acknowledge.mockRestore();
    await assertOnce(member.id);
    await admin.query('UPDATE promotion_campaigns SET ends_at = $2 WHERE id = $1', [promo.id, new Date(Date.now() - 1_000)]);
    await completion.complete(signup);
    await onboarding.ensureReadyForLogin(member.id, at());
    await assertOnce(member.id);
    await expect(completion.complete(signup)).rejects.toThrow('SIGNUP_ALREADY_COMPLETED');
  });

  it('enforces the last seat concurrently per code and allows a losing signup to remove its code', async () => {
    const promo = await campaign(2);
    const signups = [input(promo.code), input(promo.code), input(promo.code)];
    const members = await Promise.all(signups.map(async (signup) => (await completion.complete(signup)).user));
    const results = await Promise.allSettled(members.map((member) => onboarding.ensureReadyForLogin(member.id, at())));
    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(2);
    const losingIndex = results.findIndex((result) => result.status === 'rejected');
    expect((results[losingIndex] as PromiseRejectedResult).reason.message).toBe('PROMOTION_LIMIT_REACHED');
    expect(await grants(members[losingIndex].id)).toHaveLength(0);
    await completion.complete({ ...signups[losingIndex], promotionCode: null });
    await onboarding.ensureReadyForLogin(members[losingIndex].id, at());
    await assertOnce(members[losingIndex].id, 400);
    const second = `T${randomUUID().slice(0, 8).toUpperCase()}`;
    await promotions.saveCode(promo.id, second, null);
    for (let i = 0; i < 2; i++) {
      const member = (await completion.complete(input(second))).user;
      await onboarding.ensureReadyForLogin(member.id, at());
      await assertOnce(member.id);
    }
    expect((await promotions.listCodes(promo.id)).map((code) => code.redeemedCount)).toEqual([2, 2]);
  });

  it('serializes different tier edits and rolls back both mode and plugin rows on hierarchy failure', async () => {
    const tiers = await catalogRepository.listTiers();
    const ids = Object.fromEntries(tiers.map((tier) => [tier.code, tier.id]));
    await catalogRepository.replaceTierPlugins(ids.business, { entitlementMode: 'all', pluginKeys: [] });
    await catalogRepository.replaceTierPlugins(ids.pro, { entitlementMode: 'all', pluginKeys: [] });
    await catalogRepository.replaceTierPlugins(ids.basic, { entitlementMode: 'allowlist', pluginKeys: [] });
    await catalogRepository.replaceTierPlugins(ids.pro, { entitlementMode: 'allowlist', pluginKeys: ['ranking'] });
    const results = await Promise.allSettled([
      catalogRepository.replaceTierPlugins(ids.basic, { entitlementMode: 'allowlist', pluginKeys: ['ranking'] }),
      catalogRepository.replaceTierPlugins(ids.pro, { entitlementMode: 'allowlist', pluginKeys: [] }),
    ]);
    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(pluginHierarchyViolation(await catalogRepository.listTiers())).toBeNull();
    await catalogRepository.replaceTierPlugins(ids.pro, { entitlementMode: 'allowlist', pluginKeys: ['ranking'] });
    await expect(catalogRepository.replaceTierPlugins(ids.business, { entitlementMode: 'allowlist', pluginKeys: [] }))
      .rejects.toThrow('PLAN_PLUGIN_HIERARCHY_INVALID');
    expect(await catalogRepository.findTierById(ids.business)).toMatchObject({ entitlementMode: 'all', pluginKeys: [] });
    await expect(catalogRepository.updateTier(ids.free, { isActive: false })).rejects.toThrow('FREE_TIER_REQUIRED');
  });

  it('rejects a disallowed new execution before debit but completes and refunds its admitted predecessor after downgrade', async () => {
    const freeTier = (await catalogRepository.listTiers()).find((tier) => tier.code === 'free')!;
    const promo = await campaign(); const member = (await completion.complete(input(promo.code))).user;
    await onboarding.ensureReadyForLogin(member.id, at());
    const repository = new TypeOrmOperationsRepository(admin);
    await repository.seedDefaultPolicies(OPERATION_DEFINITIONS);
    const operations = new OperationsService(repository, creditService, transactions, {} as never, effective);
    const request = { userId: member.id, operationKey: 'variation.render', clientAttemptKey: randomUUID(),
      billingInput: { generatedVideoCount: 1 }, evidence: { kind: 'desktop_job' as const, reference: randomUUID() } };
    await catalogRepository.replaceTierPlugins(freeTier.id, { entitlementMode: 'allowlist', pluginKeys: [] });
    expect(await operations.quote(request)).toMatchObject({ canStart: false, reason: 'PLUGIN_NOT_ALLOWED' });
    await expect(operations.start(request)).rejects.toThrow('PLUGIN_NOT_ALLOWED');
    expect((await admin.query('SELECT count(*)::int AS count FROM operation_runs WHERE user_id = $1', [member.id]))[0].count).toBe(0);
    await assertOnce(member.id);
    await catalogRepository.replaceTierPlugins(freeTier.id, { entitlementMode: 'allowlist', pluginKeys: ['variation'] });
    const admitted = await operations.start(request);
    const afterDebit = (await creditService.summary(member.id, at())).spendableBalance;
    expect(afterDebit).toBe(600 - admitted.chargedCredits);
    await catalogRepository.replaceTierPlugins(freeTier.id, { entitlementMode: 'allowlist', pluginKeys: [] });
    expect(await operations.start(request)).toMatchObject({ runId: admitted.runId });
    expect((await creditService.summary(member.id, at())).spendableBalance).toBe(afterDebit);
    await operations.fail(member.id, admitted.runId);
    await operations.fail(member.id, admitted.runId);
    expect((await creditService.summary(member.id, at())).spendableBalance).toBe(600);
    // Persistent Free remains even after the signup and promotion grants expire.
    expect(await effective.resolve(member.id, new Date(Date.now() + 40 * 86_400_000))).toMatchObject({ source: 'free', tierCode: 'free' });
  });
});
