import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, provideRouter } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { Observable, Subject, of, throwError } from 'rxjs';
import { AuthApiService } from '@core/api/auth-api.service';
import { AuthService } from '@core/auth/auth.service';
import { BrowserNavigationService } from '@core/navigation/browser-navigation.service';
import type { SignupCompleteResponse, SignupPreview } from '@core/api/models';
import { SignupConsentComponent } from './signup-consent.component';
import { SIGNUP_TICKET_STORAGE_KEY } from './signup-ticket';

const PREVIEW: SignupPreview = {
  email: 'gildong@gmail.com', name: '홍길동', avatarUrl: null, isExistingUser: false, isSignupPending: false, signupPromotionCode: null, clientKind: 'web',
  documents: [{ type: 'terms', version: 'draft-2026-10' }, { type: 'privacy', version: 'draft-2026-10' }],
};
const WEB_DONE: SignupCompleteResponse = {
  clientKind: 'web', accessToken: 'access.jwt', accessTokenExpiresAt: '2026-10-08T01:00:00.000Z',
  sessionId: 'ses', user: { id: 'u1', email: 'gildong@gmail.com', name: '홍길동' }, returnPath: '/pricing?subscribe=pro_monthly',
};
const DESKTOP_DONE: SignupCompleteResponse = {
  clientKind: 'desktop', desktopRedirectUrl: 'clipperstudio-dev://auth/callback?code=c&requestId=r',
};
const httpError = (status: number, message: string) =>
  throwError(() => new HttpErrorResponse({ status, error: { statusCode: status, message } }));

interface SetupOptions {
  hash?: string;
  preview?: Observable<SignupPreview>;
  complete?: Observable<SignupCompleteResponse>;
  dialogResult?: boolean;
}

function setup(opts: SetupOptions = {}) {
  history.pushState(null, '', `/signup/consent${opts.hash ?? '#ticket=t-1'}`);
  const api = {
    previewSignup: jasmine.createSpy('previewSignup').and.returnValue(opts.preview ?? of(PREVIEW)),
    completeSignup: jasmine.createSpy('completeSignup').and.returnValue(opts.complete ?? of(WEB_DONE)),
  };
  const auth = { setToken: jasmine.createSpy('setToken'), loadSession: jasmine.createSpy('loadSession').and.resolveTo(true) };
  const navigation = { assign: jasmine.createSpy('assign') };
  const dialog = { open: jasmine.createSpy('open').and.returnValue({ afterClosed: () => of(opts.dialogResult ?? true) }) };
  TestBed.configureTestingModule({
    imports: [SignupConsentComponent],
    providers: [
      provideRouter([]),
      { provide: AuthApiService, useValue: api },
      { provide: AuthService, useValue: auth },
      { provide: BrowserNavigationService, useValue: navigation },
      { provide: MatDialog, useValue: dialog },
    ],
  });
  const router = TestBed.inject(Router);
  const navigateByUrl = spyOn(router, 'navigateByUrl').and.resolveTo(true);
  const navigate = spyOn(router, 'navigate').and.resolveTo(true);
  const fixture = TestBed.createComponent(SignupConsentComponent);
  return { fixture, api, auth, navigation, dialog, navigateByUrl, navigate };
}

async function settle(fixture: ComponentFixture<unknown>) {
  for (let i = 0; i < 3; i++) {
    fixture.detectChanges();
    await fixture.whenStable();
  }
  fixture.detectChanges();
}
const el = (f: ComponentFixture<unknown>, id: string) =>
  f.nativeElement.querySelector(`[data-testid="${id}"]`) as HTMLElement | null;
const check = (f: ComponentFixture<unknown>, id: string) =>
  (el(f, id)!.querySelector('input') as HTMLInputElement).click();
const agreeAll = (f: ComponentFixture<unknown>) => check(f, 'agree-all');

const DRAFT_KEY = 'clipper_signup_promotion_draft';
function enterPromotion(fixture: ComponentFixture<unknown>, value: string): HTMLInputElement | null {
  const input = fixture.nativeElement.querySelector('[data-testid="promotion-code"]') as HTMLInputElement | null;
  expect(input).not.toBeNull();
  if (input) { input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); fixture.detectChanges(); }
  return input;
}

describe('SignupConsentComponent', () => {
  afterEach(() => {
    sessionStorage.clear();
    history.pushState(null, '', '/');
  });

  it('offers an optional code to new signups and submits the normalized code only after consent', async () => {
    const { fixture, api, auth } = setup();
    await settle(fixture);
    const input = enterPromotion(fixture, '  booth-26  ');
    expect(input?.value).toBe('BOOTH-26');
    expect(api.completeSignup).not.toHaveBeenCalled();
    agreeAll(fixture); await settle(fixture);
    el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBe('BOOTH-26');
    expect(auth.loadSession).toHaveBeenCalledTimes(1);
    expect(sessionStorage.getItem(DRAFT_KEY)).toBeNull();
  });

  it('offers login recovery after the same ticket and code retry follows session response loss', async () => {
    const { fixture, api, navigateByUrl } = setup(); await settle(fixture);
    api.completeSignup.and.returnValues(httpError(503, 'session_unavailable'), httpError(409, 'SIGNUP_ALREADY_COMPLETED'));
    enterPromotion(fixture, 'BOOTH26'); agreeAll(fixture); await settle(fixture);
    el(fixture, 'submit')!.click(); await settle(fixture);
    el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBe('BOOTH26');
    expect(el(fixture, 'submit')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('가입과 혜택 지급이 완료되었어요');
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBeNull();
    el(fixture, 'restart')?.click(); await settle(fixture);
    expect(navigateByUrl).toHaveBeenCalledWith('/login');
  });

  it('restores the actual applied code and offers an explicit completion action after an edit', async () => {
    const { fixture, api } = setup(); await settle(fixture);
    api.completeSignup.and.returnValues(throwError(() => new HttpErrorResponse({ status: 409,
      error: { message: 'SIGNUP_PROMOTION_ALREADY_APPLIED', appliedPromotionCode: 'CODE-A' } })), of(WEB_DONE));
    enterPromotion(fixture, 'CODE-B'); agreeAll(fixture); await settle(fixture);
    el(fixture, 'submit')!.click(); await settle(fixture);
    expect((el(fixture, 'promotion-code') as HTMLInputElement)?.value).toBe('CODE-A');
    expect((el(fixture, 'promotion-code') as HTMLInputElement)?.readOnly).toBeTrue();
    expect(el(fixture, 'submit')?.textContent).toContain('적용된 혜택으로 가입 완료');
    el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBe('CODE-A');
  });

  it('omits an empty optional code', async () => {
    const { fixture, api } = setup(); await settle(fixture);
    enterPromotion(fixture, '   '); agreeAll(fixture); await settle(fixture);
    el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBeUndefined();
  });

  it('does not offer or send signup codes for an existing member requiring consent', async () => {
    sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ ticket: 't-1', code: 'STALE' }));
    const { fixture, api } = setup({ preview: of({ ...PREVIEW, isExistingUser: true }) });
    await settle(fixture);
    expect(el(fixture, 'promotion-code')).toBeNull();
    expect(sessionStorage.getItem(DRAFT_KEY)).toBeNull();
    agreeAll(fixture); await settle(fixture); el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBeUndefined();
  });

  it('prefills the server code only for its unfinished new signup', async () => {
    const pending = { ...PREVIEW, isExistingUser: true, isSignupPending: true, signupPromotionCode: 'SERVER26' };
    const { fixture } = setup({ preview: of(pending) }); await settle(fixture);
    expect((el(fixture, 'promotion-code') as HTMLInputElement | null)?.value).toBe('SERVER26');
    expect(fixture.nativeElement.textContent).toContain('가입을 완료해 주세요');
  });

  it('keeps cap failures editable for correction and removal without logging in early', async () => {
    const { fixture, api, auth, navigateByUrl } = setup(); await settle(fixture);
    api.completeSignup.and.returnValues(httpError(409, 'PROMOTION_LIMIT_REACHED'), httpError(409, 'PROMOTION_INACTIVE'), of(WEB_DONE));
    enterPromotion(fixture, 'FULL26'); agreeAll(fixture); await settle(fixture);
    el(fixture, 'submit')!.click(); await settle(fixture);
    expect((el(fixture, 'promotion-code') as HTMLInputElement | null)?.value).toBe('FULL26');
    expect(fixture.nativeElement.querySelector('[role="alert"]')?.textContent).toContain('등록 가능 인원');
    expect(auth.setToken).not.toHaveBeenCalled(); expect(navigateByUrl).not.toHaveBeenCalled();
    enterPromotion(fixture, 'OTHER26'); el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBe('OTHER26');
    enterPromotion(fixture, ''); el(fixture, 'submit')!.click(); await settle(fixture);
    expect(api.completeSignup.calls.mostRecent().args[0].promotionCode).toBeUndefined();
    expect(auth.loadSession).toHaveBeenCalledTimes(1);
  });

  it('preserves a processing response and blocks duplicate submits while the request is pending', async () => {
    const pending = new Subject<SignupCompleteResponse>();
    const { fixture, api, auth, navigateByUrl } = setup({ complete: pending }); await settle(fixture);
    enterPromotion(fixture, 'BOOTH26'); agreeAll(fixture); await settle(fixture);
    el(fixture, 'submit')!.click(); fixture.detectChanges(); el(fixture, 'submit')!.click();
    expect(api.completeSignup).toHaveBeenCalledTimes(1);
    expect((el(fixture, 'promotion-code') as HTMLInputElement | null)?.disabled).toBeTrue();
    pending.error(new HttpErrorResponse({ status: 503, error: { message: 'SIGNUP_BENEFITS_PROCESSING' } }));
    await settle(fixture);
    expect(fixture.nativeElement.querySelector('[role="alert"]')?.textContent).toContain('가입 혜택을 처리하고');
    expect((el(fixture, 'promotion-code') as HTMLInputElement | null)?.value).toBe('BOOTH26');
    expect(auth.setToken).not.toHaveBeenCalled(); expect(navigateByUrl).not.toHaveBeenCalled();
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBe('t-1');
  });

  it('restores the same-ticket draft on refresh and remembers removal over a pending server code', async () => {
    let result = setup(); await settle(result.fixture); enterPromotion(result.fixture, 'BOOTH26'); result.fixture.destroy();
    TestBed.resetTestingModule();
    result = setup({ hash: '' }); await settle(result.fixture);
    expect((el(result.fixture, 'promotion-code') as HTMLInputElement | null)?.value).toBe('BOOTH26');
    enterPromotion(result.fixture, ''); result.fixture.destroy(); TestBed.resetTestingModule();
    result = setup({ hash: '', preview: of({ ...PREVIEW, isExistingUser: true, isSignupPending: true, signupPromotionCode: 'SERVER26' }) });
    await settle(result.fixture);
    expect((el(result.fixture, 'promotion-code') as HTMLInputElement | null)?.value).toBe('');
    expect(result.api.completeSignup).not.toHaveBeenCalled();
  });

  it('clears an old-account draft for a new ticket and uses only that pending signup server code', async () => {
    let result = setup(); await settle(result.fixture); enterPromotion(result.fixture, 'OLD26'); result.fixture.destroy(); TestBed.resetTestingModule();
    result = setup({ hash: '#ticket=t-other', preview: of({ ...PREVIEW, email: 'other@example.com', isExistingUser: true, isSignupPending: true, signupPromotionCode: 'NEW26' }) });
    await settle(result.fixture);
    expect((el(result.fixture, 'promotion-code') as HTMLInputElement | null)?.value).toBe('NEW26');
    expect(sessionStorage.getItem(DRAFT_KEY)).toBeNull();
    expect(result.api.completeSignup).not.toHaveBeenCalled();
  });

  it('ignores a late preview from an abandoned account instead of clearing the new account draft', async () => {
    const oldPreview = new Subject<SignupPreview>();
    const first = setup({ preview: oldPreview }); first.fixture.detectChanges(); first.fixture.destroy();
    TestBed.resetTestingModule();
    const next = setup({ hash: '#ticket=next-account' }); await settle(next.fixture);
    enterPromotion(next.fixture, 'NEW26');
    oldPreview.next({ ...PREVIEW, isExistingUser: true }); oldPreview.complete();
    await settle(next.fixture);
    expect(JSON.parse(sessionStorage.getItem(DRAFT_KEY) ?? '{}')).toEqual({ ticket: 'next-account', code: 'NEW26' });
  });

  it('does not consume a late completion after leaving for another signup account', async () => {
    const pending = new Subject<SignupCompleteResponse>();
    const first = setup({ complete: pending }); await settle(first.fixture);
    enterPromotion(first.fixture, 'OLD26'); agreeAll(first.fixture); await settle(first.fixture);
    el(first.fixture, 'submit')!.click(); first.fixture.destroy(); TestBed.resetTestingModule();
    const next = setup({ hash: '#ticket=next-account' }); await settle(next.fixture);
    enterPromotion(next.fixture, 'NEW26');
    pending.next(WEB_DONE); pending.complete(); await settle(next.fixture);
    expect(first.auth.setToken).not.toHaveBeenCalled(); expect(first.navigateByUrl).not.toHaveBeenCalled();
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBe('next-account');
    expect(JSON.parse(sessionStorage.getItem(DRAFT_KEY) ?? '{}')).toEqual({ ticket: 'next-account', code: 'NEW26' });
  });

  for (const action of ['cancel', 'under14']) {
    it(`clears the optional draft on ${action}`, async () => {
      const { fixture } = setup(); await settle(fixture); enterPromotion(fixture, 'BOOTH26');
      el(fixture, action)!.click(); await settle(fixture);
      expect(sessionStorage.getItem(DRAFT_KEY)).toBeNull();
    });
  }

  for (const [status, code] of [[401, 'signup_ticket_invalid'], [409, 'signup_ticket_used']] as const) {
    it(`clears the optional draft when submit rejects the ticket: ${code}`, async () => {
      const { fixture } = setup({ complete: httpError(status, code) }); await settle(fixture);
      enterPromotion(fixture, 'BOOTH26'); agreeAll(fixture); await settle(fixture);
      el(fixture, 'submit')!.click(); await settle(fixture);
      expect(fixture.nativeElement.textContent).toContain('다시 로그인해 주세요');
      expect(sessionStorage.getItem(DRAFT_KEY)).toBeNull();
    });
  }

  for (const [code, message] of [
    ['PROMOTION_CODE_INVALID', '코드 형식'], ['PROMOTION_CODE_NOT_FOUND', '코드를 찾을 수'],
    ['PROMOTION_INACTIVE', '지금 등록할 수'], ['PROMOTION_ENDED', '등록 기간이 종료'],
    ['PROMOTION_NOT_STARTED', '아직 시작되지'], ['PROMOTION_SIGNUP_CREDITS_REQUIRED', '가입 크레딧 코드'],
    ['PROMOTION_HISTORY_INELIGIBLE_PAID', '유료 이용권'], ['PROMOTION_HISTORY_INELIGIBLE_ADMIN_PLAN', '관리자 지급'],
    ['SIGNUP_PROMOTION_NEW_MEMBERS_ONLY', '신규 회원'],
  ]) {
    it(`explains ${code} without issuing a session`, async () => {
      const { fixture, auth } = setup({ complete: httpError(409, code) }); await settle(fixture);
      enterPromotion(fixture, 'BOOTH26'); agreeAll(fixture); await settle(fixture);
      el(fixture, 'submit')!.click(); await settle(fixture);
      expect(fixture.nativeElement.querySelector('[role="alert"]')?.textContent).toContain(message);
      expect(auth.setToken).not.toHaveBeenCalled();
    });
  }

  it('keeps the submit button off until all three required items are agreed', async () => {
    const { fixture } = setup();
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('가입을 완료해 주세요');
    const submit = el(fixture, 'submit') as HTMLButtonElement;
    check(fixture, 'agree-age');
    check(fixture, 'agree-terms');
    await settle(fixture);
    expect(submit.disabled).toBeTrue();
    check(fixture, 'agree-privacy');
    await settle(fixture);
    expect(submit.disabled).toBeFalse();
  });

  it('completes a web signup and returns to where the login started', async () => {
    const { fixture, api, auth, navigateByUrl } = setup();
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    expect(api.completeSignup).toHaveBeenCalledWith({
      ticket: 't-1', ageOver14: true, termsVersion: 'draft-2026-10', privacyVersion: 'draft-2026-10',
    });
    expect(auth.setToken).toHaveBeenCalledWith('access.jwt');
    expect(auth.loadSession).toHaveBeenCalled();
    expect(navigateByUrl).toHaveBeenCalledWith('/pricing?subscribe=pro_monthly');
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBeNull();
  });

  it('opens the desktop app after a desktop signup', async () => {
    const { fixture, navigation } = setup({ complete: of(DESKTOP_DONE) });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('클리퍼 앱으로 돌아가세요');
    expect(fixture.nativeElement.querySelector('.hint')?.textContent).toContain(
      '앱에서 로그인을 다시 시작하라는 안내가 나오면 앱에서 로그인을 한 번 더 눌러 주세요. 동의는 이미 저장돼서 바로 로그인돼요.',
    );
    expect(navigation.assign).toHaveBeenCalledWith(DESKTOP_DONE.desktopRedirectUrl);
  });

  it('opens the desktop app again from the button when the browser blocked the first attempt', async () => {
    const { fixture, navigation } = setup({ complete: of(DESKTOP_DONE) });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    el(fixture, 'open-app')!.click();
    expect(navigation.assign).toHaveBeenCalledTimes(2);
    expect(navigation.assign.calls.mostRecent().args[0]).toBe(DESKTOP_DONE.desktopRedirectUrl);
  });

  it('submits once while the first request is pending', async () => {
    const pending = new Subject<SignupCompleteResponse>();
    const { fixture, api, navigateByUrl } = setup({ complete: pending });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    fixture.detectChanges();
    el(fixture, 'submit')!.click();
    expect(api.completeSignup).toHaveBeenCalledTimes(1);
    pending.next(WEB_DONE);
    pending.complete();
    await settle(fixture);
    expect(navigateByUrl).toHaveBeenCalledWith('/pricing?subscribe=pro_monthly');
    expect(fixture.nativeElement.textContent).not.toContain('다시 로그인해 주세요');
  });

  it('locks the other controls while the request is pending so a late success cannot contradict a cancel', async () => {
    const pending = new Subject<SignupCompleteResponse>();
    const { fixture, api, navigate, navigateByUrl } = setup({ complete: pending });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    const input = (id: string) => el(fixture, id)!.querySelector('input') as HTMLInputElement;
    expect((el(fixture, 'cancel') as HTMLButtonElement).disabled).toBeTrue();
    expect((el(fixture, 'under14') as HTMLButtonElement).disabled).toBeTrue();
    for (const id of ['agree-all', 'agree-age', 'agree-terms', 'agree-privacy']) expect(input(id).disabled).toBeTrue();
    expect((el(fixture, 'view-terms') as HTMLButtonElement).disabled).toBeTrue();
    expect((el(fixture, 'view-privacy') as HTMLButtonElement).disabled).toBeTrue();
    expect(fixture.nativeElement.querySelector('[data-testid="submit"] mat-progress-spinner')).not.toBeNull();

    el(fixture, 'cancel')!.click();
    el(fixture, 'under14')!.click();
    const component = fixture.componentInstance as unknown as { cancel(): void; showUnder14(): void };
    component.cancel();
    component.showUnder14();
    await settle(fixture);
    expect(navigate).not.toHaveBeenCalled();
    expect(fixture.nativeElement.textContent).not.toContain('만 14세 미만은 가입할 수 없어요');
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBe('t-1');

    pending.next(WEB_DONE);
    pending.complete();
    await settle(fixture);
    expect(api.completeSignup).toHaveBeenCalledTimes(1);
    expect(navigateByUrl).toHaveBeenCalledWith('/pricing?subscribe=pro_monthly');
  });

  it('unlocks the controls again when the request fails', async () => {
    const { fixture } = setup({ complete: httpError(500, 'internal') });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    expect((el(fixture, 'cancel') as HTMLButtonElement).disabled).toBeFalse();
    expect((el(fixture, 'under14') as HTMLButtonElement).disabled).toBeFalse();
    expect((el(fixture, 'agree-all')!.querySelector('input') as HTMLInputElement).disabled).toBeFalse();
    expect(fixture.nativeElement.querySelector('[data-testid="submit"] mat-progress-spinner')).toBeNull();
  });

  it('turns an expired ticket at submit into the re-login screen, not an error', async () => {
    const { fixture } = setup({ complete: httpError(401, 'signup_ticket_invalid') });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('다시 로그인해 주세요');
    expect(fixture.nativeElement.querySelector('[role="alert"]')).toBeNull();
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBeNull();
  });

  it('reloads the documents and asks again when the version changed meanwhile', async () => {
    const { fixture, api } = setup({ complete: httpError(409, 'consent_version_outdated') });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    el(fixture, 'submit')!.click();
    await settle(fixture);
    expect(api.previewSignup).toHaveBeenCalledTimes(2);
    expect((el(fixture, 'submit') as HTMLButtonElement).disabled).toBeTrue();
    expect(fixture.nativeElement.querySelector('[role="alert"]')?.textContent).toContain('약관이 방금 바뀌었어요');
  });

  it('stops at the under-14 screen without sending anything', async () => {
    const { fixture, api } = setup();
    await settle(fixture);
    el(fixture, 'under14')!.click();
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('만 14세 미만은 가입할 수 없어요');
    expect(api.completeSignup).not.toHaveBeenCalled();
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBeNull();
  });

  it('shows the re-login screen without a ticket and never calls the API', async () => {
    const { fixture, api } = setup({ hash: '' });
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('다시 로그인해 주세요');
    expect(api.previewSignup).not.toHaveBeenCalled();
  });

  it('shows the re-login screen when the preview says the ticket is invalid', async () => {
    const { fixture } = setup({ preview: httpError(401, 'signup_ticket_invalid') });
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('다시 로그인해 주세요');
  });

  it('keeps the ticket and offers a retry when the preview fails for a non-auth reason', async () => {
    const { fixture, api } = setup({ preview: httpError(500, 'internal') });
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('정보를 불러오지 못했어요');
    expect(fixture.nativeElement.textContent).not.toContain('다시 로그인해 주세요');
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBe('t-1');
    api.previewSignup.and.returnValue(of(PREVIEW));
    el(fixture, 'retry')!.click();
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('가입을 완료해 주세요');
    expect(api.previewSignup).toHaveBeenCalledTimes(2);
  });

  it('keeps the ticket and offers a retry when the preview reload after a version change fails', async () => {
    const { fixture, api } = setup({ complete: httpError(409, 'consent_version_outdated') });
    await settle(fixture);
    agreeAll(fixture);
    await settle(fixture);
    api.previewSignup.and.returnValue(httpError(500, 'internal'));
    el(fixture, 'submit')!.click();
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('정보를 불러오지 못했어요');
    expect(fixture.nativeElement.textContent).not.toContain('다시 로그인해 주세요');
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBe('t-1');
  });

  it('checks an item when its document is agreed in the popup', async () => {
    const { fixture, dialog } = setup({ dialogResult: true });
    await settle(fixture);
    el(fixture, 'view-terms')!.click();
    await settle(fixture);
    expect(dialog.open).toHaveBeenCalled();
    expect((el(fixture, 'agree-terms')!.querySelector('input') as HTMLInputElement).checked).toBeTrue();
  });

  it('uses the re-consent wording for an existing account', async () => {
    const { fixture } = setup({ preview: of({ ...PREVIEW, isExistingUser: true }) });
    await settle(fixture);
    expect(fixture.nativeElement.textContent).toContain('계속하려면 동의가 필요해요');
    expect(el(fixture, 'submit')!.textContent).toContain('동의하고 계속하기');
  });

  it('cancels back to the login page with a notice and forgets the ticket', async () => {
    const { fixture, navigate } = setup();
    await settle(fixture);
    el(fixture, 'cancel')!.click();
    expect(navigate).toHaveBeenCalledWith(['/login'], { queryParams: { signup: 'cancelled' } });
    expect(sessionStorage.getItem(SIGNUP_TICKET_STORAGE_KEY)).toBeNull();
  });
});
