import type { MigrationInterface, QueryRunner } from 'typeorm';

export class AddOnboardingClaimGeneration1793664000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE user_onboarding_jobs ADD COLUMN claim_generation integer NOT NULL DEFAULT 0`);
  }
  async down(queryRunner: QueryRunner): Promise<void> {
    const rows = await queryRunner.query(`SELECT EXISTS (SELECT 1 FROM user_onboarding_jobs WHERE claim_generation > 0) AS present`);
    if (rows[0]?.present) throw new Error('ONBOARDING_CLAIM_ROLLBACK_HAS_DATA');
    await queryRunner.query(`ALTER TABLE user_onboarding_jobs DROP COLUMN claim_generation`);
  }
}
