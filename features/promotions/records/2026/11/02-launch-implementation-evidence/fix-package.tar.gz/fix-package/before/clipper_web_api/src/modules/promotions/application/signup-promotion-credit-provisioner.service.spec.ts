import { SignupPromotionCreditProvisioner } from './signup-promotion-credit-provisioner.service.js';

const at = new Date('2026-11-02T00:00:00Z');
function setup() {
  const campaign = { id: 'campaign', benefitKind: 'signup_credits', creditAmount: 200,
    creditValidityDays: 30, status: 'active', startsAt: new Date('2026-11-01'),
    endsAt: new Date('2026-11-10'), historyExclusions: [], maxRedemptionsPerCode: 2 };
  const code = { id: 'code', code: 'BOOTH2026', isActive: true };
  const promotions = { bind: () => promotions,
    lockCodeAndCampaign: jest.fn(async () => ({ campaign, code })),
    memberHistory: jest.fn(async () => ({ paid: false, admin_plan: false, sameCampaign: false, sameCode: false })),
    countCodeRedemptions: jest.fn(async () => 0),
    createRedemption: jest.fn(async (input) => input), incrementCount: jest.fn(),
  };
  const credits = { bind: () => credits,
    findGrantByIdempotencyKey: jest.fn(async () => undefined),
    createGrant: jest.fn(async (input) => ({ id: 'bonus', ...input })), appendLedger: jest.fn(),
  };
  const access = { bind: () => access, withUserLock: jest.fn(async (_id, work) => work()) };
  const transactions = { run: jest.fn(async (work) => work({})) };
  const service = new SignupPromotionCreditProvisioner(promotions as never, access as never, credits as never, transactions as never);
  return { service, promotions, credits, access, transactions, campaign };
}

describe('SignupPromotionCreditProvisioner', () => {
  it('creates one promotion credit grant and ledger without an access pass or monthly schedule', async () => {
    const t = setup();
    await t.service.ensureForUser('new-member', 'booth2026', at);
    expect(t.promotions.lockCodeAndCampaign).toHaveBeenCalledWith('BOOTH2026');
    expect(t.credits.createGrant).toHaveBeenCalledWith(expect.objectContaining({
      userId: 'new-member', source: 'promotion', initialCredits: 200, remainingCredits: 200,
      accessGrantId: null, subscriptionId: null, paymentOrderId: null,
      expiresAt: new Date('2026-12-02T00:00:00Z'), idempotencyKey: 'signup-promotion:new-member',
      promotionRedemptionId: expect.any(String),
    }));
    expect(t.credits.appendLedger).toHaveBeenCalledWith(expect.objectContaining({
      creditGrantId: 'bonus', deltaCredits: 200, referenceKey: 'signup-promotion:new-member',
    }));
    expect(t.promotions.incrementCount).toHaveBeenCalledWith('campaign');
  });

  it('returns the committed grant on retry even when the code has since expired or changed', async () => {
    const t = setup();
    t.credits.findGrantByIdempotencyKey.mockResolvedValue({ id: 'committed' } as never);
    await expect(t.service.ensureForUser('new-member', 'OTHER-CODE', at)).resolves.toEqual({ id: 'committed' });
    expect(t.promotions.lockCodeAndCampaign).not.toHaveBeenCalled();
    expect(t.credits.createGrant).not.toHaveBeenCalled();
  });

  it('rechecks the locked code cap before any grant', async () => {
    const t = setup();
    t.promotions.countCodeRedemptions.mockResolvedValue(2);
    await expect(t.service.ensureForUser('new-member', 'BOOTH2026', at)).rejects.toThrow('PROMOTION_LIMIT_REACHED');
    expect(t.credits.createGrant).not.toHaveBeenCalled();
  });

  it('cannot issue an access campaign as a signup bonus', async () => {
    const t = setup();
    t.campaign.benefitKind = 'access';
    await expect(t.service.ensureForUser('new-member', 'BOOTH2026', at)).rejects.toThrow('PROMOTION_SIGNUP_CREDITS_REQUIRED');
    expect(t.credits.createGrant).not.toHaveBeenCalled();
  });
});
