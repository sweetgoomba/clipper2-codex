export type UserOnboardingJobKind = 'free_trial_provisioning';

export type UserOnboardingJobStatus =
  | 'pending'
  | 'processing'
  | 'retryable_failed'
  | 'completed'
  | 'manual_review';

export interface UserOnboardingJob {
  id: string;
  userId: string;
  signupTicketId: string | null;
  promotionCode: string | null;
  kind: UserOnboardingJobKind;
  status: UserOnboardingJobStatus;
  attemptCount: number;
  claimGeneration: number;
  nextAttemptAt: Date;
  leaseUntil: Date | null;
  lastErrorCode: string | null;
  completedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}
