import { ConflictException, Injectable, ServiceUnavailableException } from '@nestjs/common';
import { AdminTransactionRunner } from '../../../core/database/admin-transaction.runner.js';
import { SignupPromotionCreditProvisioner } from '../../promotions/application/signup-promotion-credit-provisioner.service.js';
import type { UserOnboardingJob } from '../../users/domain/user-onboarding-job.model.js';
import { UserOnboardingJobsRepository } from '../../users/domain/user-onboarding-jobs.repository.js';
import { FreeTrialProvisioner } from './free-trial-provisioner.service.js';

const JOB_KIND = 'free_trial_provisioning' as const;
const LEASE_MS = 5 * 60_000;
const RETRY_DELAYS_MS = [
  60_000,
  5 * 60_000,
  30 * 60_000,
  2 * 60 * 60_000,
  12 * 60 * 60_000,
] as const;
const SAFE_ERROR_CODE = 'FREE_TRIAL_PROVISIONING_FAILED';

@Injectable()
export class FreeTrialOnboardingService {
  constructor(
    private readonly jobs: UserOnboardingJobsRepository,
    private readonly provisioner: FreeTrialProvisioner,
    private readonly promotion: SignupPromotionCreditProvisioner,
    private readonly transactions: AdminTransactionRunner,
  ) {}

  async pendingSignup(userId: string): Promise<UserOnboardingJob | undefined> {
    const job = await this.jobs.findByUserAndKind(userId, JOB_KIND);
    return job?.signupTicketId && job.status !== 'completed' ? job : undefined;
  }

  async ensureReadyForLogin(userId: string, at: Date): Promise<void> {
    await this.repairForUser(userId, at);
    const job = await this.jobs.findByUserAndKind(userId, JOB_KIND);
    if (job?.status === 'completed') return;
    if (job?.lastErrorCode?.startsWith('PROMOTION_')) throw new ConflictException(job.lastErrorCode);
    throw new ServiceUnavailableException('SIGNUP_BENEFITS_PROCESSING');
  }

  claimDue(at: Date, limit: number): Promise<UserOnboardingJob[]> {
    return this.jobs.claimDue(
      JOB_KIND,
      at,
      new Date(at.getTime() + LEASE_MS),
      limit,
    );
  }

  async repairForUser(userId: string, at: Date): Promise<boolean> {
    const job = await this.jobs.claimForUser(
      userId,
      JOB_KIND,
      at,
      new Date(at.getTime() + LEASE_MS),
    );
    if (!job) return false;
    await this.process(job, at);
    return true;
  }

  async process(job: UserOnboardingJob, at: Date): Promise<void> {
    try {
      if (job.promotionCode) {
        await this.transactions.run(async (manager) => {
          await this.provisioner.ensureForUser(job.userId, at, manager);
          await this.promotion.ensureForUser(job.userId, job.promotionCode!, at, manager);
        });
      } else {
        await this.provisioner.ensureForUser(job.userId, at);
      }
      await this.jobs.markCompleted(job.id, job.attemptCount, at);
    } catch (error) {
      const errorCode = safeProvisioningError(error);
      if (job.attemptCount >= 6) {
        await this.jobs.markManualReview(
          job.id,
          job.attemptCount,
          errorCode,
          at,
        );
        return;
      }
      const delay = RETRY_DELAYS_MS[job.attemptCount - 1];
      await this.jobs.markRetryableFailed(
        job.id,
        job.attemptCount,
        new Date(at.getTime() + delay),
        errorCode,
        at,
      );
    }
  }
}

function safeProvisioningError(error: unknown): string {
  const code = error instanceof Error ? error.message : '';
  return /^PROMOTION_(CODE_INVALID|CODE_NOT_FOUND|SIGNUP_CREDITS_REQUIRED|CODE_ALREADY_REDEEMED|ALREADY_REDEEMED|INACTIVE|ENDED|NOT_STARTED|LIMIT_REACHED|HISTORY_INELIGIBLE_PAID|HISTORY_INELIGIBLE_ADMIN_PLAN)$/.test(code)
    ? code : SAFE_ERROR_CODE;
}
