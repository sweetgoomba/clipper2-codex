import { AddSignupBenefitIntent1793577600000 } from './migrations/user/1793577600000-AddSignupBenefitIntent.js';
import 'reflect-metadata';
import 'dotenv/config'; // migration CLI runs outside Nest, so load .env into process.env
import { DataSource } from 'typeorm';
import { UserEntity } from '../../modules/users/infrastructure/user.entity.js';
import { DesktopAuthCodeEntity } from '../../modules/auth/infrastructure/desktop-auth-code.entity.js';
import { UserSessionEntity } from '../../modules/auth/infrastructure/user-session.entity.js';
import { UserOnboardingJobEntity } from '../../modules/users/infrastructure/user-onboarding-job.entity.js';
import { CreateUsers1717800000000 } from './migrations/user/1717800000000-CreateUsers.js';
import { CreateAuthSessions1720310400000 } from './migrations/user/1720310400000-CreateAuthSessions.js';
import { AddUserSessionDevicePrivacyFields1783650000000 } from './migrations/user/1783650000000-AddUserSessionDevicePrivacyFields.js';
import { AddAuthCodePurpose1783960000000 } from './migrations/user/1783960000000-AddAuthCodePurpose.js';
import { CreateReferenceAnalysisReplays1785400000000 } from './migrations/user/1785400000000-CreateReferenceAnalysisReplays.js';
import { CreateShortformDirectorAiVideoJobs1786000000000 } from './migrations/user/1786000000000-CreateShortformDirectorAiVideoJobs.js';
import { CreateShortformDirectorAiImageJobs1786100000000 } from './migrations/user/1786100000000-CreateShortformDirectorAiImageJobs.js';
import { DropShortformDirectorGeneratedMediaJobs1787800000000 } from './migrations/user/1787800000000-DropShortformDirectorGeneratedMediaJobs.js';
import { CreateUserOnboardingJobs1788200000000 } from './migrations/user/1788200000000-CreateUserOnboardingJobs.js';
import { AddDesktopLoginBinding1789600000000 } from './migrations/user/1789600000000-AddDesktopLoginBinding.js';
import { UserConsentEntity } from '../../modules/consents/infrastructure/user-consent.entity.js';
import { SignupTicketRedemptionEntity } from '../../modules/auth/infrastructure/signup-ticket-redemption.entity.js';
import { CreateSignupConsentTables1789700000000 } from './migrations/user/1789700000000-CreateSignupConsentTables.js';
import { ReferenceAnalysisReplayEntity } from '../../modules/shortform-director-reference-analysis/infrastructure/reference-analysis-replay.entity.js';
import { DB_CONNECTIONS } from './connections/index.js';
import { resolveDbConnection } from './db-config.js';

const userDef = DB_CONNECTIONS.find((c) => c.name === 'user')!;

export default new DataSource({
  ...resolveDbConnection(userDef),
  entities: [
    UserEntity,
    UserSessionEntity,
    DesktopAuthCodeEntity,
    ReferenceAnalysisReplayEntity,
    UserOnboardingJobEntity,
    UserConsentEntity,
    SignupTicketRedemptionEntity,
  ],
  migrations: [
    AddSignupBenefitIntent1793577600000,
    CreateUsers1717800000000,
    CreateAuthSessions1720310400000,
    AddUserSessionDevicePrivacyFields1783650000000,
    AddAuthCodePurpose1783960000000,
    CreateReferenceAnalysisReplays1785400000000,
    CreateShortformDirectorAiVideoJobs1786000000000,
    CreateShortformDirectorAiImageJobs1786100000000,
    DropShortformDirectorGeneratedMediaJobs1787800000000,
    CreateUserOnboardingJobs1788200000000,
    AddDesktopLoginBinding1789600000000,
    CreateSignupConsentTables1789700000000,
  ],
});
