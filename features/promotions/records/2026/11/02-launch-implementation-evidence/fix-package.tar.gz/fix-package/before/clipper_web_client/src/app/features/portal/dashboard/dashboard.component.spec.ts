import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { provideRouter } from '@angular/router';
import { of, Subject, throwError } from 'rxjs';
import { TemplateRef } from '@angular/core';
import { AccessApiService } from '@core/api/access-api.service';
import { CatalogApiService } from '@core/api/catalog-api.service';
import type {
  CatalogTier,
  CreditSummary,
  CurrentAccessResponse,
  CurrentSubscriptionPaymentMethod,
  Subscription,
  SubscriptionPlanChangeQuote,
  SubscriptionPlanChangeResult,
} from '@core/api/models';
import { CreditsApiService } from '@core/api/credits-api.service';
import { PaymentsApiService } from '@core/api/payments-api.service';
import { PromotionsApiService, type MemberPromotion, type MemberPromotionRevocationNotice } from '@core/api/promotions-api.service';
import { TossPaymentsSdkService } from '@core/payments/toss-payments-sdk.service';
import { ConfirmDialogComponent } from '@shared/ui/confirm-dialog/confirm-dialog.component';
import { DashboardComponent } from './dashboard.component';

describe('DashboardComponent', () => {
  const activeAccess: CurrentAccessResponse = {
    access: {
      tierId: 'tier-pro',
      tierCode: 'pro',
      tierName: 'Pro',
      source: 'subscription',
      entitlementMode: 'all',
      allowedPluginKeys: [
        'shortform_url',
        'shortform_paste',
        'shortform_prompt',
        'dialog_highlight',
        'dance_highlight',
        'variation',
      ],
      spendableCreditSources: [
        'subscription',
        'topup',
        'admin_adjustment',
        'promotion',
        'free_trial',
      ],
    },
  };
  const summary: CreditSummary = {
    heldBalance: 850,
    spendableBalance: 850,
    bySource: [
      { source: 'subscription', credits: 750 },
      { source: 'topup', credits: 100 },
    ],
  };
  const subscription: Subscription = {
    id: 'subscription-1',
    billingProductId: 'product-1',
    billingProductCode: 'pro_monthly',
    productName: 'Pro 월간',
    planTierId: 'tier-pro',
    planTierCode: 'pro',
    priceKrw: 39_900,
    billingIntervalMonths: 1,
    monthlyCredits: 1_000,
    monthlyCreditValidityDays: null,
    status: 'active',
    currentPeriodStart: '2000-01-01T00:00:00.000Z',
    currentPeriodEnd: '2100-01-01T00:00:00.000Z',
    nextBillingAt: '2026-09-01T00:00:00.000Z',
    cancelAt: null,
    firstPaymentFailedAt: null,
    graceEndsAt: null,
    retryAt: null,
    refundProcessing: false,
    refundEndAt: null,
    refundEndMode: null,
    nextBillingStopped: false,
    scheduledChange: null,
  };
  const immediateQuote: SubscriptionPlanChangeQuote = {
    kind: 'immediate_charge',
    quoteOrderId: `upgrade_${'a'.repeat(56)}`,
    currentProductName: 'Basic 월간',
    targetProductCode: 'pro_monthly',
    targetProductName: 'Pro 월간',
    amountKrw: 19_984,
    targetPriceKrw: 39_900,
    targetBillingIntervalMonths: 1,
    targetMonthlyCredits: 1_000,
    creditDelta: 1_000,
    periodDifferenceKrw: 15_984,
    creditDifferenceKrw: 19_984,
    selectedBasis: 'credits',
    effectiveAt: '2026-08-21T04:00:00.000Z',
    expiresAt: '2026-08-21T04:05:00.000Z',
  };
  const scheduledQuote: SubscriptionPlanChangeQuote = {
    kind: 'scheduled',
    quoteOrderId: null,
    currentProductName: 'Pro 월간',
    targetProductCode: 'pro_yearly',
    targetProductName: 'Pro 연간',
    amountKrw: 0,
    targetPriceKrw: 382_900,
    targetBillingIntervalMonths: 12,
    targetMonthlyCredits: 1_000,
    creditDelta: 0,
    periodDifferenceKrw: null,
    creditDifferenceKrw: null,
    selectedBasis: null,
    effectiveAt: '2026-09-01T00:00:00.000Z',
    expiresAt: null,
  };
  const immediateResult: SubscriptionPlanChangeResult = {
    kind: 'immediate_charge',
    subscription,
    payment: {
      productName: 'Pro 월간',
      amountKrw: 19_984,
      orderId: `upgrade_${'a'.repeat(56)}`,
      paidAt: '2026-08-21T04:00:05.000Z',
    },
  };
  const currentPaymentMethod: CurrentSubscriptionPaymentMethod = {
    paymentMethod: {
      method: 'CARD',
      cardIssuerCode: '11',
      cardNumberMasked: '1234-****-****-5678',
      cardType: '신용',
      verifiedAt: '2026-08-13T06:30:00.000Z',
    },
    fresh: true,
    changeAllowed: true,
    changeBlockedReason: null,
    renewalConsent: null,
  };
  const catalog: CatalogTier[] = [
    {
      id: 'tier-basic', code: 'basic', name: 'Basic', description: null, sortOrder: 10,
      monthlyCredits: 400, monthlyCreditValidityDays: null,
      entitlementMode: 'allowlist', upgradeRank: 10,
      signupBenefit: null, plugins: [], pluginKeys: [
        'shortform_url', 'shortform_paste', 'shortform_prompt',
        'dialog_highlight', 'dance_highlight',
      ], isActive: true,
      createdAt: '2026-08-01T00:00:00.000Z', updatedAt: '2026-08-01T00:00:00.000Z',
      products: [
        {
          id: 'basic-monthly', code: 'basic_monthly', tierId: 'tier-basic', name: 'Basic 월간',
          billingIntervalMonths: 1, priceKrw: 19_900, effectiveDiscountPercent: null,
          autoRenews: true, isActive: true,
          createdAt: '2026-08-01T00:00:00.000Z', updatedAt: '2026-08-01T00:00:00.000Z',
        },
        {
          id: 'basic-yearly', code: 'basic_yearly', tierId: 'tier-basic', name: 'Basic 연간',
          billingIntervalMonths: 12, priceKrw: 190_900, effectiveDiscountPercent: null,
          autoRenews: true, isActive: true,
          createdAt: '2026-08-01T00:00:00.000Z', updatedAt: '2026-08-01T00:00:00.000Z',
        },
      ],
    },
    {
      id: 'tier-pro', code: 'pro', name: 'Pro', description: null, sortOrder: 20,
      monthlyCredits: 1_000, monthlyCreditValidityDays: null,
      entitlementMode: 'all', upgradeRank: 20,
      signupBenefit: null, plugins: [], pluginKeys: [
        'shortform_url', 'shortform_paste', 'shortform_prompt',
        'dialog_highlight', 'dance_highlight', 'variation',
      ], isActive: true,
      createdAt: '2026-08-01T00:00:00.000Z', updatedAt: '2026-08-01T00:00:00.000Z',
      products: [
        {
          id: 'pro-monthly', code: 'pro_monthly', tierId: 'tier-pro', name: 'Pro 월간',
          billingIntervalMonths: 1, priceKrw: 39_900, effectiveDiscountPercent: null,
          autoRenews: true, isActive: true,
          createdAt: '2026-08-01T00:00:00.000Z', updatedAt: '2026-08-01T00:00:00.000Z',
        },
        {
          id: 'pro-yearly', code: 'pro_yearly', tierId: 'tier-pro', name: 'Pro 연간',
          billingIntervalMonths: 12, priceKrw: 382_900, effectiveDiscountPercent: null,
          autoRenews: true, isActive: true,
          createdAt: '2026-08-01T00:00:00.000Z', updatedAt: '2026-08-01T00:00:00.000Z',
        },
      ],
    },
  ];

  function setup(options: {
    access?: CurrentAccessResponse;
    credits?: CreditSummary;
    subscription?: Subscription | null;
    paymentMethod?: CurrentSubscriptionPaymentMethod;
    paymentMethodError?: boolean;
    reloadedPaymentMethod?: CurrentSubscriptionPaymentMethod;
    dialogConfirmed?: boolean;
    startErrorStatus?: number;
    billingAuthError?: unknown;
    cancelChangeError?: boolean;
    quoteErrorStatus?: number;
    quoteErrorMessage?: string;
    confirmErrorStatus?: number;
    refreshedAccess?: CurrentAccessResponse;
    refreshedCredits?: CreditSummary;
    refreshedSubscription?: Subscription;
    refreshCreditsError?: boolean;
    promotion?: MemberPromotion | null;
    revocationNotice?: MemberPromotionRevocationNotice | null;
  } = {}) {
    const currentAccess = jasmine
      .createSpy('currentAccess')
      .and.returnValues(
        of(options.access ?? activeAccess),
        of(options.refreshedAccess ?? options.access ?? activeAccess),
      );
    const creditSummary = jasmine
      .createSpy('creditSummary')
      .and.returnValues(
        of(options.credits ?? summary),
        options.refreshCreditsError
          ? throwError(() => new Error('credits unavailable'))
          : of(options.refreshedCredits ?? options.credits ?? summary),
      );
    const listTiers = jasmine.createSpy('listTiers').and.returnValue(of(catalog));
    const currentSubscription = jasmine
      .createSpy('currentSubscription')
      .and.returnValues(
        of(options.subscription === undefined ? subscription : options.subscription),
        of(options.refreshedSubscription ?? subscription),
      );
    const retrySubscription = jasmine.createSpy('retrySubscription').and.returnValue(of({
      purpose: 'subscription_renewal',
      status: 'paid',
      fulfillmentStatus: 'succeeded',
      productCode: 'pro_monthly',
      productName: 'Pro 월간',
      planTierCode: 'pro',
      billingIntervalMonths: 1,
      amountKrw: 39_900,
      orderId: 'renewal-1',
      paidAt: '2026-09-01T00:00:00.000Z',
      receiptUrl: 'https://dashboard.tosspayments.com/receipt/renewal-1',
      errorMessage: null,
    }));
    const cancelSubscription = jasmine.createSpy('cancelSubscription').and.returnValue(of({
      ...subscription,
      status: 'cancel_at_period_end' as const,
      cancelAt: '2026-08-13T00:00:00.000Z',
    }));
    const resumeSubscription = jasmine.createSpy('resumeSubscription').and.returnValue(of(subscription));
    const quoteSubscriptionPlanChange = jasmine
      .createSpy('quoteSubscriptionPlanChange')
      .and.callFake((code: string) =>
        options.quoteErrorStatus
          ? throwError(() => ({ status: options.quoteErrorStatus, error: { message: options.quoteErrorMessage } }))
          : of(code === 'pro_monthly' ? immediateQuote : scheduledQuote));
    const confirmSubscriptionPlanChange = jasmine
      .createSpy('confirmSubscriptionPlanChange')
      .and.callFake((code: string) => {
        if (options.confirmErrorStatus) {
          return throwError(() => ({ status: options.confirmErrorStatus }));
        }
        if (code === 'pro_monthly') return of(immediateResult);
        return of({
          kind: 'scheduled',
          subscription: {
            ...subscription,
            scheduledChange: {
              billingProductId: 'pro-yearly', billingProductCode: 'pro_yearly',
              planTierId: 'tier-pro', planTierCode: 'pro', productName: 'Pro 연간',
              priceKrw: 382_900, billingIntervalMonths: 12, monthlyCredits: 1_000,
              monthlyCreditValidityDays: null, effectiveAt: '2026-09-01T00:00:00.000Z',
            },
          },
          payment: null,
        } satisfies SubscriptionPlanChangeResult);
      });
    const cancelScheduledPlanChange = jasmine
      .createSpy('cancelScheduledPlanChange')
      .and.returnValue(of(subscription));
    const paymentMethodCalls: string[] = [];
    const getCurrentPaymentMethod = jasmine
      .createSpy('getCurrentPaymentMethod')
      .and.callFake(() => {
        paymentMethodCalls.push('get');
        if (options.paymentMethodError) return throwError(() => new Error('provider unavailable'));
        return of(paymentMethodCalls.length > 1 && options.reloadedPaymentMethod
          ? options.reloadedPaymentMethod
          : options.paymentMethod ?? currentPaymentMethod);
      });
    const cancelPaymentMethodChange = jasmine
      .createSpy('cancelPaymentMethodChange')
      .and.callFake(() => {
        paymentMethodCalls.push('cancel');
        return options.cancelChangeError
          ? throwError(() => ({ status: 500 }))
          : of({ changeId: 'change-1', status: 'canceled', expiresAt: '2026-08-13T07:00:00.000Z', retryPastDueAfterChange: false, errorMessage: null });
      });
    const startPaymentMethodChange = jasmine
      .createSpy('startPaymentMethodChange')
      .and.returnValue(
        options.startErrorStatus
          ? throwError(() => ({ status: options.startErrorStatus }))
          : of({
              changeId: 'change-1',
              checkout: {
                flow: 'billing_auth',
                receiptToken: 'c'.repeat(43),
                clientKey: 'test_ck_billing',
                customerKey: 'customer-key',
                orderId: 'card-change-order',
                orderName: '결제수단 변경',
                amount: { currency: 'KRW', value: 1 },
                successUrl: 'https://api.example.com/payments/tosspayments/billing/success',
                failUrl: 'https://api.example.com/payments/tosspayments/billing/fail',
              },
              expiresAt: '2026-08-13T07:00:00.000Z',
            }),
      );
    const pickerClosed = new Subject<unknown>();
    const open = jasmine.createSpy('open').and.callFake((target: unknown) => target instanceof TemplateRef ? {
      afterClosed: () => pickerClosed,
      close: (value?: unknown) => { pickerClosed.next(value); pickerClosed.complete(); },
    } : { afterClosed: () => of(options.dialogConfirmed ?? true) });
    const requestBillingAuth = options.billingAuthError === undefined
      ? jasmine.createSpy('requestBillingAuth').and.resolveTo()
      : jasmine.createSpy('requestBillingAuth').and.rejectWith(options.billingAuthError);

    TestBed.configureTestingModule({
      imports: [DashboardComponent],
      providers: [
        provideRouter([]),
        { provide: AccessApiService, useValue: { current: currentAccess } },
        { provide: CatalogApiService, useValue: { listTiers } },
        { provide: CreditsApiService, useValue: { summary: creditSummary } },
        { provide: PromotionsApiService, useValue: {
          mine: () => of(options.promotion ?? null),
          latestRevocation: () => of(options.revocationNotice ?? null),
          acknowledgeRevocation: () => of(undefined),
        } },
        {
          provide: PaymentsApiService,
          useValue: {
            currentSubscription,
            retrySubscription,
            cancelSubscription,
            resumeSubscription,
            quoteSubscriptionPlanChange,
            confirmSubscriptionPlanChange,
            cancelScheduledPlanChange,
            getCurrentPaymentMethod,
            startPaymentMethodChange,
            cancelPaymentMethodChange,
          },
        },
        { provide: MatDialog, useValue: { open } },
        { provide: TossPaymentsSdkService, useValue: { requestBillingAuth } },
      ],
    });
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    return {
      fixture,
      retrySubscription,
      cancelSubscription,
      resumeSubscription,
      quoteSubscriptionPlanChange,
      confirmSubscriptionPlanChange,
      currentAccess,
      creditSummary,
      currentSubscription,
      cancelScheduledPlanChange,
      getCurrentPaymentMethod,
      startPaymentMethodChange,
      cancelPaymentMethodChange,
      paymentMethodCalls,
      open,
      requestBillingAuth,
    };
  }

  it('현재 등급과 크레딧 잔액을 표시하고 요금제별 플러그인 차등은 표시하지 않는다', () => {
    const { fixture } = setup();
    const text = fixture.nativeElement.textContent;

    expect(text).toContain('Pro');
    expect(text).not.toContain('모든 플러그인 포함');
    expect(text).not.toContain('사용 가능한 플러그인');
    expect(text).not.toContain('이용 시작');
    expect(text).not.toContain('이용 종료');
    expect(text).not.toContain('다음 크레딧');
    expect(text).not.toContain('보유 크레딧');
    expect(text).toContain('사용 가능 크레딧');
    expect(fixture.nativeElement.querySelectorAll('.credit-card strong')[0].textContent).toContain('850');
    expect(fixture.nativeElement.querySelectorAll('.credit-card strong').length).toBe(1);
    expect(text).toContain('다음 결제');
    expect(text).toContain('2026-09-01');
  });

  for (const [months, label] of [[1, '월간'], [12, '연간']] as const) {
    it(`구독 이용권의 결제 주기를 ${label}으로 표시한다`, () => {
      const { fixture } = setup({subscription: {...subscription, billingIntervalMonths: months}});
      expect(fixture.nativeElement.querySelector('.access-source').textContent).toContain(`정기구독 · ${label}`);
    });
  }

  for (const balance of [0, 321]) {
    it(`Free persists independently of expired signup credit and current balance ${balance}`, () => {
      const free = { ...activeAccess.access!, tierId: 'free', tierCode: 'free', tierName: 'Free', source: 'free' } as unknown as NonNullable<CurrentAccessResponse['access']>;
      const { fixture } = setup({ access: { access: free }, subscription: null,
        credits: { heldBalance: balance, spendableBalance: balance, bySource: balance ? [{ source: 'topup', credits: balance }] : [] },
      });
      expect(fixture.nativeElement.querySelector('.access-card__plan').textContent).toBe('Free');
      expect(fixture.nativeElement.querySelector('.access-source').textContent.trim()).toBe('Free');
      expect(fixture.nativeElement.textContent).not.toContain('현재 활성 이용권이 없습니다');
      expect(fixture.nativeElement.textContent).not.toContain('무료체험');
    });
  }

  it('프로모션 이용권의 출처와 실제 등록 코드를 따로 표시한다', () => {
    const promotion: MemberPromotion = {
      id: 'redemption-1', campaignId: 'campaign-1', codeId: 'code-1', userId: 'user-1',
      accessGrantId: 'access-1', status: 'active', grantedAt: '2026-10-01T00:00:00Z',
      endsAt: '2026-12-01T00:00:00Z', revokedAt: null, campaignName: 'AI 부스',
      code: 'BOOTH2026', promoterLabel: null, planTierCode: 'basic', durationMonths: 2,
    };
    const { fixture } = setup({
      access: { access: { ...activeAccess.access!, source: 'promotion', tierCode: 'basic', tierName: 'Basic' } },
      subscription: null,
      promotion,
    });

    expect(fixture.nativeElement.querySelector('.access-source').textContent.trim()).toBe('프로모션 코드');
    expect(fixture.nativeElement.querySelector('.access-code').textContent).toContain('BOOTH2026');
  });

  it('구독이 없거나 현재 이용권 등급과 다르면 결제 주기를 추정하지 않는다', () => {
    const { fixture } = setup({subscription:null});
    expect(fixture.nativeElement.querySelector('.access-source').textContent.trim()).toBe('정기구독');
    fixture.componentInstance.subscription.set({...subscription, planTierId:'tier-basic'});
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.access-source').textContent.trim()).toBe('정기구독');
  });

  it('다음 결제 예정 시각을 한국 시간으로 표시하고 순차 처리임을 안내한다', () => {
    const { fixture } = setup({ subscription: { ...subscription, nextBillingAt: '2026-10-08T21:06:25.000Z' } });
    const billing = fixture.nativeElement.querySelector('[data-subscription-label="next-billing"]') as HTMLElement;
    expect(billing.textContent).toContain('다음 결제 예정');
    expect(billing.textContent).toContain('2026-10-09 06:06');
    expect(billing.textContent).toContain('한국 시간');
    expect(billing.textContent).toContain('예정 시각 이후 순차적으로 결제됩니다');
  });

  it('결제가 중단되면 예정 시각 이후 결제 안내를 표시하지 않는다', () => {
    const { fixture } = setup({ subscription: { ...subscription, nextBillingStopped: true } });
    const billing = fixture.nativeElement.querySelector('[data-subscription-label="next-billing"]') as HTMLElement;
    expect(billing.textContent).toContain('중단됨');
    expect(billing.textContent).not.toContain('순차적으로 결제됩니다');
  });

  it('구독 정보를 요약 grid와 결제수단·요금제 변경 sibling panel로 균형 있게 표시한다', () => {
    const { fixture } = setup();
    const root = fixture.nativeElement as HTMLElement;

    expect(root.querySelector('.subscription-overview')).not.toBeNull();
    expect(root.querySelector('.subscription-summary')).not.toBeNull();
    expect(root.querySelectorAll('.subscription-summary [data-subscription-row]').length)
      .toBe(4);
    expect(root.querySelectorAll('.subscription-panels > .subscription-panel').length)
      .toBe(2);
    expect(root.querySelector('[data-subscription-panel="payment-method"]')).not.toBeNull();
    expect(root.querySelector('[data-subscription-panel="plan-change"]')).not.toBeNull();
    expect(root.querySelector('.subscription-meta')).toBeNull();
  });

  it('월간 환불 처리 중에는 다음 결제 중단과 즉시 종료 예정임을 구분해 표시한다', () => {
    const { fixture } = setup({
      subscription: {
        ...subscription,
        refundProcessing: true,
        refundEndAt: '2026-08-31T00:00:00.000Z',
        refundEndMode: 'immediate',
        nextBillingAt: null,
        nextBillingStopped: true,
      },
      credits: {
        heldBalance: 100,
        spendableBalance: 100,
        bySource: [{ source: 'free_trial', credits: 100 }],
      },
    });
    const root = fixture.nativeElement as HTMLElement;
    const text = root.textContent ?? '';

    expect(text).toContain('환불 처리 중');
    expect(text).toContain('다음 결제가 중단되었습니다');
    expect(text).toContain('환불이 완료되면 구독이 즉시 종료됩니다');
    expect(root.querySelector('[data-subscription-label="access-expiry"]')?.textContent)
      .toContain('현재 이용기간 종료');
    expect(root.querySelector('[data-subscription-label="access-expiry"] dd')?.textContent)
      .toBe('2100-01-01 09:00');
    expect(root.querySelector('[data-subscription-label="next-billing"]')?.textContent)
      .toContain('다음 결제 예정');
    expect(root.querySelector('[data-subscription-label="next-billing"]')?.textContent)
      .toContain('중단됨');
    expect(root.querySelector('[data-subscription-label="refund-end"]')?.textContent)
      .toContain('환불 적용 종료 시각');
  });

  it('월간 환불 완료는 결제 완료 사실과 별개로 구독의 즉시 종료를 표시한다', () => {
    const { fixture } = setup({
      subscription: {
        ...subscription,
        status: 'canceled',
        refundProcessing: true,
        refundEndAt: '2026-08-31T00:00:00.000Z',
        refundEndMode: 'immediate',
        nextBillingAt: null,
        nextBillingStopped: true,
      },
    });
    const text = fixture.nativeElement.textContent;

    expect(text).toContain('환불 완료');
    expect(text).toContain('환불이 완료되어 구독이 즉시 종료되었습니다');
    expect(text).not.toContain('환불이 완료되면 구독이 즉시 종료됩니다');
  });

  it('연간 현재 월 미사용 환불은 즉시 종료 방식으로 표시한다', () => {
    const { fixture } = setup({
      subscription: {
        ...subscription,
        productName: 'Pro 연간',
        billingProductCode: 'pro_yearly',
        billingIntervalMonths: 12,
        status: 'canceled',
        currentPeriodEnd: '2027-08-12T00:00:00.000Z',
        refundProcessing: true,
        refundEndAt: '2026-08-31T00:00:00.000Z',
        refundEndMode: 'immediate',
        nextBillingAt: null,
        nextBillingStopped: true,
      },
    });
    const text = fixture.nativeElement.textContent;

    expect(text).toContain('Pro 연간');
    expect(text).toContain('환불이 완료되어 구독이 즉시 종료되었습니다');
    expect(text).not.toContain('현재 구독 월 종료일까지 사용할 수 있습니다');
  });

  it('환불 종료된 구독은 이전 상품과 실제 종료 시각을 표시하고 관리 동작을 숨긴다', () => {
    const { fixture } = setup({subscription: {...subscription, status: 'canceled', refundProcessing: true, refundEndMode: 'immediate', refundEndAt: '2026-09-08T07:34:11Z', nextBillingAt: null, nextBillingStopped: true}});
    const host: HTMLElement = fixture.nativeElement;
    expect(host.querySelector('[data-plan-change]')).toBeNull();
    expect(host.querySelector('[data-subscription-panel="payment-method"]')).toBeNull();
    expect(host.textContent).toContain('이전 구독 상품');
    expect(host.querySelector('[data-subscription-label="access-expiry"]')?.textContent).toContain('2026-09-08 16:34');
  });

  it('과거 종료 모드 값이 남아 있어도 현재 월 유지라는 폐기된 환불 안내를 표시하지 않는다', () => {
    const { fixture } = setup({
      subscription: {
        ...subscription,
        productName: 'Pro 연간',
        billingProductCode: 'pro_yearly',
        billingIntervalMonths: 12,
        status: 'cancel_at_period_end',
        currentPeriodEnd: '2027-08-12T00:00:00.000Z',
        refundProcessing: true,
        refundEndAt: '2026-09-12T00:00:00.000Z',
        refundEndMode: 'benefit_period_end',
        nextBillingAt: null,
        nextBillingStopped: true,
      },
    });
    const root = fixture.nativeElement as HTMLElement;
    const text = root.textContent ?? '';

    expect(text).toContain('환불 처리 중');
    expect(text).not.toContain('환불 완료');
    expect(text).not.toContain('현재 구독 월 종료일까지 사용할 수 있습니다');
    expect(text).toContain('환불이 완료되면 구독이 즉시 종료됩니다');
    expect(root.querySelector('[data-subscription-label="access-expiry"]')?.textContent)
      .toContain('현재 이용기간 종료2027-08-12 09:00');
    expect(root.querySelector('[data-subscription-label="refund-end"]')?.textContent)
      .toContain('환불 적용 종료 시각2026-09-12 09:00');
    expect(root.querySelector('[data-subscription-label="next-billing"]')?.textContent)
      .toMatch(/다음 결제 예정\s*중단됨/);
  });

  it('과거 종료 모드의 완료 상태도 폐기된 현재 월 유지 안내 없이 종료로 표시한다', () => {
    const refundEndAt = '2026-09-12T00:00:00.000Z';
    const { fixture } = setup({
      subscription: {
        ...subscription,
        productName: 'Pro 연간',
        billingProductCode: 'pro_yearly',
        billingIntervalMonths: 12,
        status: 'ended',
        currentPeriodEnd: '2027-08-12T00:00:00.000Z',
        cancelAt: refundEndAt,
        refundProcessing: true,
        refundEndAt,
        refundEndMode: 'benefit_period_end',
        nextBillingAt: null,
        nextBillingStopped: true,
      },
    });
    const text = fixture.nativeElement.textContent;

    expect(text).toContain('환불 완료');
    expect(text).toContain('환불이 완료되어 구독이 즉시 종료되었습니다');
    expect(text).not.toContain('현재 구독 월 종료일까지 사용할 수 있습니다');
    expect(text).not.toContain('환불 처리 중');
  });

  it('추가 구매 크레딧만 환불 중이면 기존 정기구독은 그대로 유지한다', () => {
    const { fixture } = setup({
      subscription,
      credits: {
        heldBalance: 750,
        spendableBalance: 750,
        bySource: [{ source: 'subscription', credits: 750 }],
      },
    });
    const text = fixture.nativeElement.textContent;

    expect(text).toContain('자동 갱신 중');
    expect(text).toContain('다음 결제 예정');
    expect(text).toContain('2026-09-01');
    expect(text).not.toContain('구독이 즉시 종료');
  });

  it('환불 상태에도 무료 기능까지 잠긴다고 안내하지 않는다', () => {
    const { fixture } = setup({
      subscription: {
        ...subscription,
        refundProcessing: true,
        refundEndAt: '2026-08-31T00:00:00.000Z',
        refundEndMode: 'immediate',
        nextBillingAt: null,
        nextBillingStopped: true,
      },
    });
    const text = fixture.nativeElement.textContent;

    expect(text).not.toMatch(/무료 기능.*(잠금|사용 불가)|모든 기능.*(잠금|사용 불가)/);
    expect(text).not.toMatch(/provider|retry count|admin memo|토스 오류/i);
  });

  it('정기구독이 없어도 유효한 추가 구매 크레딧은 사용 가능하게 표시한다', () => {
    const { fixture } = setup({
      access: { access: null },
      credits: {
        heldBalance: 5_000,
        spendableBalance: 5_000,
        bySource: [{ source: 'topup', credits: 5_000 }],
      },
      subscription: null,
    });
    const text = fixture.nativeElement.textContent;

    expect(text).not.toContain('보유 크레딧');
    expect(text).toContain('사용 가능 크레딧');
    expect(fixture.nativeElement.querySelectorAll('.credit-card strong')[0].textContent).toContain('5,000');
    expect(fixture.nativeElement.querySelectorAll('.credit-card strong').length).toBe(1);
    expect(fixture.nativeElement.querySelector('.credit-card strong').textContent).toContain('5,000');
    expect(text).not.toContain('이용권을 다시 활성하면');
    expect(fixture.nativeElement.querySelector('a[href="/#price"]')).not.toBeNull();
  });

  it('화면 제목을 왼쪽 메뉴 이름(대시보드)과 같게 두고, 메뉴와 겹치는 바로가기 카드는 두지 않는다', () => {
    const { fixture } = setup();
    const el = fixture.nativeElement as HTMLElement;

    expect(el.querySelector('h1.page-title')?.textContent?.trim()).toBe('대시보드');
    expect(el.querySelector('.quick-grid')).toBeNull();
    expect(el.querySelector('a[href="/my/payment-history"]')).toBeNull();
    expect(el.querySelector('a[href="/my/topup"]')).toBeNull();
  });

  it('갱신 결제 실패 상태와 기존 주문 재시도 동작을 표시한다', () => {
    const { fixture, retrySubscription } = setup({
      subscription: {
        ...subscription,
        status: 'past_due',
        firstPaymentFailedAt: '2026-09-01T00:00:00.000Z',
        graceEndsAt: '2026-09-04T00:00:00.000Z',
        retryAt: '2026-09-02T00:00:00.000Z',
      },
    });

    expect(fixture.nativeElement.textContent).toContain('갱신 결제에 실패했습니다');
    expect(fixture.nativeElement.textContent).toContain('2026-09-04까지 이용할 수 있습니다');
    expect(fixture.nativeElement.textContent).toContain('다음 자동 재시도 2026-09-02');

    (fixture.nativeElement.querySelector('[data-action="retry-subscription"]') as HTMLButtonElement).click();
    fixture.detectChanges();

    expect(retrySubscription).toHaveBeenCalledTimes(1);
    expect(fixture.nativeElement.textContent).toContain('결제를 다시 처리했습니다');
  });

  it('재시도 확정 실패를 처리중 안내로 표시하지 않는다', () => {
    const { fixture, retrySubscription } = setup();
    retrySubscription.and.returnValue(of({ status: 'failed', fulfillmentStatus: 'pending' }));
    fixture.componentInstance.retrySubscription();
    fixture.detectChanges();
    expect(fixture.componentInstance.retryError()).toContain('결제에 실패했습니다');
    expect(fixture.componentInstance.retryMessage()).toBeNull();
  });

  it('유예가 끝난 정지 상태에서는 결제 재시도 대신 새 구독 안내를 표시한다', () => {
    const { fixture } = setup({
      subscription: {
        ...subscription,
        status: 'stopped',
        nextBillingAt: null,
        firstPaymentFailedAt: '2026-09-01T00:00:00.000Z',
        graceEndsAt: '2026-09-04T00:00:00.000Z',
        retryAt: null,
      },
    });

    expect(fixture.nativeElement.textContent).toContain('구독이 정지되었습니다');
    expect(fixture.nativeElement.textContent).toContain('새 구독을 시작');
    expect(
      fixture.nativeElement.querySelector('[data-action="retry-subscription"]'),
    ).toBeNull();
  });

  it('활성 구독은 현재 기간을 유지하는 다음 자동 결제 취소를 확인한다', fakeAsync(() => {
    const { fixture, open, cancelSubscription } = setup();

    (fixture.nativeElement.querySelector(
      '[data-action="cancel-subscription"]',
    ) as HTMLButtonElement).click();
    tick();

    expect(open.calls.mostRecent().args[1].data.message).toContain('현재 결제기간 종료일까지');
    expect(cancelSubscription).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.subscription()?.status).toBe('cancel_at_period_end');
  }));

  it('lets a failed initial payment stop retrying without describing a promotion booking', fakeAsync(() => {
    const { fixture, open, cancelSubscription } = setup({ subscription: {
      ...subscription, status: 'pending', firstPaymentFailedAt: '2026-09-01T00:01:00Z',
      firstChargeAt: '2026-09-01T00:00:00Z',
    } });
    const cancel = fixture.nativeElement.querySelector('[data-action="cancel-initial-subscription"]') as HTMLButtonElement | null;
    expect(cancel).not.toBeNull();
    cancel?.click();
    tick();
    expect(open).toHaveBeenCalled();
    if (open.calls.any()) {
      expect(open.calls.mostRecent().args[1].data.message).toContain('첫 결제 재시도');
      expect(open.calls.mostRecent().args[1].data.message).not.toContain('프로모션');
    }
    expect(cancelSubscription).toHaveBeenCalledTimes(1);
  }));

  it('취소 예약 상태는 자동 갱신을 다시 시작한다', fakeAsync(() => {
    const { fixture, open, resumeSubscription } = setup({
      subscription: { ...subscription, status: 'cancel_at_period_end', nextBillingAt: null, cancelAt: '2026-08-13T00:00:00.000Z' },
    });

    (fixture.nativeElement.querySelector(
      '[data-action="resume-subscription"]',
    ) as HTMLButtonElement).click();
    tick();

    expect(open.calls.mostRecent().args[1].data.consentText).toContain('매월 39,900원 자동 결제');
    expect(open.calls.mostRecent().args[1].data.notices[0]).toContain('2100-01-01 09:00');
    expect(resumeSubscription).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.subscription()?.status).toBe('active');
  }));

  it('자동 갱신 재개 확인을 취소하면 서버에 요청하지 않는다', fakeAsync(() => {
    const { fixture, resumeSubscription } = setup({
      subscription: { ...subscription, status: 'cancel_at_period_end' },
      dialogConfirmed: false,
    });
    fixture.componentInstance.resumeSubscription();
    tick();
    expect(resumeSubscription).not.toHaveBeenCalled();
  }));

  it('Basic에서 Pro 변경은 서버 견적 금액을 확인한 뒤 같은 quote로 승인하고 모든 상태를 다시 읽는다', fakeAsync(() => {
    const basicAccess: CurrentAccessResponse = {
      access: activeAccess.access
        ? {
            ...activeAccess.access,
            tierId: 'tier-basic',
            tierCode: 'basic',
            tierName: 'Basic',
            allowedPluginKeys: activeAccess.access.allowedPluginKeys.slice(0, 5),
          }
        : null,
    };
    const basicCredits: CreditSummary = {
      heldBalance: 500,
      spendableBalance: 500,
      bySource: [{ source: 'subscription', credits: 400 }, { source: 'topup', credits: 100 }],
    };
    const { fixture, open, quoteSubscriptionPlanChange,
      confirmSubscriptionPlanChange, currentAccess, creditSummary,
      currentSubscription, getCurrentPaymentMethod } = setup({
      access: basicAccess,
      credits: basicCredits,
      refreshedAccess: activeAccess,
      refreshedCredits: summary,
      subscription: {
        ...subscription,
        billingProductId: 'basic-monthly',
        billingProductCode: 'basic_monthly',
        productName: 'Basic 월간',
        planTierId: 'tier-basic',
        planTierCode: 'basic',
        priceKrw: 19_900,
        monthlyCredits: 400,
      },
    });

    fixture.componentInstance.changePlan(fixture.componentInstance.catalogProducts().find(option => option.product.code === 'pro_monthly')!);
    tick();
    fixture.detectChanges();

    expect(quoteSubscriptionPlanChange).toHaveBeenCalledOnceWith('pro_monthly');
    const data = open.calls.mostRecent().args[1].data;
    expect(data.confirmText).toBe('₩19,984 결제하고 변경');
    expect(data.consentText).toContain('매월 39,900원');
    expect(data.consentText).toContain('19,984원');
    expect(data.message).toContain('공제');
    expect(data.details).toContain(jasmine.objectContaining({
      label: '지금 결제할 금액', value: '₩19,984', emphasized: true,
    }));
    expect(data.calculationDetails).toContain(jasmine.objectContaining({
      label: '기간 기준 계산', value: '₩39,900 − ₩23,916 = ₩15,984',
    }));
    expect(data.calculationDetails).toContain(jasmine.objectContaining({
      label: '크레딧 기준 계산', value: '₩39,900 − ₩19,916 = ₩19,984',
    }));
    expect(data.details).toContain(jasmine.objectContaining({
      label: '새 이용기간 첫 달 정기구독 크레딧', value: '1,000',
    }));
    expect(confirmSubscriptionPlanChange).toHaveBeenCalledOnceWith(
      'pro_monthly',
      immediateQuote.quoteOrderId,
    );
    expect(currentAccess).toHaveBeenCalledTimes(2);
    expect(creditSummary).toHaveBeenCalledTimes(2);
    expect(currentSubscription).toHaveBeenCalledTimes(2);
    expect(getCurrentPaymentMethod).toHaveBeenCalledTimes(2);
    expect(fixture.componentInstance.access()?.tierCode).toBe('pro');
    expect(fixture.componentInstance.credits()?.heldBalance).toBe(850);
    expect(fixture.componentInstance.planChangeCompletion()).toEqual(immediateResult.payment);
    expect(fixture.nativeElement.textContent).toContain('₩19,984');
    expect(fixture.nativeElement.textContent).toContain(immediateResult.payment?.orderId);
  }));

  it('견적 확인창을 취소하면 결제 확인 요청을 보내지 않는다', fakeAsync(() => {
    const { fixture, quoteSubscriptionPlanChange, confirmSubscriptionPlanChange } = setup({
      dialogConfirmed: false,
      subscription: {
        ...subscription,
        billingProductCode: 'basic_monthly',
        planTierCode: 'basic',
        billingIntervalMonths: 1,
      },
    });

    fixture.componentInstance.changePlan(fixture.componentInstance.catalogProducts().find(option => option.product.code === 'pro_monthly')!);
    tick();

    expect(quoteSubscriptionPlanChange).toHaveBeenCalledTimes(1);
    expect(confirmSubscriptionPlanChange).not.toHaveBeenCalled();
  }));

  it('확인 시 견적이 무효가 되었으면 다시 견적을 확인하도록 안내한다', fakeAsync(() => {
    const { fixture } = setup({
      confirmErrorStatus: 409,
      subscription: {
        ...subscription,
        billingProductCode: 'basic_monthly',
        planTierCode: 'basic',
        billingIntervalMonths: 1,
      },
    });

    fixture.componentInstance.changePlan(fixture.componentInstance.catalogProducts().find(option => option.product.code === 'pro_monthly')!);
    tick();
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain(
      '구독 상태가 변경되었습니다. 새로고침 후 다시 확인해 주세요.',
    );
    expect(fixture.componentInstance.planChangeCompletion()).toBeNull();
  }));

  it('결제 결과가 불확실하면 새 결제를 유도하지 않고 확인 중임을 안내한다', fakeAsync(() => {
    const { fixture } = setup({
      confirmErrorStatus: 503,
      subscription: {
        ...subscription,
        billingProductCode: 'basic_monthly',
        planTierCode: 'basic',
        billingIntervalMonths: 1,
      },
    });

    fixture.componentInstance.changePlan(fixture.componentInstance.catalogProducts().find(option => option.product.code === 'pro_monthly')!);
    tick();
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain(
      '결제 결과를 확인하고 있습니다',
    );
  }));

  it('결제 완료 뒤 일부 상태 재조회가 실패해도 결제 내역은 유지하고 새로고침 안내를 표시한다', fakeAsync(() => {
    const { fixture } = setup({
      refreshCreditsError: true,
      subscription: {
        ...subscription,
        billingProductCode: 'basic_monthly',
        planTierCode: 'basic',
        billingIntervalMonths: 1,
      },
    });

    fixture.componentInstance.changePlan(fixture.componentInstance.catalogProducts().find(option => option.product.code === 'pro_monthly')!);
    tick();
    fixture.detectChanges();

    expect(fixture.componentInstance.planChangeCompletion()).toEqual(immediateResult.payment);
    expect(fixture.componentInstance.accountRefreshWarning()).toContain(
      '일부 이용 정보를 다시 불러오지 못했습니다',
    );
    expect(fixture.nativeElement.textContent).toContain('₩19,984');
  }));

  it('결제 주기 변경을 예약하고 기존 예약을 새 예약으로 교체하거나 취소한다', fakeAsync(() => {
    const scheduledChange = {
      billingProductId: 'basic-monthly', billingProductCode: 'basic_monthly',
      planTierId: 'tier-basic', planTierCode: 'basic', productName: 'Basic 월간',
      priceKrw: 19_900, billingIntervalMonths: 1, monthlyCredits: 400,
      monthlyCreditValidityDays: null, effectiveAt: '2026-09-01T00:00:00.000Z',
    };
    const { fixture, open, quoteSubscriptionPlanChange,
      confirmSubscriptionPlanChange, cancelScheduledPlanChange } = setup({
      subscription: { ...subscription, scheduledChange },
      refreshedSubscription: {
        ...subscription,
        scheduledChange: {
          billingProductId: 'pro-yearly', billingProductCode: 'pro_yearly',
          planTierId: 'tier-pro', planTierCode: 'pro', productName: 'Pro 연간',
          priceKrw: 382_900, billingIntervalMonths: 12, monthlyCredits: 1_000,
          monthlyCreditValidityDays: null, effectiveAt: '2026-09-01T00:00:00.000Z',
        },
      },
    });

    fixture.componentInstance.selectBillingInterval(12);
    fixture.detectChanges();
    fixture.componentInstance.changePlan(fixture.componentInstance.catalogProducts().find(option => option.product.code === 'pro_yearly')!);
    tick();
    fixture.detectChanges();

    expect(open.calls.mostRecent().args[1].data.message).toContain('새 예약으로 교체');
    expect(open.calls.mostRecent().args[1].data.consentText).toContain('매년 382,900원');
    expect(open.calls.mostRecent().args[1].data.consentText).toContain('2026-09-01 09:00');
    expect(quoteSubscriptionPlanChange).toHaveBeenCalledOnceWith('pro_yearly');
    expect(confirmSubscriptionPlanChange).toHaveBeenCalledOnceWith('pro_yearly', null);
    expect(fixture.nativeElement.textContent).toContain('예약됨: Pro 연간');

    (fixture.nativeElement.querySelector(
      '[data-action="cancel-scheduled-plan-change"]',
    ) as HTMLButtonElement).click();
    tick();
    expect(cancelScheduledPlanChange).toHaveBeenCalledTimes(1);
  }));

  it('회수된 혜택과 사유를 알리고 더 이상 유료 예약 결제를 안내하지 않는다', () => {
    const notice = { redemptionId: 'redemption-1', campaignName: 'AI 부스', code: 'BOOTH',
      revokedAt: '2026-10-25T00:00:00.000Z', reason: '운영 사유' };
    const { fixture } = setup({ revocationNotice: notice });
    expect(fixture.nativeElement.textContent).not.toContain(notice.campaignName);
    expect(fixture.nativeElement.querySelector('[aria-label="프로모션 혜택 회수 안내"] h2')?.textContent).toContain(notice.code);
    expect(fixture.nativeElement.textContent).toContain('운영 사유');
    expect(fixture.nativeElement.textContent).not.toContain('유료 결제 예약은 유지');
  });

  it('첫 결제가 실패한 예약은 예약 성공으로 표시하지 않고 직접 재시도를 제공한다', () => {
    const failed = { ...subscription, status: 'pending' as const,
      firstChargeAt: '2026-09-01T00:00:00.000Z', reservationReady: true,
      firstPaymentFailedAt: '2026-09-01T00:01:00.000Z', retryAt: '2026-09-02T00:00:00.000Z' };
    const { fixture, retrySubscription } = setup({ subscription: failed });
    expect(fixture.nativeElement.textContent).toContain('첫 결제에 실패했습니다');
    expect(fixture.nativeElement.textContent).not.toContain('유료 이용이 예약되었습니다');
    (fixture.nativeElement.querySelector('[data-action="retry-subscription"]') as HTMLButtonElement).click();
    expect(retrySubscription).toHaveBeenCalledTimes(1);
  });

  for (const allowed of [true, false]) {
    it(`shows first-payment failure card management with server permission ${allowed}`, () => {
      const { fixture } = setup({
        subscription: { ...subscription, status: 'pending', firstChargeAt: '2026-09-01T00:00:00Z',
          firstPaymentFailedAt: '2026-09-01T00:01:00Z', reservationReady: true },
        paymentMethod: { ...currentPaymentMethod, changeAllowed: allowed,
          changeBlockedReason: allowed ? null : 'PAYMENT_RESULT_PENDING' },
      });
      const button = fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement | null;
      expect(button).not.toBeNull();
      expect(button?.disabled).toBe(!allowed);
      expect(fixture.nativeElement.querySelector('[data-plan-change]')).toBeNull();
    });
  }

  it('shows an accepted pending charge and cancels it through the rendered subscription action', fakeAsync(() => {
    const accepted: Subscription = {
      ...subscription, status: 'pending', firstChargeAt: '2026-11-19T00:00:00Z', reservationReady: true,
      firstPaymentFailedAt: null, currentPeriodStart: null, currentPeriodEnd: null, nextBillingAt: null,
    };
    const { fixture, open, cancelSubscription } = setup({
      subscription: accepted,
      paymentMethod: { ...currentPaymentMethod, changeAllowed: false, changeBlockedReason: 'PAYMENT_RESULT_PENDING' },
    });
    cancelSubscription.and.returnValue(of({ ...accepted, status: 'canceled' }));
    const card = fixture.nativeElement.querySelector('.subscription-card') as HTMLElement | null;
    expect(card).not.toBeNull();
    expect(card?.textContent).toContain('Pro 월간');
    expect(card?.textContent).toContain('39,900원');
    expect(card?.querySelector('[data-subscription-label="first-charge"]')?.textContent).toContain('2026-11-19 09:00');
    expect(card?.querySelector('.subscription-status')?.textContent).toContain('첫 결제 대기');
    expect(fixture.nativeElement.querySelector('[data-action="change-payment-method"]')).toBeNull();
    expect(fixture.nativeElement.querySelector('[data-plan-change]')).toBeNull();
    expect(fixture.nativeElement.querySelector('[data-action="book-paid-plan"]')).toBeNull();
    expect(cancelSubscription).not.toHaveBeenCalled();

    const cancel = card?.querySelector('[data-action="cancel-initial-subscription"]') as HTMLButtonElement | null;
    expect(cancel).not.toBeNull();
    cancel?.click();
    tick();
    fixture.detectChanges();

    expect(open).toHaveBeenCalled();
    if (open.calls.any()) {
      expect(open.calls.mostRecent().args[1].data.message).toContain('예정된 첫 결제를 중단');
      expect(open.calls.mostRecent().args[1].data.message).not.toContain('프로모션');
    }
    expect(cancelSubscription).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.subscription()?.status).toBe('canceled');
    expect(fixture.nativeElement.querySelector('[data-action="cancel-initial-subscription"]')).toBeNull();
  }));

  it('keeps an accepted pending charge when the member closes its cancellation confirmation', fakeAsync(() => {
    const { fixture, open, cancelSubscription } = setup({
      subscription: { ...subscription, status: 'pending', firstChargeAt: '2026-11-19T00:00:00Z', reservationReady: true },
      dialogConfirmed: false,
    });
    const cancel = fixture.nativeElement.querySelector('[data-action="cancel-initial-subscription"]') as HTMLButtonElement | null;
    expect(cancel).not.toBeNull();
    cancel?.click();
    tick();
    fixture.detectChanges();

    expect(open).toHaveBeenCalled();
    expect(cancelSubscription).not.toHaveBeenCalled();
    expect(fixture.componentInstance.subscription()?.status).toBe('pending');
    expect(fixture.nativeElement.querySelector('[data-subscription-label="first-charge"]')?.textContent).toContain('2026-11-19 09:00');
  }));

  it('refreshes access, spendable credits and card after the first payment retry succeeds', fakeAsync(() => {
    const { fixture, getCurrentPaymentMethod } = setup({
      access: { access: null }, credits: { heldBalance: 0, spendableBalance: 0, bySource: [] },
      subscription: { ...subscription, status: 'pending', firstPaymentFailedAt: '2026-09-01T00:01:00Z' },
      refreshedAccess: activeAccess, refreshedCredits: summary, refreshedSubscription: subscription,
    });
    getCurrentPaymentMethod.and.returnValue(of({ ...currentPaymentMethod, paymentMethod: {
      ...currentPaymentMethod.paymentMethod!, cardIssuerCode: '61',
    } }));
    fixture.componentInstance.retrySubscription();
    tick();
    fixture.detectChanges();
    expect(fixture.componentInstance.access()?.tierName).toBe('Pro');
    expect(fixture.componentInstance.credits()?.spendableBalance).toBe(850);
    expect(fixture.componentInstance.subscription()?.status).toBe('active');
    expect(fixture.nativeElement.querySelector('[data-payment-method]')?.textContent).toContain('현대카드');
  }));

  it('keeps refreshed access and reports an incomplete credit refresh after successful retry', fakeAsync(() => {
    const { fixture } = setup({
      access: { access: null }, subscription: { ...subscription, status: 'pending', firstPaymentFailedAt: '2026-09-01T00:01:00Z' },
      refreshedAccess: activeAccess, refreshCreditsError: true,
    });
    fixture.componentInstance.retrySubscription();
    tick();
    fixture.detectChanges();
    expect(fixture.componentInstance.access()?.tierName).toBe('Pro');
    expect(fixture.componentInstance.accountRefreshWarning()).not.toBeNull();
    expect(fixture.componentInstance.retryError()).toBeNull();
  }));

  it('does not present an abandoned card registration as a booked subscription', () => {
    const unfinished = { ...subscription, status: 'pending' as const,
      firstChargeAt: '2026-11-19T00:00:00.000Z', reservationReady: false,
      currentPeriodStart: null, currentPeriodEnd: null };
    const { fixture } = setup({ subscription: unfinished });
    expect(fixture.nativeElement.textContent).not.toContain('카드 등록 중');
    expect(fixture.nativeElement.textContent).not.toContain('첫 결제 예정일은');
    expect(fixture.nativeElement.querySelector('[data-action="cancel-reservation"]')).toBeNull();
  });

  it('does not present an expired card-registration draft as a canceled paid subscription', () => {
    const expiredDraft = { ...subscription, status: 'canceled' as const,
      firstChargeAt: '2026-11-19T00:00:00.000Z', reservationReady: false,
      currentPeriodStart: null, currentPeriodEnd: null };
    const { fixture } = setup({ subscription: expiredDraft });
    expect(fixture.nativeElement.textContent).not.toContain('구독 취소됨');
    expect(fixture.nativeElement.textContent).not.toContain('예약 상품');
  });

  describe('요금제 변경 예약 취소 확인', () => {
    const scheduledSubscription: Subscription = {
      ...subscription,
      scheduledChange: {
        billingProductId: 'basic-monthly', billingProductCode: 'basic_monthly',
        planTierId: 'tier-basic', planTierCode: 'basic', productName: 'Basic 월간',
        priceKrw: 19_900, billingIntervalMonths: 1, monthlyCredits: 400,
        monthlyCreditValidityDays: null, effectiveAt: '2026-09-01T00:00:00.000Z',
      },
    };

    it('확인창에서 확정하기 전에는 요청하지 않고 반복 클릭도 한 번만 처리한다', fakeAsync(() => {
      const { fixture, open, cancelScheduledPlanChange } = setup({ subscription: scheduledSubscription });
      const closed = new Subject<boolean | undefined>();
      open.and.returnValue({ afterClosed: () => closed });
      const button = fixture.nativeElement.querySelector('[data-action="cancel-scheduled-plan-change"]') as HTMLButtonElement;
      button.click();
      button.click();
      tick();
      fixture.detectChanges();

      expect(cancelScheduledPlanChange).not.toHaveBeenCalled();
      expect(open).toHaveBeenCalledTimes(1);
      expect(open.calls.mostRecent()?.args[0]).toBe(ConfirmDialogComponent);
      expect(open.calls.mostRecent()?.args[1].data).toEqual(jasmine.objectContaining({
        title: '요금제 변경 예약을 취소할까요?',
        confirmText: '예약 취소',
        cancelText: '예약 유지',
        details: jasmine.arrayContaining([
          { label: '취소할 예약', value: 'Basic 월간' },
          { label: '유지할 요금제', value: 'Pro 월간' },
        ]),
      }));
      expect(button.disabled).toBeTrue();

      closed.next(true);
      closed.complete();
      tick();
      fixture.detectChanges();
      expect(cancelScheduledPlanChange).toHaveBeenCalledTimes(1);
      expect(fixture.componentInstance.subscription()?.scheduledChange).toBeNull();
      expect(fixture.nativeElement.textContent).toContain('예약된 요금제 변경을 취소했습니다.');
    }));

    for (const result of [false, undefined]) {
      it(`예약 유지 또는 확인창 닫기(${result})는 구독을 변경하지 않는다`, fakeAsync(() => {
        const { fixture, open, cancelScheduledPlanChange } = setup({ subscription: scheduledSubscription });
        open.and.returnValue({ afterClosed: () => of(result) });
        (fixture.nativeElement.querySelector('[data-action="cancel-scheduled-plan-change"]') as HTMLButtonElement).click();
        tick();
        fixture.detectChanges();
        expect(cancelScheduledPlanChange).not.toHaveBeenCalled();
        expect(fixture.componentInstance.subscription()).toEqual(scheduledSubscription);
        expect(fixture.componentInstance.subscriptionActionPending()).toBeFalse();
        expect(fixture.nativeElement.textContent).not.toContain('예약된 요금제 변경을 취소했습니다.');
      }));
    }

    it('취소 실패 시 예약을 유지하고 다시 시도할 수 있다', fakeAsync(() => {
      const { fixture, cancelScheduledPlanChange } = setup({ subscription: scheduledSubscription });
      cancelScheduledPlanChange.and.returnValue(throwError(() => new Error('unavailable')));
      (fixture.nativeElement.querySelector('[data-action="cancel-scheduled-plan-change"]') as HTMLButtonElement).click();
      tick();
      fixture.detectChanges();
      expect(fixture.componentInstance.subscription()).toEqual(scheduledSubscription);
      expect(fixture.componentInstance.subscriptionActionPending()).toBeFalse();
      expect(fixture.nativeElement.textContent).toContain('구독 상태를 변경하지 못했습니다.');
    }));

    it('예약이 없으면 확인창과 취소 요청을 실행하지 않는다', fakeAsync(() => {
      const { fixture, open, cancelScheduledPlanChange } = setup();
      fixture.componentInstance.cancelScheduledPlanChange();
      tick();
      expect(open).not.toHaveBeenCalled();
      expect(cancelScheduledPlanChange).not.toHaveBeenCalled();
    }));
  });

  it('연간 구독은 연간 표와 현재 상품을 보여주며 월간 변경을 요청하지 않는다', fakeAsync(() => {
    const { fixture, quoteSubscriptionPlanChange } = setup({subscription: {
      ...subscription, billingProductCode: 'pro_yearly', billingIntervalMonths: 12,
    }});
    const root: HTMLElement = fixture.nativeElement;
    expect(root.querySelector('[data-plan-table]')).toBeNull();
    expect(root.querySelector('[data-action="open-plan-picker"]')).not.toBeNull();
    const view = fixture.componentInstance.planPicker!.createEmbeddedView({});
    view.detectChanges();
    const picker = document.createElement('div');
    view.rootNodes.forEach(node => picker.appendChild(node));
    const monthlyTab = picker.querySelector<HTMLButtonElement>('[data-billing-interval="1"]');
    expect(monthlyTab).not.toBeNull();
    expect(monthlyTab?.disabled).toBeTrue();
    expect(monthlyTab?.getAttribute('aria-pressed')).toBe('false');
    monthlyTab?.click();
    expect(fixture.componentInstance.planBillingInterval()).toBe(12);
    expect(picker.textContent).toContain('연간 이용 중에는 월간 요금제로 직접 변경할 수 없습니다.');
    view.destroy();
    const choices = fixture.componentInstance.visiblePlanOptions();
    expect(choices.every(row => row.product.billingIntervalMonths === 12)).toBeTrue();
    expect(fixture.componentInstance.planChangeKind(choices.find(row => row.product.code === 'pro_yearly')!)).toBe('current');
    expect(fixture.componentInstance.planChangeKind(choices.find(row => row.product.code === 'basic_yearly')!)).toBe('scheduled');
    const monthly = fixture.componentInstance.catalogProducts().find(row => row.product.code === 'basic_monthly')!;
    fixture.componentInstance.changePlan(monthly);
    tick();
    expect(quoteSubscriptionPlanChange).not.toHaveBeenCalled();
  }));

  it('월간 구독은 주기를 선택해 비교하며 월간→연간 상향은 차액 확인으로 표시한다', () => {
    const { fixture } = setup();
    const root: HTMLElement = fixture.nativeElement;
    const component = fixture.componentInstance;
    expect(component.planChangeKind(component.visiblePlanOptions().find(row => row.product.code === 'pro_monthly')!)).toBe('current');
    component.selectBillingInterval(12);
    expect(component.planChangeKind(component.visiblePlanOptions().find(row => row.product.code === 'pro_yearly')!)).toBe('immediate');
    expect(component.planChangeKind(component.visiblePlanOptions().find(row => row.product.code === 'basic_yearly')!)).toBe('scheduled');
  });

  it('요금제 모달을 닫으면 견적 요청 없이 돌아간다', () => {
    const {fixture, open, quoteSubscriptionPlanChange} = setup();
    (fixture.nativeElement.querySelector('[data-action="open-plan-picker"]') as HTMLButtonElement).click();
    expect(open.calls.mostRecent().args[0]).toBe(fixture.componentInstance.planPicker);
    fixture.componentInstance.closePlanPicker();
    expect(quoteSubscriptionPlanChange).not.toHaveBeenCalled();
  });

  it('모달에서 선택한 상품만 기존 견적 확인 단계로 전달한다', fakeAsync(() => {
    const {fixture, quoteSubscriptionPlanChange, confirmSubscriptionPlanChange} = setup({dialogConfirmed:false});
    fixture.componentInstance.openPlanPicker();
    const option = fixture.componentInstance.catalogProducts().find(row => row.product.code === 'basic_yearly')!;
    fixture.componentInstance.choosePlan(option); tick();
    expect(quoteSubscriptionPlanChange).toHaveBeenCalledOnceWith('basic_yearly');
    expect(confirmSubscriptionPlanChange).not.toHaveBeenCalled();
  }));

  it('허용되지 않는 변경 응답을 견적 만료로 안내하지 않는다', fakeAsync(() => {
    const { fixture } = setup({quoteErrorStatus: 409, quoteErrorMessage: 'SUBSCRIPTION_PLAN_CHANGE_NOT_ALLOWED'});
    const option = fixture.componentInstance.catalogProducts().find(row => row.product.code === 'basic_monthly')!;
    fixture.componentInstance.changePlan(option); tick();
    expect(fixture.componentInstance.subscriptionActionError()).toContain('현재 구독 상태에서는');
    expect(fixture.componentInstance.subscriptionActionError()).not.toContain('견적이 만료');
  }));

  it('카드사와 종류를 풀어 쓰고 카드번호 끝자리만 표시한다', () => {
    const { fixture } = setup();
    const card = fixture.nativeElement.querySelector('[data-payment-method]') as HTMLElement;

    expect(card.textContent).toContain('KB국민카드 신용카드 · 카드번호 끝자리 5678');
    expect(card.textContent).not.toContain('1234-****-****-5678');
    expect(card.textContent).not.toContain('카드사 코드');
    expect(card.textContent).not.toContain('카드 종류');
    expect(card.textContent).toContain('카드 정보 확인일');
    expect(card.textContent).toContain('2026-08-13');
    expect(card.textContent).not.toContain('현대카드');
    expect(card.textContent).not.toContain('billingKey');
  });

  it('케이뱅크 체크카드의 가려진 끝자리도 그대로 표시한다', () => {
    const { fixture } = setup({
      paymentMethod: {
        ...currentPaymentMethod,
        paymentMethod: {
          ...currentPaymentMethod.paymentMethod!,
          cardIssuerCode: '3A',
          cardNumberMasked: '48546200****113*',
          cardType: '체크',
        },
      },
    });
    const card = fixture.nativeElement.querySelector('[data-payment-method]') as HTMLElement;

    expect(card.textContent).toContain('케이뱅크 체크카드 · 카드번호 끝자리 113*');
    expect(card.textContent).not.toContain('48546200');
  });

  it('provider 조회 실패는 마이페이지 전체 오류가 아닌 마지막 확인 정보로 표시한다', () => {
    const { fixture } = setup({
      paymentMethod: { ...currentPaymentMethod, fresh: false },
    });

    expect(fixture.nativeElement.textContent).toContain('마지막으로 확인된 정보');
    expect(fixture.nativeElement.textContent).not.toContain('일부 이용 정보를 불러오지 못했습니다');
  });

  it('저장된 결제수단 정보도 없으면 결제수단만 별도 오류로 표시한다', () => {
    const { fixture } = setup({ paymentMethodError: true });

    expect(fixture.nativeElement.textContent).toContain('결제수단 정보를 불러오지 못했습니다');
    expect(fixture.nativeElement.textContent).not.toContain('일부 이용 정보를 불러오지 못했습니다');
  });

  it('구독이 없으면 결제수단 API를 호출하지 않는다', () => {
    const { getCurrentPaymentMethod } = setup({ subscription: null });

    expect(getCurrentPaymentMethod).not.toHaveBeenCalled();
  });

  it('활성 구독은 최종 동의 body와 nested checkout으로 카드 인증을 요청한다', fakeAsync(() => {
    const { fixture, open, startPaymentMethodChange, requestBillingAuth } = setup();

    (fixture.nativeElement.querySelector(
      '[data-action="change-payment-method"]',
    ) as HTMLButtonElement).click();
    tick();

    expect(open.calls.mostRecent().args[1].data.message).toContain('지금은 결제되지 않습니다');
    expect(open.calls.mostRecent().args[1].data.consentText).toBe('다음 정기결제부터 변경한 결제수단을 사용하는 데 동의합니다.');
    expect(open.calls.mostRecent().args[1].data.notices.join(' ')).toContain('39,900원 · 매월');
    expect(open.calls.mostRecent().args[1].data.notices.join(' ')).not.toContain('순차');
    expect(startPaymentMethodChange).toHaveBeenCalledOnceWith({
      retryPastDueAfterChange: false,
      consentedProductName: null,
      consentedAmountKrw: null,
    });
    expect(requestBillingAuth).toHaveBeenCalledOnceWith(
      jasmine.objectContaining({
        flow: 'billing_auth',
        receiptToken: 'c'.repeat(43),
        customerKey: 'customer-key',
      }),
    );
  }));

  it('연체 구독은 새 카드 등록 뒤 정확한 미결제 금액이 즉시 결제됨을 확인한다', fakeAsync(() => {
    const pastDue = {
      ...subscription,
      status: 'past_due' as const,
      firstPaymentFailedAt: '2026-09-01T00:00:00.000Z',
      graceEndsAt: '2026-09-04T00:00:00.000Z',
      retryAt: '2026-09-02T00:00:00.000Z',
    };
    const { fixture, open, startPaymentMethodChange } = setup({
      subscription: pastDue,
      paymentMethod: {
        ...currentPaymentMethod,
        renewalConsent: {
          orderNo: 'renewal-1',
          productName: 'Pro 월간',
          amountKrw: 39_900,
        },
      },
    });

    (fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement).click();
    tick();

    const dialogData = open.calls.mostRecent().args[1].data;
    expect(dialogData.message).toContain('Pro 월간');
    expect(dialogData.message).toContain('39,900원이 즉시 결제됩니다');
    expect(dialogData.confirmText).toBe('변경하고 39,900원 결제');
    expect(dialogData.consentText).toContain('미납금 39,900원을 즉시 결제');
    expect(dialogData.consentText).not.toContain('해지');
    expect(startPaymentMethodChange).toHaveBeenCalledWith({
      retryPastDueAfterChange: true,
      consentedProductName: 'Pro 월간',
      consentedAmountKrw: 39_900,
    });
  }));

  it('변경할 수 없는 상태면 버튼을 비활성화하고 이유를 표시한다', () => {
    const { fixture, startPaymentMethodChange } = setup({
      paymentMethod: {
        ...currentPaymentMethod,
        changeAllowed: false,
        changeBlockedReason: 'PAYMENT_RESULT_PENDING',
      },
    });
    const button = fixture.nativeElement.querySelector(
      '[data-action="change-payment-method"]',
    ) as HTMLButtonElement;

    expect(button.disabled).toBeTrue();
    expect(fixture.nativeElement.textContent).toContain('결제 결과를 확인하는 동안에는 변경할 수 없습니다');
    button.click();
    expect(startPaymentMethodChange).not.toHaveBeenCalled();
  });

  it('동의 후 결제 상태가 달라졌으면 새로고침 안내를 표시한다', fakeAsync(() => {
    const { fixture, requestBillingAuth } = setup({ startErrorStatus: 409 });

    (fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement).click();
    tick();
    fixture.detectChanges();

    expect(requestBillingAuth).not.toHaveBeenCalled();
    expect(fixture.nativeElement.textContent).toContain(
      '결제 상태가 변경되었습니다. 화면을 새로고침한 뒤 다시 확인해 주세요.',
    );
  }));

  it('변경 시작이 실패하면 취소할 시도가 없으므로 취소 API를 부르지 않는다', fakeAsync(() => {
    const { fixture, cancelPaymentMethodChange, getCurrentPaymentMethod } = setup({ startErrorStatus: 409 });

    (fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement).click();
    tick();

    expect(cancelPaymentMethodChange).not.toHaveBeenCalled();
    expect(getCurrentPaymentMethod).toHaveBeenCalledTimes(1);
  }));

  for (const [name, billingAuthError] of [
    ['카드 등록 창을 닫으면(USER_CANCEL)', { code: 'USER_CANCEL', message: '취소되었습니다.' }],
    ['결제창 SDK가 실패하면', new Error('sdk load failed')],
  ] as const) {
    it(`${name} 열린 변경 시도를 취소하고 결제수단 상태를 다시 불러온다`, fakeAsync(() => {
      const { fixture, cancelPaymentMethodChange, getCurrentPaymentMethod, paymentMethodCalls } = setup({
        billingAuthError,
        reloadedPaymentMethod: {
          ...currentPaymentMethod,
          paymentMethod: { ...currentPaymentMethod.paymentMethod!, cardNumberMasked: '43211234****555*' },
        },
      });

      (fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement).click();
      tick();
      fixture.detectChanges();

      expect(cancelPaymentMethodChange).toHaveBeenCalledOnceWith('change-1');
      expect(getCurrentPaymentMethod).toHaveBeenCalledTimes(2);
      expect(paymentMethodCalls).toEqual(['get', 'cancel', 'get']);
      expect(fixture.componentInstance.paymentMethod()?.paymentMethod?.cardNumberMasked).toBe('43211234****555*');
      const button = fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement;
      expect(button.disabled).toBeFalse();
      expect(fixture.nativeElement.textContent).toContain('결제수단 변경을 시작하지 못했습니다.');
    }));
  }

  it('취소 API가 실패해도 무시하고 결제수단 상태를 다시 불러온다', fakeAsync(() => {
    const { fixture, cancelPaymentMethodChange, getCurrentPaymentMethod } = setup({
      billingAuthError: { code: 'USER_CANCEL' },
      cancelChangeError: true,
    });

    (fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement).click();
    tick();
    fixture.detectChanges();

    expect(cancelPaymentMethodChange).toHaveBeenCalledOnceWith('change-1');
    expect(getCurrentPaymentMethod).toHaveBeenCalledTimes(2);
    const button = fixture.nativeElement.querySelector('[data-action="change-payment-method"]') as HTMLButtonElement;
    expect(button.disabled).toBeFalse();
    expect(fixture.nativeElement.textContent).toContain('결제수단 변경을 시작하지 못했습니다.');
  }));

  it('대기 이용권과 무통장 구매 요청 동선을 렌더링하지 않는다', () => {
    const { fixture } = setup();
    const text = fixture.nativeElement.textContent;

    expect(text).not.toContain('대기 이용권');
    expect(text).not.toContain('구매 요청');
    expect(text).not.toContain('입금');
    expect(fixture.nativeElement.querySelector('a[href="/my/purchase"]')).toBeNull();
    // 결제내역으로 가는 길은 마이페이지 왼쪽 메뉴가 맡는다(portal-layout spec).
  });
});
