import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, WritableSignal, computed, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthApiService } from '@core/api/auth-api.service';
import type { SignupDocumentType, SignupPreview } from '@core/api/models';
import { AuthService } from '@core/auth/auth.service';
import { BrowserNavigationService } from '@core/navigation/browser-navigation.service';
import { clearSignupTicket, takeSignupTicket, readSignupPromotionDraft, saveSignupPromotionDraft, clearSignupPromotionDraft } from './signup-ticket';
import { SignupDocDialogComponent, type SignupDocDialogData } from './signup-doc-dialog/signup-doc-dialog.component';

type ConsentView = 'loading' | 'ready' | 'error' | 'under14' | 'expired' | 'done-desktop';
type AgreementKey = 'age' | 'terms' | 'privacy';

/**
 * Google 로그인 직후 처음 1회 동의(만 14세 이상·약관·개인정보).
 * 서버가 동의 전에는 회원을 만들지 않으므로, 여기서 [동의]를 눌러야 가입·로그인이 끝난다.
 * spec: clipper_docs/architecture/2026-10-08-signup-consent-design.md §4.5
 */
@Component({
  selector: 'app-signup-consent',
  standalone: true,
  imports: [MatButtonModule, MatCardModule, MatCheckboxModule, MatProgressSpinnerModule, MatFormFieldModule, MatInputModule],
  templateUrl: './signup-consent.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrl: './signup-consent.component.scss',
})
export class SignupConsentComponent implements OnInit, OnDestroy {
  private readonly api = inject(AuthApiService);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly dialog = inject(MatDialog);
  private readonly navigation = inject(BrowserNavigationService);

  protected readonly view = signal<ConsentView>('loading');
  protected readonly preview = signal<SignupPreview | null>(null);
  protected readonly promotionCode = signal('');
  protected readonly canUsePromotion = computed(() => {
    const preview = this.preview();
    return !!preview && (!preview.isExistingUser || preview.isSignupPending);
  });
  protected readonly submitting = signal(false);
  protected readonly error = signal<string | null>(null);
  protected readonly desktopRedirectUrl = signal<string | null>(null);
  protected readonly agreed: Record<AgreementKey, WritableSignal<boolean>> = {
    age: signal(false),
    terms: signal(false),
    privacy: signal(false),
  };
  protected readonly allAgreed = computed(() => this.agreed.age() && this.agreed.terms() && this.agreed.privacy());

  private destroyed = false;
  private ticket: string | null = null;
  private promotionDraft: string | null = null;

  async ngOnInit(): Promise<void> {
    this.ticket = takeSignupTicket();
    if (!this.ticket) {
      clearSignupTicket();
      this.view.set('expired');
      return;
    }
    this.promotionDraft = readSignupPromotionDraft(this.ticket);
    await this.loadPreview();
  }

  ngOnDestroy(): void { this.destroyed = true; }

  protected setPromotionCode(event: Event): void {
    if (this.submitting() || !this.canUsePromotion() || !this.ticket) return;
    const input = event.target as HTMLInputElement;
    const code = input.value.trim().toUpperCase();
    input.value = code;
    this.promotionCode.set(code);
    this.promotionDraft = code;
    saveSignupPromotionDraft(this.ticket, code);
    this.error.set(null);
  }

  protected setAll(checked: boolean): void {
    for (const key of Object.keys(this.agreed) as AgreementKey[]) this.agreed[key].set(checked);
  }

  protected setOne(key: AgreementKey, checked: boolean): void {
    this.agreed[key].set(checked);
  }

  protected async openDoc(type: SignupDocumentType): Promise<void> {
    const ref = this.dialog.open<SignupDocDialogComponent, SignupDocDialogData, boolean>(SignupDocDialogComponent, {
      data: { type },
      width: '560px',
      maxWidth: 'calc(100vw - 32px)',
    });
    if (await firstValueFrom(ref.afterClosed())) this.agreed[type].set(true);
  }

  protected async submit(): Promise<void> {
    const preview = this.preview();
    if (!preview || !this.ticket || !this.allAgreed() || this.submitting()) return;
    this.submitting.set(true);
    this.error.set(null);
    try {
      const promotionCode = this.canUsePromotion() ? this.promotionCode().trim().toUpperCase() : '';
      const result = await firstValueFrom(this.api.completeSignup({
        ticket: this.ticket,
        ageOver14: true,
        termsVersion: versionOf(preview, 'terms'),
        privacyVersion: versionOf(preview, 'privacy'),
        ...(promotionCode ? { promotionCode } : {}),
      }));
      if (this.destroyed) return;
      clearSignupTicket();
      this.ticket = null;
      if (result.clientKind === 'web') {
        this.auth.setToken(result.accessToken);
        await this.auth.loadSession();
        if (this.destroyed) return;
        await this.router.navigateByUrl(result.returnPath);
        return;
      }
      this.desktopRedirectUrl.set(result.desktopRedirectUrl);
      this.view.set('done-desktop');
      this.openApp();
    } catch (err) {
      if (this.destroyed) return;
      await this.handleCompleteError(err);
    } finally {
      this.submitting.set(false);
    }
  }

  /** 브라우저가 자동 열기를 막을 수 있어 같은 주소를 버튼으로 다시 연다. */
  protected openApp(): void {
    const url = this.desktopRedirectUrl();
    if (url) this.navigation.assign(url);
  }

  protected showUnder14(): void {
    if (this.submitting()) return;
    this.forgetTicket();
    this.view.set('under14');
  }

  protected cancel(): void {
    if (this.submitting()) return;
    this.forgetTicket();
    void this.router.navigate(['/login'], { queryParams: { signup: 'cancelled' } });
  }

  protected restart(): void {
    void this.router.navigateByUrl('/login');
  }

  /** 미리보기를 일시적으로 못 불러왔을 때(대기표는 그대로) 다시 불러온다. */
  protected async retry(): Promise<void> {
    if (!this.ticket) {
      this.expire();
      return;
    }
    this.view.set('loading');
    this.error.set(null);
    await this.loadPreview();
  }

  private async loadPreview(): Promise<void> {
    try {
      const preview = await firstValueFrom(this.api.previewSignup(this.ticket!));
      if (this.destroyed) return;
      this.preview.set(preview);
      if (this.canUsePromotion()) {
        this.promotionCode.set(this.promotionDraft ?? (preview.isSignupPending ? preview.signupPromotionCode ?? '' : ''));
      } else {
        this.promotionCode.set('');
        this.promotionDraft = null;
        clearSignupPromotionDraft();
      }
      this.view.set('ready');
    } catch (err) {
      if (this.destroyed) return;
      // 대기표가 거부된 경우만 만료 화면. 네트워크·5xx는 대기표를 지키고 다시 시도하게 한다(spec §4.5).
      if (isTicketRejected(err)) this.expire();
      else this.view.set('error');
    }
  }

  private async handleCompleteError(err: unknown): Promise<void> {
    if (errorCode(err) === 'consent_version_outdated') {
      this.setAll(false);
      this.error.set('약관이 방금 바뀌었어요. 내용을 다시 확인하고 동의해 주세요.');
      await this.loadPreview();
      return;
    }
    if (isTicketRejected(err)) {
      this.expire();
      return;
    }
    const code = errorCode(err);
    this.error.set(typeof code === 'string' && signupPromotionMessages[code]
      ? signupPromotionMessages[code]
      : '가입을 완료하지 못했어요. 잠시 후 다시 시도해 주세요.');
  }

  private expire(): void {
    this.forgetTicket();
    this.view.set('expired');
  }

  private forgetTicket(): void {
    clearSignupTicket();
    this.promotionCode.set('');
    this.promotionDraft = null;
    this.ticket = null;
  }
}

function errorCode(err: unknown): unknown {
  return err instanceof HttpErrorResponse ? (err.error as { message?: unknown } | null)?.message : undefined;
}

/** 서버가 이 대기표를 더는 받지 않는다(만료·위조 401, 이미 사용 409). 그 외 오류는 대기표와 무관하다. */
function isTicketRejected(err: unknown): boolean {
  return err instanceof HttpErrorResponse && (err.status === 401 || errorCode(err) === 'signup_ticket_used');
}

function versionOf(preview: SignupPreview, type: SignupDocumentType): string {
  const doc = preview.documents.find((d) => d.type === type);
  if (!doc) throw new Error(`missing_${type}_version`);
  return doc.version;
}

const signupPromotionMessages: Record<string, string> = {
  PROMOTION_CODE_INVALID: '프로모션 코드 형식을 확인해 주세요.',
  PROMOTION_CODE_NOT_FOUND: '프로모션 코드를 찾을 수 없어요. 다시 확인해 주세요.',
  PROMOTION_INACTIVE: '이 코드는 지금 등록할 수 없어요. 다른 코드를 입력하거나 비워 두고 다시 시도해 주세요.',
  PROMOTION_ENDED: '이 코드의 등록 기간이 종료되었어요. 다른 코드를 입력하거나 비워 두고 다시 시도해 주세요.',
  PROMOTION_NOT_STARTED: '이 코드의 등록 기간이 아직 시작되지 않았어요.',
  PROMOTION_LIMIT_REACHED: '이 코드의 등록 가능 인원이 모두 찼어요. 다른 코드를 입력하거나 비워 두고 다시 시도해 주세요.',
  PROMOTION_SIGNUP_CREDITS_REQUIRED: '가입 크레딧 코드만 사용할 수 있어요. 다른 코드를 입력하거나 비워 두고 다시 시도해 주세요.',
  PROMOTION_HISTORY_INELIGIBLE_PAID: '유료 이용권 결제·사용 이력이 있어 이 코드를 등록할 수 없어요.',
  PROMOTION_HISTORY_INELIGIBLE_ADMIN_PLAN: '관리자 지급 이용권 이력이 있어 이 코드를 등록할 수 없어요.',
  PROMOTION_CODE_ALREADY_REDEEMED: '이미 등록한 프로모션 코드예요.',
  PROMOTION_ALREADY_REDEEMED: '이미 참여한 프로모션이에요.',
  SIGNUP_PROMOTION_NEW_MEMBERS_ONLY: '가입 크레딧 코드는 신규 회원만 등록할 수 있어요.',
  SIGNUP_BENEFITS_PROCESSING: '가입 혜택을 처리하고 있어요. 아직 로그인이 완료되지 않았으니 잠시 후 다시 시도해 주세요.',
};
