import type { UserOnboardingJob } from '../../users/domain/user-onboarding-job.model.js';
import type { UserOnboardingJobsRepository } from '../../users/domain/user-onboarding-jobs.repository.js';
import { FreeTrialProvisioner } from './free-trial-provisioner.service.js';
import { FreeTrialOnboardingService } from './free-trial-onboarding.service.js';

const NOW = new Date('2026-08-31T00:00:00.000Z');

function job(attemptCount: number): UserOnboardingJob {
  return {
    id: 'job-1',
    userId: 'user-1',
    kind: 'free_trial_provisioning', promotionCode: null, signupTicketId: null,
    status: 'processing',
    attemptCount,
    claimGeneration: attemptCount,
    nextAttemptAt: NOW,
    leaseUntil: new Date('2026-08-31T00:05:00.000Z'),
    lastErrorCode: null,
    completedAt: null,
    createdAt: NOW,
    updatedAt: NOW,
  };
}

function context() {
  const jobs = {
    withClaim: jest.fn(async (_job, work) => work(jobs)),
    findByUserAndKind: jest.fn(async () => ({ ...job(1), status: 'completed' })),
    claimDue: jest.fn(() => Promise.resolve([])),
    claimForUser: jest.fn(() => Promise.resolve(undefined)),
    markCompleted: jest.fn(() => Promise.resolve(job(1))),
    markRetryableFailed: jest.fn(() => Promise.resolve(job(1))),
    markManualReview: jest.fn(() => Promise.resolve(job(6))),
  };
  const provisioner = {
    findUserForProvisioning: jest.fn(async () => ({ id: 'user-1', createdAt: NOW })),
    ensureForUser: jest.fn(() => Promise.resolve(null)),
  };
  const promotion = { ensureForUser: jest.fn(async () => ({ id: 'bonus' })) };
  const manager = {};
  const transactions = { run: jest.fn(async (work) => work(manager)) };
  return {
    promotion, transactions, manager, jobs,
    provisioner,
    service: new FreeTrialOnboardingService(
      jobs as unknown as UserOnboardingJobsRepository,
      provisioner as unknown as FreeTrialProvisioner, promotion as never, transactions as never,
    ),
  };
}

describe('FreeTrialOnboardingService', () => {
  it('reads the immutable user before holding the job lock instead of borrowing a second user connection', async () => {
    const t = context(); let holdingUserConnection = false;
    t.jobs.withClaim.mockImplementation(async (_job, work) => {
      holdingUserConnection = true;
      try { await work(t.jobs); } finally { holdingUserConnection = false; }
    });
    const users = { findById: jest.fn(async () => {
      if (holdingUserConnection) throw new Error('user pool exhausted');
      return { id: 'user-1', createdAt: NOW };
    }) };
    const access = { bind: () => access, withUserLock: async (_id, work) => work() };
    const trials = { bind: () => trials, lockPolicy: async () => ({ isEnabled: false }), findByUserId: async () => undefined };
    const credits = { bind: () => credits };
    const free = new FreeTrialProvisioner(users as never, access as never, trials as never, credits as never, t.transactions as never);
    const service = new FreeTrialOnboardingService(t.jobs as never, free, t.promotion as never, t.transactions as never);
    await service.process(job(1), NOW);
    expect(t.jobs.markCompleted).toHaveBeenCalled();
    expect(t.jobs.markRetryableFailed).not.toHaveBeenCalled();
    expect(users.findById).toHaveBeenCalledTimes(1);
  });

  it('commits the signup and promotion grants together before completing the user job', async () => {
    const t = context();
    await t.service.process({ ...job(1), signupTicketId: 'ticket', promotionCode: 'BOOTH2026' }, NOW);
    expect(t.transactions.run).toHaveBeenCalledTimes(1);
    expect(t.provisioner.ensureForUser).toHaveBeenCalledWith('user-1', NOW, t.manager, expect.objectContaining({ id: 'user-1' }));
    expect(t.promotion.ensureForUser).toHaveBeenCalledWith('user-1', 'BOOTH2026', NOW, t.manager);
    expect(t.jobs.markCompleted).toHaveBeenCalledWith('job-1', 1, NOW);
  });

  it('does not allow login until the durable benefit job is complete', async () => {
    const t = context();
    t.jobs.findByUserAndKind.mockResolvedValue({ ...job(1), status: 'processing' });
    await expect(t.service.ensureReadyForLogin('user-1', NOW)).rejects.toThrow('SIGNUP_BENEFITS_PROCESSING');
  });

  it('persists a safe promotion cap error and returns it instead of a false ready balance', async () => {
    const t = context();
    const pending = { ...job(1), signupTicketId: 'ticket', promotionCode: 'BOOTH2026' };
    t.jobs.claimForUser.mockResolvedValue(pending);
    t.promotion.ensureForUser.mockRejectedValue(new Error('PROMOTION_LIMIT_REACHED'));
    t.jobs.findByUserAndKind.mockResolvedValue({ ...pending, status: 'retryable_failed', lastErrorCode: 'PROMOTION_LIMIT_REACHED' });
    await expect(t.service.ensureReadyForLogin('user-1', NOW)).rejects.toThrow('PROMOTION_LIMIT_REACHED');
    expect(t.jobs.markCompleted).not.toHaveBeenCalled();
    expect(t.jobs.markRetryableFailed).toHaveBeenCalledWith('job-1', 1, expect.any(Date), 'PROMOTION_LIMIT_REACHED', NOW);
  });

  it('claims due work with a five-minute lease', async () => {
    const current = context();

    await current.service.claimDue(NOW, 100);

    expect(current.jobs.claimDue).toHaveBeenCalledWith(
      'free_trial_provisioning',
      NOW,
      new Date('2026-08-31T00:05:00.000Z'),
      100,
    );
  });

  it('marks a successfully provisioned job complete', async () => {
    const current = context();
    const claimed = job(1);

    await current.service.process(claimed, NOW);

    expect(current.provisioner.ensureForUser).toHaveBeenCalledWith(
      'user-1',
      NOW,
      undefined,
      expect.objectContaining({ id: 'user-1' }),
    );
    expect(current.jobs.markCompleted).toHaveBeenCalledWith('job-1', 1, NOW);
    expect(current.jobs.markRetryableFailed).not.toHaveBeenCalled();
  });

  it.each([
    [1, 60_000],
    [2, 5 * 60_000],
    [3, 30 * 60_000],
    [4, 2 * 60 * 60_000],
    [5, 12 * 60 * 60_000],
  ])('schedules attempt %s with the approved retry delay', async (attempt, delay) => {
    const current = context();
    current.provisioner.ensureForUser.mockRejectedValue(
      new Error('database detail must not be persisted'),
    );

    await current.service.process(job(attempt), NOW);

    expect(current.jobs.markRetryableFailed).toHaveBeenCalledWith(
      'job-1',
      attempt,
      new Date(NOW.getTime() + delay),
      'FREE_TRIAL_PROVISIONING_FAILED',
      NOW,
    );
  });

  it('moves the sixth failed attempt to manual review', async () => {
    const current = context();
    current.provisioner.ensureForUser.mockRejectedValue(new Error('failed'));

    await current.service.process(job(6), NOW);

    expect(current.jobs.markManualReview).toHaveBeenCalledWith(
      'job-1',
      6,
      'FREE_TRIAL_PROVISIONING_FAILED',
      NOW,
    );
    expect(current.jobs.markRetryableFailed).not.toHaveBeenCalled();
  });

  it('immediately claims and processes one user during credit-read repair', async () => {
    const current = context();
    const claimed = job(2);
    current.jobs.claimForUser.mockResolvedValue(claimed);

    await expect(current.service.repairForUser('user-1', NOW)).resolves.toBe(
      true,
    );

    expect(current.jobs.claimForUser).toHaveBeenCalledWith(
      'user-1',
      'free_trial_provisioning',
      NOW,
      new Date('2026-08-31T00:05:00.000Z'),
    );
    expect(current.jobs.markCompleted).toHaveBeenCalledWith('job-1', 2, NOW);
  });
});
