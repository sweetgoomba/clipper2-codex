"""Independent source-pixel evidence for output scene boundaries only."""

import cv2
import numpy as np


def _distance(left, right, *, centered=False):
    left, right = left.ravel(), right.ravel()
    if centered:
        left, right = left - left.mean(), right - right.mean()
    norm = float(np.linalg.norm(left) * np.linalg.norm(right))
    return None if norm < 1e-6 else float(1 - np.clip(np.dot(left, right) / norm, -1, 1))


def _features(image):
    # Exclude broadcast overlays; retain four independent central regions.
    gray = cv2.cvtColor(cv2.resize(image, (128, 72)), cv2.COLOR_BGR2GRAY).astype(np.float32)[11:58, 26:102]
    edge = np.stack((cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3),
                     cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)), axis=-1)
    return gray, edge


def spatial_cut_candidate(before, after):
    """Cheap screening only; a candidate cannot move an output boundary."""
    if before.shape != after.shape:
        return False
    left, right = _features(before), _features(after)
    gray = _distance(left[0], right[0], centered=True)
    edge = _distance(left[1], right[1])
    return gray is not None and edge is not None and gray >= .8 and edge >= .8


def _color_layout_agreement(before, after):
    """Positive channel gains can invert grayscale while preserving geometry."""
    images = [cv2.resize(im, (128, 72)).astype(np.float32)[11:58, 26:102]
              for im in (before, after)]
    matched = 0
    for y in (slice(0, 23), slice(23, None)):
        for x in (slice(0, 38), slice(38, None)):
            for channel in range(3):
                a, b = [im[y, x, channel] for im in images]
                valid = (a > 2) & (a < 253) & (b > 2) & (b < 253)
                if valid.sum() < 32 or valid.mean() < .25:
                    continue
                a, b = a[valid], b[valid]
                if min(float(a.std()), float(b.std())) < 1:
                    continue  # Constant channels cannot prove matching layout.
                distance = _distance(a, b, centered=True)
                if distance is not None and distance <= .02:
                    matched += 1
                    break
    return matched


def spatial_cut_evidence(images):
    """Require a persistent, isolated layout change between images 4 and 5.

    Ten consecutive original frames are required. This does not authorize
    identity transfer, body continuity, or a change of the selected performer.
    """
    report = dict(accepted=False, reason='unconfirmed_spatial_cut')
    def reject(reason):
        return dict(report, reason=reason)
    if (len(images) != 10 or any(im is None or im.ndim != 3 or im.shape[2] != 3
                                or im.shape != images[0].shape for im in images)):
        return reject('incomplete_spatial_context')
    features = [_features(im) for im in images]
    differences = [dict(gray=_distance(a[0], b[0], centered=True), edge=_distance(a[1], b[1]))
                   for a, b in zip(features, features[1:])]
    center = differences[4]
    report['differences'] = differences
    if (center['gray'] is None or center['edge'] is None
            or center['gray'] < .8 or center['edge'] < .8):
        return reject('similar_spatial_layout')
    if center['gray'] >= 1.8 and center['edge'] >= 1.8:
        # Strong color lighting can quantize common channels away. A strongly
        # inverted copy still retains the same spatial pattern, not a new shot.
        return reject('reversed_spatial_contrast')
    report['color_coherent_tiles'] = _color_layout_agreement(images[4], images[5])
    if report['color_coherent_tiles'] >= 3:
        return reject('photometric_color_change')
    tiles = []
    for y in (slice(0, 23), slice(23, None)):
        for x in (slice(0, 38), slice(38, None)):
            regions = [features[i][0][y, x] for i in (4, 5)]
            usable = all(r.std() >= 4 and np.mean((r <= 2) | (r >= 253)) <= .2 for r in regions)
            distance = _distance(features[4][1][y, x], features[5][1][y, x])
            tiles.append(bool(usable and distance is not None and distance >= .6))
    report['supporting_tiles'] = sum(tiles)
    if sum(tiles) < 3:
        return reject('insufficient_unclipped_spatial_support')
    for neighbors in (differences[:4], differences[5:]):
        if any(d['gray'] is None or d['edge'] is None for d in neighbors):
            return reject('insufficient_temporal_context')
        if any(d['gray'] >= .8 and d['edge'] >= .8 for d in neighbors):
            return reject('multiple_spatial_transitions')
        if (center['gray'] < 2 * max(.01, float(np.median([d['gray'] for d in neighbors])))
                or center['edge'] < 1.5 * max(.01, float(np.median([d['edge'] for d in neighbors])))):
            return reject('sustained_spatial_motion')
    for following in features[6:]:
        gray = _distance(features[4][0], following[0], centered=True)
        edge = _distance(features[4][1], following[1])
        if gray is not None and edge is not None and gray <= .2 and edge <= .4:
            return reject('returning_flash_or_insert')
    from .camera_transitions import structural_continuity
    structure = structural_continuity(images[4], images[5])
    report['structure'] = structure
    # Coherent camera motion is negative evidence, regardless of its magnitude.
    # Missing descriptors never supply the positive proof above.
    if (structure.get('inliers', 0) >= 30 and structure.get('ratio', 0) >= .6
            and structure.get('quadrants', 0) >= 3):
        return reject('coherent_camera_motion')
    return dict(report, accepted=True, reason='isolated_spatial_cut')
