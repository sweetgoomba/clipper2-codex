"""Persist the selected observed face crops used by Dance's person assignments."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import logging
from pathlib import Path
import re
from typing import BinaryIO

import cv2
import numpy as np


logger = logging.getLogger(__name__)


class FaceThumbnailStore(Mapping[int, bytes]):
    """Index dense display JPEGs in one anonymous file shared by a face batch.

    The pipeline closes the shared file after identity refinement has copied
    selected JPEGs. The file also closes when its final result is released.
    """

    def __init__(self, image_file: BinaryIO):
        self._file = image_file
        self._entries: dict[int, tuple[int, int]] = {}

    def __setitem__(self, frame_index: int, image: bytes) -> None:
        offset = self._file.seek(0, 2)
        self._file.write(image)
        self._entries[frame_index] = (offset, len(image))

    def __getitem__(self, frame_index: int) -> bytes:
        offset, length = self._entries[frame_index]
        self._file.seek(offset)
        return self._file.read(length)

    def __iter__(self):
        return iter(self._entries)

    def __len__(self):
        return len(self._entries)

    def __contains__(self, frame_index):
        return frame_index in self._entries

    def close(self) -> None:
        self._file.close()


def release_person_thumbnails(face_results: Sequence[object]) -> None:
    for result in face_results:
        thumbnails = getattr(result, "owned_thumbnails", None)
        if isinstance(thumbnails, FaceThumbnailStore):
            thumbnails.close()


def persist_person_thumbnails(
    project_root: Path,
    person_ids: Sequence[str],
    segment_images: Sequence[Sequence[bytes]],
) -> dict[str, str]:
    """Use only selected track evidence; missing crops never become scene portraits.

    These JPEGs were cropped during existing face extraction. Reusing them
    preserves the same observation and avoids another video decode or model call.
    """
    paths: dict[str, str] = {}
    for person_id, images in zip(person_ids, segment_images, strict=True):
        if person_id in paths or re.fullmatch(r"person_[1-9][0-9]*", person_id) is None:
            continue
        for image_bytes in images:
            if not image_bytes:
                continue
            try:
                image = cv2.imdecode(np.frombuffer(image_bytes, dtype=np.uint8), cv2.IMREAD_COLOR)
            except cv2.error:
                continue
            if image is None or image.size == 0:
                continue
            relative_path = f"faces/{person_id}.jpg"
            destination = project_root / relative_path
            try:
                destination.parent.mkdir(parents=True, exist_ok=True)
                if destination.write_bytes(image_bytes) != len(image_bytes):
                    continue
            except OSError:
                logger.warning("Cannot persist observed face thumbnail for %s", person_id, exc_info=True)
                break
            paths[person_id] = relative_path
            break
    return paths
