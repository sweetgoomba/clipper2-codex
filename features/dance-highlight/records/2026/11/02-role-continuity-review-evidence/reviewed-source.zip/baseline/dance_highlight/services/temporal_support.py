"""Choose independent frozen face observations without fixing the nearest one."""
import math


def independent_pair(values, minimum_gap=.15):
    """Minimize the worse distance in a pair separated by the required time.

    Values contain (distance, source time, ...). In distance order, the first
    prefix spanning the required time contains an optimal pair. Its earliest
    and latest instants suffice, so comparisons after sorting are linear.
    """
    ordered = sorted(v for v in values if math.isfinite(v[0]) and math.isfinite(v[1]))
    if not ordered:
        return None
    earliest = latest = ordered[0]
    for current in ordered[1:]:
        partners = [v for v in (earliest, latest) if abs(current[1] - v[1]) >= minimum_gap]
        if partners:
            return min(partners), current
        if current[1] < earliest[1]:
            earliest = current
        if current[1] > latest[1]:
            latest = current
    return None
