"""Retain visible Dance members outside the single selected main body."""
from dataclasses import replace
import numpy as np
from .segment import Segment
from .track import bbox_iou


def visible_member_segments(records, main_segments=None):
    """Track measurable heads with one-to-one body assignment, solely for sampling.

    These IDs never decide identity. The ordinary pose-owned face matcher names
    each resulting interval. Main bodies already sampled by the main pass are
    excluded; group-only and otherwise filtered intervals remain eligible.
    """
    active, completed, next_id = {}, [], 1
    times = sorted({r.t for r in records})
    step = float(np.median(np.diff(times))) if len(times) >= 2 else 1/30
    def finish(track):
        rows = track['rows']
        if len(rows) >= 2 and rows[-1][0]-rows[0][0] >= .3:
            completed.append(Segment('main', -track['id'], rows[0][0], rows[-1][0]+step, rows))
    for rec in records:
        for tid in list(active):
            if rec.t-active[tid]['rows'][-1][0] > .4:
                finish(active.pop(tid))
        covered = main_segments is None or any(s.start <= rec.t < s.end for s in main_segments)
        candidates = []
        for body, head in zip(rec.person_bboxes, rec.person_head_keypoints):
            if covered and rec.main_bbox is not None and bbox_iou(body, rec.main_bbox) >= .7:
                continue
            points = np.asarray(head)
            points = points[points[:, 2] >= .5, :2] if points.ndim == 2 and points.shape[1] >= 3 else []
            if len(points) < 2 or np.linalg.norm(np.ptp(points, axis=0)) < 12:
                continue
            candidates.append(body)
        pairs = sorted(((bbox_iou(body, track['rows'][-1][1]), index, tid)
                        for index, body in enumerate(candidates) for tid, track in active.items()), reverse=True)
        assigned, used = {}, set()
        for iou, index, tid in pairs:
            if iou >= .35 and index not in assigned and tid not in used:
                assigned[index] = tid; used.add(tid)
        for index, body in enumerate(candidates):
            tid = assigned.get(index)
            if tid is None:
                tid = next_id; next_id += 1
                active[tid] = {'id': tid, 'rows': []}
            active[tid]['rows'].append((float(rec.t), body, -tid))
    for track in active.values():
        finish(track)
    return sorted(completed, key=lambda s: (s.start, s.label))


def append_visible_member_clips(main_output, extra_output, matcher):
    """Add named supporting parts, subtracting coverage already kept per member."""
    from .member_timeline import _assign_piece
    occupied = {}
    for seg, decision in zip(main_output['segments'], main_output['decisions'], strict=True):
        if decision.reference_id:
            occupied.setdefault(decision.reference_id, []).append((seg.start, seg.end))
    next_label = max((x for x in main_output['labels'] if x is not None), default=0)+1
    added = 0
    for seg, decision, images, evidence, sources in zip(extra_output['segments'], extra_output['decisions'],
                                              extra_output['previews'], extra_output['evidence'], extra_output['preview_sources'], strict=True):
        name = decision.reference_id
        if not name:
            continue
        intervals = [(seg.start, seg.end)]
        for left, right in occupied.get(name, []):
            intervals = [(a, b) for start, end in intervals
                         for a, b in ((start, min(end, left)), (max(start, right), end)) if b > a]
        for start, end in intervals:
            if end-start < .3:
                continue
            part = replace(seg, start=start, end=end,
                           bboxes=[row for row in seg.bboxes if start <= row[0] < end])
            own = [(o, n) for o, n in evidence if start <= o.time_seconds < end]
            assignment = _assign_piece(part, own, matcher, extra_output['anchors'], 'visible-member')
            if assignment.reference_id != name:
                continue
            main_output['segments'].append(part); main_output['decisions'].append(assignment)
            main_output['evidence'].append(own)
            main_output['labels'].append(next_label); next_label += 1
            thumbnails, owned = sources
            candidates = sorted((o for o, _ in own), key=lambda o: o.quality, reverse=True)
            main_output['previews'].append([thumbnails.get(o.frame_index) or owned[o.frame_index]
                                            for o in candidates if o.frame_index in thumbnails or o.frame_index in owned][:5])
            main_output['preview_sources'].append(sources)
            occupied.setdefault(name, []).append((start, end)); added += 1
    order = sorted(range(len(main_output['segments'])), key=lambda i: (main_output['segments'][i].start, i))
    for key in ('segments', 'decisions', 'labels', 'previews', 'evidence', 'preview_sources'):
        main_output[key] = [main_output[key][i] for i in order]
    main_output['accurate_indices'] = list(range(len(order)))
    main_output['visible_member_clips_added'] = added
    return main_output
