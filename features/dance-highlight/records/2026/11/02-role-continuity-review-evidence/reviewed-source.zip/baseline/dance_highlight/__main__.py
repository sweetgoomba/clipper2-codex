"""dance_highlight 플러그인 엔트리포인트.

실행: python -m plugins.dance_highlight <port> [--idle-timeout <초>]
"""

import argparse
import logging

from .app import DanceHighlightPlugin

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
)


def main():
    parser = argparse.ArgumentParser(description="Dance Highlight Plugin")
    parser.add_argument("port", type=int, help="바인딩할 포트 번호")
    parser.add_argument(
        "--idle-timeout",
        type=float,
        default=300.0,
        help="유휴 자동 종료 시간(초). 0이면 persistent 모드. (기본: 300)",
    )
    args = parser.parse_args()

    plugin = DanceHighlightPlugin()
    plugin.run(port=args.port, idle_timeout=args.idle_timeout)


if __name__ == "__main__":
    main()
