import os
import urllib.parse
import urllib.request
import json
from typing import List, Dict, Any, Optional

import requests


class ImageSearchError(RuntimeError):
    """이미지 검색 중 발생한 에러."""

    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message)
        self.status_code = status_code


class HighlightImageSearchService:
    """
    highlight_dance 전용 이미지 검색 서비스

    목적:
    - S3 업로드 없이 이미지 URL만 수집
    - Naver 우선, 필요 시 Kakao fallback
    - 멤버별 후보 이미지 여러 장 확보
    """

    ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}  # gif 제외: 얼굴 임베딩에 사용 불가
    BLOCKED_CONTENT_TYPES = {"image/gif"}

    def __init__(self) -> None:
        self.naver_client_id = os.environ.get("NAVER_CLIENT_ID", "")
        self.naver_client_secret = os.environ.get("NAVER_CLIENT_SECRET", "")
        self.kakao_rest_api_key = os.environ.get("KAKAO_REST_API_KEY", "")

    # ------------------------------------------------------------------
    # 공통 유틸
    # ------------------------------------------------------------------
    def get_extension(self, url: str) -> str:
        try:
            clean_url = url.split("?")[0]
            if "." not in clean_url:
                return ""
            return clean_url.split(".")[-1].lower()
        except Exception:
            return ""

    def is_valid_image_url(self, url: str) -> bool:
        try:
            response = requests.head(url, timeout=3, allow_redirects=True)
            content_type = response.headers.get("Content-Type", "").split(";")[0].strip().lower()
            if not (response.status_code == 200 and content_type.startswith("image/")):
                return False
            if content_type in self.BLOCKED_CONTENT_TYPES:
                return False
            return True
        except Exception:
            return False

    def _dedupe_by_url(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen = set()
        out = []
        for item in items:
            image_url = item.get("image_url", "").strip()
            if not image_url:
                continue
            if image_url in seen:
                continue
            seen.add(image_url)
            out.append(item)
        return out

    # ------------------------------------------------------------------
    # Naver
    # ------------------------------------------------------------------
    def search_naver_images(
        self,
        keyword: str,
        page_size: int = 20,
        start: int = 1,
        sort: str = "sim",
        max_pages: int = 3,
    ) -> Dict[str, Any]:
        """
        네이버 이미지 검색
        - URL만 반환
        - 여러 페이지를 누적 수집
        """
        if not self.naver_client_id or not self.naver_client_secret:
            raise ImageSearchError(status_code=500, detail="네이버 이미지 API 키가 설정되지 않았습니다.")

        enc_query = urllib.parse.quote(keyword)
        current_start = start
        pages_tried = 0
        images: List[Dict[str, Any]] = []

        while pages_tried < max_pages and current_start <= 1000:
            url = (
                "https://openapi.naver.com/v1/search/image"
                f"?query={enc_query}&display={page_size}&start={current_start}&sort={sort}"
            )

            request = urllib.request.Request(url)
            request.add_header("X-Naver-Client-Id", self.naver_client_id)
            request.add_header("X-Naver-Client-Secret", self.naver_client_secret)

            try:
                with urllib.request.urlopen(request) as response:
                    if response.getcode() != 200:
                        raise ImageSearchError(
                            status_code=response.getcode(),
                            detail="Failed to fetch from Naver"
                        )

                    res_body = response.read()
                    data = json.loads(res_body)

                    for item in data.get("items", []):
                        link = item.get("link")
                        if not link:
                            continue

                        ext = self.get_extension(link)
                        if ext and ext not in self.ALLOWED_EXTENSIONS:
                            continue

                        images.append({
                            "image_url": link,
                            "thumbnail_url": item.get("thumbnail"),
                            "source": "naver",
                            "title": item.get("title"),
                            "doc_url": None,
                            "width": None,
                            "height": None,
                            "keyword": keyword,
                        })

                    current_start += page_size
                    pages_tried += 1

            except ImageSearchError:
                raise
            except Exception as e:
                raise ImageSearchError(status_code=500, detail=f"Naver image search error: {str(e)}")

        images = self._dedupe_by_url(images)

        return {
            "medias": images,
            "next_page": current_start if current_start <= 1000 else None,
        }

    # ------------------------------------------------------------------
    # Kakao
    # ------------------------------------------------------------------
    def search_kakao_images(
        self,
        keyword: str,
        page_size: int = 20,
        page: int = 1,
        sort: str = "accuracy",
        max_pages: int = 3,
    ) -> Dict[str, Any]:
        """
        카카오 이미지 검색
        - URL만 반환
        - 여러 페이지를 누적 수집
        """
        if not self.kakao_rest_api_key:
            raise ImageSearchError(status_code=500, detail="카카오 REST API 키가 설정되지 않았습니다.")

        headers = {
            "Authorization": f"KakaoAK {self.kakao_rest_api_key}"
        }

        current_page = page
        pages_tried = 0
        images: List[Dict[str, Any]] = []

        while pages_tried < max_pages and current_page <= 50:
            params = {
                "query": keyword,
                "size": page_size,
                "page": current_page,
                "sort": sort,
            }
            url = "https://dapi.kakao.com/v2/search/image"

            try:
                response = requests.get(url, headers=headers, params=params, timeout=5)
                response.raise_for_status()

                data = response.json()

                for item in data.get("documents", []):
                    image_url = item.get("image_url")
                    if not image_url:
                        continue

                    ext = self.get_extension(image_url)
                    if ext and ext not in self.ALLOWED_EXTENSIONS:
                        continue

                    images.append({
                        "image_url": image_url,
                        "thumbnail_url": item.get("thumbnail_url"),
                        "source": "kakao",
                        "title": None,
                        "doc_url": item.get("doc_url"),
                        "width": item.get("width"),
                        "height": item.get("height"),
                        "keyword": keyword,
                    })

                meta = data.get("meta", {})
                is_end = meta.get("is_end", True)

                current_page += 1
                pages_tried += 1

                if is_end:
                    break

            except requests.exceptions.HTTPError as e:
                status_code = e.response.status_code if e.response is not None else 500
                raise ImageSearchError(status_code=status_code, detail=f"Kakao image search error: {str(e)}")
            except requests.exceptions.RequestException as e:
                raise ImageSearchError(status_code=500, detail=f"Kakao image search error: {str(e)}")
            except Exception as e:
                raise ImageSearchError(status_code=500, detail=f"Kakao image search error: {str(e)}")

        images = self._dedupe_by_url(images)

        return {
            "medias": images,
            "next_page": current_page if current_page <= 50 else None,
        }

    # ------------------------------------------------------------------
    # 통합 검색
    # ------------------------------------------------------------------
    def search_member_images(
        self,
        artist_name: str,
        member_name: str,
        page: int = 1,
        target_count: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        멤버 이미지 검색 통합
        전략:
        1. Naver 우선
        2. 부족하면 Kakao 추가
        3. target_count 만큼 자르기
        """
        # solo artist인 경우 artistName과 memberName이 동일 → 중복 없이 단일 키워드 사용
        if artist_name.strip().lower() == member_name.strip().lower():
            keyword = artist_name.strip()
        else:
            keyword = f"{artist_name} {member_name}".strip()
        collected: List[Dict[str, Any]] = []

        # 1) Naver 우선
        try:
            naver_start = ((max(page, 1) - 1) * 20) + 1
            naver_result = self.search_naver_images(
                keyword=keyword,
                page_size=20,
                start=naver_start,
                sort="sim",
                max_pages=2,
            )
            collected.extend(naver_result.get("medias", []))
        except ImageSearchError as e:
            # 네이버 429면 그냥 넘어가고 카카오로 진행
            if e.status_code != 429:
                raise

        collected = self._dedupe_by_url(collected)

        # 2) 부족하면 Kakao 보충
        if len(collected) < target_count:
            kakao_result = self.search_kakao_images(
                keyword=keyword,
                page=max(page, 1),
                page_size=20,
                sort="accuracy",
                max_pages=2,
            )
            collected.extend(kakao_result.get("medias", []))
            collected = self._dedupe_by_url(collected)

        return collected[:target_count]