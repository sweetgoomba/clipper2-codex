from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Literal, Optional
import platform

try:
    import torch
except Exception:
    torch = None


ClusterMethod = Literal["agglomerative", "dbscan"]


def detect_yolo_device() -> object:
    sysname = platform.system()

    if sysname == "Darwin":
        if torch is not None and hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        return "cpu"

    if torch is None:
        print("[CONFIG] torch import failed → cpu", flush=True)
        return "cpu"

    try:
        available = torch.cuda.is_available()
        count = torch.cuda.device_count() if available else 0
        print(f"[CONFIG] torch.cuda.is_available()={available} device_count={count}", flush=True)
        if available:
            return 0
    except Exception as e:
        print(f"[CONFIG] torch.cuda check failed: {e}", flush=True)

    return "cpu"


def detect_ffmpeg_hw_encoder() -> Optional[str]:
    """
    플랫폼별 ffmpeg 하드웨어 인코더를 탐색.
    - macOS  : h264_videotoolbox (Apple VideoToolbox)
    - Windows/Linux + NVIDIA : h264_nvenc
    - 지원 없음 : None (libx264 fallback)
    """
    import subprocess
    try:
        result = subprocess.run(
            ["ffmpeg", "-hide_banner", "-encoders"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=5,
        )
        encoders = result.stdout + result.stderr

        if platform.system() == "Darwin" and "h264_videotoolbox" in encoders:
            return "h264_videotoolbox"

        if "h264_nvenc" in encoders:
            # h264_nvenc은 NVIDIA GPU 필요 — 컴파일되어 있어도 GPU 없으면 런타임 실패
            if torch is not None and torch.cuda.is_available():
                return "h264_nvenc"

    except Exception:
        pass

    return None


@dataclass(frozen=True)
class DanceConfig:
    # YOLO Pose
    yolo_model_path: str = "yolov8s-pose.pt"
    yolo_device: object = detect_yolo_device()
    yolo_half: bool = True
    yolo_conf: float = 0.25
    yolo_iou: float = 0.7

    # 분석 샘플링 (프레임 스킵)
    # TrackAssigner는 시간(초) 기반 TTL이므로 skip 증가가 트랙 연속성에 무영향
    analyze_skip: int = 4

    # 메인/그룹 후처리
    min_main_seg_sec: float = 1.2
    bridge_gap_sec: float = 1.2
    min_group_seg_sec: float = 1.2
    merge_gap_sec: float = 0.8

    # 메인 트랙 ID 할당(간단 트래커)
    track_match_iou: float = 0.35
    track_ttl_sec: float = 1.0

    # Face(OpenCV YuNet + AuraFace)
    face_det_size: Tuple[int, int] = (320, 320)
    face_min_det_score: float = 0.28
    face_nms_threshold: float = 0.30
    face_top_k: int = 5000

    # 메인 bbox에서 얼굴 ROI 확장 비율
    face_roi_expand_w: float = 0.15
    face_roi_expand_h_top: float = 0.35
    face_roi_expand_h_bottom: float = 0.10

    # 세그먼트당 최종 평균에 사용할 얼굴 샘플 프레임 수
    face_sample_frames: int = 5
    # 세그먼트당 먼저 훑어볼 얼굴 후보 프레임 수. 후보 중 품질 상위 face_sample_frames개만 평균에 사용한다.
    face_candidate_sample_frames: int = 12
    face_identity_interval_sec: float = .2
    # Opt-in until fixed-input ownership and identity evaluation accepts it.
    face_select_main_head: bool = False

    # 클러스터링
    cluster_method: ClusterMethod = "agglomerative"
    cluster_distance_threshold: float = 0.42
    dbscan_eps: float = 0.6
    dbscan_min_samples: int = 2

    # 클러스터 → 멤버 매핑
    # match: 이 거리 이하만 후보. duplicate_*: 이미 주인 클러스터가 있는 멤버에
    # 덧붙일 때의 추가 조건(min(duplicate_threshold, 주인거리 + duplicate_margin)).
    # 참조 멤버가 1명일 때 남의 클러스터가 전부 흡수되는 것을 막는다.
    member_match_threshold: float = 0.60
    member_duplicate_threshold: float = 0.45
    member_duplicate_margin: float = 0.08

    # ffmpeg 인코딩
    use_stream_copy: bool = True
    encode_preset: str = "medium"
    encode_crf: int = 18
    ffmpeg_hw_encoder: Optional[str] = detect_ffmpeg_hw_encoder()

    # FS 경로
    clips_dir_rel: str = "clips/dance"
    json_dir_rel: str = "json"
    meta_filename: str = "dance_meta.json"

    def resolved_yolo_half(self) -> bool:
        if self.yolo_device == 0 or self.yolo_device == "mps":
            return bool(self.yolo_half)
        return False
