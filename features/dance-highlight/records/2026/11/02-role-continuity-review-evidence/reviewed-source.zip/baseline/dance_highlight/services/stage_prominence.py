"""Corroborate a front performer with two independent perspective measurements.

Face scale alone favors people crossing the camera. Torso length alone favors
an extended pose. Agreement can preserve an isolated front performer when a
supporting row happens to straddle the exact image center. Temporal confirmation
and camera-subject evidence remain the responsibility of the role timeline.
"""
import numpy as np


def foreground_subject(features, width, height):
    measured = []
    for feature in features:
        size, x = feature.get('size'), feature.get('x')
        pose = np.asarray(feature.get('pose_keypoints', []))
        if size is None or x is None:
            continue
        if pose.shape != (17, 3):
            return None
        torso = pose[[5, 6, 11, 12]]
        if (not np.isfinite(torso).all() or (torso[:, 2] < .75).any()
                or (torso[:, 0] < 0).any() or (torso[:, 0] >= width).any()
                or (torso[:, 1] < 0).any() or (torso[:, 1] >= height).any()):
            return None
        length = float(np.linalg.norm(torso[:2, :2].mean(axis=0) - torso[2:, :2].mean(axis=0)))
        if length < .08 * height:
            return None
        measured.append((feature, length))
    if len(measured) < 3:
        return None
    selected, length = max(measured, key=lambda pair: pair[0]['size'])
    if not .2 * width <= selected['x'] <= .8 * width or selected['size'] < .04 * height:
        return None
    others = [(f, scale) for f, scale in measured if f is not selected]
    # Both measurements must be uniquely larger; two people in the front row
    # supply no single-subject evidence. The role timeline still requires a
    # sustained observation before this can replace an incumbent.
    if (selected['size'] < 1.08 * max(f['size'] for f, _ in others)
            or length < 1.08 * max(scale for _, scale in others)):
        return None
    return selected
