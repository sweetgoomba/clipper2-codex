import requests
from urllib.parse import unquote
from typing import List, Dict, Optional


class WikidataGroupResolver:
    EN_API = "https://en.wikipedia.org/w/api.php"
    SPARQL_API = "https://query.wikidata.org/sparql"

    def __init__(self, user_agent: str = "adlight/1.0 (contact: jinahan@metabuzz.co.kr)"):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": user_agent,
            "Accept": "application/json"
        })

    def _group_name_to_qid(self, group_name: str) -> Optional[str]:
        params = {
            "action": "query",
            "titles": group_name,
            "prop": "pageprops",
            "ppprop": "wikibase_item",
            "redirects": 1,
            "format": "json",
            "formatversion": 2,
        }

        r = self.session.get(self.EN_API, params=params, timeout=15)
        r.raise_for_status()
        data = r.json()

        pages = data.get("query", {}).get("pages", [])
        if not pages:
            return None

        return (pages[0].get("pageprops") or {}).get("wikibase_item")

    def _fetch_members_from_wikidata(self, group_qid: str) -> List[Dict]:
        sparql_query = f"""
        SELECT ?member ?memberLabel ?kowiki WHERE {{
          ?member wdt:P463 wd:{group_qid}.
          ?member wdt:P31 wd:Q5.

          OPTIONAL {{
            ?kowiki schema:about ?member ;
                    schema:isPartOf <https://ko.wikipedia.org/> .
          }}

          SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
        }}
        """

        r = self.session.get(
            self.SPARQL_API,
            params={"query": sparql_query},
            headers={
                "Accept": "application/sparql-results+json",
                "User-Agent": "adlight/1.0 (contact: jinahan@metabuzz.co.kr)"
            },
            timeout=15
        )
        r.raise_for_status()
        data = r.json()

        members: List[Dict] = []

        for item in data.get("results", {}).get("bindings", []):
            name_en = item["memberLabel"]["value"]

            ko_title = None
            if "kowiki" in item:
                raw = item["kowiki"]["value"].split("/")[-1]
                ko_title = unquote(raw)

            members.append({
                "name_en": name_en,
                "title_ko": ko_title,
                "display_ko": ko_title.split("(")[0].replace("_", " ").strip() if ko_title else None
            })

        return members

    def resolve_group_members(self, group_name: str) -> List[Dict]:
        group_qid = self._group_name_to_qid(group_name)
        if not group_qid:
            return []

        return self._fetch_members_from_wikidata(group_qid)

    def resolve_group_members_with_qid(self, group_name: str) -> Dict[str, object]:
        group_qid = self._group_name_to_qid(group_name)
        if not group_qid:
            return {
                "artist_qid": None,
                "members": []
            }

        members = self._fetch_members_from_wikidata(group_qid)
        return {
            "artist_qid": group_qid,
            "members": members
        }