"""Keep sustained main-performer changes out of one identity decision."""
from dataclasses import replace
import numpy as np
from .track import bbox_iou


def _center(observations):
    vector = np.mean([o.embedding for o in observations], axis=0)
    return vector / (np.linalg.norm(vector) + 1e-9)


def _spatial_change(a, b):
    area = lambda x: (x[2] - x[0]) * (x[3] - x[1])
    if min(area(a), area(b)) <= 0:
        return False
    scale = max(area(a), area(b)) / min(area(a), area(b))
    displacement = np.linalg.norm(np.array([(a[0]+a[2]-b[0]-b[2])/2,
                                            (a[1]+a[3]-b[1]-b[3])/2]))
    return scale >= 4 or (bbox_iou(np.asarray(a), np.asarray(b)) < .1
                         and displacement > np.sqrt(min(area(a), area(b))))


def find_identity_switches(segment, observations, *, reference_names=None):
    """Require repeated face change plus spatial change, never a track ID alone.

    Three nearby faces on each side reduce pose/blur noise. A shared directly
    matched reference vetoes an angle/scale change of the same known person.
    Boundaries are sample estimates (at most .6s bracket), not claimed PTS cuts.
    """
    reference_names = reference_names or {}
    rows = sorted((o for o in observations
                   if o.association == 'confirmed' and not o.failure
                   and o.embedding is not None and o.face_bbox is not None
                   and o.detector_score >= .5
                   and segment.start <= o.time_seconds < segment.end), key=lambda o:o.time_seconds)
    candidates = []
    for index in range(2, len(rows)-1):
        left, right = rows[max(0,index-3):index], rows[index:index+3]
        a, b = left[-1], right[0]
        if b.time_seconds - a.time_seconds > .6 or not _spatial_change(a.face_bbox, b.face_bbox):
            continue
        if a.time_seconds-left[0].time_seconds < .15 or right[-1].time_seconds-b.time_seconds < .15:
            continue
        if b.time_seconds-left[0].time_seconds > 1.2 or right[-1].time_seconds-a.time_seconds > 1.2:
            continue
        left_names = {reference_names[o.frame_index] for o in rows if b.time_seconds-2 <= o.time_seconds < b.time_seconds and o.frame_index in reference_names}
        right_names = {reference_names[o.frame_index] for o in rows if b.time_seconds <= o.time_seconds <= b.time_seconds+2 and o.frame_index in reference_names}
        if left_names & right_names:
            continue
        lc, rc = _center(left), _center(right)
        separation = 1. - float(lc @ rc)
        spread = max(np.mean([1.-float(o.embedding @ lc) for o in left]),
                     np.mean([1.-float(o.embedding @ rc) for o in right]))
        if separation < .7 or spread > .35:
            continue
        # Use the first newly observed face: an actual source-frame timestamp.
        cut = b.time_seconds
        if cut-segment.start < .6 or segment.end-cut < .6:
            continue
        candidates.append({'time':cut, 'left_time':a.time_seconds, 'right_time':b.time_seconds,
                           'face_distance':separation, 'within_side_spread':float(spread),
                           'reason':'repeated_face_and_spatial_change'})
    # Several windows around one transition compete; keep the strongest and
    # preserve a minimum useful clip length without re-merging different faces.
    selected = []
    for candidate in sorted(candidates,key=lambda c:c['face_distance'],reverse=True):
        if all(abs(candidate['time']-other['time']) >= .6 for other in selected):
            selected.append(candidate)
    return sorted(selected,key=lambda c:c['time'])


def split_segment(segment, boundaries):
    times = [segment.start, *[b['time'] for b in boundaries], segment.end]
    return [replace(segment, start=float(start), end=float(end),
                    bboxes=[row for row in segment.bboxes
                            if start <= row[0] < end or (end == segment.end and row[0] == end)])
            for start,end in zip(times,times[1:])]


def match_identity_piece(segment, observations, matches):
    """A new piece needs its own direct evidence; the parent's name never votes."""
    from .reference_matcher import SegmentReferenceDecision
    def reject(reason):
        return SegmentReferenceDecision(None, 'unmatched', reason)
    hits = [(o,m) for o,m in zip(observations,matches,strict=True) if m.reference_id]
    names = {m.reference_id for m in matches if m.reference_id}
    if len(names) > 1:
        return reject('conflicting_references')
    if any(m.reason in ('tied_references','insufficient_margin') for m in matches):
        return reject('competing_reference_evidence')
    clear_hits = [o for o,m in hits if o.detector_score >= .9]
    if len(clear_hits) < 2 or len(hits) * 2 < len(observations):
        return reject('insufficient_direct_support')
    times = [o.time_seconds for o,_ in hits]
    third = (segment.end-segment.start)/3
    if (max(times)-min(times) < .15 or min(times) > segment.start+third
            or max(times) < segment.end-third):
        return reject('insufficient_temporal_coverage')
    valid = [o for o in observations if o.association=='confirmed' and o.embedding is not None and not o.failure and o.detector_score >= .9]
    inconsistent = []
    for obs in valid:
        distances = sorted(1.-float(obs.embedding @ other.embedding)
                           for other,_ in hits if other.frame_index != obs.frame_index)
        if len(distances) < min(2,len(hits)-1) or distances[min(1,len(hits)-2)] > .6:
            inconsistent.append(obs.time_seconds)
    # A repeated second face vetoes the piece. An isolated vector cannot establish
    # a different identity in noisy dance footage; direct name conflicts still veto immediately.
    if len(inconsistent) >= 2 and max(inconsistent)-min(inconsistent) >= .15:
        return reject('inconsistent_face_scope')
    name = next(iter(names))
    distance = float(np.mean([next(c.distance for c in m.candidates if c.reference_id==name) for _,m in hits]))
    return SegmentReferenceDecision(name,'matched','split_pose_consensus',distance,name,distance,.6)


def refine_switch_boundaries(video_path, boundaries):
    """Locate a visual transition inside an already verified identity bracket."""
    import cv2
    cap = cv2.VideoCapture(video_path)
    refined = []
    try:
        if not cap.isOpened():
            return boundaries
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.)
        for boundary in boundaries:
            first = int(round(boundary['left_time'] * fps))
            last = int(round(boundary['right_time'] * fps))
            cap.set(cv2.CAP_PROP_POS_FRAMES, first)
            previous, best, scores = None, (0., last), []
            for index in range(first, last + 1):
                ok, frame = cap.read()
                if not ok:
                    break
                gray = cv2.cvtColor(cv2.resize(frame, (160,90)), cv2.COLOR_BGR2GRAY)
                if previous is not None:
                    score = float(cv2.absdiff(previous, gray).mean())
                    scores.append(score)
                    if score > best[0]:
                        best = (score, index)
                previous = gray
            # Otherwise retain the source-frame estimate for a gradual handover.
            frame_index = best[1] if best[0] >= 20. else last
            refined.append({**boundary, 'time':frame_index/fps,
                            'boundary_frame_index':frame_index, 'visual_difference':best[0],
                            'visual_peak_time':best[1]/fps,
                            'visual_peak_frame_index':best[1],
                            'visual_median_difference':float(np.median(scores)) if scores else 0.})
    finally:
        cap.release()
    return refined


def refine_main_identities(segments, decisions, labels, previews, face_results, matcher, *, video_path=None):
    """Refine unresolved clips only when at least one resulting piece has a name."""
    from dataclasses import asdict
    output = {'segments':[], 'decisions':[], 'labels':[], 'previews':[],
              'accurate_indices':[], 'audit':[]}
    next_label = max((label for label in labels if label is not None),default=0)+1
    for index,(seg,decision,label,images,result) in enumerate(zip(
            segments,decisions,labels,previews,face_results,strict=True)):
        observations = [o for o in getattr(result,'owned_observations',[]) if seg.start <= o.time_seconds < seg.end]
        boundaries, pieces, piece_decisions = [], [], []
        if decision.status != 'matched' and observations:
            matches = [matcher.match(o,seg,f'main-{index}') for o in observations]
            names = {o.frame_index:m.reference_id for o,m in zip(observations,matches,strict=True) if m.reference_id}
            boundaries = find_identity_switches(seg,observations,reference_names=names)
        def evaluate(cuts):
            parts = split_segment(seg,cuts)
            assignments = []
            for part_index,part in enumerate(parts):
                rows = [o for o in observations if part.start <= o.time_seconds < part.end]
                matches = [matcher.match(o,part,f'main-{index}-part-{part_index}') for o in rows]
                assignments.append(match_identity_piece(part,rows,matches))
            return parts,assignments
        if boundaries:
            pieces,piece_decisions = evaluate(boundaries)
            if any(d.status=='matched' for d in piece_decisions) and video_path is not None:
                boundaries = refine_switch_boundaries(video_path,boundaries)
                pieces,piece_decisions = evaluate(boundaries)
        applied = bool(boundaries and any(d.status=='matched' for d in piece_decisions)
                       and all(part.end-part.start >= .3 for part in pieces))
        output['audit'].append({'parent_index':index,'parent_start':seg.start,'parent_end':seg.end,
                                'baseline':asdict(decision),'boundaries':boundaries,'applied':applied,
                                'pieces':[{'start':part.start,'end':part.end,'decision':asdict(d)}
                                          for part,d in zip(pieces,piece_decisions,strict=True)]})
        if not applied:
            output['segments'].append(seg); output['decisions'].append(decision)
            output['labels'].append(label); output['previews'].append(images)
            continue
        for part,assignment in zip(pieces,piece_decisions,strict=True):
            output['accurate_indices'].append(len(output['segments']))
            output['segments'].append(part); output['decisions'].append(assignment)
            output['labels'].append(next_label); next_label += 1
            owned_previews = getattr(result,'owned_previews',{})
            owned_thumbnails = getattr(result,'owned_thumbnails',{})
            candidates = sorted((o for o in observations if part.start <= o.time_seconds < part.end),
                                key=lambda o:o.quality,reverse=True)
            frames = [o.frame_index for o in candidates
                      if o.frame_index in owned_thumbnails or o.frame_index in owned_previews][:5]
            output['previews'].append([owned_thumbnails.get(frame) or owned_previews[frame]
                                       for frame in frames])
    return output
