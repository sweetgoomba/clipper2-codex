"""Observe a camera's central subject through lateral foreground crossings.

This narrow proof applies to a camera push-in with a unique stationary central
body and a larger person traversing the foreground. It returns observed body
indices separately from short, demonstrably covered holes. It never supplies an
identity, a fabricated body box, or permission to cross a camera cut.
"""
import numpy as np


_MAX_POSE_GAP = .400001


def _pose(feature):
    pose = np.asarray(feature.get('pose_keypoints', []), dtype=float)
    return pose if pose.shape == (17, 3) else None


def _scale(feature):
    size = feature.get('size')
    if size is not None and np.isfinite(size) and size > 0:
        return float(size)
    pose = _pose(feature)
    if pose is None:
        return 0.
    head = pose[:5]
    visible = np.isfinite(head).all(axis=1) & (head[:, 2] >= .5)
    if visible.sum() < 2:
        return 0.
    return float(np.linalg.norm(np.ptp(head[visible, :2], axis=0)))


def _distance(a, b):
    p, q = _pose(a), _pose(b)
    if p is None or q is None:
        return float('inf')
    visible = (np.isfinite(p[:7]).all(axis=1) & np.isfinite(q[:7]).all(axis=1)
               & (p[:7, 2] >= .5) & (q[:7, 2] >= .5))
    if visible[:5].sum() < 2 or visible[5:7].sum() < 1:
        return float('inf')
    scale = max(_scale(a), _scale(b))
    if scale < 4:
        return float('inf')
    return float(np.linalg.norm(p[:7, :2][visible]-q[:7, :2][visible], axis=1).mean()/scale)


def _head(feature):
    pose = _pose(feature)
    if pose is None:
        return None
    head = pose[:5]
    valid = np.isfinite(head).all(axis=1) & (head[:, 2] >= .5)
    return head[valid, :2].mean(axis=0) if valid.sum() >= 2 else None


def _covered_hole(shot, left, right):
    """Only interpolate an occluded head location, never an observable body."""
    li, a = left
    ri, b = right
    if ri == li+1:
        return True
    h1, h2 = _head(a), _head(b)
    if h1 is None or h2 is None:
        return False
    t1, t2 = shot[li]['time'], shot[ri]['time']
    for i in range(li+1, ri):
        frac = (shot[i]['time']-t1)/(t2-t1)
        head = h1*(1-frac)+h2*frac
        size = _scale(a)*(1-frac)+_scale(b)*frac
        covered = False
        for other in shot[i]['features']:
            box = np.asarray(other.get('box', []), dtype=float)
            if (box.shape == (4,) and np.isfinite(box).all()
                    and _scale(other) >= size
                    and _head(other) is not None
                    and np.linalg.norm(_head(other)-head) >= .25*size
                    and box[0] <= head[0] <= box[2]
                    and box[1] <= head[1] <= box[3]):
                covered = True
                break
        if not covered:
            return False
    return True


def _tracks(shot):
    tracks = []
    for i, row in enumerate(shot):
        features = row['features']
        active = [track for track in tracks
                  if 0 < row['time']-shot[track[-1][0]]['time'] <= _MAX_POSE_GAP]
        costs = np.full((len(active), len(features)), np.inf)
        for ai, track in enumerate(active):
            for fi, feature in enumerate(features):
                distance = _distance(track[-1][1], feature)
                if distance <= .65 and _covered_hole(shot, track[-1], (i, feature)):
                    costs[ai, fi] = distance
        attached = set()
        for ai, track in enumerate(active):
            order = np.argsort(costs[ai])
            if not len(order) or not np.isfinite(costs[ai, order[0]]):
                continue
            fi = int(order[0])
            if len(order) > 1 and costs[ai, order[1]]-costs[ai, fi] < .15:
                continue
            reverse = np.sort(costs[:, fi])
            if costs[ai, fi] != reverse[0] or len(reverse) > 1 and reverse[1]-reverse[0] < .15:
                continue
            track.append((i, features[fi]))
            attached.add(fi)
        tracks.extend([[(i, feature)] for fi, feature in enumerate(features) if fi not in attached])
    return tracks


def _central(track, shot, width, minimum_duration):
    times = [shot[i]['time'] for i, _ in track]
    xs = [f.get('x') for _, f in track]
    if (len(track) < 3 or times[-1]-times[0] < minimum_duration-1e-6
            or any(x is None or not np.isfinite(x) for x in xs)):
        return False
    return (max(abs(x-width/2) for x in xs) <= .12*width
            and np.ptp(xs) <= .10*width
            and abs(xs[-1]-xs[0])/(times[-1]-times[0]) <= .10*width)


def _push_in(track, shot, width, height):
    if not _central(track, shot, width, .6):
        return False
    measured = [f['size'] for _, f in track if f.get('size') is not None]
    if len(measured) < 6:
        return False
    edge = max(2, len(measured)//4)
    first, last = np.median(measured[:edge]), np.median(measured[-edge:])
    return first > 0 and last >= first*1.25 and last >= .075*height


def _foreground_passer(track, target, shot, width):
    if len(track) < 4 or shot[track[-1][0]]['time']-shot[track[0][0]]['time'] < .3:
        return False
    xs = [f.get('x') for _, f in track]
    if any(x is None or not np.isfinite(x) for x in xs):
        return False
    span = float(np.ptp(xs))
    if span < .18*width or abs(xs[-1]-xs[0]) < .8*span:
        return False
    target_by_row = dict(target)
    for i, feature in track:
        same = target_by_row.get(i)
        if same is not None and _scale(feature) >= _scale(same)*1.2:
            return True
    return False


def camera_focal_evidence(rows, width, height, cuts):
    """Return source-bound camera episodes, with visible and role-only evidence.

    The caller must still establish member identity from owned visible faces.
    A role-only frame is context for that episode; it must not be passed into a
    face matcher using a foreground person's box.
    """
    if width <= 0 or height <= 0:
        return []
    shots = []
    for row in rows:
        if (not shots or not 0 < row['time']-shots[-1][-1]['time'] <= .200001
                or any(shots[-1][-1]['frame'] < c <= row['frame'] for c in cuts)):
            shots.append([])
        shots[-1].append(row)
    result = []
    for shot in shots:
        tracks = _tracks(shot)
        candidates = [track for track in tracks if _push_in(track, shot, width, height)]
        if len(candidates) != 1:
            continue
        target = candidates[0]
        # A second established central body can be a real handoff. Camera
        # context must not decide that identity or override its observed role.
        if any(track is not target and _central(track, shot, width, .3) for track in tracks):
            continue
        passers = [track for track in tracks if track is not target
                   and _foreground_passer(track, target, shot, width)]
        if not passers:
            continue
        observed = {i for i, _ in target}
        start, end = target[0][0], target[-1][0]
        result.append(dict(
            start_frame=shot[start]['frame'], end_frame=shot[end]['frame'],
            start_time=shot[start]['time'], end_time=shot[end]['time'],
            visible_targets=[dict(frame=shot[i]['frame'], index=f['index']) for i, f in target],
            role_only_frames=[shot[i]['frame'] for i in range(start, end+1) if i not in observed],
            reason='stationary_camera_subject_behind_lateral_foreground',
        ))
    return result
