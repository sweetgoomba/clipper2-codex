import json
import re
from pathlib import Path
from typing import List, Dict, Any, Optional


_DATA_DIR = Path(__file__).resolve().parent.parent / "data"


EXCLUDE_KEYWORDS = [
    "music bank",
    "뮤직뱅크",
    "inkigayo",
    "인기가요",
    "music core",
    "쇼 음악중심",
    "show musiccore",
    "m countdown",
    "엠카운트다운",
    "mnet",
    "kbs",
    "mbc",
    "sbs",
    "방송",
    "stage",
    "performance",
    "live",
    "ver",
    "bonus",
]

EXCLUDE_PATTERNS = [
    r"\[.*?\]",
    r"\(.*?방송\)",
]


class ArtistTitleDetector:
    def __init__(self, artists_json_path: Optional[Path] = None):
        if artists_json_path is None:
            artists_json_path = _DATA_DIR / "korean_artists.json"

        self.artists_json_path = artists_json_path
        self.artists: Dict[str, Any] = self._load_artists()
        self.search_list: List[Dict[str, Any]] = self._build_search_names(self.artists)

    def _load_artists(self) -> Dict[str, Any]:
        print(f"[ArtistTitleDetector] json path = {self.artists_json_path}")

        if not self.artists_json_path.exists():
            print("[ArtistTitleDetector] artists json NOT FOUND")
            return {}
        
        data = json.loads(self.artists_json_path.read_text(encoding="utf-8"))
        print(f"[ArtistTitleDetector] loaded artists = {len(data)}")
        
        return data

    @staticmethod
    def normalize(text: str) -> str:
        text = (text or "").lower()
        text = re.sub(r"[^\w가-힣]+", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def clean_title(self, title: str) -> str:
        text = (title or "").lower()

        for pattern in EXCLUDE_PATTERNS:
            text = re.sub(pattern, " ", text)

        for keyword in EXCLUDE_KEYWORDS:
            text = text.replace(keyword.lower(), " ")

        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def _build_search_names(self, artists: Dict[str, Any]) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []

        for key, data in artists.items():
            names: List[str] = []

            if data.get("label_en"):
                names.append(data["label_en"])

            if data.get("label_ko"):
                names.append(data["label_ko"])

            for name in names:
                norm = self.normalize(name)

                if len(norm) <= 2:
                    continue

                if norm.isdigit():
                    continue

                result.append({
                    "display": key,
                    "normalized": norm,
                    "qid": data["qid"],
                    "type": data["type"],
                })

        return result

    def extract_all_matches(self, title: str) -> List[Dict[str, Any]]:
        cleaned = self.clean_title(title)
        norm_title = self.normalize(cleaned)

        matches: List[Dict[str, Any]] = []

        for entry in self.search_list:
            pattern = r"\b" + re.escape(entry["normalized"]) + r"\b"
            if re.search(pattern, norm_title):
                matches.append(entry)

        unique: Dict[str, Dict[str, Any]] = {}
        for item in matches:
            unique[item["qid"]] = item

        return list(unique.values())