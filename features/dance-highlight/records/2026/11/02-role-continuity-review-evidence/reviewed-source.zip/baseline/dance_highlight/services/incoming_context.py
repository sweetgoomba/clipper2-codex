"""Separately evidenced incoming clip context, never an exclusive main label.

A preceding formation view may be prepended to a verified incoming solo. Its
outgoing role, names, evidence and clips remain untouched. All new observations
are owned by the incoming body and remain outside the frozen naming gallery.
"""
from bisect import bisect_left
import math

import numpy as np

from .face_evidence import FaceObservation, select_pose_face
from .focal_output import _box_equal
from .member_timeline import _valid
from .segment import FrameRec
from .stage_prominence import foreground_subject

VERSION = 'named_incoming_preparation_v1'


def _complete(feature, width, height):
    pose = np.asarray(feature.get('pose_keypoints', []))
    box = np.asarray(feature['box'])
    if pose.shape != (17, 3) or not np.isfinite(pose).all():
        return False
    needed = pose[[5, 6, 11, 12]]
    return (np.all(needed[:, 2] >= .5) and (pose[:5, 2] >= .5).sum() >= 2
            and (pose[[15, 16], 2] >= .5).any()
            and .25*height <= box[3]-box[1] <= .85*height
            and np.all(needed[:, 0] >= 0) and np.all(needed[:, 0] < width)
            and np.all(needed[:, 1] >= 0) and np.all(needed[:, 1] < height))


def _formation(row, width, height):
    features = row['features']
    return (sum(_complete(f, width, height) for f in features) >= 3
            and all(f['box'][3]-f['box'][1] < .9*height for f in features))


def _owned(observation, feature, row, record, fps):
    if (observation is None or not _valid(observation) or observation.face_bbox is None
            or observation.frame_index != row['frame']
            or abs(observation.time_seconds-row['frame']/fps) > 1e-6
            or not _box_equal(observation.body_bbox, feature['box'])
            or not 0 <= feature['index'] < len(record.person_bboxes)
            or not _box_equal(feature['box'], record.person_bboxes[feature['index']])):
        return False
    pose = FrameRec(record.t, None, None, False,
        person_bboxes=[np.asarray(f['box']) for f in row['features']],
        person_head_keypoints=[f['pose_keypoints'][:5] for f in row['features']])
    selected, _ = select_pose_face([observation.face_bbox], np.asarray(feature['box']), pose)
    return selected == 0


def _positive(observation, match, name):
    # Positive support is stricter than counterevidence: an already accepted
    # valid rival must remain visible even at detector confidence .8--.9.
    return (observation is not None and observation.detector_score >= .9
            and match.get('status') == 'accepted' and match.get('name') == name)


def _body_distance(a, b):
    left, right = (np.asarray(f['pose_keypoints']) for f in (a, b))
    valid = ((left[:, 2] >= .5) & (right[:, 2] >= .5)
             & np.isfinite(left).all(axis=1) & np.isfinite(right).all(axis=1))
    head = [i for i in range(5) if valid[i]]
    torso = [5, 6, 11, 12]
    if len(head) < 2 or not valid[torso].all():
        return float('inf')
    scales = [np.linalg.norm(p[[5, 6], :2].mean(axis=0)-p[[11, 12], :2].mean(axis=0))
              for p in (left, right)]
    return (float(np.linalg.norm(left[head+torso, :2]-right[head+torso, :2], axis=1).mean()/np.mean(scales))
            if min(scales) >= 4 else float('inf'))


def _repositions(path):
    values, scales = [], []
    for row, feature, _, _ in path:
        center = np.asarray(feature['pose_keypoints'])[[5, 6, 11, 12], :2].mean(axis=0)
        others = [np.asarray(f['pose_keypoints'])[[5, 6, 11, 12], :2].mean(axis=0)
                  for f in row['features'] if f['index'] != feature['index']]
        if len(others) < 2:
            return False
        values.append(center-np.median(others, axis=0))
        p = np.asarray(feature['pose_keypoints'])
        scales.append(np.linalg.norm(p[[5, 6], :2].mean(axis=0)-p[[11, 12], :2].mean(axis=0)))
    return np.linalg.norm(values[-1]-values[0]) >= .15*np.median(scales)


def incoming_preparation_context(identity, records, joint_matches, *, fps, cut_frames, query):
    """Return separately owned clip contexts and a JSON-safe decision audit.

    ``query`` supplies cached ``geometry(record)`` and ``observe(record,index)``.
    Face recognition is queried only for the previous formation's incoming body
    and competing bodies at its tail or an ambiguous pose association. The
    first .8 seconds of the incoming shot are a verification window, not a
    clip duration rule. Nothing mutates exclusive main or identity arrays.
    """
    from .observed_main import strict_pose_corresponding
    audit = dict(version=VERSION, accepted=[], rejected=[], face_queries=0)
    if not math.isfinite(fps) or fps <= 0 or cut_frames is None or not records:
        return [], dict(audit, reason='source_context_unavailable')
    cuts = sorted(set(cut_frames))
    lookup = {round(r.t*fps): r for r in records}
    if len(lookup) != len(records):
        return [], dict(audit, reason='duplicate_source_records')
    rows, answers = {}, {}

    def geometry(record):
        frame = round(record.t*fps)
        if frame not in rows:
            rows[frame] = query.geometry(record)
        return rows[frame]

    def observe(row, feature):
        key = (row['frame'], feature['index'])
        if key not in answers:
            observation, match = query.observe(lookup[row['frame']], feature['index'])
            audit['face_queries'] += 1
            answers[key] = ((observation, match) if _owned(observation, feature, row, lookup[row['frame']], fps)
                            else (None, {}))
        return answers[key]

    contexts = []
    for source, (segment, decision, evidence) in enumerate(zip(identity['segments'], identity['decisions'], identity['evidence'], strict=True)):
        if decision.status != 'matched' or not decision.reference_id or segment.seg_type != 'main':
            continue
        cut = round(segment.start*fps)
        position = bisect_left(cuts, cut)
        if position == 0 or position == len(cuts) or cuts[position] != cut or abs(segment.start-cut/fps) > 1e-6:
            continue
        previous_cut = cuts[position-1]
        next_cut = cuts[position+1] if position+1 < len(cuts) else float('inf')
        name = decision.reference_id
        incoming = [o for o, _ in evidence if _valid(o)
                    and cut <= o.frame_index < next_cut
                    and segment.start <= o.time_seconds < min(segment.end, segment.start+.8)]
        contrary = False
        for observation in incoming:
            match = joint_matches.get(observation.frame_index, {})
            if match.get('status') != 'accepted' or match.get('name') == name:
                continue
            record = lookup.get(observation.frame_index)
            if record is None:
                continue
            selected = record.candidate_main_bbox if record.candidate_main_bbox is not None else record.main_bbox
            if not _box_equal(observation.body_bbox, selected):
                continue
            row = geometry(record)
            feature = next((f for f in row['features'] if _box_equal(f['box'], selected)), None) if row else None
            if feature is not None and _owned(observation, feature, row, record, fps):
                contrary = True; break
        if contrary:
            audit['rejected'].append(dict(source_index=source, reason='contrary_incoming_identity')); continue
        anchors = [o for o in incoming if _positive(o, joint_matches.get(o.frame_index, {}), name)]
        if len(anchors) < 2 or max(o.time_seconds for o in anchors)-min(o.time_seconds for o in anchors) < .15-1e-6:
            continue
        previous = [r for r in records if previous_cut <= round(r.t*fps) < cut]
        if (not previous or cut/fps-previous[-1].t > .200001):
            continue
        from .observed_main import retained_bodies
        shapes = []
        for record in previous:
            boxes = [np.asarray(b) for b in record.person_bboxes]
            poses = [np.asarray(p) for p in record.person_pose_keypoints]
            if len(boxes) != len(poses) or any(p.shape != (17, 3) for p in poses):
                shapes.append(dict(features=[])); continue
            shapes.append(dict(features=[dict(box=boxes[i], pose_keypoints=poses[i])
                for i in retained_bodies(boxes, poses)]))
        if any(not _formation(row, query.width, query.height) for row in shapes):
            audit['rejected'].append(dict(source_index=source, reason='previous_view_not_formation')); continue
        previous_rows = [geometry(r) for r in previous]
        if any(row is None or not _formation(row, query.width, query.height) for row in previous_rows):
            audit['rejected'].append(dict(source_index=source, reason='previous_view_not_formation')); continue
        fronts = []
        for observation in sorted(anchors, key=lambda o: o.time_seconds):
            record = lookup.get(observation.frame_index)
            row = geometry(record) if record is not None else None
            if row is None:
                continue
            front = foreground_subject(row['features'], query.width, query.height)
            selected = record.candidate_main_bbox if record.candidate_main_bbox is not None else record.main_bbox
            if (front is not None and _box_equal(front['box'], selected)
                    and _owned(observation, front, row, record, fps)):
                fronts.append(observation)
                if fronts[-1].time_seconds-fronts[0].time_seconds >= .15-1e-6:
                    break
        if len(fronts) < 2 or fronts[-1].time_seconds-fronts[0].time_seconds < .15-1e-6:
            audit['rejected'].append(dict(source_index=source, reason='incoming_front_solo_unverified')); continue
        last = previous_rows[-1]
        seeds = []
        for feature in last['features']:
            observation, match = observe(last, feature)
            if _positive(observation, match, name):
                seeds.append((last, feature, observation, match))
        if len(seeds) != 1:
            audit['rejected'].append(dict(source_index=source, reason='unique_incoming_tail_name_missing')); continue
        path = seeds
        bridges, rejected = [], False
        for row in reversed(previous_rows[:-1]):
            current, feature, own, match = path[-1]
            if not 0 < current['time']-row['time'] <= .200001:
                break
            earlier = strict_pose_corresponding(current, feature, row)
            if earlier is None:
                if not _positive(own, match, name):
                    break
                candidates = []
                for candidate in row['features']:
                    if _body_distance(candidate, feature) > .6:
                        continue
                    obs, named = observe(row, candidate)
                    if _positive(obs, named, name):
                        candidates.append((candidate, obs, named))
                if len(candidates) != 1:
                    break
                earlier, own, match = candidates[0]
                bridges.append(dict(previous_frame=row['frame'], frame=current['frame'], reason='independently_named_owned_endpoints'))
            else:
                own, match = observe(row, earlier)
            if match.get('status') == 'accepted' and match.get('name') != name:
                rejected = True; break
            path.append((row, earlier, own, match))
        if rejected:
            audit['rejected'].append(dict(source_index=source, reason='contrary_owned_identity')); continue
        path.reverse()
        named = [o for _, _, o, m in path if _positive(o, m, name)]
        if len(named) < 2 or named[-1].time_seconds-named[0].time_seconds < .15-1e-6 or not _repositions(path):
            audit['rejected'].append(dict(source_index=source, reason='incoming_preparation_not_corroborated')); continue
        start = path[0][0]['time']
        if path[0][0]['frame'] == previous_rows[0]['frame'] and start-previous_cut/fps <= .200001:
            start = previous_cut/fps
        proof = dict(source_index=source, start=start, end=cut/fps, reference_id=name,
            reason='named_incoming_preparation', previous_cut=previous_cut, incoming_cut=cut,
            named_frames=[o.frame_index for o in named], incoming_front_frames=[o.frame_index for o in fronts],
            bridges=bridges, visible_targets=[dict(frame=r['frame'], index=f['index']) for r, f, _, _ in path])
        contexts.append(dict(proof, observations=[o for _, _, o, _ in path if o is not None],
            bboxes=[(r['time'], np.asarray(f['box']), -1) for r, f, _, _ in path]))
        proof['context_observations'] = [dict(frame=o.frame_index, time=o.time_seconds,
            person_index=f['index'], body_bbox=list(map(float, o.body_bbox)),
            face_bbox=list(map(float, o.face_bbox)), landmarks=[list(map(float, p)) for p in o.landmarks],
            detector_score=float(o.detector_score), association=o.association, joint_match=m)
            for _, f, o, m in path if o is not None]
        audit['accepted'].append(proof)
    return contexts, dict(audit, reason='complete')


def match_frozen_query(observation, vector, frozen_joint):
    """Reuse the original joint policy without making a query a gallery anchor."""
    from .joint_identity import joint_video_matches
    frames = {a['frame_index'] for a in frozen_joint['anchors']}
    rows = {f: o for f, o in frozen_joint['observations'].items() if f in frames}
    vectors = {f: v for f, v in frozen_joint['vectors'].items() if f in frames}
    # Multiple people can share a source frame. A separate temporary key keeps
    # its original anchor intact; exclusion still uses actual source time.
    key = min([-1, *rows])-1
    rows[key], vectors[key] = observation, vector
    return joint_video_matches(rows, vectors, frozen_joint['anchors'], frozen_joint['roster'], query_frames={key})[key]


class IncomingFaceQuery:
    """Targeted source reads using existing primary/secondary model instances.

    Only one decoded image is retained. Detector results and queried owned
    observations are small cached values; no recovered row updates the gallery.
    Call ``close()`` in a finally block after computing preparation contexts.
    """
    def __init__(self, face_service, video_path, fps, frozen_joint, secondary_recognizer):
        import cv2
        self.service, self.fps, self.frozen = face_service, fps, frozen_joint
        self.secondary = secondary_recognizer
        self.cap = cv2.VideoCapture(str(video_path))
        if not self.cap.isOpened() or abs(self.cap.get(cv2.CAP_PROP_FPS)-fps) > .001:
            self.cap.release()
            raise ValueError('incoming_context_source_unavailable')
        self.width = round(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = round(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.frame, self.image = None, None
        self.detections, self.rows, self.observations = {}, {}, {}

    def close(self):
        self.cap.release()
        self.image = None

    def _image(self, frame):
        import cv2
        if frame != self.frame:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame)
            ok, image = self.cap.read()
            if not ok or abs(self.cap.get(cv2.CAP_PROP_POS_FRAMES)-(frame+1)) > .1:
                raise ValueError('incoming_context_source_frame_unavailable')
            self.frame, self.image = frame, image
        return self.image

    def geometry(self, record):
        from .observed_main import measured_features
        frame = round(record.t*self.fps)
        if frame not in self.rows:
            image = self._image(frame)
            self.service._detector.setInputSize((self.width, self.height))
            _, detected = self.service._detector.detect(image)
            self.detections[frame] = [] if detected is None else detected
            self.rows[frame] = dict(frame=frame, time=record.t,
                features=measured_features(record, self.detections[frame], self.width, self.height))
        return self.rows[frame]

    def observe(self, record, body_index):
        frame, key = round(record.t*self.fps), (round(record.t*self.fps), body_index)
        if key in self.observations:
            return self.observations[key]
        row = self.geometry(record)
        feature = next((f for f in row['features'] if f['index'] == body_index), None)
        if feature is None:
            return None, {}
        image = self._image(frame)
        pose = FrameRec(record.t, None, None, False,
            person_bboxes=[np.asarray(f['box']) for f in row['features']],
            person_head_keypoints=[f['pose_keypoints'][:5] for f in row['features']])
        candidate, _ = self.service._inspect_face(image, pose_record=pose,
            source_body=np.asarray(feature['box']), preferred_body=tuple(feature['box']), require_pose=True,
            cache={'detections': self.detections[frame]})
        result = (None, {})
        if candidate is not None:
            observation = FaceObservation(frame, frame/self.fps, -1, tuple(feature['box']),
                (0., 0., float(self.width), float(self.height)), face_bbox=candidate.face_bbox,
                landmarks=candidate.landmarks, candidate_boxes=candidate.candidate_boxes,
                embedding=candidate.embedding, quality=candidate.quality,
                detector_score=candidate.detector_score, face_sharpness=candidate.face_sharpness,
                association='confirmed', detection_rotation_degrees=candidate.detection_rotation_degrees)
            if _owned(observation, feature, row, record, self.fps) and len(observation.landmarks) == 5:
                from .secondary_faces import _normalized
                box = observation.face_bbox
                face = np.array([box[0], box[1], box[2]-box[0], box[3]-box[1],
                    *np.asarray(observation.landmarks).reshape(-1), observation.detector_score], np.float32)
                vector = _normalized(self.secondary.feature(self.secondary.alignCrop(image, face)))
                result = observation, match_frozen_query(observation, vector, self.frozen) if vector is not None else {}
        self.observations[key] = result
        return result


def apply_preparation_contexts(identity, contexts):
    """Prepend verified context without replacing another member's role.

    Evidence name stays None: joint agreement is in the separate context audit,
    and is not promoted to a direct primary-photo match. Context boxes use -1
    as a non-identity track sentinel. Existing preview ownership is unchanged.
    """
    from dataclasses import replace
    result = identity
    changed = set()
    for context in contexts:
        index = context['source_index']
        if not 0 <= index < len(identity['segments']) or index in changed:
            continue
        segment, decision = identity['segments'][index], identity['decisions'][index]
        start, end = context['start'], context['end']
        if (context.get('reason') != 'named_incoming_preparation' or decision.status != 'matched'
                or context['reference_id'] != decision.reference_id or not math.isfinite(start)
                or not math.isfinite(end) or not start < end or abs(end-segment.start) > 1e-6):
            continue
        if result is identity:
            result = dict(identity, segments=list(identity['segments']), evidence=list(identity['evidence']))
        result['segments'][index] = replace(segment, start=start,
            bboxes=[(time, box, -1) for time, box, _ in context['bboxes'] if start <= time < end]+segment.bboxes)
        result['evidence'][index] = [(o, None) for o in context['observations'] if start <= o.time_seconds < end]+identity['evidence'][index]
        changed.add(index)
    return result
