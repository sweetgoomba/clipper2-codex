from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional
import numpy as np


def bbox_iou(a: np.ndarray, b: np.ndarray) -> float:
    xA, yA = max(float(a[0]), float(b[0])), max(float(a[1]), float(b[1]))
    xB, yB = min(float(a[2]), float(b[2])), min(float(a[3]), float(b[3]))
    inter = max(0.0, xB - xA) * max(0.0, yB - yA)
    areaA = max(1.0, (float(a[2]) - float(a[0])) * (float(a[3]) - float(a[1])))
    areaB = max(1.0, (float(b[2]) - float(b[0])) * (float(b[3]) - float(b[1])))
    return float(inter / (areaA + areaB - inter + 1e-6))


@dataclass
class TrackState:
    track_id: int
    bbox: np.ndarray
    last_t: float


class TrackAssigner:
    def __init__(self, track_match_iou: float, track_ttl_sec: float):
        self.track_match_iou = float(track_match_iou)
        self.track_ttl_sec = float(track_ttl_sec)
        self.next_id = 1
        self.tracks: Dict[int, TrackState] = {}

    def _prune(self, t: float):
        dead = [tid for tid, st in self.tracks.items() if (float(t) - float(st.last_t)) > self.track_ttl_sec]
        for tid in dead:
            del self.tracks[tid]

    def assign(self, t: float, bbox: np.ndarray) -> int:
        self._prune(t)

        best_id: Optional[int] = None
        best_iou = 0.0
        for tid, st in self.tracks.items():
            i = bbox_iou(st.bbox, bbox)
            if i > best_iou:
                best_iou = i
                best_id = tid

        if best_id is not None and best_iou >= self.track_match_iou:
            self.tracks[best_id].bbox = bbox
            self.tracks[best_id].last_t = float(t)
            return int(best_id)

        tid = self.next_id
        self.next_id += 1
        self.tracks[tid] = TrackState(track_id=tid, bbox=bbox, last_t=float(t))
        return int(tid)