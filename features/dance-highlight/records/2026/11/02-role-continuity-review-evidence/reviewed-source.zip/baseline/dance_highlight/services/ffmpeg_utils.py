from __future__ import annotations

import os
import shutil
from pathlib import Path


def ensure_ffmpeg() -> str:
    env_path = os.environ.get("FFMPEG_BIN")
    if env_path and Path(env_path).is_file():
        return env_path

    path_bin = shutil.which("ffmpeg")
    if path_bin:
        return path_bin

    raise RuntimeError("ffmpeg 실행 파일을 찾지 못했습니다.")


def ensure_ffprobe() -> str:
    env_path = os.environ.get("FFPROBE_BIN")
    if env_path and Path(env_path).is_file():
        return env_path

    path_bin = shutil.which("ffprobe")
    if path_bin:
        return path_bin

    raise RuntimeError("ffprobe 실행 파일을 찾지 못했습니다.")
