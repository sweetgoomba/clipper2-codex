from __future__ import annotations

import subprocess
from pathlib import Path
from typing import List

from .ffmpeg_utils import ensure_ffmpeg


DEFAULT_SUBPROCESS_TIMEOUT_SEC = 3600.0


def run_cmd(cmd: List[str], timeout: float = DEFAULT_SUBPROCESS_TIMEOUT_SEC) -> None:
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           text=True, encoding='utf-8', errors='replace',
                           timeout=timeout)
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f"command timed out after {timeout:.0f}s: {cmd[0] if cmd else '?'}") from e
    if p.returncode != 0:
        raise RuntimeError(f"command failed:\n{cmd}\n\nstderr:\n{p.stderr}")


class RenderService:
    def __init__(self, config):
        self.config = config
        self.ffmpeg = ensure_ffmpeg()

    def _video_encode_args(self) -> List[str]:
        """
        설정된 하드웨어 인코더에 따라 ffmpeg 비디오 인코딩 인수를 반환.

        - h264_videotoolbox (macOS Apple VideoToolbox)
        - h264_nvenc        (Windows/Linux NVIDIA GPU)
        - libx264           (fallback, CPU)
        """
        hw = self.config.ffmpeg_hw_encoder

        if hw == "h264_videotoolbox":
            # VideoToolbox는 crf 미지원 → bitrate 기반
            return [
                "-c:v", "h264_videotoolbox",
                "-allow_sw", "1",          # SW fallback 허용 (호환성)
                "-b:v", "5000k",
                "-pix_fmt", "yuv420p",
            ]

        if hw == "h264_nvenc":
            # NVENC: -cq = 화질 기반 (낮을수록 고화질, libx264 crf와 유사)
            cq = str(self.config.encode_crf)
            return [
                "-c:v", "h264_nvenc",
                "-preset", "p4",           # p1(빠름)~p7(느림), p4 = balanced
                "-rc", "vbr",
                "-cq", cq,
                "-pix_fmt", "yuv420p",
            ]

        # libx264 fallback (CPU)
        return [
            "-c:v", "libx264",
            "-preset", self.config.encode_preset,
            "-crf", str(self.config.encode_crf),
            "-profile:v", "high",
            "-level", "4.2",
            "-pix_fmt", "yuv420p",
        ]

    def extract_clip(self, video_path: str, out_path: Path, start: float, end: float, *, accurate: bool = False) -> None:
        start = max(0.0, float(start))
        end = max(start, float(end))
        dur = end - start
        if dur <= 0.05:
            return

        out_path.parent.mkdir(parents=True, exist_ok=True)

        if self.config.use_stream_copy and not accurate:
            cmd = [
                self.ffmpeg, "-y",
                "-ss", f"{start}",
                "-to", f"{end}",
                "-i", video_path,
                "-c", "copy",
                str(out_path),
            ]
            run_cmd(cmd)
            return

        cmd = [
            self.ffmpeg, "-y",
            "-ss", f"{start}",
            "-to", f"{end}",
            "-i", video_path,
            *self._video_encode_args(),
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart",
            str(out_path),
        ]
        run_cmd(cmd)

    def extract_thumbnail(self, input_video: str, out_jpg: Path, ts_sec: float) -> None:
        out_jpg.parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            self.ffmpeg,
            "-y",
            "-ss", f"{float(ts_sec):.3f}",
            "-i", input_video,
            "-frames:v", "1",
            "-q:v", "2",
            str(out_jpg),
        ]
        run_cmd(cmd)
