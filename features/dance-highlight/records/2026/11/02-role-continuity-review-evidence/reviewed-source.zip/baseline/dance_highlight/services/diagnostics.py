"""Compact, source-time evidence for the dance result time map."""

from __future__ import annotations

from typing import Iterable

import numpy as np

from .segment import FrameRec


def _box(value: np.ndarray) -> list[float]:
    return [round(float(part), 2) for part in value]


def _inside(face: np.ndarray, body: np.ndarray) -> bool:
    cx = (float(face[0]) + float(face[2])) / 2
    cy = (float(face[1]) + float(face[3])) / 2
    return float(body[0]) <= cx <= float(body[2]) and float(body[1]) <= cy <= float(body[3])


def frame_diagnostics(recs: Iterable[FrameRec]) -> list[dict]:
    return [
        {
            "t": round(float(rec.t), 3),
            "main_track_id": rec.main_id,
            "main_body": _box(rec.main_bbox) if rec.main_bbox is not None else None,
            "bodies": [_box(box) for box in rec.person_bboxes],
            "faces": [_box(box) for box in rec.face_bboxes],
            "group": rec.is_group,
            "group_candidate": rec.group_candidate,
            "group_score_gap": round(rec.group_score_gap, 3) if rec.group_score_gap is not None else None,
            "group_area_ratio": round(rec.group_area_ratio, 3) if rec.group_area_ratio is not None else None,
            "group_bodies": [_box(box) for box in rec.group_bboxes],
            "group_faces": [_box(face) for face in rec.face_bboxes
                            if any(_inside(face, body) for body in rec.group_bboxes)],
        }
        for rec in recs
    ]


def coverage_gaps(duration: float, intervals: Iterable[tuple[float, float]]) -> list[tuple[float, float]]:
    """Complement of every exported clip, preserving overlaps in the source list."""
    end = max(0.0, duration)
    cursor = 0.0
    gaps: list[tuple[float, float]] = []
    for start, stop in sorted((max(0.0, a), min(end, b)) for a, b in intervals):
        if stop <= start:
            continue
        if start > cursor:
            gaps.append((cursor, start))
        cursor = max(cursor, stop)
    if cursor < end:
        gaps.append((cursor, end))
    return gaps
