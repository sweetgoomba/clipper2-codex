from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from pathlib import Path


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


@dataclass
class DanceClipItem:
    seg_id: int
    seg_type: str
    start: float
    end: float
    clip_path: Optional[str]
    person_id: Optional[str]
    person_ids: tuple[str, ...] | None = None
    clip_id: str | None = None
    thumbnail_path: str | None = None


class DanceMetaBuilder:
    def __init__(self, config):
        self.config = config

    def build(
        self,
        project_id: int,
        input_video_rel: str,
        main_items: List[DanceClipItem],
        group_items: List[DanceClipItem],
        persons: List[Dict[str, Any]],
        stats: Dict[str, Any],
        dance_setup: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return {
            "schema_version": "dance_meta_v1",
            "project_id": int(project_id),
            "category": "dance",
            "created_at": now_iso(),
            "input_video": input_video_rel,
            "config": {
                "yolo_model_path": self.config.yolo_model_path,
                "analyze_skip": int(self.config.analyze_skip),
                "min_main_seg_sec": float(self.config.min_main_seg_sec),
                "bridge_gap_sec": float(self.config.bridge_gap_sec),
                "min_group_seg_sec": float(self.config.min_group_seg_sec),
                "merge_gap_sec": float(self.config.merge_gap_sec),
                "track_match_iou": float(self.config.track_match_iou),
                "track_ttl_sec": float(self.config.track_ttl_sec),
                "face_sample_frames": int(self.config.face_sample_frames),
                "face_candidate_sample_frames": int(self.config.face_candidate_sample_frames),
                "face_min_det_score": float(self.config.face_min_det_score),
                "cluster_method": self.config.cluster_method,
                "cluster_distance_threshold": float(self.config.cluster_distance_threshold),
            },
            "lists": {
                "main": [self._item_to_dict(x) for x in main_items],
                "group": [self._item_to_dict(x) for x in group_items],
            },
            "persons": persons,
            "stats": stats,
            "dance_setup": self._public_dance_setup(dance_setup),
        }

    def _public_dance_setup(self, dance_setup: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not dance_setup:
            return {}
        setup = dict(dance_setup)
        setup["members"] = [
            {key: value for key, value in member.items()
             if key not in ("selectedImages", "validatedImagePaths")}
            for member in dance_setup.get("members", [])
        ]
        return setup

    def _item_to_dict(self, x: DanceClipItem) -> Dict[str, Any]:
        item = {
            "seg_id": int(x.seg_id),
            "seg_type": x.seg_type,
            "start": float(x.start),
            "end": float(x.end),
            "person_id": x.person_id,
        }
        if x.clip_path is not None:
            item["clip_path"] = x.clip_path
        if x.clip_id is not None:
            item["clip_id"] = x.clip_id
        if x.thumbnail_path is not None:
            item["thumbnail_path"] = x.thumbnail_path
        if x.person_ids is not None:
            item["person_ids"] = list(x.person_ids)
        return item
