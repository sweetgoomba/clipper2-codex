"""DancePipeline이 의존하는 추상 인터페이스.

DancePipeline은 구체 클래스가 아닌 이 Protocol들에만 의존한다.
구체 구현(PoseEngine, FaceClusterService, RenderService, DanceMetaBuilder)은
외부에서 주입하거나 팩토리에서 생성한다.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Protocol

import numpy as np

from .segment import Segment, FrameRec


class SegmentFaceResultLike(Protocol):
    """FaceClusterer가 반환하는 세그먼트별 얼굴 분석 결과."""

    seg: Segment
    track_embeddings: List[np.ndarray]
    face_detected: bool
    track_evidence_images: List[List[bytes]]
    track_thumbnail_images: List[List[bytes]]
    observations: list
    owned_observations: list


class PoseAnalyzer(Protocol):
    """프레임에서 포즈를 추출하는 인터페이스."""

    def run_pose_on_frame(self, frame: np.ndarray, *, image_size: int = 640) -> List[dict]:
        """단일 프레임에서 인물 포즈(bbox + keypoints)를 추출."""
        ...


class FaceClusterer(Protocol):
    """얼굴 임베딩 추출·클러스터링 인터페이스."""

    def get_face_embedding_from_image_path(self, image_path: str) -> Optional[np.ndarray]:
        """이미지 파일에서 얼굴 임베딩 추출."""
        ...

    def detect_face_boxes(self, frame: np.ndarray) -> List[np.ndarray]:
        """진단 화면용 전체 프레임 얼굴 박스."""
        ...

    def group_face_embeddings(
        self, frame: np.ndarray, participant_bboxes: List[np.ndarray],
    ) -> List[np.ndarray]:
        """단체 장면 참여자 몸 안에 있는 얼굴의 특징만 추출한다."""
        ...

    def average_embeddings(self, embeddings: List[np.ndarray]) -> Optional[np.ndarray]:
        """임베딩 리스트의 평균 벡터 계산."""
        ...

    def batch_segment_embeddings(
        self,
        video_path: str,
        segments: List[Segment],
        on_progress: Optional[Callable[[int, int], None]] = None,
        *, frame_records: Optional[List[FrameRec]] = None,
        evidence_only_indices: frozenset[int] = frozenset(),
        sample_all_main_frames: bool = False,
    ) -> List[SegmentFaceResultLike]:
        """영상의 세그먼트들에서 얼굴 임베딩을 일괄 추출."""
        ...

    def cluster_embeddings(self, embeddings: List[np.ndarray]) -> List[Optional[int]]:
        """임베딩 벡터들을 클러스터링하여 라벨 배열 반환."""
        ...


class Renderer(Protocol):
    """영상 클립 추출·인코딩 인터페이스."""

    def extract_clip(self, video_path: str, out_path: Path, start: float, end: float, *, accurate: bool = False) -> None:
        """영상에서 구간을 클립으로 추출."""
        ...

    def extract_thumbnail(self, input_video: str, out_jpg: Path, ts_sec: float) -> None:
        """영상의 특정 시점에서 썸네일 추출."""
        ...


class MetaBuilder(Protocol):
    """분석 결과를 메타데이터 dict로 조립하는 인터페이스."""

    def build(
        self,
        project_id: int,
        input_video_rel: str,
        main_items: List[Any],
        group_items: List[Any],
        persons: List[Dict[str, Any]],
        stats: Dict[str, Any],
        dance_setup: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """최종 메타데이터 dict 생성."""
        ...
