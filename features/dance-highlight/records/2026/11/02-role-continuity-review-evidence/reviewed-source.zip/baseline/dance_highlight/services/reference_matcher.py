"""Dance's adapter from selected main face features to the shared matching API.

The current face extractor returns one aggregate per temporary body track. Its ROI
selection is an assumption about face ownership, not independently verified GT.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Sequence

import numpy as np

from clipper_face_core import (
    EmbeddingSpace,
    GalleryBuildError,
    MatchPolicy,
    QueryEvidence,
    ReferenceSample,
    SourceEvidence,
    build_gallery,
    combine_reference_matches,
    match_reference,
)


@dataclass(frozen=True)
class ReferenceEmbeddingSample:
    reference_id: str
    sample_id: str
    image_sha256: str
    width: int
    height: int
    embedding: np.ndarray


@dataclass(frozen=True)
class SegmentEmbeddingScope:
    scope_id: str
    start_sec: float
    end_sec: float
    track_embeddings: tuple[np.ndarray, ...]
    cluster_id: int | None = None


@dataclass(frozen=True)
class SegmentReferenceDecision:
    reference_id: str | None
    status: str
    reason: str
    distance: float | None = None
    closest_reference_id: str | None = None
    closest_distance: float | None = None
    decision_threshold: float | None = None


def assign_reference_person_ids(
    *,
    references: Sequence[ReferenceEmbeddingSample],
    scopes: Sequence[SegmentEmbeddingScope],
    analysis_id: str,
    video_sha256: str,
    detector_sha256: str,
    recognizer_sha256: str,
    config_sha256: str,
    backend_version: str,
    video_size: tuple[int, int],
    max_distance: float,
    min_margin: float,
    duplicate_threshold: float = 0.45,
    duplicate_margin: float = 0.08,
) -> tuple[SegmentReferenceDecision, ...]:
    """Match each main segment independently; conflicting tracks stay unresolved."""
    if not references:
        return tuple(SegmentReferenceDecision(None, "unmatched", "no_references") for _ in scopes)

    width, height = video_size
    dimension = int(np.asarray(references[0].embedding).size)
    space = EmbeddingSpace(
        recognizer_sha256=recognizer_sha256,
        alignment_version="yunet5_arcface112_v1",
        preprocessing_version="bgr_to_rgb_mean127_5_std127_5_auraface_v1",
        normalization_version="float32_l2_eps_1e-9",
        dimension=dimension,
        backend_version=backend_version,
    )
    policy = MatchPolicy(max_distance=max_distance, min_margin=min_margin, minimum_support=1)
    samples = tuple(
        ReferenceSample(
            sample_id=ref.sample_id,
            reference_id=ref.reference_id,
            source=SourceEvidence(
                analysis_id=analysis_id,
                source_sha256=ref.image_sha256,
                observation_version=1,
                detector_sha256=detector_sha256,
                config_sha256=config_sha256,
                adapter_version="dance_reference_image_v1",
                time_kind="still_image",
                time_seconds=None,
                pts=None,
                time_base=None,
                frame_index=None,
                width=ref.width,
                height=ref.height,
                rotation=0,
                bbox_px=None,
                track_id=None,
                scope_id=None,
                scope_range_seconds=None,
            ),
            space=space,
            embedding=ref.embedding,
            failure=None,
        )
        for ref in references
    )
    try:
        gallery = build_gallery(samples, space=space)
    except GalleryBuildError as exc:
        if exc.reason != "no_valid_references":
            raise
        return tuple(SegmentReferenceDecision(None, "invalid", exc.reason) for _ in scopes)
    decisions = []
    for scope in scopes:
        if not scope.start_sec < scope.end_sec:
            raise ValueError("Invalid main segment range")
        queries = tuple(
            QueryEvidence(
                observation_id=f"{scope.scope_id}:aggregate:{index}",
                source=SourceEvidence(
                    analysis_id=analysis_id,
                    source_sha256=video_sha256,
                    observation_version=1,
                    detector_sha256=detector_sha256,
                    config_sha256=config_sha256,
                    adapter_version="dance_roi_track_aggregate_v1",
                    time_kind="derived_seconds",
                    time_seconds=(scope.start_sec + scope.end_sec) / 2,
                    pts=None,
                    time_base=None,
                    frame_index=None,
                    width=width,
                    height=height,
                    rotation=0,
                    bbox_px=None,
                    track_id=None,
                    scope_id=scope.scope_id,
                    scope_range_seconds=(scope.start_sec, scope.end_sec),
                ),
                space=space,
                embedding=embedding,
                # The ROI is selected by Dance, not confirmed by identity GT.
                association="confirmed",
                failure=None,
                quality=(),
            )
            for index, embedding in enumerate(scope.track_embeddings)
        )
        matches = tuple(match_reference(query, gallery, policy) for query in queries)
        consensus = combine_reference_matches(scope.scope_id, queries, matches, policy)
        selected_distances = tuple(
            candidate.distance
            for match in matches if match.reference_id == consensus.reference_id
            for candidate in match.candidates if candidate.reference_id == consensus.reference_id
        )
        nearest = min(
            (candidate for match in matches for candidate in match.candidates),
            key=lambda candidate: candidate.distance,
            default=None,
        )
        decisions.append(
            SegmentReferenceDecision(
                consensus.reference_id,
                consensus.status,
                consensus.reason,
                float(np.mean(selected_distances)) if selected_distances else None,
                nearest.reference_id if nearest is not None else None,
                float(nearest.distance) if nearest is not None else None,
                max_distance,
            )
        )

    # A second, distinct cluster needs the same conservative evidence that the
    # prior Dance mapper required. The core comparisons remain independent;
    # this is a Dance-only guard applied to final segment assignments.
    primary_by_reference: dict[str, tuple[float, int]] = {}
    for scope, decision in zip(scopes, decisions, strict=True):
        if decision.reference_id is None or decision.distance is None or scope.cluster_id is None:
            continue
        candidate = (decision.distance, scope.cluster_id)
        current = primary_by_reference.get(decision.reference_id)
        if current is None or candidate < current:
            primary_by_reference[decision.reference_id] = candidate

    guarded = []
    for scope, decision in zip(scopes, decisions, strict=True):
        primary = primary_by_reference.get(decision.reference_id or "")
        if (primary is not None and scope.cluster_id != primary[1]
                and decision.distance is not None
                and decision.distance > min(duplicate_threshold, primary[0] + duplicate_margin)):
            guarded.append(replace(
                decision,
                reference_id=None,
                status="unmatched",
                reason="duplicate_cluster_distance_exceeded",
                decision_threshold=min(duplicate_threshold, primary[0] + duplicate_margin),
            ))
        else:
            guarded.append(decision)
    return tuple(guarded)
