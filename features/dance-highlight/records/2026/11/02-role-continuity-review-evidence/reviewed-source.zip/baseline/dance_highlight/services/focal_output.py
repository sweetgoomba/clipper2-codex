"""Restore camera-role coverage using frozen, owned member evidence.

A camera episode describes an observed role, not a new identity match. Only an
already named selected body with agreeing independent joint face observations
can retain that role across the episode's explicitly observed occlusion holes.
"""
from dataclasses import replace
import math

import numpy as np

from .member_timeline import _valid
from .segment import Segment

VERSION = 'verified_camera_focal_output_v1'
_KEYS = ('segments', 'decisions', 'labels', 'evidence', 'previews', 'preview_sources')


def _box_equal(a, b):
    if a is None or b is None:
        return False
    a, b = np.asarray(a), np.asarray(b)
    return (a.shape == b.shape == (4,) and np.isfinite(a).all() and np.isfinite(b).all()
            and np.allclose(a, b, atol=1e-3, rtol=0))


def _previews(evidence, sources, start, end, fps):
    owned_frames = {row.frame_index for row, _ in evidence}
    thumbnails, owned = ({f: value for mapping in sources for f, value in mapping[k].items()
                          if f in owned_frames and start <= f/fps < end} for k in (0, 1))
    images = []
    for row, _ in sorted(evidence, key=lambda item: item[0].quality, reverse=True):
        image = thumbnails.get(row.frame_index)
        if image is None:
            image = owned.get(row.frame_index)
        if image is not None:
            images.append(image)
        if len(images) == 5:
            break
    return images, (thumbnails, owned)


def _piece(identity, index, start, end, fps):
    original = identity['segments'][index]
    evidence = [(o, n) for o, n in identity['evidence'][index] if start <= o.time_seconds < end]
    images, sources = _previews(evidence, [identity['preview_sources'][index]], start, end, fps)
    return dict(segments=replace(original, start=start, end=end,
                bboxes=[b for b in original.bboxes if start <= b[0] < end]),
                decisions=identity['decisions'][index], labels=identity['labels'][index],
                evidence=evidence, previews=images, preview_sources=sources,
                accurate=index in identity['accurate_indices'])


def _episode_proof(identity, episode, records, joint, fps, cuts, bounds, handoffs):
    lookup = {round(r.t*fps): (i, r) for i, r in enumerate(records)}
    if len(lookup) != len(records):
        return None, 'duplicate_source_records'
    try:
        targets = {int(v['frame']): int(v['index']) for v in episode['visible_targets']}
        hidden = set(episode['role_only_frames'])
        first, last = int(episode['start_frame']), int(episode['end_frame'])
        if (not targets or targets.keys() & hidden or first not in lookup or last not in lookup
                or len(targets) != len(episode['visible_targets']) or first > last
                or first not in targets or last not in targets
                or any(frame not in lookup or not first <= frame <= last for frame in targets.keys() | hidden)):
            return None, 'invalid_episode_inventory'
        lo, hi = lookup[first][0], lookup[last][0]
        if (lo > hi or any(not 0 < b.t-a.t <= .200001 for a, b in zip(records[lo:hi], records[lo+1:hi+1]))
                or any(round(record.t*fps) not in targets and round(record.t*fps) not in hidden
                       for record in records[lo:hi+1])):
            return None, 'unobserved_episode_frame'
        target_times = sorted(lookup[frame][1].t for frame in targets)
        if any(b-a > .400001 for a, b in zip(target_times, target_times[1:])):
            return None, 'occlusion_interval_too_long'
        if bounds is None:
            start = lookup[first][1].t
            end = (records[hi+1].t if hi+1 < len(records)
                   and 0 < records[hi+1].t-records[hi].t <= .200001 else records[hi].t+1/fps)
            end = min([end]+[cut/fps for cut in cuts if last < cut and cut/fps <= end])
        else:
            start, end = map(float, bounds)
        safe_left = records[lo-1].t if lo else records[lo].t-.200001
        safe_right = (records[hi+1].t if hi+1 < len(records)
                      and 0 < records[hi+1].t-records[hi].t <= .200001 else records[hi].t+1/fps)
        if (not math.isfinite(start) or not math.isfinite(end) or start >= end
                or start < safe_left-1e-6 or end > safe_right+1e-6):
            return None, 'bounds_outside_observed_episode'
        if any(start+1e-6 < cut/fps < end-1e-6 for cut in cuts):
            return None, 'source_cut_inside_episode'
        if any(start < float(h['time']) < end for h in handoffs):
            return None, 'main_handoff_inside_episode'
    except (KeyError, TypeError, ValueError):
        return None, 'invalid_episode_inventory'

    inside = {frame: record for frame, (_, record) in lookup.items() if start <= record.t < end}
    if not inside or any(frame not in targets and frame not in hidden for frame in inside):
        return None, 'unobserved_episode_frame'
    selected = {}
    for frame, record in inside.items():
        if frame in hidden:
            if record.main_bbox is not None:
                return None, 'occlusion_has_visible_main'
            continue
        index = targets[frame]
        if not 0 <= index < len(record.person_bboxes):
            return None, 'target_body_missing'
        body = record.person_bboxes[index]
        candidate = record.candidate_main_bbox
        if candidate is None:
            candidate = record.main_bbox
        if (not _box_equal(body, candidate) or record.main_bbox is not None
                and not _box_equal(body, record.main_bbox)
                or sum(_box_equal(body, other) for other in record.person_bboxes) != 1):
            return None, 'target_body_not_selected'
        selected[frame] = body

    source_indices = [i for i, segment in enumerate(identity['segments'])
                      if segment.start < end and start < segment.end]
    rows = []
    owners = []
    seen = set()
    for i in source_indices:
        for row, primary_name in identity['evidence'][i]:
            if not start <= row.time_seconds < end:
                continue
            body = selected.get(row.frame_index)
            owned = (body is not None and abs(row.time_seconds-row.frame_index/fps) < 1e-6
                     and _box_equal(row.body_bbox, body))
            if _valid(row) and not owned:
                return None, 'unowned_face_inside_episode'
            if not owned:
                continue
            key = (row.frame_index, tuple(row.body_bbox))
            if key not in seen:
                rows.append((row, primary_name)); owners.append(i); seen.add(key)
            elif primary_name and any(o.frame_index == row.frame_index and n and n != primary_name
                                      for o, n in rows):
                return None, 'conflicting_duplicate_face'
    accepted = [(row, joint.get(row.frame_index, {}).get('name'), i)
                for (row, _), i in zip(rows, owners, strict=True)
                if _valid(row) and joint.get(row.frame_index, {}).get('status') == 'accepted']
    names = {name for _, name, _ in accepted if name}
    if len(names) != 1:
        return None, 'joint_identity_not_unique'
    name = next(iter(names))
    anchors = [row for row, own_name, _ in accepted if own_name == name]
    if len(anchors) < 2 or max(o.time_seconds for o in anchors)-min(o.time_seconds for o in anchors) < .15-1e-6:
        return None, 'independent_joint_support_missing'
    if any(_valid(row) and primary and primary != name for row, primary in rows):
        return None, 'contrary_primary_identity'
    if any(joint.get(frame, {}).get('status') == 'accepted'
           and joint[frame].get('name') != name for frame in inside):
        return None, 'contrary_joint_identity'
    if any(identity['decisions'][i].status == 'matched'
           and identity['decisions'][i].reference_id != name for i in source_indices):
        return None, 'contrary_final_identity'
    agreeing = [i for _, own_name, i in accepted if own_name == name
                and identity['decisions'][i].status == 'matched'
                and identity['decisions'][i].reference_id == name]
    if not agreeing:
        return None, 'existing_owned_identity_missing'
    seed = agreeing[0]
    rows.sort(key=lambda item: item[0].time_seconds)
    images, sources = _previews(rows, [identity['preview_sources'][i] for i in source_indices], start, end, fps)
    record_boxes = [(record.t, selected[frame], record.candidate_main_id
                     if record.candidate_main_id is not None else record.main_id)
                    for frame, record in inside.items() if frame in selected]
    segment = Segment('main', identity['segments'][seed].label, start, end, record_boxes)
    piece = dict(segments=segment,
                 decisions=replace(identity['decisions'][seed], reason='verified_camera_focal_context'),
                 labels=identity['labels'][seed], evidence=rows, previews=images, preview_sources=sources,
                 accurate=any(i in identity['accurate_indices'] for i in source_indices))
    proof = dict(start=start, end=end, reference_id=name,
                 source_indices=source_indices, joint_frames=sorted({o.frame_index for o in anchors}),
                 visible_frames=sorted(selected), role_only_frames=sorted(hidden & inside.keys()))
    return (piece, proof), None


def restore_focal_output(identity, episodes, records, joint_matches, *, fps, cut_frames,
                         bounds=None, handoffs=()):
    """Return updated parallel identity lists and an audit of verified intervals.

    Explicit bounds may trim an episode or align its first/last observation to
    the adjacent original source boundary. The caller can use audit['restored']
    for scene eligibility and removing overlapping group clips.
    """
    audit = dict(version=VERSION, reason='complete', restored=[], rejected=[])
    if (not records or not episodes or not math.isfinite(fps) or fps <= 0
            or cut_frames is None or handoffs is None):
        return identity, dict(audit, reason='camera_output_proof_unavailable')
    if len({len(identity[key]) for key in _KEYS}) != 1 or bounds is not None and len(bounds) != len(episodes):
        return identity, dict(audit, reason='invalid_parallel_inputs')
    verified = []
    for index, episode in enumerate(episodes):
        result, reason = _episode_proof(identity, episode, records, joint_matches, fps, cut_frames,
                                        bounds[index] if bounds is not None else None, handoffs)
        if result is None:
            audit['rejected'].append(dict(episode_index=index, reason=reason)); continue
        piece, proof = result
        if any(proof['start'] < previous[1]['end'] and previous[1]['start'] < proof['end'] for previous in verified):
            audit['rejected'].append(dict(episode_index=index, reason='overlapping_camera_episodes')); continue
        verified.append((piece, proof)); audit['restored'].append(dict(proof, episode_index=index))
    if not verified:
        return identity, audit
    pieces = [piece for piece, _ in verified]
    for index, segment in enumerate(identity['segments']):
        intervals = [(segment.start, segment.end)]
        for _, proof in verified:
            remaining = []
            for start, end in intervals:
                if end <= proof['start'] or start >= proof['end']:
                    remaining.append((start, end)); continue
                if start < proof['start']:
                    remaining.append((start, proof['start']))
                if proof['end'] < end:
                    remaining.append((proof['end'], end))
            intervals = remaining
        pieces.extend(_piece(identity, index, start, end, fps) for start, end in intervals)
    pieces.sort(key=lambda piece: (piece['segments'].start, piece['segments'].end))
    result = {key: [piece[key] for piece in pieces] for key in _KEYS}
    result['accurate_indices'] = [i for i, piece in enumerate(pieces) if piece['accurate']]
    return dict(identity, **result), audit
