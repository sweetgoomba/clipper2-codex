"""Observed face fallback for cropped pose correspondence.

This is same-shot temporal role tracking, not a name assignment or cut proof.
All detected competitors are retained; missing or conflicting owners abstain.
"""

import cv2, numpy as np
from .cut_face_link import CutFaceLink, mutual_face_match
from .face_evidence import select_pose_face
from .segment import FrameRec


def _record(row):
    return FrameRec(
        row["time"],
        None,
        None,
        False,
        person_bboxes=[np.asarray(f["box"]) for f in row["features"]],
        person_head_keypoints=[np.asarray(f["head_keypoints"]) for f in row["features"]],
    )


def _missing_owner(row, owner, face):
    center = (np.asarray(face[:2]) + face[2:]) / 2
    for f in row["features"]:
        if f["index"] == owner["index"]:
            continue
        p = np.asarray(f["head_keypoints"])
        if p.ndim == 2 and p.shape[1] == 3:
            visible = np.isfinite(p).all(axis=1) & (p[:, 2] >= 0.5)
            if visible.sum() >= 2:
                continue
        b = f["box"]
        if b[0] <= center[0] <= b[2] and b[1] <= center[1] <= b[3]:
            return True
    return False


def observed_face_target(row, person, other, before, after, cuts, strict_corresponding=None):
    def reject(reason):
        return None, dict(accepted=False, reason=reason)

    lo, hi = sorted([row["frame"], other["frame"]])
    if not 0 < abs(row["time"] - other["time"]) <= 0.200001 or any(lo < c <= hi for c in cuts):
        return reject("cut_or_unobserved_gap")
    if person.get("source") != "detected" or not before or not after:
        return reject("missing_direct_face")
    if any(f[k] is None for f in before + after for k in ("primary", "secondary")):
        return reject("incomplete_face_inventory")
    records = [_record(r) for r in (row, other)]
    source, _ = select_pose_face([f["box"] for f in before], np.asarray(person["box"]), records[0])
    if source is None or before[source]["detector_score"] < 0.8:
        return reject("unconfirmed_source_face")
    if _missing_owner(row, person, before[source]["box"]):
        return reject("unobserved_competing_owner")
    matrices = [
        np.clip(1 - np.array([f[k] for f in before]) @ np.array([f[k] for f in after]).T, 0, 2)
        for k in ("primary", "secondary")
    ]
    matches = [
        (j, p)
        for j in range(len(after))
        if (p := mutual_face_match(*matrices, source, j))["accepted"]
    ]
    if len(matches) != 1:
        return reject("unconfirmed_dual_face_competition")
    target, proof = matches[0]
    owners = [
        f
        for f in other["features"]
        if select_pose_face([f["box"] for f in after], np.asarray(f["box"]), records[1])[0]
        == target
    ]
    if len(owners) != 1:
        return reject("unconfirmed_target_face")
    chosen = owners[0]
    if chosen.get("source") != "detected" or after[target]["detector_score"] < 0.8:
        return reject("missing_direct_target_face")
    if not (person.get("cropped_foreground") or chosen.get("cropped_foreground")):
        return reject("not_cropped")
    if _missing_owner(other, chosen, after[target]["box"]):
        return reject("unobserved_competing_owner")
    if strict_corresponding is not None:
        forward = strict_corresponding(row, person, other)
        reverse = strict_corresponding(other, chosen, row)
        if (forward is not None and forward["index"] != chosen["index"]) or (
            reverse is not None and reverse["index"] != person["index"]
        ):
            return reject("conflicting_pose_correspondence")
    boxes = [before[source]["box"], after[target]["box"]]
    sizes = [min(b[2:] - b[:2]) for b in boxes]
    if min(sizes) < 8 or max(sizes) > 1.4 * min(sizes):
        return reject("large_face_scale_change")
    shift = float(
        np.linalg.norm(before[source]["points"] - after[target]["points"], axis=1).mean()
        / min(sizes)
    )
    if shift > 1.0:
        return reject("distant_face")
    return chosen, dict(
        proof,
        normalized_shift=shift,
        reason="same_shot_dual_face",
        source_count=len(before),
        target_count=len(after),
    )


class MainFaceLink:
    def __init__(self, source, face_service):
        self.link = CutFaceLink(face_service=face_service)
        self.cap = cv2.VideoCapture(str(source))
        if not self.cap.isOpened():
            raise ValueError("source_unavailable")

    def get(self, frame):
        if (frame, 0.0) in self.link.cache:
            return self.link.cache[(frame, 0.0)]
        pos = self.cap.get(cv2.CAP_PROP_POS_FRAMES)
        if 0 <= frame - pos <= 12:
            for _ in range(round(frame - pos)):
                if not self.cap.grab():
                    raise ValueError("source_frame_unavailable")
        elif not self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame):
            raise ValueError("source_seek_failed")
        if abs(self.cap.get(cv2.CAP_PROP_POS_FRAMES) - frame) > 0.1:
            raise ValueError("source_position_mismatch")
        ok, image = self.cap.read()
        if not ok:
            raise ValueError("source_frame_unavailable")
        return self.link._faces(image, frame)

    def close(self):
        self.cap.release()
