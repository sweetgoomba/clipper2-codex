"""Confirm a continuous main role before assigning its original boundary."""

from .stage_prominence import foreground_subject


def choose_roles(rows, old, width, height, cuts, corresponding):
    last_row = last_selected = None
    pending = []
    for row in rows:
        valid = [f for f in row["features"] if f["size"] is not None and f["x"] is not None]
        for f in valid:
            f["score"] = f["size"] / height * max(0, 1 - abs(f["x"] - width / 2) / (width / 2)) ** 2
        old_box = old[row["frame"]]["candidate_main_bbox"]
        incumbent = next((f for f in row["features"] if f["box"] == old_box), None)
        continuous = (
            last_row is not None
            and 0 < row["time"] - last_row["time"] <= 0.200001
            and not any(last_row["frame"] < c <= row["frame"] for c in cuts)
        )
        if continuous and last_selected is not None:
            incumbent = corresponding(last_row, last_selected, row) or incumbent
        if not continuous:
            pending = []
        if incumbent is not None and incumbent.get("score") is None and (continuous or not valid):
            pending = []
            chosen = incumbent
            reason = "incomplete_incumbent_geometry"
        elif not valid:
            pending = []
            chosen = incumbent
            reason = "no_measured_face_keep_previous_selection"
        else:
            ordered = sorted(valid, key=lambda f: f["size"], reverse=True)
            dominant = (
                len(ordered) >= 2
                and ordered[0]["size"] >= 1.3 * ordered[1]["size"]
                and (
                    0.25 * width <= ordered[0]["x"] <= 0.75 * width
                    or ordered[0].get("cropped_foreground", False)
                )
            )
            foreground = foreground_subject(row['features'], width, height)
            desired = foreground or (ordered[0] if dominant else max(valid, key=lambda f: f["score"]))
            reason = ('corroborated_foreground_subject' if foreground is not None else
                      "dominant_face" if dominant else "measured_face_composition")
            dominant = dominant or foreground is not None
            if incumbent is None or not continuous or desired["index"] == incumbent["index"]:
                # A legacy reacquisition can catch up at the confirming observation. The
                # independently followed pending path still owns its original start.
                followed = (
                    corresponding(pending[-1][0], pending[-1][1], row)
                    if continuous and pending
                    else None
                )
                if (
                    followed is not None
                    and followed["index"] == desired["index"]
                    and row["time"] - pending[0][0]["time"] >= 0.15 - 1e-6
                ):
                    for previous, person, why in pending:
                        previous.update(
                            index=person["index"], box=person["box"], reason="confirmed_" + why
                        )
                chosen = desired
                pending = []
            elif not dominant and desired["score"] <= incumbent["score"] * 1.06:
                chosen = incumbent
                pending = []
                reason = "near_tie_keep_incumbent"
            else:
                followed = corresponding(pending[-1][0], pending[-1][1], row) if pending else None
                if followed is None or followed["index"] != desired["index"]:
                    pending = []
                pending.append((row, desired, reason))
                if row["time"] - pending[0][0]["time"] >= 0.15 - 1e-6:
                    # Confirm first, then place the transition at the actual evidence edge.
                    # There is no clip-duration limit and no extra delay in final boundaries.
                    for previous, person, why in pending:
                        previous.update(
                            index=person["index"], box=person["box"], reason="confirmed_" + why
                        )
                    chosen = desired
                    pending = []
                else:
                    chosen = incumbent
                    reason = "awaiting_sustained_composition"
        row.update(
            index=chosen["index"] if chosen else None,
            box=chosen["box"] if chosen else old_box,
            reason=reason,
        )
        last_row, last_selected = row, chosen


def extend_near_ties(rows, cuts, corresponding):
    selected = [
        next((f for f in row["features"] if f["index"] == row["index"]), None) for row in rows
    ]
    i = 0
    while i < len(rows):
        start = i
        i += 1
        if selected[start] is None:
            continue
        while i < len(rows) and selected[i] is not None:
            if rows[i]["time"] - rows[i - 1]["time"] > 0.200001 or any(
                rows[i - 1]["frame"] < c <= rows[i]["frame"] for c in cuts
            ):
                break
            match = corresponding(rows[i - 1], selected[i - 1], rows[i])
            if match is None or match["index"] != selected[i]["index"]:
                break
            i += 1
        if rows[i - 1]["time"] - rows[start]["time"] < 0.15:
            continue
        current = selected[start]
        current_row = rows[start]
        for j in range(start - 1, -1, -1):
            previous_row = rows[j]
            if (
                rows[start]["time"] - previous_row["time"] > 0.250001
                or current_row["time"] - previous_row["time"] > 0.200001
            ):
                break
            if any(previous_row["frame"] < c <= current_row["frame"] for c in cuts):
                break
            incumbent = next(
                (f for f in previous_row["features"] if f["index"] == previous_row["index"]), None
            )
            if incumbent is None or incumbent.get("score") is None:
                break
            candidate = corresponding(current_row, current, previous_row)
            if candidate is None or candidate.get("score") is None:
                break
            ranked = [f for f in previous_row["features"] if f.get("score") is not None]
            if not ranked or candidate["score"] < max(f["score"] for f in ranked) / 1.06:
                break
            if (
                any(proof in previous_row['reason'] for proof in
                    ('dominant_face', 'corroborated_foreground_subject'))
                and previous_row["index"] != candidate["index"]
            ):
                break
            previous_row.update(
                box=candidate["box"],
                index=candidate["index"],
                reason="confirmed_near_tie_transition",
            )
            current, current_row = candidate, previous_row
