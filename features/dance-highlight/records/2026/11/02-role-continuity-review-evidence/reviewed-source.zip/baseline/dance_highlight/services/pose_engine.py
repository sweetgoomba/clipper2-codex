from __future__ import annotations

from typing import List, Dict
import numpy as np


class PoseEngine:
    def __init__(self, config):
        self.config = config
        self._model = None
        self._ensure_model()

    def _ensure_model(self):
        if self._model is not None:
            return
        from ultralytics import YOLO
        self._model = YOLO(self.config.yolo_model_path)
        print(f"[YOLO] device={self.config.yolo_device} half={self.config.resolved_yolo_half()}", flush=True)

    def run_pose_on_frame(self, frame: np.ndarray, *, image_size: int = 640) -> List[dict]:
        self._ensure_model()

        results = self._model(
            frame,
            imgsz=image_size,
            device=self.config.yolo_device,
            half=self.config.resolved_yolo_half(),
            conf=self.config.yolo_conf,
            iou=self.config.yolo_iou,
            verbose=False,
        )

        persons: List[dict] = []
        if not results:
            return persons

        r = results[0]
        if r.boxes is None or r.keypoints is None:
            return persons

        boxes = r.boxes.xyxy.cpu().numpy()
        keypoints = r.keypoints.xy.cpu().numpy()

        confidence = r.keypoints.conf
        scores = confidence.cpu().numpy() if confidence is not None else None
        for index, (box, kp) in enumerate(zip(boxes, keypoints)):
            persons.append({
                "bbox": box.astype(np.float32),
                "keypoints": kp.astype(np.float32),
                "head_keypoints": (np.column_stack((kp[:5], scores[index, :5])).astype(np.float32)
                                   if scores is not None else np.empty((0, 3), dtype=np.float32)),
                "pose_keypoints": (np.column_stack((kp, scores[index])).astype(np.float32)
                                   if scores is not None else np.empty((0, 3), dtype=np.float32)),
            })

        return persons
