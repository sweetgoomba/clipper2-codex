"""Re-detect tilted Dance faces using measured pose eyes, without name input."""
import cv2
import numpy as np

from .face_evidence import select_pose_face
from .track import bbox_iou


def rotated_pose_face(image, detector, body, record, offset, min_score):
    if record is None or body is None or len(record.person_bboxes) != len(record.person_head_keypoints):
        return None
    owners = [i for i, box in enumerate(record.person_bboxes) if bbox_iou(body, box) >= .7]
    if len(owners) != 1:
        return None
    head = np.asarray(record.person_head_keypoints[owners[0]], np.float32)
    if head.ndim != 2 or head.shape[0] < 3 or head.shape[1] != 3:
        return None
    eyes = head[[1, 2]].copy()
    if not np.isfinite(eyes).all() or min(eyes[:, 2]) < .5:
        return None
    eyes[:, :2] -= offset
    height, width = image.shape[:2]
    if (np.any(eyes[:, :2] < 0) or np.any(eyes[:, 0] >= width)
            or np.any(eyes[:, 1] >= height)):
        return None
    delta = eyes[1, :2] - eyes[0, :2]
    if np.linalg.norm(delta) < 4.:
        return None
    angle = float((np.degrees(np.arctan2(delta[1], delta[0])) + 90.) % 180. - 90.)
    if not 15. <= abs(angle) <= 75.:
        return None
    matrix = cv2.getRotationMatrix2D(tuple(map(float, eyes[:, :2].mean(axis=0))), angle, 1.)
    try:
        rotated = cv2.warpAffine(image, matrix, (width, height))
        detector.setInputSize((width, height))
        _, faces = detector.detect(rotated)
        inverse = cv2.invertAffineTransform(matrix)
    except cv2.error:
        return None
    rotated_heads = []
    for value in record.person_head_keypoints:
        points = np.asarray(value, np.float32)
        if points.ndim != 2 or points.shape[1] != 3:
            rotated_heads.append(np.empty((0,2)))
            continue
        points = points[:5]
        points = points[np.isfinite(points).all(axis=1) & (points[:,2] >= .5), :2]
        rotated_heads.append((points-np.asarray(offset)) @ matrix[:,:2].T + matrix[:,2])
    restored, owned_indices = [], []
    for value in [] if faces is None else faces:
        face = np.asarray(value, np.float32).copy()
        if face.size != 15 or not np.isfinite(face).all() or face[-1] < min_score:
            continue
        x, y, w, h = face[:4]
        if min(w, h) <= 0:
            continue
        corners = cv2.transform(np.array([[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]]), inverse)[0]
        landmarks = cv2.transform(face[4:14].reshape(1,5,2), inverse)[0]
        if (np.any(landmarks < 0) or np.any(landmarks[:,0] >= width)
                or np.any(landmarks[:,1] >= height)):
            continue
        # Ownership belongs to the detected rotated rectangle. Its inverse
        # AABB is larger and may contain eyes outside the actual detection.
        counts = [int(np.sum((p[:,0] >= x) & (p[:,0] <= x+w) &
                             (p[:,1] >= y) & (p[:,1] <= y+h))) for p in rotated_heads]
        if counts[owners[0]] >= 2:
            if any(n >= 2 for i,n in enumerate(counts) if i != owners[0]):
                return None
            owned_indices.append(len(restored))
        low = np.maximum(corners.min(axis=0), 0.)
        high = np.minimum(corners.max(axis=0), [width, height])
        face[:4] = [*low, *(high-low)]
        face[4:14] = landmarks.ravel()
        restored.append(face)
    boxes = [(float(f[0])+offset[0], float(f[1])+offset[1],
              float(f[0]+f[2])+offset[0], float(f[1]+f[3])+offset[1]) for f in restored]
    if len(owned_indices) != 1:
        return None
    chosen, _ = select_pose_face(boxes, body, record)
    return (restored[chosen], restored, angle) if chosen == owned_indices[0] else None
