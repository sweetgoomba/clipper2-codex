from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

# 윈도우 MAX_PATH. 긴 경로 지원(레지스트리 LongPathsEnabled + longPathAware 매니페스트)이
# 꺼져 있으면 CreateFileW가 이 길이를 넘는 순간 ERROR_PATH_NOT_FOUND를 돌려주고, 파이썬은
# 그걸 FileNotFoundError(errno 2)로 옮긴다. 디렉토리 한도는 248이라 mkdir만 먼저 성공하는
# 경우가 흔해서, 원문 메시지만 보면 "방금 만든 폴더가 없다"는 엉뚱한 얘기로 읽힌다.
WINDOWS_MAX_PATH = 260

_WINDOWS_ABS_PATH = re.compile(r"^(?:[A-Za-z]:[\\/]|\\\\)")


@dataclass
class Classified:
    category: str
    level: str       # "info" | "warn" | "error"
    need_stack: bool


@dataclass
class PathDiagnosis:
    """OSError 원문에 덧붙일 한 줄 + 그 실패에 맞는 분류."""
    hint: str
    category: str


_NAME = {
    "ValueError": "validation",
    "ImageSearchError": "dependency",
    "FileNotFoundError": "not_found",
}
_LEVEL = {
    "validation": "warn", "not_found": "info", "conflict": "warn", "forbidden": "warn",
    "dependency": "error", "resource": "error", "not_implemented": "warn",
    "internal": "error", "cancelled": "info",
}


def diagnose_path(exc: BaseException) -> PathDiagnosis | None:
    """경로 때문에 난 OSError면 원인을 짚어 준다. 짚을 게 없으면 None."""
    if not isinstance(exc, OSError):
        return None
    filename = exc.filename
    if not isinstance(filename, (str, bytes, os.PathLike)):
        return None
    path = os.fsdecode(filename)
    if not path:
        return None

    if _is_windows_path(path) and len(path) > WINDOWS_MAX_PATH:
        return PathDiagnosis(
            hint=(
                f"경로가 {len(path)}자로 윈도우 한도({WINDOWS_MAX_PATH}자)를 넘습니다. "
                "긴 경로 지원이 꺼진 윈도우에서는 상위 폴더가 있어도 '파일/경로 없음'으로 실패합니다."
            ),
            # 사용자 입력 문제가 아니라 우리 경로 설계 문제 → 스택과 함께 error로 남긴다.
            category="internal",
        )

    missing = _missing_ancestor(path)
    if missing is not None:
        return PathDiagnosis(hint=f"상위 폴더가 없습니다: {missing}", category="not_found")
    return None


def describe(exc: BaseException) -> str:
    """로그·잡 에러에 쓸 메시지. 원문을 보존하고 진단만 덧붙인다."""
    diagnosis = diagnose_path(exc)
    return f"{exc} — {diagnosis.hint}" if diagnosis else str(exc)


def classify(exc: BaseException) -> Classified:
    name = type(exc).__name__
    msg = str(exc)
    diagnosis = diagnose_path(exc)
    if "OutOfMemoryError" in name or "CUDA out of memory" in msg:
        category = "resource"
    elif diagnosis is not None:
        category = diagnosis.category
    else:
        category = _NAME.get(name, "internal")
    return Classified(category, _LEVEL[category], category == "internal")


def _is_windows_path(path: str) -> bool:
    """호스트가 윈도우거나, 경로 모양이 윈도우 절대경로(드라이브 문자/UNC)일 때.

    경로 모양까지 보는 이유: 윈도우에서 난 실패를 맥/CI에서 재현·테스트할 수 있어야 한다.
    """
    return os.name == "nt" or bool(_WINDOWS_ABS_PATH.match(path))


def _missing_ancestor(path: str) -> str | None:
    """존재하지 않는 상위 폴더 중 **가장 위쪽**(어디서 체인이 끊겼는지)을 돌려준다."""
    try:
        current = Path(path).parent
        missing: Path | None = None
        while True:
            if current.exists():
                break
            missing = current
            parent = current.parent
            if parent == current:
                break
            current = parent
    except OSError:
        return None
    return str(missing) if missing is not None else None
