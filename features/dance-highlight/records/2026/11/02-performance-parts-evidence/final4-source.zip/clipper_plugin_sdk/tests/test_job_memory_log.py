"""SDK 작업 처리부가 작업마다 남기는 최대 메모리 로그(`job.memory`).

매니페스트의 예상 RAM(`estimated_ram_mb`)을 실측으로 고치려고 남긴다 — 직원 Windows PC에서 기능을 돌리고
로그 폴더의 `python.<plugin>.jsonl`에서 이 줄만 뽑는다.
"""
import asyncio
import logging

import pytest

from clipper_plugin_sdk import base as sdk_base
from clipper_plugin_sdk.base import PluginBase, PluginRuntime
from clipper_plugin_sdk.models import JobRequest, JobStatus
from clipper_plugin_sdk.process_memory import peak_rss_mb


class EchoPlugin(PluginBase):
    name = "echo_plugin"
    version = "0.0.1"

    def __init__(self, outcome="ok"):
        super().__init__()
        self.outcome = outcome

    def load_models(self) -> None:
        pass

    def run_job(self, request, cancel_flag):
        if self.outcome == "raise":
            raise RuntimeError("boom")
        if self.outcome == "cancel":
            return {"status": "cancelled"}
        return {"ok": True}


def run(runtime, job_id):
    return asyncio.run(runtime.handle_job(JobRequest(job_id=job_id, params={})))


def memory_lines(caplog):
    return [r for r in caplog.records if getattr(r, "ctx", {}).get("operation") == "job.memory"]


@pytest.fixture
def peak(monkeypatch):
    value = {"mb": 1234.5}
    monkeypatch.setattr(sdk_base, "peak_rss_mb", lambda: value["mb"])
    return value


def test_a_finished_job_leaves_one_memory_line_with_its_peak(caplog, peak):
    caplog.set_level(logging.INFO, logger="clipper_plugin")

    result = run(PluginRuntime(EchoPlugin()), "job-1")

    assert result.status == JobStatus.COMPLETED
    [line] = memory_lines(caplog)
    assert line.ctx["jobId"] == "job-1"
    assert line.ctx["plugin"] == "echo_plugin"
    assert line.ctx["status"] == "completed"
    assert line.ctx["peakRssMb"] == 1234.5
    assert line.ctx["elapsedSec"] >= 0
    assert line.levelno == logging.INFO


def test_counts_jobs_since_the_process_started_because_the_peak_is_process_wide(caplog, peak):
    caplog.set_level(logging.INFO, logger="clipper_plugin")
    runtime = PluginRuntime(EchoPlugin())

    run(runtime, "job-1")
    run(runtime, "job-2")

    assert [line.ctx["jobsSinceStart"] for line in memory_lines(caplog)] == [1, 2]


@pytest.mark.parametrize("outcome, status", [("raise", "failed"), ("cancel", "cancelled")])
def test_failed_and_cancelled_jobs_are_measured_too(caplog, peak, outcome, status):
    caplog.set_level(logging.INFO, logger="clipper_plugin")

    run(PluginRuntime(EchoPlugin(outcome)), "job-1")

    [line] = memory_lines(caplog)
    assert line.ctx["status"] == status


def test_an_unreadable_peak_is_logged_as_unknown_and_never_breaks_the_job(caplog, monkeypatch):
    caplog.set_level(logging.INFO, logger="clipper_plugin")
    monkeypatch.setattr(sdk_base, "peak_rss_mb", lambda: None)

    result = run(PluginRuntime(EchoPlugin()), "job-1")

    assert result.status == JobStatus.COMPLETED
    [line] = memory_lines(caplog)
    assert line.ctx["peakRssMb"] is None


def test_a_crashing_measurement_never_breaks_the_job(caplog, monkeypatch):
    caplog.set_level(logging.INFO, logger="clipper_plugin")

    def broken():
        raise ValueError("counter gone")

    monkeypatch.setattr(sdk_base, "peak_rss_mb", broken)

    result = run(PluginRuntime(EchoPlugin()), "job-1")

    assert result.status == JobStatus.COMPLETED


def test_peak_rss_reads_this_process():
    peak = peak_rss_mb()

    assert peak is not None
    assert 10 < peak < 64 * 1024
