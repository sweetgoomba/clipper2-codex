"""Test completed_event_payload helper function."""
from __future__ import annotations

from clipper_plugin_sdk.routes import completed_event_payload
from clipper_plugin_sdk.models import JobResult, JobStatus


def test_payload_includes_category_and_fields():
    r = JobResult(job_id="j1", status=JobStatus.FAILED, error="boom", category="internal")
    p = completed_event_payload("j1", r)
    assert p["type"] == "completed"
    assert p["job_id"] == "j1"
    assert p["status"] == "failed"
    assert p["error"] == "boom"
    assert p["category"] == "internal"


def test_payload_category_none_when_success():
    r = JobResult(job_id="j2", status=JobStatus.COMPLETED, result={"ok": True})
    p = completed_event_payload("j2", r)
    assert p["status"] == "completed"
    assert p["category"] is None
