"""PluginRuntime 취소 경로 테스트.

cancel_job() → cancel_flag.set() 전파 → 플러그인이 is_set() 감지하여 종료
→ 최종 JobResult.status == CANCELLED.
"""

from __future__ import annotations

import asyncio
import threading
import time
from typing import Any

import pytest

from clipper_plugin_sdk.base import CancelFlag, PluginBase, PluginRuntime
from clipper_plugin_sdk.models import JobRequest, JobStatus


class _PollingPlugin(PluginBase):
    """cancel_flag를 짧은 주기로 polling. 취소 감지 시 cancelled 반환."""

    name = "polling"
    version = "0.0.0"

    def __init__(self) -> None:
        super().__init__()
        self.started = threading.Event()

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        self.started.set()
        for _ in range(200):  # 최대 2초 대기
            if cancel_flag.is_set():
                return {"status": "cancelled"}
            time.sleep(0.01)
        return {"status": "finished_without_cancel"}


@pytest.mark.asyncio
async def test_cancel_mid_flight_produces_cancelled_status():
    plugin = _PollingPlugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime

    req = JobRequest(job_id="c1", params={})
    task = runtime.submit_job(req)

    await asyncio.get_event_loop().run_in_executor(None, plugin.started.wait, 1.0)

    ack = runtime.cancel_job("c1")
    assert ack == {"status": "cancelling", "job_id": "c1"}

    result = await task
    assert result.job_id == "c1"
    assert result.status == JobStatus.CANCELLED


def test_cancel_unknown_job_returns_not_found():
    plugin = _PollingPlugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime

    ack = runtime.cancel_job("does-not-exist")
    assert ack == {"error": "job_not_found", "job_id": "does-not-exist"}


@pytest.mark.asyncio
async def test_job_completes_normally_without_cancel():
    class _FastPlugin(PluginBase):
        name = "fast"
        version = "0.0.0"

        def load_models(self) -> None:
            pass

        def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
            return {"value": 42}

    plugin = _FastPlugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime

    req = JobRequest(job_id="ok1", params={})
    task = runtime.submit_job(req)
    result = await task

    assert result.status == JobStatus.COMPLETED
    assert result.result == {"value": 42}
