"""x-trace-id 헤더 → contextvar. 전 플러그인 공통(FastAPI http 미들웨어)."""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from fastapi import FastAPI, Request

from .logging_config import new_trace_id, trace_ctx


async def set_trace_from_request(
    request: Request,
    call_next: Callable[[Request], Awaitable[Any]],
) -> Any:
    header = request.headers.get("x-trace-id")
    trace = header if header else new_trace_id()
    # 요청 자체에도 남긴다 — `Exception` 핸들러는 이 미들웨어 **바깥**(ServerErrorMiddleware)에서
    # 돌아서, 그때는 아래 finally가 contextvar를 이미 되돌린 뒤다(`request_trace` 참고).
    request.state.trace_id = trace
    token = trace_ctx.set(trace)
    try:
        return await call_next(request)
    finally:
        trace_ctx.reset(token)


def request_trace(request: Request) -> str | None:
    """이 요청의 trace. 미들웨어가 붙인 값이 없으면 헤더, 그것도 없으면 None."""
    trace = getattr(request.state, "trace_id", None)
    if isinstance(trace, str) and trace:
        return trace
    return request.headers.get("x-trace-id") or None


def install_trace_middleware(app: FastAPI) -> None:
    app.middleware("http")(set_trace_from_request)
