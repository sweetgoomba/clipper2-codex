"""이 프로세스가 켜진 뒤 가장 많이 쓴 메모리(MB). 못 읽으면 None.

프로세스 전체의 최고치다 — 작업 하나의 최고치가 아니다. 같은 프로세스가 작업을 연달아 하면 앞 작업의
최고치가 남는다. Windows는 PeakWorkingSetSize(작업 관리자 「최대 작업 집합」), macOS·Linux는 ru_maxrss.
자식 프로세스(ffmpeg 등)는 들어가지 않는다.
"""
from __future__ import annotations

import sys


def peak_rss_mb() -> float | None:
    try:
        if sys.platform == 'win32':
            import ctypes
            from ctypes import wintypes

            class MemoryCounters(ctypes.Structure):
                _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
                    (name, ctypes.c_size_t) for name in (
                        'PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
                        'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
                        'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage')]
            counters = MemoryCounters()
            counters.cb = ctypes.sizeof(counters)
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.GetCurrentProcess.restype = wintypes.HANDLE
            query = ctypes.WinDLL('psapi', use_last_error=True).GetProcessMemoryInfo
            query.argtypes = [wintypes.HANDLE, ctypes.POINTER(MemoryCounters), wintypes.DWORD]
            query.restype = wintypes.BOOL
            if query(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
                return round(counters.PeakWorkingSetSize / 1024**2, 2)
            return None
        import resource
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return round(peak / (1024**2 if sys.platform == 'darwin' else 1024), 2)
    except (ImportError, OSError, AttributeError):
        return None
