"""Tests for P2: FastAPI global exception handler + JsonLogFormatter ctx merge."""
from __future__ import annotations

import json
import logging

import pytest
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient

from clipper_plugin_sdk.errors import classify
from clipper_plugin_sdk.logging_config import JsonLogFormatter, trace_ctx


# ── 1. Formatter ctx merge ──────────────────────────────────────────────────

def _make_record(name: str, level: int, msg: str, extra: dict | None = None) -> logging.LogRecord:
    rec = logging.LogRecord(name, level, "f.py", 1, msg, (), None)
    if extra:
        for k, v in extra.items():
            setattr(rec, k, v)
    return rec


def test_formatter_merges_extra_ctx() -> None:
    """extra={'ctx': {...}} keys appear in emitted JSON ctx alongside 'logger'."""
    fmt = JsonLogFormatter("python.test")
    rec = _make_record(
        "my.logger",
        logging.ERROR,
        "something failed",
        extra={"ctx": {"category": "internal", "jobId": "j1"}},
    )
    out = json.loads(fmt.format(rec))
    assert out["ctx"]["logger"] == "my.logger"
    assert out["ctx"]["category"] == "internal"
    assert out["ctx"]["jobId"] == "j1"


def test_formatter_no_extra_ctx_unchanged() -> None:
    """Records without extra ctx still emit {'logger': ...} only."""
    fmt = JsonLogFormatter("python.test")
    rec = _make_record("x", logging.INFO, "hi")
    out = json.loads(fmt.format(rec))
    assert out["ctx"] == {"logger": "x"}


def test_formatter_non_dict_ctx_ignored() -> None:
    """Non-dict record.ctx is silently ignored (no crash)."""
    fmt = JsonLogFormatter("python.test")
    rec = _make_record("x", logging.INFO, "hi", extra={"ctx": "oops"})
    out = json.loads(fmt.format(rec))
    # Should still have logger key and not crash
    assert out["ctx"]["logger"] == "x"


# ── 2. Global exception handler ─────────────────────────────────────────────

def _build_test_app(raise_exc: Exception) -> FastAPI:
    """Build a minimal FastAPI app with the global exception handler registered."""
    from fastapi import Request
    from clipper_plugin_sdk.errors import classify

    _LEVEL_MAP = {
        "warn": logging.WARNING,
        "error": logging.ERROR,
        "info": logging.INFO,
    }

    handler_logger = logging.getLogger("clipper_plugin")

    app = FastAPI()

    @app.get("/boom")
    async def boom():
        raise raise_exc

    async def _unhandled(request: Request, exc: Exception):
        c = classify(exc)
        handler_logger.log(
            _LEVEL_MAP[c.level],
            "unhandled: %s",
            exc,
            exc_info=c.need_stack,
            extra={"ctx": {"category": c.category, "route": str(request.url.path)}},
        )
        return JSONResponse(status_code=500, content={"error": "internal_error"})

    app.add_exception_handler(Exception, _unhandled)
    return app


def _capture_json_logs(logger_name: str):
    """Context manager returning a list that collects JSON-parsed log records."""
    import contextlib

    @contextlib.contextmanager
    def _ctx():
        records = []

        class _H(logging.Handler):
            def emit(self, rec: logging.LogRecord):
                records.append(rec)

        h = _H()
        h.setFormatter(JsonLogFormatter("python.test"))
        lgr = logging.getLogger(logger_name)
        lgr.addHandler(h)
        lgr.setLevel(logging.DEBUG)
        old_propagate = lgr.propagate
        lgr.propagate = False
        try:
            yield records
        finally:
            lgr.removeHandler(h)
            lgr.propagate = old_propagate

    return _ctx()


def test_exception_handler_returns_500_json() -> None:
    """Any unhandled exception → 500 {"error": "internal_error"}."""
    app = _build_test_app(RuntimeError("surprise"))
    client = TestClient(app, raise_server_exceptions=False)
    resp = client.get("/boom")
    assert resp.status_code == 500
    assert resp.json() == {"error": "internal_error"}


def test_exception_handler_logs_error_for_internal() -> None:
    """RuntimeError → category=internal, level=ERROR, ctx has category+route."""
    app = _build_test_app(RuntimeError("surprise"))
    client = TestClient(app, raise_server_exceptions=False)

    with _capture_json_logs("clipper_plugin") as records:
        resp = client.get("/boom")

    assert resp.status_code == 500
    assert len(records) == 1
    rec = records[0]
    assert rec.levelno == logging.ERROR

    # Verify ctx merge: category and route should be in the formatted JSON ctx
    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert out["ctx"]["category"] == "internal"
    assert out["ctx"]["route"] == "/boom"


def test_exception_handler_logs_warn_for_validation() -> None:
    """ValueError → category=validation, level=WARNING."""
    app = _build_test_app(ValueError("bad input"))
    client = TestClient(app, raise_server_exceptions=False)

    with _capture_json_logs("clipper_plugin") as records:
        resp = client.get("/boom")

    assert resp.status_code == 500
    assert len(records) == 1
    rec = records[0]
    assert rec.levelno == logging.WARNING

    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert out["ctx"]["category"] == "validation"


def test_exception_handler_includes_stack_for_internal() -> None:
    """Internal errors have exc_info set (need_stack=True) → stack in ctx."""
    app = _build_test_app(RuntimeError("surprise"))
    client = TestClient(app, raise_server_exceptions=False)

    with _capture_json_logs("clipper_plugin") as records:
        client.get("/boom")

    assert len(records) == 1
    rec = records[0]
    # Internal errors: need_stack=True, so exc_info should be set on record
    assert rec.exc_info is not None

    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert "stack" in out["ctx"]
    assert "RuntimeError" in out["ctx"]["stack"]


def test_exception_handler_no_stack_for_validation() -> None:
    """Validation errors (need_stack=False) → no stack in formatted ctx."""
    app = _build_test_app(ValueError("bad input"))
    client = TestClient(app, raise_server_exceptions=False)

    with _capture_json_logs("clipper_plugin") as records:
        client.get("/boom")

    assert len(records) == 1
    rec = records[0]
    # Validation: need_stack=False so exc_info should be falsy
    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert "stack" not in out["ctx"]


# ── 3. 예외 핸들러 로그의 trace ─────────────────────────────────────────────
# Starlette는 `Exception` 핸들러를 가장 바깥(ServerErrorMiddleware)에서 부른다. 그때는 trace
# 미들웨어가 이미 contextvar를 되돌린 뒤라, 정작 원인을 찾아야 하는 에러 로그에서만 trace가
# 빠져 nest·renderer 로그와 묶이지 않았다. 아래는 실제 핸들러·미들웨어로 그 경로를 고정한다.

def _real_app(raise_exc: Exception) -> FastAPI:
    from clipper_plugin_sdk.base import _unhandled_exception_handler
    from clipper_plugin_sdk.trace_middleware import install_trace_middleware

    app = FastAPI()

    @app.get("/boom")
    async def boom():
        raise raise_exc

    @app.get("/boom-sync")
    def boom_sync():
        raise raise_exc

    app.add_exception_handler(Exception, _unhandled_exception_handler)
    install_trace_middleware(app)
    return app


def _capture_lines(logger_name: str):
    """emit 순간에 JSON으로 직렬화한다 — trace는 포맷 시점의 contextvar라 나중에 찍으면 비어 있다."""
    import contextlib

    @contextlib.contextmanager
    def _ctx():
        lines: list[dict] = []
        fmt = JsonLogFormatter("python.test")

        class _H(logging.Handler):
            def emit(self, rec: logging.LogRecord):
                lines.append(json.loads(fmt.format(rec)))

        h = _H()
        lgr = logging.getLogger(logger_name)
        old_level, old_propagate = lgr.level, lgr.propagate
        lgr.addHandler(h)
        lgr.setLevel(logging.DEBUG)
        lgr.propagate = False
        try:
            yield lines
        finally:
            lgr.removeHandler(h)
            lgr.setLevel(old_level)
            lgr.propagate = old_propagate

    return _ctx()


@pytest.mark.parametrize("route", ["/boom", "/boom-sync"])
def test_unhandled_error_log_carries_request_trace(route: str) -> None:
    client = TestClient(_real_app(RuntimeError("surprise")), raise_server_exceptions=False)

    with _capture_lines("clipper_plugin") as lines:
        resp = client.get(route, headers={"x-trace-id": "abcd1234"})

    assert resp.status_code == 500
    assert resp.json() == {"error": "internal_error"}
    assert len(lines) == 1
    assert lines[0]["trace"] == "abcd1234"
    assert lines[0]["ctx"]["category"] == "internal"


def test_handled_validation_error_log_carries_request_trace() -> None:
    client = TestClient(_real_app(ValueError("bad input")), raise_server_exceptions=False)

    with _capture_lines("clipper_plugin") as lines:
        client.get("/boom", headers={"x-trace-id": "feedbeef"})

    assert len(lines) == 1
    assert lines[0]["level"] == "warn"
    assert lines[0]["trace"] == "feedbeef"


def test_error_log_without_header_uses_the_generated_request_trace() -> None:
    """헤더가 없으면 미들웨어가 만든 trace를 써야 한다 — 같은 요청의 다른 로그와 묶이도록."""
    app = FastAPI()
    request_logger = logging.getLogger("clipper_plugin.request")

    @app.get("/boom")
    async def boom():
        request_logger.info("before failing")
        raise RuntimeError("surprise")

    from clipper_plugin_sdk.base import _unhandled_exception_handler
    from clipper_plugin_sdk.trace_middleware import install_trace_middleware

    app.add_exception_handler(Exception, _unhandled_exception_handler)
    install_trace_middleware(app)
    client = TestClient(app, raise_server_exceptions=False)

    with _capture_lines("clipper_plugin") as lines:
        client.get("/boom")

    assert [line["msg"] for line in lines] == ["before failing", "unhandled: surprise"]
    assert lines[0]["trace"]
    assert lines[1]["trace"] == lines[0]["trace"]


def test_error_handler_does_not_leak_trace_after_the_request() -> None:
    client = TestClient(_real_app(RuntimeError("surprise")), raise_server_exceptions=False)

    client.get("/boom", headers={"x-trace-id": "abcd1234"})

    assert trace_ctx.get() is None
