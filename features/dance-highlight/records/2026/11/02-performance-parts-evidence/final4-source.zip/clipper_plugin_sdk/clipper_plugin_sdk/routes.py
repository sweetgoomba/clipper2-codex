"""공통 HTTP + WebSocket 엔드포인트 등록."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse

from .models import JobRequest, JobResult, JobStatus

if TYPE_CHECKING:
    from .base import PluginRuntime

logger = logging.getLogger("clipper_plugin")


def completed_event_payload(job_id: str, result: JobResult) -> dict[str, Any]:
    """WS 'completed' 이벤트 페이로드(분류 신호 포함). 직렬화 한 곳."""
    return {
        "type": "completed",
        "job_id": job_id,
        "status": result.status.value,
        "result": result.result,
        "error": result.error,
        "category": result.category,
        "timestamp": time.time(),
    }


def register_routes(app: FastAPI, runtime: PluginRuntime) -> None:
    """런타임에 공통 엔드포인트를 등록."""

    @app.get("/health")
    async def health():
        return runtime.get_health()

    @app.get("/runtime/accelerators")
    async def runtime_accelerators():
        return runtime.get_runtime_accelerators()

    @app.post("/jobs", response_model=JobResult)
    async def create_job(request: JobRequest):
        if runtime.has_active_job(request.job_id):
            return JSONResponse(
                status_code=409,
                content={"error": "job_already_running", "job_id": request.job_id},
            )

        runtime.submit_job(request)

        return JobResult(
            job_id=request.job_id,
            status=JobStatus.QUEUED,
        )

    @app.delete("/jobs/{job_id}")
    async def cancel_job(job_id: str):
        result = runtime.cancel_job(job_id)
        if "error" in result:
            return JSONResponse(status_code=404, content=result)
        return result

    @app.post("/shutdown")
    async def shutdown():
        asyncio.create_task(runtime.shutdown())
        return {"status": "shutting_down"}

    @app.websocket("/jobs/{job_id}/events")
    async def job_events(websocket: WebSocket, job_id: str):
        await websocket.accept()
        runtime.register_ws(job_id, websocket)
        logger.debug("WS connected for job %s", job_id)

        # Capture task reference once before the loop.
        # handle_job pops itself from _active_jobs on completion, so we must
        # hold the reference here to detect when it finishes.
        task = runtime.get_active_job_task(job_id)
        missing_job_deadline = time.monotonic() + 5.0

        async def _send_result(result: JobResult) -> None:
            await websocket.send_text(json.dumps(completed_event_payload(job_id, result)))

        try:
            while True:
                if task is None:
                    # Task may have already completed before WS connected —
                    # check _completed_results before giving up. Also allow
                    # clients to pre-connect the event stream before POST /jobs
                    # so very fast jobs do not lose early progress events.
                    completed = runtime.get_completed_result(job_id)
                    if completed is not None:
                        await _send_result(completed)
                        break
                    if time.monotonic() >= missing_job_deadline:
                        await websocket.send_text(json.dumps({
                            "type": "error",
                            "job_id": job_id,
                            "error": "job_not_found",
                            "timestamp": time.time(),
                        }))
                        break
                    await asyncio.sleep(0.05)
                    task = runtime.get_active_job_task(job_id)
                    continue

                if task.done():
                    try:
                        await _send_result(task.result())
                    except Exception as exc:
                        await websocket.send_text(json.dumps({
                            "type": "error",
                            "job_id": job_id,
                            "error": str(exc),
                            "timestamp": time.time(),
                        }))
                    break

                try:
                    await asyncio.wait_for(websocket.receive_text(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                except WebSocketDisconnect:
                    break

        finally:
            runtime.unregister_ws(job_id)
            logger.debug("WS disconnected for job %s", job_id)
