"""공통 JSON Lines 로깅 구성 — 모든 플러그인이 동일 스키마로 stdout에 출력."""

from __future__ import annotations

import json
import logging
import sys
import uuid
from contextvars import ContextVar
from datetime import datetime, timezone

# 현재 요청의 trace(미들웨어가 set). 없으면 None.
trace_ctx: ContextVar[str | None] = ContextVar("trace_id", default=None)


def new_trace_id() -> str:
    """8-hex 상관 ID."""
    return uuid.uuid4().hex[:8]

_LEVEL_MAP = {
    "DEBUG": "debug",
    "INFO": "info",
    "WARNING": "warn",
    "ERROR": "error",
    "CRITICAL": "fatal",
}


def _iso_utc(created: float) -> str:
    # ISO-8601 UTC + ms + 'Z'
    return (
        datetime.fromtimestamp(created, tz=timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


class JsonLogFormatter(logging.Formatter):
    """LogRecord → 공통 스키마 JSON 1줄. src는 생성 시 고정."""

    def __init__(self, src: str) -> None:
        super().__init__()
        self.src = src

    def format(self, record: logging.LogRecord) -> str:
        ctx: dict[str, object] = {"logger": record.name}
        if record.exc_info:
            ctx["stack"] = self.formatException(record.exc_info)
        extra_ctx = getattr(record, "ctx", None)
        if isinstance(extra_ctx, dict):
            ctx.update(extra_ctx)
        obj = {
            "v": 1,
            "ts": _iso_utc(record.created),
            "level": _LEVEL_MAP.get(record.levelname, "info"),
            "src": self.src,
            "msg": record.getMessage(),
            "ctx": ctx,
        }
        trace = trace_ctx.get()
        if trace:
            obj["trace"] = trace
        return json.dumps(obj, ensure_ascii=False)


def configure_json_logging(src: str, level: int = logging.INFO) -> None:
    """루트 로거 핸들러를 JSON-stdout 핸들러로 교체. 플러그인 basicConfig를 덮어씀."""
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonLogFormatter(src))
    root.addHandler(handler)
    root.setLevel(level)
