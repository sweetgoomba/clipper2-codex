"""공통 데이터 모델."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    CANCELLING = "cancelling"


class JobRequest(BaseModel):
    job_id: str
    params: dict[str, Any] = Field(default_factory=dict)


class JobResult(BaseModel):
    job_id: str
    status: JobStatus
    result: dict[str, Any] | None = None
    error: str | None = None
    category: str | None = None


class HealthResponse(BaseModel):
    status: str = "ok"
    plugin_name: str
    version: str
    active_jobs: int = 0
    vram_used_mb: float | None = None


class RuntimeProbe(BaseModel):
    name: str
    installed: bool
    available: bool | None = None
    version: str | None = None
    error: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class RuntimeAcceleratorsResponse(BaseModel):
    plugin_name: str
    version: str
    models_loaded: bool
    selected: dict[str, Any] = Field(default_factory=dict)
    probes: list[RuntimeProbe] = Field(default_factory=list)
