from __future__ import annotations

import time
from types import SimpleNamespace
from typing import Any

import pytest

from clipper_plugin_sdk import PluginBase
from clipper_plugin_sdk.base import CancelFlag, PluginRuntime
from clipper_plugin_sdk.models import JobRequest


class _IdlePlugin(PluginBase):
    name = "idle_test"
    version = "0.0.0"

    def load_models(self) -> None:
        return None

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        return {"status": "ok"}


@pytest.mark.asyncio
async def test_idle_watcher_requests_server_shutdown_without_system_exit(monkeypatch: pytest.MonkeyPatch) -> None:
    import clipper_plugin_sdk.base as base

    original_sleep = base.asyncio.sleep

    async def fast_sleep(_delay: float) -> None:
        await original_sleep(0)

    monkeypatch.setattr(base.asyncio, "sleep", fast_sleep)

    runtime = PluginRuntime(_IdlePlugin())
    server = SimpleNamespace(should_exit=False)
    runtime._server = server  # noqa: SLF001
    runtime._idle_timeout = 0.01  # noqa: SLF001
    runtime._last_activity = time.monotonic() - 1.0  # noqa: SLF001

    await runtime._idle_watcher()  # noqa: SLF001

    assert server.should_exit is True
