"""CancelFlag 단위 테스트."""

from __future__ import annotations

import threading

from clipper_plugin_sdk.base import CancelFlag


def test_default_state_is_not_set():
    flag = CancelFlag()
    assert flag.is_set() is False
    assert bool(flag) is False


def test_set_marks_flag():
    flag = CancelFlag()
    flag.set()
    assert flag.is_set() is True
    assert bool(flag) is True


def test_set_is_idempotent():
    flag = CancelFlag()
    flag.set()
    flag.set()
    assert flag.is_set() is True


def test_flag_visible_across_threads():
    import time

    flag = CancelFlag()
    observed: list[bool] = []

    def worker() -> None:
        for _ in range(200):
            if flag.is_set():
                observed.append(True)
                return
            time.sleep(0.005)

    t = threading.Thread(target=worker)
    t.start()
    time.sleep(0.05)
    flag.set()
    t.join(timeout=2.0)
    assert observed == [True]
