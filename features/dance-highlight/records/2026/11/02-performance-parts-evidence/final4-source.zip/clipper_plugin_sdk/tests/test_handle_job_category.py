from __future__ import annotations

from typing import Any

import pytest

from clipper_plugin_sdk.base import CancelFlag, PluginBase, PluginRuntime
from clipper_plugin_sdk.models import JobRequest, JobStatus


class _FailingPlugin(PluginBase):
    name = "failing_plugin"
    version = "0.0.0"

    def __init__(self, exc: Exception) -> None:
        super().__init__()
        self._exc = exc

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        raise self._exc


def _make_runtime(exc: Exception):
    plugin = _FailingPlugin(exc)
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime  # noqa: SLF001
    return runtime


@pytest.mark.asyncio
async def test_internal_error_sets_category_internal():
    runtime = _make_runtime(RuntimeError("boom"))
    result = await runtime.submit_job(JobRequest(job_id="j1", params={}))
    assert result.status == JobStatus.FAILED
    assert result.category == "internal"


@pytest.mark.asyncio
async def test_value_error_sets_category_validation():
    runtime = _make_runtime(ValueError("bad"))
    result = await runtime.submit_job(JobRequest(job_id="j2", params={}))
    assert result.status == JobStatus.FAILED
    assert result.category == "validation"


@pytest.mark.asyncio
async def test_windows_path_length_failure_reaches_the_job_error():
    # 잡 에러 문자열은 nest → FE까지 그대로 흘러간다(변형 배치 카드의 error). 원인을
    # 여기서 못 붙이면 사용자는 "파일 없음"만 보고 파일시스템/권한을 의심하게 된다.
    import errno
    import os

    path = "C:\\Users\\u\\AppData\\Roaming\\Clipper Studio\\" + "x" * 240 + ".json"
    runtime = _make_runtime(FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), path))
    result = await runtime.submit_job(JobRequest(job_id="j3", params={}))

    assert result.status == JobStatus.FAILED
    assert "260" in result.error
    assert result.category == "internal"


class _ReturningPlugin(PluginBase):
    """예외 대신 실패 dict를 돌려주는 플러그인 — 실패 종류는 플러그인이 안다."""

    name = "returning_plugin"
    version = "0.0.0"

    def __init__(self, result: dict[str, Any]) -> None:
        super().__init__()
        self._result = result

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        return self._result


def _make_returning_runtime(result: dict[str, Any]):
    plugin = _ReturningPlugin(result)
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime  # noqa: SLF001
    return runtime


@pytest.mark.asyncio
async def test_returned_error_carries_the_plugin_category():
    # overseas_dub 계약: 실패 category ∈ input_invalid | model_missing | internal.
    # 플러그인이 고른 분류가 완료 이벤트까지 그대로 가야 Nest가 문구를 고를 수 있다.
    runtime = _make_returning_runtime({"error": "영상 파일이 없습니다", "category": "input_invalid"})
    result = await runtime.submit_job(JobRequest(job_id="r1", params={}))

    assert result.status == JobStatus.FAILED
    assert result.error == "영상 파일이 없습니다"
    assert result.category == "input_invalid"


@pytest.mark.asyncio
async def test_returned_error_without_category_keeps_category_empty():
    runtime = _make_returning_runtime({"error": "video_path is required"})
    result = await runtime.submit_job(JobRequest(job_id="r2", params={}))

    assert result.status == JobStatus.FAILED
    assert result.category is None


@pytest.mark.asyncio
async def test_non_string_category_is_ignored():
    runtime = _make_returning_runtime({"error": "x", "category": 3})
    result = await runtime.submit_job(JobRequest(job_id="r3", params={}))

    assert result.category is None
