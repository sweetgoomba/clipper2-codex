import errno
import os

from clipper_plugin_sdk.errors import classify, describe

# 2026-08-11 윈도우 베리에이션 렌더 실패 때 실제로 올라온 경로(331자).
WINDOWS_LONG_PATH = (
    "C:\\Users\\adlight16\\AppData\\Roaming\\Clipper Studio\\projects\\files\\"
    "cd3da5be-78c0-4d90-89dc-931efb69cf7e\\"
    "variation_1923908f-d873-4b4f-838c-441233c539d6_4b347f49-0a60-456c-a241-63bc29547d2e_v0\\"
    "render-jobs\\variation_render_variation_1923908f-d873-4b4f-838c-441233c539d6_"
    "4b347f49-0a60-456c-a241-63bc29547d2e_0.clipper-render-payload.json"
)


def _enoent(path: str) -> FileNotFoundError:
    return FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), path)


def test_bare_exception_is_internal():
    c = classify(RuntimeError("boom"))
    assert c.category == "internal" and c.level == "error" and c.need_stack is True


def test_value_error_is_validation():
    c = classify(ValueError("bad"))
    assert c.category == "validation" and c.level == "warn" and c.need_stack is False


def test_windows_max_path_failure_says_so_instead_of_file_not_found():
    message = describe(_enoent(WINDOWS_LONG_PATH))
    assert "[Errno 2]" in message  # 원문은 보존한다 (기존 로그 검색 습관)
    assert "331" in message and "260" in message


def test_windows_max_path_failure_is_a_bug_not_a_benign_not_found():
    # 경로 설계가 한도를 넘긴 것이므로 사용자 입력 문제(not_found/info)로 묻히면 안 된다.
    c = classify(_enoent(WINDOWS_LONG_PATH))
    assert c.category == "internal" and c.level == "error" and c.need_stack is True


def test_missing_parent_directory_is_named(tmp_path):
    target = tmp_path / "a" / "b" / "c.json"
    message = describe(_enoent(str(target)))
    assert str(tmp_path / "a") in message
    assert classify(_enoent(str(target))).category == "not_found"


def test_missing_file_whose_parent_exists_keeps_the_original_message(tmp_path):
    target = tmp_path / "c.json"
    assert describe(_enoent(str(target))) == str(_enoent(str(target)))


def test_non_os_errors_are_untouched():
    assert describe(ValueError("bad")) == "bad"
