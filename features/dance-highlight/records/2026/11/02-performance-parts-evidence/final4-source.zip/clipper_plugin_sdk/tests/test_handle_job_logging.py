"""P4: handle_job failure logging — TDD.

Tests:
(a) JobResult is FAILED with error string (existing behaviour preserved).
(b) Exactly one structured warning/error line is emitted with ctx.category, ctx.jobId,
    ctx.operation == "job.run", correct level, and stack present only for
    internal errors (bare RuntimeError → internal → stack present).
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from typing import Any

import pytest

from clipper_plugin_sdk.base import CancelFlag, PluginBase, PluginRuntime
from clipper_plugin_sdk.logging_config import JsonLogFormatter, trace_ctx
from clipper_plugin_sdk.models import JobRequest, JobStatus


# ── helpers ──────────────────────────────────────────────────────────────────

def _problems(records: list[logging.LogRecord]) -> list[logging.LogRecord]:
    """경고·에러 줄만. 작업마다 남는 정보 줄(최대 메모리 `job.memory`)은 실패 기록이 아니다."""
    return [r for r in records if r.levelno >= logging.WARNING]


@contextlib.contextmanager
def _capture_json_logs(logger_name: str):
    """Collect log records from *logger_name*, return list of raw LogRecord."""
    records: list[logging.LogRecord] = []

    class _H(logging.Handler):
        def emit(self, rec: logging.LogRecord) -> None:
            records.append(rec)

    h = _H()
    h.setFormatter(JsonLogFormatter("python.test"))
    lgr = logging.getLogger(logger_name)
    lgr.addHandler(h)
    lgr.setLevel(logging.DEBUG)
    old_propagate = lgr.propagate
    lgr.propagate = False
    try:
        yield records
    finally:
        lgr.removeHandler(h)
        lgr.propagate = old_propagate


class _FailingPlugin(PluginBase):
    """run_job always raises the given exception."""

    name = "failing_plugin"
    version = "0.0.0"

    def __init__(self, exc: Exception) -> None:
        super().__init__()
        self._exc = exc

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        raise self._exc


def _make_runtime(exc: Exception):
    plugin = _FailingPlugin(exc)
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime  # noqa: SLF001
    return runtime


# ── tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_handle_job_failure_returns_failed_status():
    """Existing behaviour: FAILED JobResult with the exception string."""
    runtime = _make_runtime(RuntimeError("boom"))
    req = JobRequest(job_id="job-log-1", params={})

    with _capture_json_logs("clipper_plugin"):
        result = await runtime.submit_job(req)

    assert result.status == JobStatus.FAILED
    assert result.error == "boom"
    assert result.result is None


@pytest.mark.asyncio
async def test_handle_job_logs_exactly_one_record_on_failure():
    """Exactly one warning/error record is emitted when handle_job catches an exception."""
    runtime = _make_runtime(RuntimeError("boom"))
    req = JobRequest(job_id="job-log-2", params={})

    with _capture_json_logs("clipper_plugin") as records:
        await runtime.submit_job(req)

    assert len(_problems(records)) == 1


@pytest.mark.asyncio
async def test_handle_job_log_ctx_fields_for_internal_error():
    """Internal error (RuntimeError) → ERROR level, ctx has category/jobId/operation."""
    runtime = _make_runtime(RuntimeError("internal boom"))
    job_id = "job-log-3"
    req = JobRequest(job_id=job_id, params={})

    with _capture_json_logs("clipper_plugin") as records:
        await runtime.submit_job(req)

    problems = _problems(records)
    assert len(problems) == 1
    rec = problems[0]
    assert rec.levelno == logging.ERROR

    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert out["ctx"]["category"] == "internal"
    assert out["ctx"]["jobId"] == job_id
    assert out["ctx"]["operation"] == "job.run"


@pytest.mark.asyncio
async def test_handle_job_log_stack_present_for_internal_error():
    """Internal error → need_stack=True → exc_info set → stack in formatted JSON."""
    runtime = _make_runtime(RuntimeError("internal boom"))
    req = JobRequest(job_id="job-log-4", params={})

    with _capture_json_logs("clipper_plugin") as records:
        await runtime.submit_job(req)

    problems = _problems(records)
    assert len(problems) == 1
    rec = problems[0]
    assert rec.exc_info is not None

    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert "stack" in out["ctx"]
    assert "RuntimeError" in out["ctx"]["stack"]


@pytest.mark.asyncio
async def test_handle_job_log_no_stack_for_validation_error():
    """Validation error (ValueError) → WARNING level, no stack in formatted JSON."""
    runtime = _make_runtime(ValueError("bad param"))
    job_id = "job-log-5"
    req = JobRequest(job_id=job_id, params={})

    with _capture_json_logs("clipper_plugin") as records:
        await runtime.submit_job(req)

    problems = _problems(records)
    assert len(problems) == 1
    rec = problems[0]
    assert rec.levelno == logging.WARNING

    fmt = JsonLogFormatter("python.test")
    out = json.loads(fmt.format(rec))
    assert out["ctx"]["category"] == "validation"
    assert out["ctx"]["jobId"] == job_id
    assert out["ctx"]["operation"] == "job.run"
    assert "stack" not in out["ctx"]
