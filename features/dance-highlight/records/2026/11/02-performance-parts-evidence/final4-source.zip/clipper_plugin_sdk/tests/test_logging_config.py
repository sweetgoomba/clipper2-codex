from __future__ import annotations

import json
import logging

from clipper_plugin_sdk.logging_config import JsonLogFormatter, trace_ctx, new_trace_id


def _record(name: str, level: int, msg: str, args=()) -> logging.LogRecord:
    return logging.LogRecord(name, level, "f.py", 1, msg, args, None)


def test_formatter_emits_schema() -> None:
    line = JsonLogFormatter("python.dance_highlight").format(
        _record("dance_highlight", logging.INFO, "hello %s", ("world",))
    )
    o = json.loads(line)
    assert o["v"] == 1
    assert o["level"] == "info"
    assert o["src"] == "python.dance_highlight"
    assert o["msg"] == "hello world"
    assert o["ts"].endswith("Z")
    assert o["ctx"]["logger"] == "dance_highlight"
    assert "trace" not in o  # v1: 미배선


def test_level_mapping() -> None:
    fmt = JsonLogFormatter("python.x")
    levels = [
        (logging.DEBUG, "debug"),
        (logging.WARNING, "warn"),
        (logging.ERROR, "error"),
        (logging.CRITICAL, "fatal"),
    ]
    for lvl, want in levels:
        o = json.loads(fmt.format(_record("x", lvl, "m")))
        assert o["level"] == want


def test_exception_adds_stack() -> None:
    try:
        raise ValueError("boom")
    except ValueError:
        import sys
        rec = logging.LogRecord("x", logging.ERROR, "f.py", 1, "failed", (), sys.exc_info())
    o = json.loads(JsonLogFormatter("python.x").format(rec))
    assert o["level"] == "error"
    assert "ValueError: boom" in o["ctx"]["stack"]


def _format(formatter):
    rec = logging.LogRecord('n', logging.INFO, __file__, 1, 'hello', None, None)
    return json.loads(formatter.format(rec))


def test_new_trace_id_8hex():
    t = new_trace_id()
    assert len(t) == 8 and all(c in '0123456789abcdef' for c in t)


def test_formatter_includes_trace_when_set():
    fmt = JsonLogFormatter('python.test')
    token = trace_ctx.set('abcd1234')
    try:
        assert _format(fmt)['trace'] == 'abcd1234'
    finally:
        trace_ctx.reset(token)


def test_formatter_no_trace_when_unset():
    fmt = JsonLogFormatter('python.test')
    assert 'trace' not in _format(fmt)


def test_configure_replaces_root_handlers(capsys) -> None:
    from clipper_plugin_sdk.logging_config import configure_json_logging

    configure_json_logging("python.demo")
    logging.getLogger("demo").info("hi there")
    out = capsys.readouterr().out.strip().splitlines()[-1]
    o = json.loads(out)
    assert o["src"] == "python.demo"
    assert o["msg"] == "hi there"
