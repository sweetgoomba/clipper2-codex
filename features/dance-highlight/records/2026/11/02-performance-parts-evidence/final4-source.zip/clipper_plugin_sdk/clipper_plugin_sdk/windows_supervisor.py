"""Windows 10+ per-launch containment. Never launches a plugin outside its job.

JOB_LIST assigns the process atomically at CreateProcessW, unlike spawn/assign.
Only this supervisor owns the non-inheritable kill-on-close job handle.
The host closes stdin to cancel; the plugin receives NUL as stdin.
"""
from __future__ import annotations

import ctypes as C
import json
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone

DWORD = C.c_uint32
WORD = C.c_uint16
BOOL = C.c_int32
HANDLE = C.c_void_p
SIZE_T = C.c_size_t


class BasicLimits(C.Structure):
    _fields_ = [('process_time', C.c_int64), ('job_time', C.c_int64),
                ('flags', DWORD), ('min_ws', SIZE_T), ('max_ws', SIZE_T),
                ('active_limit', DWORD), ('affinity', SIZE_T),
                ('priority', DWORD), ('scheduling', DWORD)]


class IoCounters(C.Structure):
    _fields_ = [(name, C.c_uint64) for name in
                ('read_ops', 'write_ops', 'other_ops', 'read_bytes', 'write_bytes', 'other_bytes')]


class ExtendedLimits(C.Structure):
    _fields_ = [('basic', BasicLimits), ('io', IoCounters),
                ('process_memory', SIZE_T), ('job_memory', SIZE_T),
                ('peak_process_memory', SIZE_T), ('peak_job_memory', SIZE_T)]


class Accounting(C.Structure):
    _fields_ = [(name, C.c_int64) for name in ('user', 'kernel', 'period_user', 'period_kernel')] + [
        (name, DWORD) for name in ('faults', 'total', 'active', 'terminated')]


class StartupInfo(C.Structure):
    _fields_ = [('cb', DWORD), ('reserved', C.c_wchar_p), ('desktop', C.c_wchar_p),
                ('title', C.c_wchar_p)] + [(name, DWORD) for name in
                ('x', 'y', 'width', 'height', 'chars_x', 'chars_y', 'fill', 'flags')] + [
                ('show', WORD), ('reserved_size', WORD), ('reserved_bytes', C.c_void_p),
                ('stdin', HANDLE), ('stdout', HANDLE), ('stderr', HANDLE)]


class StartupInfoEx(C.Structure):
    _fields_ = [('startup', StartupInfo), ('attributes', C.c_void_p)]


class ProcessInfo(C.Structure):
    _fields_ = [('process', HANDLE), ('thread', HANDLE), ('pid', DWORD), ('tid', DWORD)]


class WindowsJob:
    """Native handles stay private; no PID lookup or process-name termination."""
    def __init__(self):
        if sys.platform != 'win32':
            raise OSError('Windows Job Object supervisor requires Windows 10+')
        self.api = C.WinDLL('kernel32', use_last_error=True)
        self.job = None
        self.process = None
        signatures = {
            'CreateJobObjectW': (HANDLE, [C.c_void_p, C.c_wchar_p]),
            'SetInformationJobObject': (BOOL, [HANDLE, C.c_int, C.c_void_p, DWORD]),
            'QueryInformationJobObject': (BOOL, [HANDLE, C.c_int, C.c_void_p, DWORD, C.c_void_p]),
            'TerminateJobObject': (BOOL, [HANDLE, C.c_uint]),
            'CloseHandle': (BOOL, [HANDLE]),
            'GetCurrentProcess': (HANDLE, []),
            'DuplicateHandle': (BOOL, [HANDLE, HANDLE, HANDLE, C.POINTER(HANDLE), DWORD, BOOL, DWORD]),
            'InitializeProcThreadAttributeList': (BOOL, [C.c_void_p, DWORD, DWORD, C.POINTER(SIZE_T)]),
            'UpdateProcThreadAttribute': (BOOL, [C.c_void_p, DWORD, SIZE_T, C.c_void_p, SIZE_T, C.c_void_p, C.c_void_p]),
            'DeleteProcThreadAttributeList': (None, [C.c_void_p]),
            'CreateProcessW': (BOOL, [C.c_wchar_p, C.c_wchar_p, C.c_void_p, C.c_void_p, BOOL,
                                     DWORD, C.c_void_p, C.c_wchar_p, C.c_void_p, C.POINTER(ProcessInfo)]),
            'WaitForSingleObject': (DWORD, [HANDLE, DWORD]),
            'GetExitCodeProcess': (BOOL, [HANDLE, C.POINTER(DWORD)]),
        }
        for name, (result, args) in signatures.items():
            fn = getattr(self.api, name)
            fn.restype, fn.argtypes = result, args
        self.job = self.api.CreateJobObjectW(None, None)
        if not self.job:
            raise C.WinError(C.get_last_error())
        limits = ExtendedLimits()
        limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE; no breakaway
        try:
            self._check(self.api.SetInformationJobObject(self.job, 9, C.byref(limits), C.sizeof(limits)))
        except BaseException:
            self.close()
            raise

    @staticmethod
    def _check(ok):
        if not ok:
            raise C.WinError(C.get_last_error())

    def spawn(self, argv):
        import msvcrt
        if self.process:
            raise RuntimeError('owned job already launched')
        size = SIZE_T()
        # First call obtains the size and returns ERROR_INSUFFICIENT_BUFFER.
        self.api.InitializeProcThreadAttributeList(None, 2, 0, C.byref(size))
        if not size.value:
            raise C.WinError(C.get_last_error())
        storage = C.create_string_buffer(size.value)
        attributes = C.cast(storage, C.c_void_p)
        self._check(self.api.InitializeProcThreadAttributeList(attributes, 2, 0, C.byref(size)))
        inherited = []
        try:
            with open(os.devnull, 'rb') as null_input:
                current = self.api.GetCurrentProcess()
                for stream in (null_input, sys.stdout, sys.stderr):
                    duplicate = HANDLE()
                    self._check(self.api.DuplicateHandle(current, msvcrt.get_osfhandle(stream.fileno()),
                                                         current, C.byref(duplicate), 0, True, 2))
                    inherited.append(duplicate.value)
                handles = (HANDLE * 3)(*inherited)
                jobs = (HANDLE * 1)(self.job)
                self._check(self.api.UpdateProcThreadAttribute(attributes, 0, 0x20002,
                                                               handles, C.sizeof(handles), None, None))
                self._check(self.api.UpdateProcThreadAttribute(attributes, 0, 0x2000D,
                                                               jobs, C.sizeof(jobs), None, None))
                startup = StartupInfoEx()
                startup.startup.cb = C.sizeof(startup)
                startup.startup.flags = 0x100  # STARTF_USESTDHANDLES
                startup.startup.stdin, startup.startup.stdout, startup.startup.stderr = inherited
                startup.attributes = attributes
                info = ProcessInfo()
                command = C.create_unicode_buffer(subprocess.list2cmdline(argv))
                self._check(self.api.CreateProcessW(argv[0], command, None, None, True,
                                                    0x00080000 | 0x08000000,  # EXTENDED_STARTUPINFO_PRESENT | CREATE_NO_WINDOW
                                                    None, None, C.byref(startup), C.byref(info)))
                self.process = info.process
                self.api.CloseHandle(info.thread)
        finally:
            for handle in inherited:
                self.api.CloseHandle(handle)
            self.api.DeleteProcThreadAttributeList(attributes)

    def poll(self):
        result = self.api.WaitForSingleObject(self.process, 0)
        if result == 258:  # WAIT_TIMEOUT
            return None
        if result != 0:
            raise C.WinError(C.get_last_error())
        code = DWORD()
        self._check(self.api.GetExitCodeProcess(self.process, C.byref(code)))
        return code.value

    def terminate_and_wait(self, timeout):
        self._check(self.api.TerminateJobObject(self.job, 1))
        deadline = time.monotonic() + timeout
        while True:
            counts = Accounting()
            self._check(self.api.QueryInformationJobObject(self.job, 1, C.byref(counts), C.sizeof(counts), None))
            if counts.active == 0:
                return
            if time.monotonic() >= deadline:
                raise TimeoutError('owned Windows job still has active processes')
            time.sleep(0.02)

    def close(self):
        if self.job:
            self.api.CloseHandle(self.job)  # kernel fallback also covers supervisor crashes
            self.job = None
        if self.process:
            self.api.CloseHandle(self.process)
            self.process = None


def supervise(job, argv, stop, emit):
    try:
        if stop.is_set():
            emit('owned_tree_empty')
            return 0
        job.spawn(argv)
        code = None
        while not stop.is_set():
            code = job.poll()
            if code is not None:
                break
            stop.wait(0.05)
        job.terminate_and_wait(5.0)
        emit('owned_tree_empty')
        return code if code is not None else 0
    finally:
        job.close()


def watch_host(stop, fd):
    """The host closes our stdin to cancel; EOF (or a broken pipe) sets `stop`.

    Reads the raw fd, never `sys.stdin.buffer`: this daemon thread is still parked here
    when the plugin exits on its own, and a parked BufferedReader holds its lock, so
    interpreter shutdown aborted with "Fatal Python error: _enter_buffered_busy". The
    host then saw 0xC0000005 instead of the plugin's own exit code.
    """
    try:
        os.read(fd, 1)
    finally:
        stop.set()


def exit_status(code):
    """Windows exit codes are DWORDs but os._exit takes a C int: pass the same 32 bits signed.

    Python 3.11 on Windows turns SystemExit(code > 2**31 - 1) into -1, which loses NTSTATUS
    crash codes such as 0xC0000005.
    """
    return code - (1 << 32) if code > 0x7FFFFFFF else code


def main(argv=None, job_factory=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        raise SystemExit('usage: windows_supervisor MODULE [ARGS...]')
    stop = threading.Event()
    threading.Thread(target=watch_host, args=(stop, sys.stdin.fileno()), daemon=True).start()

    def emit(event):
        print('\n' + json.dumps({'v': 1, 'ts': datetime.now(timezone.utc).isoformat(),
                                 'level': 'info', 'src': 'python.windows_supervisor',
                                 'msg': event, 'ctx': {'ownedTree': event}}), flush=True)

    return supervise((job_factory or WindowsJob)(), [sys.executable, '-m', *argv], stop, emit)


def run(argv=None, job_factory=None):
    """Exit with the plugin's exit code exactly; the job is already drained and closed."""
    code = main(argv, job_factory)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(exit_status(code))


if __name__ == '__main__':
    run()
