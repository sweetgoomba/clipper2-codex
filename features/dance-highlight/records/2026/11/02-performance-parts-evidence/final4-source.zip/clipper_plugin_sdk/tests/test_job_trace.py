"""handle_job이 to_thread 워커에 trace_ctx를 전파하는지 검증.

TDD: 먼저 실패하는 테스트를 작성하고 구현 후 green 확인.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from clipper_plugin_sdk.base import CancelFlag, PluginBase, PluginRuntime
from clipper_plugin_sdk.logging_config import trace_ctx
from clipper_plugin_sdk.models import JobRequest, JobStatus


class _TraceCapturingPlugin(PluginBase):
    """run_job 내에서 trace_ctx 값을 캡처하는 플러그인."""

    name = "trace_capture"
    version = "0.0.0"

    def __init__(self) -> None:
        super().__init__()
        self.captured_trace: str | None = "NOT_SET"  # sentinel: NOT_SET = run_job not called

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        # 워커 스레드 내에서 trace_ctx 값을 캡처
        self.captured_trace = trace_ctx.get()
        return {"status": "ok"}


@pytest.mark.asyncio
async def test_trace_propagates_into_worker_thread():
    """handle_job → to_thread 경계를 지나 trace_ctx가 워커 스레드에 도달해야 한다."""
    plugin = _TraceCapturingPlugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime  # noqa: SLF001

    # 요청 컨텍스트에서 trace_ctx 설정 (미들웨어가 set하는 것 시뮬레이션)
    token = trace_ctx.set("test-trace-abc")
    try:
        req = JobRequest(job_id="trace-job-1", params={})
        task = runtime.submit_job(req)
        result = await task
    finally:
        trace_ctx.reset(token)

    assert result.status == JobStatus.COMPLETED
    # 핵심 검증: 워커 스레드 내에서 캡처한 trace가 설정한 값과 일치해야 한다
    assert plugin.captured_trace == "test-trace-abc", (
        f"Worker thread got trace={plugin.captured_trace!r}, expected 'test-trace-abc'. "
        "trace_ctx was not propagated across to_thread boundary."
    )


@pytest.mark.asyncio
async def test_none_trace_in_worker_when_not_set():
    """trace_ctx가 설정되지 않은 경우, 워커 스레드에서도 None이어야 한다."""
    plugin = _TraceCapturingPlugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime  # noqa: SLF001

    # trace_ctx 미설정 상태 (default=None)
    assert trace_ctx.get() is None

    req = JobRequest(job_id="trace-job-2", params={})
    task = runtime.submit_job(req)
    result = await task

    assert result.status == JobStatus.COMPLETED
    assert plugin.captured_trace is None, (
        f"Worker thread got trace={plugin.captured_trace!r}, expected None."
    )
