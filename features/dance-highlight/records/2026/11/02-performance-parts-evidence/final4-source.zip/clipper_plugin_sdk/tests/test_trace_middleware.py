import asyncio
from types import SimpleNamespace

from clipper_plugin_sdk.trace_middleware import request_trace, set_trace_from_request
from clipper_plugin_sdk.logging_config import trace_ctx


class FakeReq:
    def __init__(self, headers):
        self.headers = headers
        self.state = SimpleNamespace()


async def _run(headers):
    captured = {}

    async def call_next(_req):
        captured['trace'] = trace_ctx.get()
        return 'resp'

    result = await set_trace_from_request(FakeReq(headers), call_next)
    return captured['trace'], result


def test_header_sets_contextvar():
    trace, result = asyncio.run(_run({'x-trace-id': 'abcd1234'}))
    assert trace == 'abcd1234'
    assert result == 'resp'


def test_missing_header_generates_8hex():
    trace, _ = asyncio.run(_run({}))
    assert len(trace) == 8 and all(c in '0123456789abcdef' for c in trace)


def test_contextvar_reset_after():
    asyncio.run(_run({'x-trace-id': 'abcd1234'}))
    assert trace_ctx.get() is None


def test_trace_is_kept_on_the_request_for_handlers_outside_the_middleware():
    req = FakeReq({})

    async def call_next(_req):
        return 'resp'

    asyncio.run(set_trace_from_request(req, call_next))

    # contextvar는 되돌려졌어도 요청에는 남아 있다 — 바깥의 Exception 핸들러가 이걸 읽는다.
    assert trace_ctx.get() is None
    assert request_trace(req) == req.state.trace_id
    assert len(req.state.trace_id) == 8


def test_request_trace_falls_back_to_header_without_middleware():
    assert request_trace(FakeReq({'x-trace-id': 'abcd1234'})) == 'abcd1234'
    assert request_trace(FakeReq({})) is None
