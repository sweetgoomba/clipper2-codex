from __future__ import annotations

from typing import Any

from clipper_plugin_sdk.base import CancelFlag, PluginBase, PluginRuntime
from clipper_plugin_sdk.models import JobRequest, RuntimeProbe


class _AcceleratorPlugin(PluginBase):
    name = "accelerator_test"
    version = "0.1.0"

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        return {"ok": True}

    def get_runtime_accelerators(self) -> dict[str, Any]:
        return {
            "primary_device": "mps",
            "pipeline": "test",
        }


def test_runtime_accelerators_includes_plugin_selection_and_probes(monkeypatch):
    plugin = _AcceleratorPlugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime
    runtime._models_loaded = True

    monkeypatch.setattr(
        PluginRuntime,
        "_probe_torch",
        staticmethod(lambda: RuntimeProbe(
            name="torch",
            installed=True,
            available=True,
            version="test",
            details={"mps_available": True},
        )),
    )
    monkeypatch.setattr(
        PluginRuntime,
        "_probe_onnxruntime",
        staticmethod(lambda: RuntimeProbe(
            name="onnxruntime",
            installed=False,
            available=False,
        )),
    )
    monkeypatch.setattr(
        PluginRuntime,
        "_probe_ctranslate2",
        staticmethod(lambda: RuntimeProbe(
            name="ctranslate2",
            installed=False,
            available=False,
        )),
    )

    response = runtime.get_runtime_accelerators()

    assert response.plugin_name == "accelerator_test"
    assert response.version == "0.1.0"
    assert response.models_loaded is True
    assert response.selected == {"primary_device": "mps", "pipeline": "test"}
    assert [probe.name for probe in response.probes] == [
        "torch",
        "onnxruntime",
        "ctranslate2",
    ]
    assert response.probes[0].details["mps_available"] is True
