"""PluginRuntime OOM 분류 테스트.

run_job OOM → VRAM_OOM_RUNTIME 에러 반환, empty_cache 호출
load_models OOM → classify_load_failure()가 exit code 반환 (os._exit은 별도 E2E 검증)

분류 로직(순수 함수)은 여기서, 실제 프로세스 종료는
`tests/e2e/test_runtime_oom_subprocess.py`에서 uvicorn lifespan 포함해 검증.
"""

from __future__ import annotations

from typing import Any

import pytest

from clipper_plugin_sdk.base import (
    EXIT_LOAD_FAILED,
    EXIT_RAM_OOM,
    EXIT_VRAM_OOM,
    CancelFlag,
    PluginBase,
    PluginRuntime,
)
from clipper_plugin_sdk.models import JobRequest


class FakeCudaOutOfMemoryError(Exception):
    """torch.cuda.OutOfMemoryError를 이름으로 흉내.

    PluginRuntime은 `type(exc).__name__`에 'OutOfMemoryError' 포함 여부로 분류.
    """


# type(exc).__name__ 매칭을 위해 이름 강제 교체
FakeCudaOutOfMemoryError.__name__ = "OutOfMemoryError"


class _DummyPlugin(PluginBase):
    name = "dummy"
    version = "0.0.0"

    def __init__(self, run_job_fn) -> None:
        super().__init__()
        self._run_job_fn = run_job_fn

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        return self._run_job_fn(request, cancel_flag)


def _make_runtime(run_job_fn) -> PluginRuntime:
    plugin = _DummyPlugin(run_job_fn)
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime
    return runtime


# ── run_job OOM 래퍼 ──


def test_run_job_vram_oom_by_name_maps_to_runtime_error():
    def raise_oom(req, flag):
        raise FakeCudaOutOfMemoryError("CUDA out of memory. Tried to allocate...")

    runtime = _make_runtime(raise_oom)
    req = JobRequest(job_id="j1", params={})

    result = runtime._run_job_safe(req, CancelFlag())

    assert result == {"error": "VRAM_OOM_RUNTIME", "job_id": "j1"}


def test_run_job_vram_oom_by_message_maps_to_runtime_error():
    def raise_oom(req, flag):
        raise RuntimeError("CUDA out of memory")

    runtime = _make_runtime(raise_oom)
    req = JobRequest(job_id="j2", params={})

    result = runtime._run_job_safe(req, CancelFlag())

    assert result == {"error": "VRAM_OOM_RUNTIME", "job_id": "j2"}


def test_run_job_non_oom_error_bubbles_up():
    def raise_other(req, flag):
        raise ValueError("unrelated failure")

    runtime = _make_runtime(raise_other)
    req = JobRequest(job_id="j3", params={})

    with pytest.raises(ValueError, match="unrelated failure"):
        runtime._run_job_safe(req, CancelFlag())


def test_run_job_success_returns_result():
    def succeed(req, flag):
        return {"ok": True}

    runtime = _make_runtime(succeed)
    req = JobRequest(job_id="j4", params={})

    assert runtime._run_job_safe(req, CancelFlag()) == {"ok": True}


# ── load_models 예외 분류 (순수 함수) ──


def test_classify_vram_oom_by_name():
    exc = FakeCudaOutOfMemoryError("simulated")
    assert PluginRuntime.classify_load_failure(exc) == EXIT_VRAM_OOM


def test_classify_vram_oom_by_message():
    exc = RuntimeError("CUDA out of memory: tried to allocate X")
    assert PluginRuntime.classify_load_failure(exc) == EXIT_VRAM_OOM


def test_classify_ram_oom():
    exc = MemoryError("unable to allocate")
    assert PluginRuntime.classify_load_failure(exc) == EXIT_RAM_OOM


def test_classify_generic_failure():
    exc = RuntimeError("model file missing")
    assert PluginRuntime.classify_load_failure(exc) == EXIT_LOAD_FAILED


def test_classify_value_error_as_generic():
    exc = ValueError("bad config")
    assert PluginRuntime.classify_load_failure(exc) == EXIT_LOAD_FAILED
