"""진행 이벤트에 플러그인별 필드를 더 싣는다(하위 호환).

overseas_dub 계약 §2: 진행 이벤트 `phase` ∈ ocr|stt, `percent` 0~100.
기존 소비자(Nest LocalPluginJobRunner)는 `progress`·`message`만 읽으므로 그 둘은 그대로 둔다.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import pytest

from clipper_plugin_sdk.base import CancelFlag, PluginBase, PluginRuntime
from clipper_plugin_sdk.models import JobRequest


class _Plugin(PluginBase):
    name = "progress_plugin"
    version = "0.0.0"

    def load_models(self) -> None:
        pass

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        return {}


class _FakeWs:
    def __init__(self) -> None:
        self.sent: list[str] = []

    async def send_text(self, data: str) -> None:
        self.sent.append(data)


async def _sent_after_report(**fields: Any) -> dict[str, Any]:
    plugin = _Plugin()
    runtime = PluginRuntime(plugin)
    plugin._runtime = runtime  # noqa: SLF001
    runtime._event_loop = asyncio.get_running_loop()  # noqa: SLF001
    ws = _FakeWs()
    runtime.register_ws("p1", ws)

    await asyncio.to_thread(plugin.report_progress, "p1", 0.5, "ocr", **fields)
    for _ in range(50):
        if ws.sent:
            break
        await asyncio.sleep(0.01)

    assert len(ws.sent) == 1
    return json.loads(ws.sent[0])


@pytest.mark.asyncio
async def test_progress_event_carries_extra_fields():
    payload = await _sent_after_report(phase="ocr", percent=40)

    assert payload["type"] == "progress"
    assert payload["job_id"] == "p1"
    assert payload["progress"] == 0.5
    assert payload["message"] == "ocr"
    assert payload["phase"] == "ocr"
    assert payload["percent"] == 40


@pytest.mark.asyncio
async def test_extra_fields_cannot_overwrite_standard_keys():
    # progress·message·job_id는 인자 이름이라 파이썬이 막는다 — 남은 표준 키는 type·timestamp.
    payload = await _sent_after_report(type="completed", timestamp=0, phase="stt")

    assert payload["type"] == "progress"
    assert payload["timestamp"] > 0
    assert payload["phase"] == "stt"


@pytest.mark.asyncio
async def test_progress_event_without_extra_fields_is_unchanged():
    payload = await _sent_after_report()

    assert set(payload) == {"type", "job_id", "progress", "message", "timestamp"}
