"""PluginBase — 모든 플러그인이 상속하는 ABC.

제공하는 것:
- load_models() / run_job() 인터페이스
- report_progress() — 진행률 보고

PluginRuntime이 실제 서버·OOM·취소·idle-kill 인프라를 관리.
플러그인 개발자는 PluginBase만 의존하면 된다.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import time
import threading
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager, contextmanager
from typing import Any, Protocol

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .models import (
    HealthResponse,
    JobRequest,
    JobResult,
    JobStatus,
    RuntimeAcceleratorsResponse,
    RuntimeProbe,
)

from .errors import classify, describe
from .logging_config import trace_ctx
from .process_memory import peak_rss_mb
from .routes import register_routes
from .trace_middleware import install_trace_middleware, request_trace

logger = logging.getLogger("clipper_plugin")

_LEVEL_MAP = {
    "warn": logging.WARNING,
    "error": logging.ERROR,
    "info": logging.INFO,
}


async def _unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """전역 예외 핸들러: 분류 후 1회 로깅, 항상 500 반환.

    Starlette는 `Exception` 핸들러를 trace 미들웨어 **바깥**에서 부른다 — 여기 올 때는 요청의
    trace contextvar가 이미 되돌려진 뒤라, 그대로 찍으면 정작 원인을 찾아야 할 에러 줄에서만
    trace가 빠진다. 요청에 남겨 둔 trace를 로깅하는 동안만 다시 건다.
    """
    c = classify(exc)
    token = trace_ctx.set(request_trace(request))
    try:
        logger.log(
            _LEVEL_MAP.get(c.level, logging.ERROR),
            "unhandled: %s",
            exc,
            exc_info=c.need_stack,
            extra={"ctx": {"category": c.category, "route": str(request.url.path)}},
        )
    finally:
        trace_ctx.reset(token)
    return JSONResponse(status_code=500, content={"error": "internal_error"})

# Exit codes — 매니저가 이 코드로 원인 분류
EXIT_VRAM_OOM = 10
EXIT_RAM_OOM = 11
EXIT_LOAD_FAILED = 12


class ProgressReporter(Protocol):
    """진행률 보고 인터페이스. 플러그인 개발자가 의존하는 추상."""

    def report_progress(
        self, job_id: str, progress: float, message: str = "", **fields: Any
    ) -> None:
        ...


class PluginBase(ABC):
    """플러그인 개발자가 상속하여 load_models()와 run_job()만 구현.

    플러그인 개발자의 계약:
    - name, version 오버라이드
    - load_models() 구현 — 모델 로드
    - run_job(request, cancel_flag) 구현 — 작업 실행
    - report_progress(job_id, progress, message) 호출 — 진행률 보고
    """

    # 서브클래스에서 오버라이드
    name: str = "unnamed_plugin"
    version: str = "0.0.0"

    def __init__(self) -> None:
        self._runtime: PluginRuntime | None = None
        self._request_lock = threading.Lock()
        self._active_requests = 0

    @property
    def active_requests(self) -> int:
        with self._request_lock:
            return self._active_requests

    @contextmanager
    def active_request(self):
        """Protect synchronous extra routes, including work in worker threads."""
        with self._request_lock:
            self._active_requests += 1
        try:
            yield
        finally:
            with self._request_lock:
                if self._runtime is not None:
                    self._runtime._last_activity = time.monotonic()
                self._active_requests -= 1

    # ── 플러그인 개발자가 구현 ──

    @abstractmethod
    def load_models(self) -> None:
        """모델을 GPU/CPU에 로드. OOM 시 런타임이 catch."""
        ...

    @abstractmethod
    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        """동기 작업 실행. cancel_flag.is_set()으로 취소 체크.

        반환값은 결과 dict. 취소 시 {"status": "cancelled"} 반환 권장.
        """
        ...

    # ── 플러그인 개발자가 호출 ──

    def report_progress(
        self, job_id: str, progress: float, message: str = "", **fields: Any
    ) -> None:
        """진행률 보고 (0.0~1.0). WebSocket heartbeat 겸용.

        `fields`는 진행 이벤트에 더 싣는 플러그인별 값(예: overseas_dub의 `phase`·`percent`).
        표준 키(type·job_id·progress·message·timestamp)는 덮어쓰지 못한다.
        """
        if self._runtime is not None:
            self._runtime.report_progress(job_id, progress, message, **fields)

    @staticmethod
    def print_model_loading(name: str, current: int, total: int) -> None:
        """모델 로딩 진행을 stdout에 JSON으로 출력. Electron이 파싱해 Angular에 전달."""
        import json
        print(json.dumps({
            "type": "model_loading",
            "name": name,
            "current": current,
            "total": total,
        }), flush=True)

    @staticmethod
    def print_download_progress(model_name: str, pct: float) -> None:
        """HuggingFace 다운로드 진행률을 stdout에 JSON으로 출력. Electron이 파싱해 Angular에 전달."""
        import json
        print(json.dumps({
            "type": "download_progress",
            "model_name": model_name,
            "pct": round(pct, 4),
        }), flush=True)

    def register_extra_routes(self, app: FastAPI) -> None:
        """플러그인별 커스텀 라우트 등록 훅. 기본 구현은 아무것도 하지 않음.

        PluginRuntime이 앱을 생성한 뒤 호출한다. 플러그인이 표준 SDK 엔드포인트 외에
        추가 라우트가 필요할 때(예: pre-pipeline API) 오버라이드한다.
        """

    def get_runtime_accelerators(self) -> dict[str, Any]:
        """플러그인별 실제 선택 accelerator/device를 반환하는 선택 훅.

        SDK는 torch/onnxruntime 같은 공통 provider probe를 담당하고, 플러그인은
        자신이 최종 선택한 device나 provider만 얕게 보고한다.
        """
        return {}

    # ── 진입점 ──

    def run(self, port: int, idle_timeout: float = 300.0) -> None:
        """플러그인 서버 시작. __main__.py에서 호출."""
        from .logging_config import configure_json_logging

        configure_json_logging(f"python.{self.name}")
        runtime = PluginRuntime(self)
        self._runtime = runtime
        runtime.start(port=port, idle_timeout=idle_timeout)


class PluginRuntime:
    """플러그인 실행 인프라. PluginBase와 분리된 런타임 계층.

    책임: FastAPI 앱 생성, OOM 방어, 취소 관리, idle-kill, WebSocket 관리.
    플러그인 개발자는 이 클래스를 직접 다루지 않는다.
    """

    def __init__(self, plugin: PluginBase) -> None:
        self._plugin = plugin
        self._cancel_flags: dict[str, CancelFlag] = {}
        self._active_jobs: dict[str, asyncio.Task] = {}
        self._completed_results: dict[str, JobResult] = {}  # job_id → result (survives task removal)
        self._ws_connections: dict[str, Any] = {}  # job_id → WebSocket
        self._last_activity: float = time.monotonic()
        self._idle_timeout: float = 300.0
        self._shutdown_event: asyncio.Event | None = None
        self._models_loaded: bool = False
        self._event_loop: asyncio.AbstractEventLoop | None = None  # set in lifespan
        self._server: uvicorn.Server | None = None
        self._jobs_started = 0  # 이 프로세스가 받은 작업 수 — 최대 메모리 기록이 첫 작업인지 가른다

        self.app = self._create_app()

    # ── routes.py가 사용하는 공개 인터페이스 ──

    @property
    def plugin_name(self) -> str:
        return self._plugin.name

    @property
    def plugin_version(self) -> str:
        return self._plugin.version

    def has_active_job(self, job_id: str) -> bool:
        return job_id in self._active_jobs

    def get_active_job_task(self, job_id: str) -> asyncio.Task | None:
        return self._active_jobs.get(job_id)

    def register_ws(self, job_id: str, ws: Any) -> None:
        self._ws_connections[job_id] = ws

    def unregister_ws(self, job_id: str) -> None:
        self._ws_connections.pop(job_id, None)

    # ── 진행률 보고 ──

    def report_progress(
        self, job_id: str, progress: float, message: str = "", **fields: Any
    ) -> None:
        """진행률 보고 (0.0~1.0). WebSocket heartbeat 겸용."""
        self._last_activity = time.monotonic()
        ws = self._ws_connections.get(job_id)
        if ws is not None:
            import json
            data = json.dumps({
                **fields,
                "type": "progress",
                "job_id": job_id,
                "progress": round(progress, 4),
                "message": message,
                "timestamp": time.time(),
            })
            loop = self._event_loop
            if loop is not None and loop.is_running():
                asyncio.run_coroutine_threadsafe(ws.send_text(data), loop)

    # ── 작업 관리 ──

    async def handle_job(self, request: JobRequest) -> JobResult:
        """작업 제출 처리. asyncio.to_thread로 별도 스레드 실행."""
        self._last_activity = time.monotonic()
        started_at = self._last_activity
        self._jobs_started += 1
        job_number = self._jobs_started
        cancel_flag = CancelFlag()
        self._cancel_flags[request.job_id] = cancel_flag
        category: str | None = None

        try:
            trace = trace_ctx.get()  # 요청 컨텍스트에서 캡처 (asyncio task가 복사해 줌)

            def _runner() -> Any:
                # 워커 스레드에서 명시적으로 trace 재설정 (Python 버전 호환 + 명시성)
                if trace is not None:
                    trace_ctx.set(trace)
                return self._run_job_safe(request, cancel_flag)

            result = await asyncio.to_thread(_runner)
            status = JobStatus.COMPLETED
            error = None

            if isinstance(result, dict):
                if result.get("status") == "cancelled":
                    status = JobStatus.CANCELLED
                elif result.get("error"):
                    status = JobStatus.FAILED
                    error = result.get("error")
                    # 실패 종류를 아는 건 플러그인이다(예: overseas_dub 계약의
                    # input_invalid | model_missing | internal) — 준 값을 그대로 싣는다.
                    returned_category = result.get("category")
                    if isinstance(returned_category, str) and returned_category:
                        category = returned_category
        except Exception as exc:
            c = classify(exc)
            category = c.category
            # describe = 원문 + 진단(경로 길이/없는 상위 폴더). 이 문자열이 로그와 잡 에러를
            # 거쳐 nest → FE까지 그대로 가므로, 원인은 여기서 붙여야 사용자에게 닿는다.
            message = describe(exc)
            logger.log(
                _LEVEL_MAP.get(c.level, logging.ERROR),
                "job %s failed: %s", request.job_id, message,
                exc_info=c.need_stack,
                extra={"ctx": {"category": c.category, "jobId": request.job_id, "operation": "job.run"}},
            )
            result = None
            status = JobStatus.FAILED
            error = message

        job_result = JobResult(
            job_id=request.job_id,
            status=status,
            result=result if status == JobStatus.COMPLETED else None,
            error=error,
            category=category,
        )
        self._log_job_memory(request.job_id, status, started_at, job_number)
        # Store before removing from _active_jobs so WS handler can retrieve
        # the result even if the task finished before the WS connected.
        self._completed_results[request.job_id] = job_result

        self._cancel_flags.pop(request.job_id, None)
        self._active_jobs.pop(request.job_id, None)
        self._last_activity = time.monotonic()

        return job_result

    def _log_job_memory(
        self, job_id: str, status: JobStatus, started_at: float, job_number: int
    ) -> None:
        """작업이 끝날 때(성공·실패·취소) 이 프로세스의 최대 메모리를 한 줄 남긴다.

        매니페스트의 예상 RAM(`estimated_ram_mb`)을 실측으로 고치려는 기록이다 — 로그 폴더의
        `python.<plugin>.jsonl`에서 `operation == "job.memory"`인 줄만 뽑는다. 최고치는 프로세스 전체 값이라
        (`process_memory.peak_rss_mb`) 작업 하나를 재려면 그 작업이 이 프로세스의 첫 작업이어야 한다 —
        `jobsSinceStart`가 1인 줄만 믿는다. 재기는 부가 기록이라 어떤 실패도 작업 결과를 바꾸지 않는다.
        """
        try:
            peak = peak_rss_mb()
            logger.info(
                "job %s memory peak %s MB", job_id, peak,
                extra={"ctx": {
                    "operation": "job.memory",
                    "plugin": self._plugin.name,
                    "jobId": job_id,
                    "status": status.value,
                    "peakRssMb": peak,
                    "elapsedSec": round(time.monotonic() - started_at, 1),
                    "jobsSinceStart": job_number,
                }},
            )
        except Exception:  # noqa: BLE001 — 기록 실패가 작업을 깨면 안 된다
            logger.debug("job %s memory peak not recorded", job_id, exc_info=True)

    def get_completed_result(self, job_id: str) -> JobResult | None:
        return self._completed_results.pop(job_id, None)

    def submit_job(self, request: JobRequest) -> asyncio.Task:
        """작업을 백그라운드 태스크로 제출하고 Task를 반환."""
        task = asyncio.create_task(self.handle_job(request))
        self._active_jobs[request.job_id] = task
        return task

    def cancel_job(self, job_id: str) -> dict[str, str]:
        """취소 요청.

        handle_job이 아직 시작 전이면 _cancel_flags에 없을 수 있으므로
        asyncio Task 자체를 취소하는 경로도 병행.
        """
        flag = self._cancel_flags.get(job_id)
        if flag is not None:
            flag.set()
            return {"status": "cancelling", "job_id": job_id}
        task = self._active_jobs.pop(job_id, None)
        if task is not None:
            task.cancel()
            return {"status": "cancelled", "job_id": job_id}
        return {"error": "job_not_found", "job_id": job_id}

    def get_health(self) -> HealthResponse:
        return HealthResponse(
            plugin_name=self._plugin.name,
            version=self._plugin.version,
            active_jobs=len(self._active_jobs) + self._plugin.active_requests,
            vram_used_mb=self._measure_vram(),
        )

    def get_runtime_accelerators(self) -> RuntimeAcceleratorsResponse:
        return RuntimeAcceleratorsResponse(
            plugin_name=self._plugin.name,
            version=self._plugin.version,
            models_loaded=self._models_loaded,
            selected=self._plugin.get_runtime_accelerators(),
            probes=[
                self._probe_torch(),
                self._probe_onnxruntime(),
                self._probe_ctranslate2(),
            ],
        )

    async def shutdown(self) -> None:
        """정상 종료. 진행 중인 작업이 끝나길 잠시 대기 후 종료."""
        logger.info("Shutdown requested")
        if self._shutdown_event:
            self._shutdown_event.set()
        for _ in range(60):
            if not self._active_jobs and not self._plugin.active_requests:
                break
            await asyncio.sleep(0.5)

        if self._server is not None:
            self._server.should_exit = True
            return

        raise SystemExit(0)

    # ── 내부 ──

    def _create_app(self) -> FastAPI:
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            self._event_loop = asyncio.get_running_loop()
            self._shutdown_event = asyncio.Event()
            self._try_load_models()
            # 모델 다운로드/로딩에 수 분이 소요될 수 있으므로 완료 후 idle timer 리셋.
            # __init__에서 설정된 _last_activity 기준으로는 watcher가 첫 실행 시
            # elapsed >= idle_timeout이 되어 즉시 shutdown되는 문제를 방지.
            self._last_activity = time.monotonic()
            idle_task = asyncio.create_task(self._idle_watcher())
            yield
            idle_task.cancel()
            try:
                await idle_task
            except asyncio.CancelledError:
                pass

        app = FastAPI(
            title=self._plugin.name,
            version=self._plugin.version,
            lifespan=lifespan,
        )
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["http://localhost:4200", "http://127.0.0.1:4200"],
            allow_methods=["GET", "POST", "DELETE"],
            allow_headers=["Content-Type"],
        )
        app.add_exception_handler(Exception, _unhandled_exception_handler)
        install_trace_middleware(app)
        register_routes(app, self)
        self._plugin.register_extra_routes(app)
        return app

    @staticmethod
    def classify_load_failure(exc: Exception) -> int:
        """load_models() 예외를 exit code로 분류. SRP: 분류만 담당."""
        exc_name = type(exc).__name__
        if "OutOfMemoryError" in exc_name or "CUDA out of memory" in str(exc):
            return EXIT_VRAM_OOM
        if isinstance(exc, MemoryError):
            return EXIT_RAM_OOM
        return EXIT_LOAD_FAILED

    def _try_load_models(self) -> None:
        """모델 로딩 + OOM catch.

        uvicorn lifespan 안에서 호출되므로 `sys.exit()`은 starlette이 잡아
        uvicorn 자체 종료 코드(3)로 덮어버린다. 매니저가 OOM을 구분하려면
        프로세스를 즉시 원하는 exit code로 죽여야 한다 → `os._exit()`.
        """
        try:
            self._plugin.load_models()
            self._models_loaded = True
            vram = self._measure_vram()
            logger.info(
                "Models loaded. VRAM used: %s MB",
                f"{vram:.0f}" if vram else "N/A",
            )
        except Exception as exc:
            exit_code = self.classify_load_failure(exc)
            if exit_code == EXIT_VRAM_OOM:
                logger.error("VRAM OOM during model loading")
            elif exit_code == EXIT_RAM_OOM:
                logger.error("RAM OOM during model loading")
            else:
                logger.error("Model loading failed: %s", exc)

            # stderr/stdout flush 후 즉시 프로세스 종료 (uvicorn 우회)
            sys.stdout.flush()
            sys.stderr.flush()
            os._exit(exit_code)

    def _run_job_safe(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        """OOM catch 래퍼."""
        try:
            return self._plugin.run_job(request, cancel_flag)
        except Exception as exc:
            exc_name = type(exc).__name__
            if "OutOfMemoryError" in exc_name or "CUDA out of memory" in str(exc):
                self._try_empty_cache()
                return {"error": "VRAM_OOM_RUNTIME", "job_id": request.job_id}
            raise

    async def _idle_watcher(self) -> None:
        """idle-kill 타이머."""
        while True:
            await asyncio.sleep(10)
            if self._idle_timeout <= 0:
                continue
            elapsed = time.monotonic() - self._last_activity
            if elapsed >= self._idle_timeout and not self._active_jobs and not self._plugin.active_requests:
                logger.info(
                    "Idle for %.0fs (limit: %.0fs), shutting down",
                    elapsed,
                    self._idle_timeout,
                )
                await self.shutdown()
                return

    def _measure_vram(self) -> float | None:
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            return info.used / (1024 * 1024)
        except Exception:
            return None

    @staticmethod
    def _probe_torch() -> RuntimeProbe:
        try:
            import torch

            cuda_available = bool(torch.cuda.is_available())
            details: dict[str, Any] = {
                "cuda_available": cuda_available,
                "cuda_device_count": torch.cuda.device_count() if cuda_available else 0,
            }
            if hasattr(torch.backends, "mps"):
                details["mps_available"] = bool(torch.backends.mps.is_available())
            if cuda_available:
                details["cuda_devices"] = [
                    torch.cuda.get_device_name(index)
                    for index in range(torch.cuda.device_count())
                ]
            return RuntimeProbe(
                name="torch",
                installed=True,
                available=cuda_available or bool(details.get("mps_available")),
                version=getattr(torch, "__version__", None),
                details=details,
            )
        except Exception as exc:
            return RuntimeProbe(
                name="torch",
                installed=False,
                available=False,
                error=str(exc),
            )

    @staticmethod
    def _probe_onnxruntime() -> RuntimeProbe:
        try:
            import onnxruntime as ort

            providers = list(ort.get_available_providers())
            return RuntimeProbe(
                name="onnxruntime",
                installed=True,
                available=bool(providers),
                version=getattr(ort, "__version__", None),
                details={
                    "available_providers": providers,
                    "cuda_available": "CUDAExecutionProvider" in providers,
                    "coreml_available": "CoreMLExecutionProvider" in providers,
                },
            )
        except Exception as exc:
            return RuntimeProbe(
                name="onnxruntime",
                installed=False,
                available=False,
                error=str(exc),
            )

    @staticmethod
    def _probe_ctranslate2() -> RuntimeProbe:
        try:
            import ctranslate2

            cuda_device_count = 0
            get_cuda_device_count = getattr(ctranslate2, "get_cuda_device_count", None)
            if callable(get_cuda_device_count):
                try:
                    cuda_device_count = int(get_cuda_device_count())
                except Exception:
                    cuda_device_count = 0

            return RuntimeProbe(
                name="ctranslate2",
                installed=True,
                available=cuda_device_count > 0,
                version=getattr(ctranslate2, "__version__", None),
                details={
                    "cuda_device_count": cuda_device_count,
                },
            )
        except Exception as exc:
            return RuntimeProbe(
                name="ctranslate2",
                installed=False,
                available=False,
                error=str(exc),
            )

    @staticmethod
    def _try_empty_cache() -> None:
        try:
            import torch.cuda
            torch.cuda.empty_cache()
        except Exception:
            pass

    def start(self, port: int, idle_timeout: float = 300.0) -> None:
        """서버 시작."""
        self._idle_timeout = idle_timeout
        logger.info(
            "Starting %s v%s on 127.0.0.1:%d",
            self._plugin.name,
            self._plugin.version,
            port,
        )
        config = uvicorn.Config(
            self.app,
            host="127.0.0.1",
            port=port,
            log_level="info",
        )
        server = uvicorn.Server(config)
        self._server = server
        try:
            server.run()
        finally:
            self._server = None


class CancelFlag:
    """스레드 안전한 취소 플래그. 플러그인 개발자가 is_set()으로 체크."""

    def __init__(self) -> None:
        self._cancelled = False

    def set(self) -> None:
        self._cancelled = True

    def is_set(self) -> bool:
        return self._cancelled

    def __bool__(self) -> bool:
        return self._cancelled
