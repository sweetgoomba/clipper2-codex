"""Build reviewable Person playback clips from visual and timed speech evidence.

Identity stays in occurrences.py. Speech only suggests where a clip starts or ends.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from typing import Sequence

from clipper_speech_core import TimedTranscript

from .occurrences import PersonGroup

PADDING_SEC = .25
MAX_PLAYBACK_SEC = 45.
VISUAL_GAP_SEC = 2.
SPEECH_EVENT_VISUAL_CONTEXT_SEC = 10.
SPEECH_BRIDGE_SEC = 6.
SPEECH_PAUSE_SEC = 1.2
SPEECH_EVENT_PAUSE_SEC = 2.
SPEECH_EVENT_MAX_SEC = 20.
CONTINUITY_TIME_TOLERANCE_SEC = .05
CONTINUITY_MIN_COVERAGE = .6
CONTINUITY_BREAK_PAUSE_SEC = 3.


@dataclass(frozen=True)
class _Appearance:
    person_id: str
    shot_id: str
    start: float
    end: float
    evidence: str
    needs_review: bool
    track_id: str | None


def _appearances(group: PersonGroup, shot_bounds: dict[str, tuple[float, float]],
                 duration: float) -> list[_Appearance]:
    evidence = "face_group" if group.representative_observation_id else "body_track"
    review = group.status == "needs_review" or group.representative_observation_id is None
    result: list[_Appearance] = []
    for interval in group.intervals:
        start = max(0., interval.start_sec)
        end = min(duration, interval.end_sec)
        if end <= start:
            continue
        shot_ids = interval.shot_ids or (interval.shot_id,)
        for shot_id in shot_ids:
            bounds = shot_bounds.get(shot_id)
            if bounds is None:
                if shot_id != interval.shot_id:
                    continue
                lower, upper = start, end
            else:
                lower, upper = max(start, bounds[0]), min(end, bounds[1])
            if upper > lower:
                result.append(_Appearance(group.group_id, shot_id, lower, upper,
                                          evidence, review, interval.track_id))
    ordered = sorted(result, key=lambda value: (value.start, value.end, value.shot_id))
    if group.group_id != "unidentified":
        return ordered
    # Unknown is a review bucket, not one asserted identity. Co-visible body
    # tracks describe one unknown-presence window rather than duplicate clips.
    merged: list[_Appearance] = []
    for item in ordered:
        previous = merged[-1] if merged else None
        if previous and previous.shot_id == item.shot_id and item.start <= previous.end:
            merged[-1] = _Appearance(group.group_id, item.shot_id, previous.start,
                                      max(previous.end, item.end), "body_track", True,
                                      previous.track_id if previous.track_id == item.track_id else None)
        else:
            merged.append(item)
    return merged


def _speech_continues(words: tuple, start: float, end: float) -> bool:
    relevant = [word for word in words if word.end > start and word.start < end]
    if not relevant:
        return False
    cursor = start
    for word in relevant:
        if word.start - cursor >= SPEECH_PAUSE_SEC:
            return False
        cursor = max(cursor, word.end)
    return end - cursor < SPEECH_PAUSE_SEC


def _pause_at_cut(words: tuple, cut: float) -> bool:
    left = max((word.end for word in words if word.end <= cut), default=None)
    right = min((word.start for word in words if word.start >= cut), default=None)
    return (left is not None and right is not None and cut - left <= 3.
            and right - cut <= 3. and right - left >= SPEECH_PAUSE_SEC)


def _speech_blocks(transcript: TimedTranscript | None) -> list[tuple[float, float]]:
    if transcript is None or not transcript.words:
        return []
    blocks: list[tuple[float, float]] = []
    for word in transcript.words:
        if blocks and word.start - blocks[-1][1] < SPEECH_PAUSE_SEC:
            blocks[-1] = (blocks[-1][0], max(blocks[-1][1], word.end))
        else:
            blocks.append((word.start, word.end))
    return blocks


def _group_appearances(appearances: list[_Appearance], transcript: TimedTranscript | None,
                       confirmed: bool) -> list[list[_Appearance]]:
    clusters: list[list[_Appearance]] = []
    words = transcript.words if transcript else ()
    for item in appearances:
        if not clusters:
            clusters.append([item])
            continue
        previous = clusters[-1][-1]
        gap = max(0., item.start - previous.end)
        same_shot = previous.shot_id == item.shot_id
        if not same_shot and _pause_at_cut(words, item.start):
            clusters.append([item])
            continue
        same_body_track = (previous.track_id is not None
                           and previous.track_id == item.track_id)
        visual = same_shot and gap <= VISUAL_GAP_SEC and (confirmed or same_body_track)
        face_return = not same_shot and confirmed and gap <= VISUAL_GAP_SEC
        speech_bridge = (confirmed and gap <= SPEECH_BRIDGE_SEC
                         and _speech_continues(words, previous.end, item.start))
        if visual or face_return or speech_bridge:
            clusters[-1].append(item)
        else:
            clusters.append([item])
    return clusters


def _split_long(cluster: list[_Appearance]) -> list[list[_Appearance]]:
    chunks: list[list[_Appearance]] = []
    current: list[_Appearance] = []
    for item in cluster:
        start = item.start
        while item.end - start > MAX_PLAYBACK_SEC - 2 * PADDING_SEC:
            limit = start + MAX_PLAYBACK_SEC - 2 * PADDING_SEC
            if current:
                chunks.append(current)
                current = []
            chunks.append([_Appearance(item.person_id, item.shot_id, start, limit,
                                       item.evidence, item.needs_review, item.track_id)])
            start = limit
        remaining = _Appearance(item.person_id, item.shot_id, start, item.end,
                                item.evidence, item.needs_review, item.track_id)
        if current and remaining.end - current[0].start > MAX_PLAYBACK_SEC - 2 * PADDING_SEC:
            chunks.append(current)
            current = []
        current.append(remaining)
    if current:
        chunks.append(current)
    return chunks


def _playback_bounds(chunk: list[_Appearance], duration: float) -> tuple[float, float]:
    first, last = chunk[0].start, max(item.end for item in chunk)
    padded_left = max(0., first - PADDING_SEC)
    padded_right = min(duration, last + PADDING_SEC)
    if padded_right - padded_left > MAX_PLAYBACK_SEC:
        padded_left = max(0., first - PADDING_SEC)
        padded_right = min(duration, max(last + PADDING_SEC, padded_left + MAX_PLAYBACK_SEC))
        if padded_right - padded_left > MAX_PLAYBACK_SEC:
            padded_right = padded_left + MAX_PLAYBACK_SEC
    return padded_left, padded_right


def _cap_scene_padding(rows: list[dict], shot_bounds: dict[str, tuple[float, float]],
                       duration: float) -> None:
    """Cap outer padding at accepted cuts without breaking visual returns.

    Apply after speech splitting and continuity joining, while each row still
    belongs to one person. Millisecond precision matches the serialized spans.
    """
    cuts = sorted({round(edge, 3) for bounds in shot_bounds.values() for edge in bounds})
    for row in rows:
        first = min(span["start_sec"] for span in row["appearance_spans"])
        last = max(span["end_sec"] for span in row["appearance_spans"])
        before = bisect_right(cuts, first) - 1
        after = bisect_left(cuts, last)
        lower = cuts[before] if before >= 0 else 0.
        upper = cuts[after] if after < len(cuts) else duration
        row["source_start_sec"] = round(max(row["source_start_sec"], lower,
                                            first - PADDING_SEC), 3)
        row["source_end_sec"] = round(min(row["source_end_sec"], upper,
                                          last + PADDING_SEC), 3)


def _uncovered(start: float, end: float,
               covered: list[tuple[float, float]]) -> list[tuple[float, float]]:
    remaining: list[tuple[float, float]] = []
    cursor = start
    for lower, upper in sorted(covered):
        if lower > cursor:
            remaining.append((cursor, min(lower, end)))
        cursor = max(cursor, upper)
        if cursor >= end:
            break
    if cursor < end:
        remaining.append((cursor, end))
    return [(lower, upper) for lower, upper in remaining if upper > lower]


def _bounded_speech_context(lower: float, upper: float,
                            window: tuple[float, float]) -> tuple[tuple[float, float] | None,
                                                                  list[tuple[float, float]]]:
    """Retain nearby action without stretching a spoken event past its limit."""
    start, end = window
    if upper <= start:
        attached = (max(lower, start - SPEECH_EVENT_VISUAL_CONTEXT_SEC), upper)
        return attached, _uncovered(lower, upper, [attached])
    if lower >= end:
        attached = (lower, min(upper, end + SPEECH_EVENT_VISUAL_CONTEXT_SEC))
        return attached, _uncovered(lower, upper, [attached])
    return None, [(lower, upper)]


def _attach_unknown(rows: list[dict], duration: float) -> list[dict]:
    known = [row for row in rows if row["person_ids"] != ["unidentified"]]
    unknown_only: list[dict] = []
    for row in rows:
        if row["person_ids"] != ["unidentified"]:
            continue
        leftovers: list[dict] = []
        for span in row["appearance_spans"]:
            covered: list[tuple[float, float]] = []
            for target in known:
                if not any(item["start_sec"] < span["end_sec"]
                           and item["end_sec"] > span["start_sec"]
                           for item in target["appearance_spans"] if item["person_id"] != "unidentified"):
                    continue
                lower = max(span["start_sec"], target["source_start_sec"])
                upper = min(span["end_sec"], target["source_end_sec"])
                if upper <= lower:
                    continue
                target["appearance_spans"].append({**span, "start_sec": lower, "end_sec": upper})
                target["person_ids"] = sorted(set(target["person_ids"] + ["unidentified"]))
                target["appearance_start_sec"] = min(target["appearance_start_sec"], lower)
                target["appearance_end_sec"] = max(target["appearance_end_sec"], upper)
                target["needs_review"] = True
                if "unidentified_coappearance" not in target["boundary_reasons"]:
                    target["boundary_reasons"].append("unidentified_coappearance")
                covered.append((lower, upper))
            leftovers.extend({**span, "start_sec": lower, "end_sec": upper}
                             for lower, upper in _uncovered(span["start_sec"], span["end_sec"], covered))
        if leftovers:
            row["appearance_spans"] = leftovers
            row["appearance_start_sec"] = min(span["start_sec"] for span in leftovers)
            row["appearance_end_sec"] = max(span["end_sec"] for span in leftovers)
            row["source_start_sec"] = round(max(row["source_start_sec"],
                                                row["appearance_start_sec"] - PADDING_SEC), 3)
            row["source_end_sec"] = round(min(duration, row["source_end_sec"],
                                              row["appearance_end_sec"] + PADDING_SEC), 3)
            unknown_only.append(row)
    return known + unknown_only


def _coalesce_same_scene(rows: list[dict]) -> list[dict]:
    """Share a virtual clip only when the people's playback bounds agree.

    This combines clip records, not identities: every person's exact appearance
    span remains separate for matching, overlays, and manual review.
    """
    known = sorted((row for row in rows if row["person_ids"] != ["unidentified"]),
                   key=lambda row: (row["scene_id"], row["source_start_sec"],
                                    row["source_end_sec"]))
    result: list[dict] = []
    for row in known:
        match = None
        for target in reversed(result):
            if target["scene_id"] != row["scene_id"]:
                continue
            if set(target["person_ids"]) & set(row["person_ids"]):
                continue
            if (target["source_start_sec"] != row["source_start_sec"]
                    or target["source_end_sec"] != row["source_end_sec"]):
                continue
            if not any(left["start_sec"] < right["end_sec"]
                       and right["start_sec"] < left["end_sec"]
                       for left in target["appearance_spans"]
                       for right in row["appearance_spans"]):
                continue
            match = target
            break
        if match is None:
            result.append(row)
            continue
        match["person_ids"] = sorted(match["person_ids"] + row["person_ids"])
        match["appearance_spans"].extend(row["appearance_spans"])
        match["appearance_spans"].sort(key=lambda span: (span["start_sec"], span["person_id"]))
        match["appearance_start_sec"] = min(match["appearance_start_sec"], row["appearance_start_sec"])
        match["appearance_end_sec"] = max(match["appearance_end_sec"], row["appearance_end_sec"])
        match["source_start_sec"] = min(match["source_start_sec"], row["source_start_sec"])
        match["source_end_sec"] = max(match["source_end_sec"], row["source_end_sec"])
        match["boundary_reasons"] = list(dict.fromkeys(
            match["boundary_reasons"] + row["boundary_reasons"] + ["shared_scene"]))
        match["needs_review"] = match["needs_review"] or row["needs_review"]
    return result + [row for row in rows if row["person_ids"] == ["unidentified"]]


def _speech_windows(transcript: TimedTranscript | None,
                    shot_bounds: dict[str, tuple[float, float]]) -> list[tuple[float, float]]:
    if transcript is None or not transcript.words:
        return []
    cuts = sorted(start for start, _ in shot_bounds.values() if start > 0)
    blocks: list[list] = []
    for word in transcript.words:
        previous = blocks[-1][-1] if blocks else None
        cut_index = bisect_left(cuts, previous.end) if previous is not None else len(cuts)
        cut_in_pause = cut_index < len(cuts) and cuts[cut_index] <= word.start
        if previous is None or word.start - previous.end >= SPEECH_EVENT_PAUSE_SEC or (
            word.start - previous.end >= SPEECH_PAUSE_SEC
            and cut_in_pause
        ):
            blocks.append([word])
        else:
            blocks[-1].append(word)
    windows: list[tuple[float, float]] = []
    for block in blocks:
        start, end = block[0].start, block[-1].end
        while end - start > SPEECH_EVENT_MAX_SEC:
            limit = start + SPEECH_EVENT_MAX_SEC
            candidates = [word.end for word in block
                          if start + SPEECH_EVENT_MAX_SEC / 2 <= word.end <= limit]
            boundary = max(candidates, default=limit)
            windows.append((start, boundary))
            start = boundary
        if end > start:
            windows.append((start, end))
    return windows


def _covered_seconds(spans: list[dict], person_id: str) -> float:
    bounds = sorted((span["start_sec"], span["end_sec"]) for span in spans
                    if span["person_id"] == person_id)
    total = 0.
    end = float("-inf")
    for lower, upper in bounds:
        total += max(0., upper - max(lower, end))
        end = max(end, upper)
    return total


def _compact_spans(spans: list[dict]) -> list[dict]:
    """Union identical evidence without filling gaps or merging different people."""
    compact: list[dict] = []
    for span in sorted(spans, key=lambda item: (item["person_id"], item["evidence"],
                                                item["needs_review"], item["start_sec"],
                                                item["end_sec"])):
        previous = compact[-1] if compact else None
        if (previous and previous["person_id"] == span["person_id"]
                and previous["evidence"] == span["evidence"]
                and previous["needs_review"] == span["needs_review"]
                and span["start_sec"] <= previous["end_sec"] + 1e-6):
            previous["end_sec"] = max(previous["end_sec"], span["end_sec"])
        else:
            compact.append(dict(span))
    return sorted(compact, key=lambda span: (span["start_sec"], span["person_id"]))


def _continuity_breaks(transcript: TimedTranscript | None,
                       shot_bounds: dict[str, tuple[float, float]]) -> list[float]:
    """A cut inside a clear speech pause is stronger than a short reaction cut.

    Silence far from either utterance is not by itself proof of a new situation:
    a person may simply be carrying on a silent action.
    """
    cuts = sorted(start for start, _ in shot_bounds.values() if start > 0)
    breaks: set[float] = set()
    words = transcript.words if transcript else ()
    for previous, following in zip(words, words[1:]):
        if following.start - previous.end < CONTINUITY_BREAK_PAUSE_SEC:
            continue
        lower = max(previous.end, following.start - CONTINUITY_BREAK_PAUSE_SEC)
        upper = min(following.start, previous.end + CONTINUITY_BREAK_PAUSE_SEC)
        index = bisect_left(cuts, lower)
        while index < len(cuts) and cuts[index] <= upper:
            breaks.add(cuts[index])
            index += 1
    return sorted(breaks)


def _join_continuous_scenes(rows: list[dict], confirmed_ids: set[str],
                            transcript: TimedTranscript | None,
                            shot_bounds: dict[str, tuple[float, float]]) -> list[dict]:
    """Rejoin short visual returns split by timestamp drift or speech windows.

    Every named person must return and occupy most of the resulting playback.
    Unknown bodies cannot authorize a join. This changes clips, never identities
    or the exact face evidence used for overlays.
    """
    breaks = _continuity_breaks(transcript, shot_bounds)
    result: list[dict] = []
    last_by_people: dict[tuple[str, ...], int] = {}
    for row in sorted(rows, key=lambda item: (item["source_start_sec"], item["source_end_sec"])):
        people = tuple(sorted(person_id for person_id in row["person_ids"]
                              if person_id != "unidentified"))
        index = last_by_people.get(people)
        previous = result[index] if index is not None else None
        can_join = bool(previous and people and all(p in confirmed_ids for p in people))
        if can_join:
            start = min(previous["source_start_sec"], row["source_start_sec"])
            end = max(previous["source_end_sec"], row["source_end_sec"])
            spans = previous["appearance_spans"] + row["appearance_spans"]
            can_join = 0 < end - start <= MAX_PLAYBACK_SEC
            for person_id in people:
                left = [s for s in previous["appearance_spans"] if s["person_id"] == person_id]
                right = [s for s in row["appearance_spans"] if s["person_id"] == person_id]
                if not can_join or not left or not right:
                    can_join = False
                    break
                left_end = max(s["end_sec"] for s in left)
                right_start = min(s["start_sec"] for s in right)
                cut_index = bisect_left(breaks, min(left_end, right_start) - CONTINUITY_TIME_TOLERANCE_SEC)
                crosses_break = (cut_index < len(breaks)
                                 and breaks[cut_index] <= max(left_end, right_start)
                                 + CONTINUITY_TIME_TOLERANCE_SEC)
                if (right_start - left_end > VISUAL_GAP_SEC + CONTINUITY_TIME_TOLERANCE_SEC
                        or crosses_break
                        or _covered_seconds(spans, person_id) < CONTINUITY_MIN_COVERAGE * (end - start)):
                    can_join = False
                    break
        if not can_join:
            if people:
                last_by_people[people] = len(result)
            result.append(row)
            continue
        compact = _compact_spans(spans)
        result[index] = {
            **previous,
            "source_start_sec": start, "source_end_sec": end,
            "appearance_start_sec": min(s["start_sec"] for s in compact),
            "appearance_end_sec": max(s["end_sec"] for s in compact),
            "appearance_spans": compact,
            "person_ids": sorted(set(previous["person_ids"]) | set(row["person_ids"])),
            "needs_review": previous["needs_review"] or row["needs_review"],
            "boundary_reasons": list(dict.fromkeys(previous["boundary_reasons"]
                                                  + row["boundary_reasons"]
                                                  + ["continuous_appearance"])),
        }
    return result


def _speech_event_clips(rows: list[dict], transcript: TimedTranscript | None,
                        shot_bounds: dict[str, tuple[float, float]],
                        duration: float) -> list[dict]:
    """Split at spoken turns without assigning one person's whole turn to another."""
    windows = _speech_windows(transcript, shot_bounds)
    if not windows:
        return rows
    buckets: list[list[tuple[int, dict, dict]]] = [[] for _ in windows]
    visual_rows: list[dict] = []
    for row_index, row in enumerate(rows):
        attached = False
        leftover: list[dict] = []
        for span in row["appearance_spans"]:
            intersections: list[tuple[float, float]] = []
            matched: list[int] = []
            for index, (start, end) in enumerate(windows):
                lower = max(start, span["start_sec"])
                upper = min(end, span["end_sec"])
                if upper <= lower:
                    continue
                buckets[index].append((row_index, row, {**span, "start_sec": lower,
                                                       "end_sec": upper}))
                intersections.append((lower, upper))
                matched.append(index)
                attached = True
            for lower, upper in _uncovered(span["start_sec"], span["end_sec"], intersections):
                nearby = min(matched, key=lambda index: min(
                    abs(lower - windows[index][1]), abs(upper - windows[index][0]))) if matched else None
                if nearby is not None and min(abs(lower - windows[nearby][1]),
                                               abs(upper - windows[nearby][0])) <= VISUAL_GAP_SEC:
                    attached_span, residual = _bounded_speech_context(lower, upper,
                                                                       windows[nearby])
                    if attached_span is not None and attached_span[1] > attached_span[0]:
                        buckets[nearby].append((row_index, row, {**span,
                                                "start_sec": attached_span[0],
                                                "end_sec": attached_span[1]}))
                    leftover.extend({**span, "start_sec": start, "end_sec": end}
                                    for start, end in residual)
                else:
                    leftover.append({**span, "start_sec": lower, "end_sec": upper})
        if not attached:
            visual_rows.append(row)
            continue
        for span in leftover:
            lower, upper = span["start_sec"], span["end_sec"]
            visual_rows.append({
                **row, "person_ids": [span["person_id"]], "appearance_spans": [span],
                "appearance_start_sec": lower, "appearance_end_sec": upper,
                "source_start_sec": round(max(0., lower - PADDING_SEC), 3),
                "source_end_sec": round(min(duration, upper + PADDING_SEC), 3),
                "needs_review": span["needs_review"],
                "boundary_reasons": ["visual_between_speech"],
            })
    event_rows: list[dict] = []
    for bucket in buckets:
        bucket_rows: list[dict] = []
        by_row: dict[int, tuple[dict, list[dict]]] = {}
        for row_index, row, span in bucket:
            by_row.setdefault(row_index, (row, []))[1].append(span)
        for row, raw_spans in by_row.values():
            seen = set()
            spans = []
            for span in raw_spans:
                key = (span["person_id"], span["start_sec"], span["end_sec"], span["evidence"])
                if key not in seen:
                    seen.add(key)
                    spans.append(span)
            spans = _compact_spans(spans)
            first = min(span["start_sec"] for span in spans)
            last = max(span["end_sec"] for span in spans)
            bucket_rows.append({
                "scene_id": row["scene_id"],
                "appearance_start_sec": first, "appearance_end_sec": last,
                "source_start_sec": round(max(0., row["source_start_sec"],
                                              first - PADDING_SEC), 3),
                "source_end_sec": round(min(duration, row["source_end_sec"],
                                              last + PADDING_SEC), 3),
                "person_ids": sorted({span["person_id"] for span in spans}),
                "appearance_spans": spans,
                "boundary_reasons": ["speech_event"],
                "needs_review": any(span["needs_review"] for span in spans),
            })
        event_rows.extend(bucket_rows)
    return event_rows + visual_rows


def compose_person_clips(groups: Sequence[PersonGroup], base_clips: Sequence[dict],
                         shot_bounds: dict[str, tuple[float, float]],
                         transcript: TimedTranscript | None, duration_sec: float) -> list[dict]:
    """Produce deterministic virtual clips; never cut or store video files here."""
    del base_clips  # v2 windows can mix people; canonical group intervals carry identity.
    if duration_sec < 0:
        raise ValueError("duration_sec must be non-negative")
    blocks = _speech_blocks(transcript)
    rows: list[dict] = []
    for group in groups:
        appearances = _appearances(group, shot_bounds, duration_sec)
        confirmed = group.representative_observation_id is not None and group.group_id != "unidentified"
        for cluster in _group_appearances(appearances, transcript, confirmed):
            for chunk in _split_long(cluster):
                source_start, source_end = _playback_bounds(chunk, duration_sec)
                spans = [{"person_id": item.person_id,
                          "start_sec": round(item.start, 3), "end_sec": round(item.end, 3),
                          "evidence": item.evidence, "needs_review": item.needs_review}
                         for item in chunk]
                reasons = ["speech_unavailable"] if not blocks else ["speech_boundary"]
                if len(cluster) > 1:
                    reasons.append("linked_appearances")
                if len(chunk) < len(cluster):
                    reasons.append("max_duration")
                rows.append({
                    "scene_id": chunk[0].shot_id,
                    "appearance_start_sec": round(chunk[0].start, 3),
                    "appearance_end_sec": round(max(item.end for item in chunk), 3),
                    "source_start_sec": round(source_start, 3),
                    "source_end_sec": round(source_end, 3),
                    "person_ids": [group.group_id],
                    "appearance_spans": spans,
                    "boundary_reasons": reasons,
                    "needs_review": any(item.needs_review for item in chunk),
                })
    rows = _speech_event_clips(rows, transcript, shot_bounds, duration_sec)
    rows = _join_continuous_scenes(rows, {
        group.group_id for group in groups if group.representative_observation_id is not None
        and group.group_id != "unidentified"
    }, transcript, shot_bounds)
    _cap_scene_padding(rows, shot_bounds, duration_sec)
    # Coappearance annotations cannot determine a named person's playback bounds.
    rows = _attach_unknown(_coalesce_same_scene(rows), duration_sec)
    rows.sort(key=lambda item: (item["appearance_start_sec"], item["person_ids"][0],
                                item["appearance_end_sec"]))
    for index, row in enumerate(rows, 1):
        row["clip_id"] = f"clip_{index:04d}"
        row["thumbnail_path"] = f"thumbnails/clip_{index:04d}.jpg"
    return rows
