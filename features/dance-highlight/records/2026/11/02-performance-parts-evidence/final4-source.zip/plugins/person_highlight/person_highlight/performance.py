"""Small aggregate timings; never retain frames or per-face trace payloads."""
from __future__ import annotations

from collections import Counter
from contextlib import contextmanager
from threading import Lock
from time import perf_counter

# 작업별 최대 메모리 로그(SDK `job.memory`)와 같은 값을 쓴다 — 측정 코드는 SDK 한 벌.
from clipper_plugin_sdk.process_memory import peak_rss_mb


class PerformanceStats:
    def __init__(self) -> None:
        self._start = perf_counter()
        self._stages: Counter[str] = Counter()
        self._calls: Counter[str] = Counter()
        self._counters: Counter[str] = Counter()
        self._lock = Lock()

    @contextmanager
    def measure(self, stage: str):
        start = perf_counter()
        try:
            yield
        finally:
            with self._lock:
                self._stages[stage] += perf_counter() - start
                self._calls[stage] += 1

    def increment(self, key: str, amount: int = 1) -> None:
        with self._lock:
            self._counters[key] += amount

    def snapshot(self) -> dict:
        with self._lock:
            return {'wall_time_sec': round(perf_counter() - self._start, 4),
                    'stages_sec': {key: round(value, 4) for key, value in self._stages.items()},
                    'stage_calls': dict(self._calls), 'counters': dict(self._counters),
                    'peak_rss_mb': peak_rss_mb(),
                    'timing_note': 'Nested and concurrent stage times must not be added.'}
