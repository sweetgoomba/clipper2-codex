"""Anonymous person highlight plugin."""
