"""Overlap CPU faces and accelerator bodies with exactly one frame in flight."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import nullcontext


def allow_parallel_inference(device: str) -> bool:
    if device != "mps" and not device.startswith("cuda"):
        return False
    try:
        import psutil
        # Queried after model loading: leave headroom for concurrent native workspaces.
        return psutil.virtual_memory().available >= 2 * 1024**3
    except (ImportError, OSError, AttributeError):
        return False


class FrameInference:
    def __init__(self, face_detector, body_detector, *, parallel: bool, metrics=None):
        self._faces = face_detector
        self._bodies = body_detector
        self._metrics = metrics
        self._pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='person-body') if parallel else None

    def __enter__(self):
        return self

    def __exit__(self, *_exception):
        try:
            if self._pool is not None:
                self._pool.shutdown(wait=True, cancel_futures=True)
        finally:
            self._pool = self._faces = self._bodies = None

    def _measure(self, key, function, frame):
        with self._metrics.measure(key) if self._metrics is not None else nullcontext():
            return function(frame)

    def detect(self, frame):
        if self._metrics is not None:
            self._metrics.increment("parallel_frames" if self._pool is not None else "serial_frames")
        if self._pool is None:
            bodies = self._measure('body_inference', self._bodies.detect, frame)
            return self._measure('face_inference', self._faces, frame), bodies
        # Never submit the next frame until both results are consumed by the tracker.
        body = self._pool.submit(self._measure, 'body_inference', self._bodies.detect, frame)
        faces = self._measure('face_inference', self._faces, frame)
        return faces, body.result()
