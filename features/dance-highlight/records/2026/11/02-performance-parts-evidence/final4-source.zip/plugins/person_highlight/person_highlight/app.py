"""Queued anonymous person-highlight job. Never identifies names or speakers."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import gc
import sys
import logging
import traceback
from functools import partial
import json
import shutil
import cv2

from clipper_plugin_sdk import PluginBase
from clipper_plugin_sdk.base import CancelFlag
from clipper_plugin_sdk.models import JobRequest
from clipper_face_core import ModelFiles, OpenCvFaceBackend
from clipper_speech_core.assets import ensure_whisper_files
from .analysis import analyze_video
from .clip_composer import compose_person_clips
from .body_detector import YoloBodyDetector
from .model_assets import (FACE_MODEL_SPECS, ensure_face_models,
                           resolve_pose_model_path, detect_yolo_device)
from .occurrences import representative_candidates
from .speech_stage import run_person_speech
from .performance import PerformanceStats
from .frame_inference import allow_parallel_inference
from .thumbnails import generate_scene_thumbnails
from .result_storage import write_person_result

logger = logging.getLogger(__name__)


def existing_model_files() -> ModelFiles:
    paths = ensure_face_models()
    return ModelFiles(paths["detector"], paths["recognizer"],
                      FACE_MODEL_SPECS[0][3], FACE_MODEL_SPECS[1][3])


def _crop_representative(cap: cv2.VideoCapture, sec: float, box: tuple[int, int, int, int],
                         target: Path) -> None:
    cap.set(cv2.CAP_PROP_POS_MSEC, sec * 1000)
    okay, frame = cap.read()
    if not okay:
        return
    height, width = frame.shape[:2]
    x1, y1, x2, y2 = box
    if x2 <= x1 or y2 <= y1 or min(width, height) <= 0:
        return
    side = min(min(width, height), max(200, round(max(x2 - x1, y2 - y1) * 1.6)))
    center_x, center_y = (x1 + x2) / 2, (y1 + y2) / 2
    left = max(0, min(round(center_x - side / 2), width - side))
    top = max(0, min(round(center_y - side / 2), height - side))
    crop = frame[top:top + side, left:left + side]
    if crop.size:
        crop = cv2.resize(crop, (256, 256), interpolation=cv2.INTER_AREA if side > 256 else cv2.INTER_CUBIC)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(target), crop):
            raise RuntimeError(f"Cannot write representative image: {target}")


class PersonHighlightPlugin(PluginBase):
    name = "person_highlight"
    version = "0.1.0"

    def __init__(self) -> None:
        super().__init__()
        self._backend: OpenCvFaceBackend | None = None
        self._body_detector: YoloBodyDetector | None = None
        self._device = "unknown"

    def load_models(self) -> None:
        self.print_model_loading("얼굴 모델 (YuNet/AuraFace)", 0, 3)
        self._backend = OpenCvFaceBackend(existing_model_files(), score_threshold=.75)
        self.print_model_loading("사람 검출 모델 (YOLO)", 1, 3)
        self._device = detect_yolo_device()
        self._body_detector = YoloBodyDetector(resolve_pose_model_path(), device=self._device)
        self.print_model_loading("음성 인식 모델 (faster-whisper-small)", 2, 3)
        ensure_whisper_files(
            on_progress=lambda pct: self.print_download_progress("faster-whisper-small", pct))

    def get_runtime_accelerators(self) -> dict[str, Any]:
        return {"primary_device": self._device, "pipeline": "yolo_body+opencv_all_faces",
                "model_sha256": self._backend.model_sha256 if self._backend else None}

    def _release_models(self) -> None:
        self._backend = None
        self._body_detector = None
        gc.collect()
        # Clearing Python objects alone does not return the accelerator allocator cache.
        torch = sys.modules.get("torch")
        if torch is not None:
            try:
                if self._device.startswith("cuda"):
                    torch.cuda.empty_cache()
                elif self._device == "mps":
                    torch.mps.empty_cache()
            except RuntimeError:
                logger.warning("Cannot clear Person accelerator cache", exc_info=True)

    def run_job(self, request: JobRequest, cancel_flag: CancelFlag) -> dict[str, Any]:
        metrics = PerformanceStats()
        outcome = "failed"
        try:
            result = self._run_job(request, cancel_flag, metrics)
            outcome = result.get("status", "failed")
            return result
        except BaseException as error:
            if isinstance(error, InterruptedError):
                outcome = "cancelled"
            # Completed inference frames may retain models through a future's traceback.
            # Keep diagnostic stack locations, but release locals before empty_cache.
            pending, seen = [error], set()
            while pending:
                failure = pending.pop()
                if id(failure) in seen:
                    continue
                seen.add(id(failure))
                traceback.clear_frames(failure.__traceback__)
                pending.extend(link for link in (failure.__cause__, failure.__context__)
                               if link is not None)
            raise
        finally:
            if self._backend is not None or self._body_detector is not None:
                with metrics.measure("model_release"):
                    self._release_models()
            performance = metrics.snapshot()
            performance.update(status=outcome, body_device=self._device,
                               face_provider="CPUExecutionProvider")
            output = request.params.get("output_root")
            if isinstance(output, str) and output and Path(output).is_dir():
                try:
                    path = Path(output) / "json" / "performance.json"
                    path.parent.mkdir(parents=True, exist_ok=True)
                    temporary = path.with_suffix(".json.part")
                    temporary.write_text(json.dumps(performance), encoding="utf-8")
                    temporary.replace(path)
                except OSError:
                    logger.warning("Cannot save Person performance metrics", exc_info=True)
            logger.info("person_highlight.performance %s", json.dumps(performance))

    def _run_job(self, request: JobRequest, cancel_flag: CancelFlag,
                 metrics: PerformanceStats) -> dict[str, Any]:
        video_path = Path(str(request.params.get("video_path") or ""))
        output_root = Path(str(request.params.get("output_root") or ""))
        sample_fps = request.params.get("sample_fps", 2.0)
        if (isinstance(sample_fps, bool) or not isinstance(sample_fps, (int, float))
                or sample_fps not in (2, 5)):
            raise ValueError("sample_fps must be 2 or 5")
        if not video_path.is_file() or not request.params.get("output_root"):
            return {"error": "video_path and output_root are required"}
        if self._backend is None or self._body_detector is None:
            with metrics.measure("model_load"):
                self.load_models()
        assert self._backend is not None
        assert self._body_detector is not None
        output_root.mkdir(parents=True, exist_ok=True)
        self.report_progress(request.job_id, .10, "등장 인물 분석 중")
        phase_updates = {
            "grouping": (.61, "같은 인물 묶는 중"),
            "intervals": (.64, "등장 구간 정리 중"),
        }
        last_analysis_bucket = 0

        def report_analysis_progress(value: float) -> None:
            nonlocal last_analysis_bucket
            bucket = int(min(1.0, max(0.0, value)) * 50)
            if bucket > last_analysis_bucket:
                last_analysis_bucket = bucket
                self.report_progress(request.job_id, .10 + .50 * value,
                                     "등장 인물 분석 중")

        model_metadata = {"model_sha256": self._backend.model_sha256,
                          "config_sha256": self._backend.config_sha256,
                          "backend_id": self._backend.backend_id}
        with metrics.measure("visual_analysis"):
            observations, body_observations, groups, clips, duration, source_hash, shot_bounds = analyze_video(
                video_path, self._backend, self._body_detector,
                sample_fps=float(sample_fps), cancelled=cancel_flag.is_set,
                progress=report_analysis_progress,
                on_phase=lambda phase: self.report_progress(request.job_id, *phase_updates[phase]),
                face_detector=partial(self._backend.detect, min_embedding_score=.85,
                                      min_embedding_size=48),
                parallel_inference=allow_parallel_inference(self._device),
                metrics=metrics)
        with metrics.measure("model_release"):
            self._release_models()
        self.report_progress(request.job_id, .67, "대표 얼굴 고르는 중")
        with metrics.measure("representative_images"):
            by_id = {item.observation_id: item for item in observations}
            image_candidates: dict[str, list[str]] = {}
            cap = cv2.VideoCapture(str(video_path)) if any(
                group.representative_observation_id is not None for group in groups) else None
            try:
                for group in groups:
                    if group.representative_observation_id is None:
                        image_candidates[group.group_id] = []
                        continue
                    assert cap is not None
                    observation = by_id[group.representative_observation_id]
                    primary_path = output_root / "faces" / f"{group.group_id}.jpg"
                    _crop_representative(cap, observation.time_sec, observation.bbox_px,
                                         primary_path)
                    candidate_ids = representative_candidates(
                        [by_id[item_id] for item_id in group.observation_ids])
                    candidate_paths: list[str] = []
                    for candidate_id in candidate_ids[:5]:
                        candidate = by_id[candidate_id]
                        path = f"faces/{group.group_id}_{candidate_id}.jpg"
                        if candidate_id == group.representative_observation_id and primary_path.is_file():
                            shutil.copyfile(primary_path, output_root / path)
                        else:
                            _crop_representative(cap, candidate.time_sec, candidate.bbox_px,
                                                 output_root / path)
                        if (output_root / path).is_file():
                            candidate_paths.append(path)
                    image_candidates[group.group_id] = candidate_paths
            finally:
                if cap is not None:
                    cap.release()
        speech_diagnostics: dict[str, Any] = {"status": "skipped_no_people"}
        transcript = None
        if groups:
            self.report_progress(request.job_id, .70, "음성 흐름 분석 중")
            cache_value = request.params.get("speech_cache_dir")
            cache_dir = Path(cache_value) if isinstance(cache_value, str) and cache_value else None
            speech_diagnostics = {}
            with metrics.measure("speech"):
                transcript = run_person_speech(
                    video_path, output_root / "json" / "speech.json", cache_dir, source_hash,
                    cancel_flag.is_set, diagnostics=speech_diagnostics, device=self._device)
            speech_diagnostics.setdefault("status", "unavailable" if transcript is None else "completed")
            self.report_progress(request.job_id, .84, "음성 흐름 분석 완료")
        with metrics.measure("clip_composition"):
            clips = compose_person_clips(groups, clips, shot_bounds, transcript, duration)
        if clips:
            self.report_progress(request.job_id, .85, "장면 미리보기 준비 중")
        last_thumbnail_bucket = 0

        def thumbnail_progress(value: float) -> None:
            nonlocal last_thumbnail_bucket
            bucket = round(value * 1000) // 100
            if bucket > last_thumbnail_bucket:
                last_thumbnail_bucket = bucket
                self.report_progress(request.job_id, .85 + .10 * value,
                                     "장면 미리보기 준비 중")

        with metrics.measure("scene_thumbnails"):
            counters = generate_scene_thumbnails(video_path, output_root, clips,
                cancelled=cancel_flag.is_set, progress=thumbnail_progress)
        for name, value in counters.items():
            metrics.increment(f"thumbnail_{name}", value)
        self.report_progress(request.job_id, .96, "원본 영상 보관 중")
        with metrics.measure("source_copy"):
            source_path = output_root / "source" / f"original{video_path.suffix.lower()}"
            source_path.parent.mkdir(parents=True, exist_ok=True)
            source_part = source_path.with_name(source_path.name + ".part")
            try:
                shutil.copy2(video_path, source_part)
                if cancel_flag.is_set():
                    raise InterruptedError("Person highlight cancelled")
                source_part.replace(source_path)
            finally:
                source_part.unlink(missing_ok=True)
        manifest = {
            "schema_version": "person-highlight.v3",
            "source_video_path": str(source_path.relative_to(output_root)),
            "source_sha256": source_hash, **model_metadata, "time_base": "seconds",
            "duration_sec": duration, "sample_fps": float(sample_fps),
            "analysis_policy": {"identity": "established-full-evidence-v2",
                                "sampling": "uncertainty-budget-v1",
                                "cuts": "face-continuity-v2",
                                "playback": "person-bounds-pad025-v2"},
            "shot_bounds": shot_bounds,
            "speech_analysis": speech_diagnostics,
            "observations": [{
                "observation_id": item.observation_id, "track_id": item.track_id,
                "scene_id": item.shot_id, "time_sec": item.time_sec,
                "bbox_px": item.bbox_px, "bbox_normalized": item.bbox_normalized,
                "quality": item.quality, "sharpness": item.sharpness,
                "detection_score": item.detection_score,
                "association_uncertain": item.association_uncertain,
                "failure": item.failure, "version": item.version,
            } for item in observations],
            "body_observations": [{
                "track_id": item.track_id, "scene_id": item.shot_id,
                "time_sec": item.time_sec, "bbox_px": item.bbox_px,
                "score": item.score,
            } for item in body_observations],
            "groups": [{
                "person_id": group.group_id, "status": group.status,
                "observation_ids": group.observation_ids,
                "track_ids": group.track_ids,
                "representative_observation_id": group.representative_observation_id,
                "person_image_path": (f"faces/{group.group_id}.jpg"
                                      if group.representative_observation_id is not None else None),
                "image_candidates": image_candidates[group.group_id],
                "intervals": [{"scene_id": interval.shot_id,
                               "start_sec": interval.start_sec, "end_sec": interval.end_sec,
                               "track_id": interval.track_id}
                              for interval in group.intervals],
            } for group in groups],
            "clips": clips,
            "unobserved_people": "unknown; detector misses cannot be enumerated",
        }
        with metrics.measure("result_storage"):
            write_person_result(output_root, manifest, observations)
        self.report_progress(request.job_id, 1.0, "완료")
        return {"status": "completed", "output_root": str(output_root),
                "meta": {"schema_version": "person-highlight.v3", "groups": len(groups),
                         "clips": len(clips), "source_sha256": source_hash,
                         "speech_analysis": speech_diagnostics,
                         "source_video_path": str(source_path)}}
