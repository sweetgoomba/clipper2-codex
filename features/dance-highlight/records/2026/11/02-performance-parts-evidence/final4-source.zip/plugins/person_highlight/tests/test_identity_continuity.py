"""Regression cases for short appearances split by motion and occluding bodies."""
import numpy as np
from clipper_face_core import FaceObservation
from person_highlight.body_tracking import BodyObservation
from person_highlight.occurrences import PersonGroup, PersonInterval, build_person_results
from clipper_face_core import group_observations


def face(key, sec, box, vector, shot='shot'):
    return FaceObservation(key, key, shot, sec, box, np.array(vector, np.float32), .8,
                           detection_score=.9, sharpness=.8)


def body(key, sec, box, appearance=(1., 0.), shot='shot'):
    return BodyObservation(key, shot, sec, box, .9, np.array(appearance, np.float32))


def groups_for(faces, bodies):
    return build_person_results(group_observations(faces, cosine_threshold=.5), faces, bodies,
                                duration_sec=10., sample_interval_sec=.5)[0]


def test_nonoverlapping_face_motion_on_same_body_is_one_person():
    faces = [face('a', 0., (120, 100, 180, 190), (1., 0.)),
             face('b', .5, (20, 20, 80, 110), (.21, .978))]
    bodies = [body('body', 0., (0, 70, 220, 400)),
              body('body', .5, (-70, 0, 180, 400))]
    groups = [g for g in groups_for(faces, bodies) if g.observation_ids]
    assert len(groups) == 1
    assert set(groups[0].observation_ids) == {'a', 'b'}


def test_overlapping_body_boxes_still_resolve_the_same_head():
    faces = [face('a', 0., (671, 452, 746, 554), (1., 0., 0.)),
             face('b', .5, (710, 477, 791, 587), (.24, .971, 0.)),
             face('c', 1., (692, 474, 775, 587), (.2, .29, .936))]
    bodies = [body('front', t, (249, 368, 781, 1070)) for t in (0., .5, 1.)]
    bodies += [body('target', t, box) for t, box in
               [(0., (527, 367, 863, 818)), (.5, (526, 407, 812, 794)),
                (1., (526, 405, 825, 794))]]
    groups = [g for g in groups_for(faces, bodies) if g.observation_ids]
    assert len(groups) == 1
    assert set(groups[0].observation_ids) == {'a', 'b', 'c'}


def test_body_continuity_rejects_crossing_cut_gap_and_changed_appearance():
    for scenario in ('crossing', 'cut', 'gap', 'appearance', 'different_face'):
        shot = 'cut' if scenario == 'cut' else 'shot'
        sec = 2. if scenario == 'gap' else .5
        vector = (0., 1.) if scenario == 'different_face' else (.21, .978)
        faces = [face('a', 0., (40, 20, 100, 100), (1., 0.)),
                 face('b', sec, (50, 30, 110, 110), vector, shot)]
        if scenario == 'crossing':
            faces.append(face('other', sec, (30, 30, 90, 110), (0., 1.)))
        bodies = [body('body', 0., (0, 0, 160, 300)),
                  body('body', sec, (0, 0, 160, 300),
                       (0., 1.) if scenario == 'appearance' else (1., 0.), shot)]
        assert not any({'a', 'b'} <= set(g.observation_ids) for g in groups_for(faces, bodies)), scenario


def test_continuous_short_faces_join_known_person_through_two_local_anchor_frames():
    vectors = [(1., 0., 0.), (.24, .971, 0.), (.2, .29, .936),
               (.3, .4, .866), (.3, .4, .866), (.1, .5, .86)]
    faces = [face(str(i), i * .5, (40 + i, 20, 100 + i, 100), v)
             for i, v in enumerate(vectors)]
    faces += [face('remote', 8., (40, 20, 100, 100), vectors[3], 'remote')]
    from person_highlight.occurrences import _merge_local_body_fragments
    known = [faces[3], faces[4], faces[-1]]
    groups = [PersonGroup('known', (), tuple(f.observation_id for f in known),
                          (PersonInterval('shot', 1.5, 2.5),), '3', 'grouped')]
    groups += [PersonGroup(f.observation_id, (), (f.observation_id,),
                           (PersonInterval('shot', f.time_sec, f.time_sec + .5),),
                           f.observation_id, 'grouped') for f in faces[:3] + [faces[5]]]
    result = _merge_local_body_fragments(groups, {f.observation_id:f for f in faces},
        [body('body', i * .5, (0, 0, 160, 300)) for i in range(6)], .5, None)
    assert len(result) == 1
    assert set(result[0].observation_ids) == {f.observation_id for f in faces}


def test_sustained_body_switch_cannot_join_two_recurring_identity_anchors():
    from person_highlight.occurrences import _merge_local_body_fragments
    a = [face('a0', 0., (40, 20, 100, 100), (1., 0.)),
         face('a1', .5, (40, 20, 100, 100), (1., 0.)),
         face('a2', 5., (40, 20, 100, 100), (1., 0.), 'remote_a')]
    b = [face('b0', 1., (40, 20, 100, 100), (.208, .978)),
         face('b1', 1.5, (40, 20, 100, 100), (.208, .978)),
         face('b2', 6., (40, 20, 100, 100), (.208, .978), 'remote_b')]
    groups = [PersonGroup(name, (), tuple(f.observation_id for f in fs), (), fs[0].observation_id, 'grouped')
              for name, fs in [('a', a), ('b', b)]]
    result = _merge_local_body_fragments(groups, {f.observation_id:f for f in a+b},
        [body('body', i*.5, (0, 0, 160, 300)) for i in range(4)], .5, None)
    assert len(result) == 2


def test_short_fragment_samples_cannot_substitute_for_known_person_anchor_support():
    from person_highlight.occurrences import _merge_local_body_fragments
    short = [face(f'b{i}', i*.5, (40, 20, 100, 100), (1., 0.)) for i in range(3)]
    known = [face('a0', 1.5, (40, 20, 100, 100), (.208, .978)),
             face('a1', 8., (40, 20, 100, 100), (.208, .978), 'remote')]
    groups = [PersonGroup(name, (), tuple(f.observation_id for f in fs), (), fs[0].observation_id, 'grouped')
              for name, fs in [('short', short), ('known', known)]]
    result = _merge_local_body_fragments(groups, {f.observation_id:f for f in short+known},
        [body('body', i*.5, (0, 0, 160, 300)) for i in range(4)], .5, None)
    assert len(result) == 2


def test_short_body_bridge_cannot_move_a_substantial_single_shot_anchor():
    from person_highlight.occurrences import _merge_local_body_fragments
    def angled(key, sec, angle):
        radians = np.deg2rad(angle)
        return face(key, sec, (40, 20, 100, 100), (np.cos(radians), np.sin(radians)))
    a = [angled(f'a{i}', i*.5 if i < 7 else 12., -51. if i == 1 else 0.) for i in range(8)]
    c = [angled(f'c{i}', 4.+i*.5 if i < 7 else 16., 10. if i == 1 else 69.) for i in range(8)]
    bridge = [angled(f'b{i}', 12.5+i*.5, 80.) for i in range(7)]
    groups = [PersonGroup(name, (), tuple(f.observation_id for f in fs), (), fs[0].observation_id, 'grouped')
              for name, fs in [('a', a), ('c', c), ('bridge', bridge)]]
    result = _merge_local_body_fragments(groups, {f.observation_id:f for f in a+c+bridge},
        [body('body', 12.+i*.5, (0, 0, 160, 300)) for i in range(9)], .5, None)
    assert not any({'a0', 'c0'} <= set(group.observation_ids) for group in result)
