from pathlib import Path
import json

import cv2
import numpy as np
import pytest

from clipper_face_core import FaceDetection, FaceObservation
from clipper_plugin_sdk.base import CancelFlag
from clipper_plugin_sdk.models import JobRequest
from person_highlight import analysis, app
from person_highlight.body_tracking import BodyDetection
from person_highlight.occurrences import PersonGroup, PersonInterval


@pytest.fixture(autouse=True)
def no_real_speech_for_synthetic_media(monkeypatch):
    monkeypatch.setattr(app, "run_person_speech", lambda *_args, **_kwargs: None, raising=False)


class _Capture:
    def __init__(self):
        self.index = 0

    def isOpened(self):
        return True

    def get(self, property_id):
        if property_id == cv2.CAP_PROP_FPS:
            return 1.0
        if property_id == cv2.CAP_PROP_FRAME_COUNT:
            return 2
        return 0

    def grab(self):
        self.index += 1
        return self.index <= 2

    def retrieve(self):
        return True, np.zeros((40, 40, 3), np.uint8)

    def read(self):
        return self.retrieve() if self.grab() else (False, None)

    def set(self, _property_id, _value):
        return True

    def release(self):
        pass


class _Backend:
    model_sha256 = "model"
    config_sha256 = "config"
    backend_id = "test"

    def detect(self, _frame, **_kwargs):
        return [FaceDetection((5, 5, 25, 25), np.array([1, 0], np.float32), 0.9, 0.9, "none")]


class _BodyDetector:
    def detect(self, _frame, **_kwargs):
        return [BodyDetection((0, 0, 35, 35), .9, np.array([1, 0], np.float32))]


def test_job_reports_each_real_analysis_stage_in_order(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")
    monkeypatch.setattr(analysis, "sha256_file", lambda _path: "source")
    monkeypatch.setattr(analysis.cv2, "VideoCapture", lambda _path: _Capture())
    monkeypatch.setattr(app, "_crop_representative",
                        lambda _source, _sec, _box, target: target.parent.mkdir(parents=True, exist_ok=True)
                        or target.write_bytes(b"image"))

    plugin = app.PersonHighlightPlugin()
    plugin._backend = _Backend()
    plugin._body_detector = _BodyDetector()
    updates = []
    plugin.report_progress = lambda _job_id, progress, message: updates.append((progress, message))

    result = plugin.run_job(
        JobRequest(job_id="progress-test", params={"video_path": str(source),
                                                   "output_root": str(tmp_path / "output")}),
        CancelFlag(),
    )

    assert result["status"] == "completed"
    messages = [message for _, message in updates]
    stages = ["등장 인물 분석 중", "같은 인물 묶는 중", "등장 구간 정리 중",
              "대표 얼굴 고르는 중", "장면 미리보기 준비 중", "원본 영상 보관 중", "완료"]
    positions = [messages.index(stage) for stage in stages]
    assert positions == sorted(positions)
    assert "얼굴 관측 중" not in messages
    assert [progress for progress, _ in updates] == sorted(progress for progress, _ in updates)


def test_long_analysis_reports_at_most_one_progress_event_per_percent(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")

    def many_frames(_path, _backend, _body_detector, *, progress, on_phase, **_kwargs):
        for index in range(1000):
            progress(index / 999)
        on_phase("grouping")
        on_phase("intervals")
        return [], [], [], [], 1.0, "source", {"shot_0000": (0., 1.)}

    monkeypatch.setattr(app, "analyze_video", many_frames)
    plugin = app.PersonHighlightPlugin()
    plugin._backend = _Backend()
    plugin._body_detector = _BodyDetector()
    updates = []
    plugin.report_progress = lambda _job_id, progress, message: updates.append((progress, message))

    result = plugin.run_job(JobRequest(job_id="many-frames", params={
        "video_path": str(source), "output_root": str(tmp_path / "output"),
    }), CancelFlag())

    analysis_updates = [value for value, message in updates
                        if message == "등장 인물 분석 중"]
    assert result["status"] == "completed"
    assert len(analysis_updates) <= 51
    assert analysis_updates[-1] >= .59


def test_many_clips_do_not_report_progress_for_every_thumbnail(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")
    clips = [{"video_path": f"clips/clip_{index}.mp4",
              "thumbnail_path": f"thumbnails/clip_{index}.jpg",
              "source_start_sec": 0.0, "source_end_sec": 1.0}
             for index in range(200)]
    monkeypatch.setattr(app, "analyze_video", lambda *_args, **_kwargs:
                        ([], [], [], clips, 1.0, "source", {"shot_0000": (0., 1.)}))
    monkeypatch.setattr(app, "compose_person_clips", lambda _groups, base, *_args: base)

    opened = []

    class EmptyCapture:
        def __init__(self):
            opened.append(self)

        def set(self, *_args):
            return True

        def read(self):
            return False, None

        def release(self):
            pass

    monkeypatch.setattr(app.cv2, "VideoCapture", lambda _path: EmptyCapture())
    plugin = app.PersonHighlightPlugin()
    plugin._backend = _Backend()
    plugin._body_detector = _BodyDetector()
    updates = []
    plugin.report_progress = lambda _job_id, progress, message: updates.append((progress, message))

    result = plugin.run_job(JobRequest(job_id="many-clips", params={
        "video_path": str(source), "output_root": str(tmp_path / "output"),
    }), CancelFlag())

    thumbnail_updates = [value for value, message in updates
                         if message == "장면 미리보기 준비 중"]
    assert result["status"] == "completed"
    assert len(opened) == 1
    assert len(thumbnail_updates) <= 26
    assert thumbnail_updates[-1] == .95


def test_scene_thumbnails_fit_within_480_pixels(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")
    clips = [{"thumbnail_path": "thumbnails/wide.jpg", "source_start_sec": 0.0,
              "source_end_sec": 1.0},
             {"thumbnail_path": "thumbnails/tall.jpg", "source_start_sec": 1.0,
              "source_end_sec": 2.0}]
    monkeypatch.setattr(app, "analyze_video", lambda *_args, **_kwargs:
                        ([], [], [], clips, 2.0, "source", {"shot_0000": (0., 2.)}))
    monkeypatch.setattr(app, "compose_person_clips", lambda _groups, base, *_args: base)

    class Capture:
        index = 0

        def set(self, *_args):
            return True

        def read(self):
            self.index += 1
            shape = (1080, 1920, 3) if self.index == 1 else (1920, 1080, 3)
            return True, np.zeros(shape, np.uint8)

        def release(self):
            pass

    monkeypatch.setattr(app.cv2, "VideoCapture", lambda _path: Capture())
    plugin = app.PersonHighlightPlugin()
    plugin._backend = _Backend()
    plugin._body_detector = _BodyDetector()
    plugin.run_job(JobRequest(job_id="thumbnail-size", params={
        "video_path": str(source), "output_root": str(tmp_path / "output"),
    }), CancelFlag())

    wide = cv2.imread(str(tmp_path / "output/thumbnails/wide.jpg"))
    tall = cv2.imread(str(tmp_path / "output/thumbnails/tall.jpg"))
    assert wide.shape[:2] == (270, 480)
    assert tall.shape[:2] == (480, 270)


def test_representative_crops_reuse_one_video_capture(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")
    observations = [FaceObservation(f"face_{index}", f"track_{index}", "shot_0",
                                    float(index), (5, 5, 105, 105), np.array([1, 0], np.float32),
                                    .9, detection_score=.9) for index in range(2)]
    groups = [PersonGroup(f"person_{index}", (f"track_{index}",),
                          (observation.observation_id,),
                          (PersonInterval("shot_0", observation.time_sec,
                                          observation.time_sec + .5),),
                          observation.observation_id, "grouped")
              for index, observation in enumerate(observations)]
    monkeypatch.setattr(app, "analyze_video", lambda *_args, **_kwargs:
                        (observations, [], groups, [], 2.0, "source", {"shot_0": (0., 2.)}))
    opened = []

    class Capture:
        def __init__(self):
            opened.append(self)
            self.read_count = 0

        def isOpened(self):
            return True

        def set(self, *_args):
            return True

        def read(self):
            self.read_count += 1
            return True, np.zeros((120, 120, 3), np.uint8)

        def release(self):
            pass

    monkeypatch.setattr(app.cv2, "VideoCapture", lambda _path: Capture())
    plugin = app.PersonHighlightPlugin()
    plugin._backend = _Backend()
    plugin._body_detector = _BodyDetector()

    result = plugin.run_job(JobRequest(job_id="crops", params={
        "video_path": str(source), "output_root": str(tmp_path / "output"),
    }), CancelFlag())

    assert result["status"] == "completed"
    assert len(opened) == 2
    assert opened[0].read_count == 2
    assert len(list((tmp_path / "output" / "faces").glob("*.jpg"))) == 4


def test_representative_image_is_saved_at_retina_card_resolution(tmp_path: Path):
    class Capture:
        def set(self, *_args):
            return True

        def read(self):
            frame = np.zeros((720, 1280, 3), np.uint8)
            frame[260:360, 460:560] = 255
            return True, frame

    target = tmp_path / 'face.jpg'
    app._crop_representative(Capture(), 1.0, (460, 260, 560, 360), target)

    image = cv2.imread(str(target))
    assert image.shape[:2] == (256, 256)
    assert image[128, 128].mean() > 240


def test_bounded_evaluation_job_records_requested_five_fps(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")
    seen = []
    monkeypatch.setattr(analysis, "sha256_file", lambda _path: "source")
    monkeypatch.setattr(analysis.cv2, "VideoCapture", lambda _path: _Capture())
    original_analyze = app.analyze_video

    def recorded_analyze(*args, **kwargs):
        seen.append(kwargs.get("sample_fps"))
        return original_analyze(*args, **kwargs)

    monkeypatch.setattr(app, "analyze_video", recorded_analyze)
    monkeypatch.setattr(app, "_crop_representative",
                        lambda _source, _sec, _box, target: target.parent.mkdir(parents=True, exist_ok=True)
                        or target.write_bytes(b"image"))
    plugin = app.PersonHighlightPlugin()
    plugin._backend = _Backend()
    plugin._body_detector = _BodyDetector()
    plugin.report_progress = lambda *_args: None
    output = tmp_path / "output"
    result = plugin.run_job(JobRequest(job_id="five-fps", params={
        "video_path": str(source), "output_root": str(output), "sample_fps": 5.0,
    }), CancelFlag())
    manifest = json.loads((output / "json/person_highlight.json").read_text())
    assert result["status"] == "completed"
    assert seen == [5.0]
    assert manifest["sample_fps"] == 5.0


def test_job_records_body_only_person_with_appearance_and_padded_source(tmp_path: Path, monkeypatch):
    source = tmp_path / "input.mp4"
    source.write_bytes(b"synthetic test source")
    monkeypatch.setattr(analysis, "sha256_file", lambda _path: "source")
    monkeypatch.setattr(analysis.cv2, "VideoCapture", lambda _path: _Capture())
    plugin = app.PersonHighlightPlugin()
    plugin._backend = type("NoFaces", (), {"model_sha256": "model", "config_sha256": "config",
                                            "backend_id": "test", "detect": lambda self, frame, **kwargs: []})()
    plugin._body_detector = _BodyDetector()
    plugin.report_progress = lambda *_args: None

    output = tmp_path / "output"
    result = plugin.run_job(JobRequest(job_id="body-only", params={
        "video_path": str(source), "output_root": str(output),
    }), CancelFlag())
    manifest = json.loads((output / "json/person_highlight.json").read_text())
    assert result["status"] == "completed"
    assert manifest["schema_version"] == "person-highlight.v3"
    assert manifest["groups"][0]["status"] == "needs_review"
    assert manifest["groups"][0]["person_image_path"] is None
    assert manifest["clips"][0]["appearance_start_sec"] == 0
    assert manifest["clips"][0]["appearance_end_sec"] == 2
    assert manifest["clips"][0]["source_start_sec"] == 0
    assert manifest["clips"][0]["source_end_sec"] == 2
    assert manifest["clips"][0]["appearance_spans"][0]["person_id"] == "unidentified"
    assert manifest["clips"][0]["needs_review"] is True
    assert "video_path" not in manifest["clips"][0]
    assert not list((output / "clips").glob("*.mp4"))
    assert (output / manifest["source_video_path"]).read_bytes() == source.read_bytes()
    assert result["meta"]["source_video_path"] == str(output / manifest["source_video_path"])
