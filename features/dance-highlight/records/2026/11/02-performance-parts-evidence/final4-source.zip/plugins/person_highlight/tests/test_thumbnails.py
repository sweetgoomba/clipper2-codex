from pathlib import Path

import cv2
import numpy as np
import pytest


def _write_video(path: Path, size: tuple[int, int] = (640, 360)) -> None:
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"MJPG"), 10.0, size)
    assert writer.isOpened()
    try:
        for color in [(20, 40, 180), (70, 160, 40), (190, 80, 20)]:
            writer.write(np.full((size[1], size[0], 3), color, dtype=np.uint8))
    finally:
        writer.release()


def test_scene_thumbnails_sort_and_decode_unique_times_preserving_every_path(tmp_path, monkeypatch):
    from person_highlight import thumbnails

    source = tmp_path / "source.avi"
    _write_video(source)
    capture_factory = cv2.VideoCapture
    seeks = []
    reads = []
    releases = []

    class RecordingCapture:
        def __init__(self, path):
            self.capture = capture_factory(path)

        def set(self, property_id, value):
            assert property_id == cv2.CAP_PROP_POS_MSEC
            seeks.append(value)
            return self.capture.set(property_id, value)

        def read(self):
            reads.append(True)
            return self.capture.read()

        def release(self):
            releases.append(True)
            self.capture.release()

    clips = [
        {"source_start_sec": .2, "thumbnail_path": "thumbnails/late.jpg"},
        {"source_start_sec": 0., "thumbnail_path": "thumbnails/early.jpg"},
        {"source_start_sec": .2, "thumbnail_path": "thumbnails/hidden.jpg", "hidden": True},
        {"source_start_sec": .1, "thumbnail_path": "thumbnails/middle.jpg"},
        {"source_start_sec": 0., "thumbnail_path": "other/early.jpg"},
    ]
    original_clips = [clip.copy() for clip in clips]
    progress = []
    monkeypatch.setattr(thumbnails.cv2, "VideoCapture", RecordingCapture)

    result = thumbnails.generate_scene_thumbnails(
        source, tmp_path / "output", clips, cancelled=lambda: False, progress=progress.append)

    assert result == {"requested": 5, "unique_timestamps": 3, "decoded": 3,
                      "written": 5, "reused": 2, "failed_reads": 0}
    assert seeks == [0., 100., 200.]
    assert len(reads) == 3
    assert releases == [True]
    assert clips == original_clips
    assert progress == [.2, .4, .6, .8, 1.]
    reference = capture_factory(str(source))
    try:
        for clip in clips:
            target = tmp_path / "output" / clip["thumbnail_path"]
            assert cv2.imread(str(target)).shape[:2] == (270, 480)
            reference.set(cv2.CAP_PROP_POS_MSEC, clip["source_start_sec"] * 1000)
            okay, frame = reference.read()
            assert okay
            frame = cv2.resize(frame, (480, 270), interpolation=cv2.INTER_AREA)
            encoded, expected = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            assert encoded
            assert target.read_bytes() == expected.tobytes()
    finally:
        reference.release()


class _Capture:
    def __init__(self, *, failed_times=(), seek_succeeds=True):
        self.failed_times = failed_times
        self.seek_succeeds = seek_succeeds
        self.sec = 0.
        self.read_count = 0
        self.released = False

    def set(self, property_id, value):
        assert property_id == cv2.CAP_PROP_POS_MSEC
        self.sec = value / 1000
        return self.seek_succeeds

    def read(self):
        self.read_count += 1
        if self.sec in self.failed_times:
            return False, None
        return True, np.full((60, 40, 3), 120, dtype=np.uint8)

    def release(self):
        self.released = True


@pytest.mark.parametrize("completed_before_cancel", [0, 1])
def test_cancellation_stops_decoding_and_duplicate_copies(tmp_path, monkeypatch,
                                                       completed_before_cancel):
    from person_highlight import thumbnails

    capture = _Capture()
    monkeypatch.setattr(thumbnails.cv2, "VideoCapture", lambda _: capture)
    clips = [{"source_start_sec": sec, "thumbnail_path": f"{index}.jpg"}
             for index, sec in enumerate([0., 0., 1.])]
    updates = []

    with pytest.raises(InterruptedError):
        thumbnails.generate_scene_thumbnails(
            tmp_path / "source.avi", tmp_path, clips,
            cancelled=lambda: len(updates) >= completed_before_cancel,
            progress=updates.append)

    assert capture.read_count == completed_before_cancel
    assert capture.released
    assert len(list(tmp_path.glob("*.jpg"))) == completed_before_cancel


def test_failed_read_is_counted_once_and_remaining_thumbnails_continue(tmp_path, monkeypatch):
    from person_highlight import thumbnails

    capture = _Capture(failed_times=(1.,))
    monkeypatch.setattr(thumbnails.cv2, "VideoCapture", lambda _: capture)
    clips = [{"source_start_sec": sec, "thumbnail_path": f"{index}.jpg"}
             for index, sec in enumerate([1., 1., 3600.])]
    updates = []

    result = thumbnails.generate_scene_thumbnails(
        tmp_path / "source.avi", tmp_path, clips,
        cancelled=lambda: False, progress=updates.append)

    assert result == {"requested": 3, "unique_timestamps": 2, "decoded": 1,
                      "written": 1, "reused": 0, "failed_reads": 1}
    assert capture.read_count == 2
    assert capture.released
    assert not (tmp_path / "0.jpg").exists()
    assert not (tmp_path / "1.jpg").exists()
    assert cv2.imread(str(tmp_path / "2.jpg")).shape[:2] == (60, 40)
    assert updates == [1 / 3, 2 / 3, 1.]


@pytest.mark.parametrize("failure", ["seek", "write", "copy", "progress"])
def test_failures_are_observable_and_release_capture(tmp_path, monkeypatch, failure):
    from person_highlight import thumbnails

    capture = _Capture(seek_succeeds=failure != "seek")
    monkeypatch.setattr(thumbnails.cv2, "VideoCapture", lambda _: capture)
    if failure == "write":
        monkeypatch.setattr(thumbnails.cv2, "imwrite", lambda *_: False)
    if failure == "copy":
        (tmp_path / "duplicate.jpg").mkdir()
    clips = [{"source_start_sec": 0., "thumbnail_path": "first.jpg"},
             {"source_start_sec": 0., "thumbnail_path": "duplicate.jpg"}]

    def progress(_value):
        if failure == "progress":
            raise RuntimeError("progress unavailable")

    expected_error = OSError if failure == "copy" else RuntimeError
    with pytest.raises(expected_error):
        thumbnails.generate_scene_thumbnails(
            tmp_path / "source.avi", tmp_path, clips,
            cancelled=lambda: False, progress=progress)

    assert capture.released
    if failure == "seek":
        assert capture.read_count == 0


def test_no_clips_does_not_open_video(tmp_path, monkeypatch):
    from person_highlight import thumbnails

    opened = []
    monkeypatch.setattr(thumbnails.cv2, "VideoCapture", lambda path: opened.append(path))
    updates = []

    result = thumbnails.generate_scene_thumbnails(
        tmp_path / "missing.avi", tmp_path, [],
        cancelled=lambda: False, progress=updates.append)

    assert result == {"requested": 0, "unique_timestamps": 0, "decoded": 0,
                      "written": 0, "reused": 0, "failed_reads": 0}
    assert opened == []
    assert updates == []
