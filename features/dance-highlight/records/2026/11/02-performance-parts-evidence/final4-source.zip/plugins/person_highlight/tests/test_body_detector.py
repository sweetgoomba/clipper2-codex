from types import SimpleNamespace

import numpy as np

from person_highlight.body_detector import YoloBodyDetector


class FakeTensor:
    def __init__(self, values):
        self.values = np.asarray(values)

    def cpu(self):
        return self

    def numpy(self):
        return self.values


def test_yolo_adapter_returns_all_people_and_keeps_low_confidence_candidate():
    calls = []

    def fake_model(frame, **kwargs):
        calls.append(kwargs)
        return [SimpleNamespace(boxes=SimpleNamespace(
            xyxy=FakeTensor([[0, 0, 20, 40], [20, 0, 40, 40], [0, 0, 1, 1]]),
            conf=FakeTensor([.9, .16, .99]),
            cls=FakeTensor([0, 0, 2]),
        ))]

    frame = np.zeros((40, 40, 3), np.uint8)
    frame[:, :20] = (0, 0, 255)
    frame[:, 20:] = (255, 0, 0)
    detector = YoloBodyDetector("fake.pt", model_factory=lambda _: fake_model)
    people = detector.detect(frame)

    assert len(people) == 2
    assert [round(person.score, 2) for person in people] == [.9, .16]
    assert np.dot(people[0].appearance, people[1].appearance) < .5
    assert calls == [{"conf": .1, "classes": [0], "device": "cpu", "verbose": False}]


def test_yolo_adapter_suppresses_duplicate_boxes_for_same_person():
    def fake_model(frame, **kwargs):
        return [SimpleNamespace(boxes=SimpleNamespace(
            xyxy=FakeTensor([[36, 411, 1079, 1897], [172, 402, 1080, 1500]]),
            conf=FakeTensor([.9, .3]), cls=FakeTensor([0, 0]),
        ))]

    frame = np.full((1920, 1080, 3), (30, 30, 200), np.uint8)
    detector = YoloBodyDetector('fake.pt', model_factory=lambda _: fake_model)
    assert len(detector.detect(frame)) == 1
