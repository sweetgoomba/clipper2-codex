import numpy as np
import tracemalloc
from dataclasses import replace

from clipper_face_core import FaceGroup, FaceInterval, FaceObservation, group_observations
from person_highlight.body_tracking import BodyObservation
from person_highlight.occurrences import build_person_results, representative_candidates


def face(obs_id, track, shot, sec, box, vector):
    return FaceObservation(obs_id, track, shot, sec, box,
                           np.asarray(vector, np.float32), .9)


def face_group(group_id, *observations):
    return FaceGroup(group_id, tuple({item.track_id for item in observations}),
                     tuple(item.observation_id for item in observations),
                     tuple(FaceInterval(item.shot_id, item.time_sec, item.time_sec,
                                        (item.observation_id,)) for item in observations),
                     observations[0].observation_id, "grouped")


def body(track, shot, sec, box=(0, 0, 60, 100), appearance=(1, 0)):
    return BodyObservation(track, shot, sec, box, .9, np.asarray(appearance, np.float32))


def test_one_continuous_body_run_rejoins_split_face_groups_and_face_dropout():
    first = face("face_1", "face_track_a", "shot_0", 0.0, (20, 10, 40, 30), (1, 0))
    last = face("face_2", "face_track_b", "shot_0", 2.0, (20, 10, 40, 30), (.98, .2))
    groups, clips = build_person_results(
        [face_group("person_001", first), face_group("person_002", last)],
        [first, last],
        [body("body_1", "shot_0", sec) for sec in (0.0, 1.0, 2.0)],
        duration_sec=4.0, sample_interval_sec=1.0,
    )

    assert len(groups) == 1
    assert groups[0].status == "needs_review"
    assert len(groups[0].intervals) == 1
    assert (groups[0].intervals[0].start_sec, groups[0].intervals[0].end_sec) == (0.0, 3.0)
    assert len(clips) == 1
    assert (clips[0]["appearance_start_sec"], clips[0]["appearance_end_sec"]) == (0.0, 3.0)


def test_continuous_body_track_does_not_merge_different_faces():
    first = face("face_1", "face_track_a", "shot_0", 0.0, (20, 10, 40, 30), (1, 0))
    last = face("face_2", "face_track_b", "shot_0", 2.0, (20, 10, 40, 30), (0, 1))

    groups, _ = build_person_results(
        [face_group("person_001", first), face_group("person_002", last)],
        [first, last],
        [body("body_1", "shot_0", sec) for sec in (0.0, 1.0, 2.0)],
        duration_sec=4.0, sample_interval_sec=1.0,
    )

    assert {group.group_id for group in groups} == {"person_001", "person_002", "unidentified"}
    assert all("body_1" not in group.track_ids for group in groups if group.group_id != "unidentified")


def test_continuous_high_confidence_body_rejoins_pose_changed_face_fragments():
    first = face("first", "fa", "shot_0", 0.0, (10, 10, 30, 40), (1, 0))
    turned = face("turned", "fb", "shot_0", .5, (65, 10, 85, 40), (.45, .893))
    groups, _ = build_person_results(
        [face_group("person_001", first), face_group("person_002", turned)],
        [first, turned],
        [body("body_1", "shot_0", sec, (0, 0, 120, 100)) for sec in (0., .5)],
        duration_sec=2., sample_interval_sec=.5,
    )
    assert len(groups) == 1
    assert set(groups[0].observation_ids) == {"first", "turned"}
    assert groups[0].status == "needs_review"


def test_body_track_switch_with_dissimilar_faces_stays_unresolved():
    first = face("first", "fa", "shot_0", 0.0, (10, 10, 30, 40), (1, 0))
    other = face("other", "fb", "shot_0", .5, (65, 10, 85, 40), (0, 1))
    groups, _ = build_person_results(
        [face_group("person_001", first), face_group("person_002", other)],
        [first, other],
        [body("body_1", "shot_0", sec, (0, 0, 120, 100)) for sec in (0., .5)],
        duration_sec=2., sample_interval_sec=.5,
    )
    assert {group.group_id for group in groups} == {"person_001", "person_002", "unidentified"}


def test_repeated_cross_shot_face_support_rejoins_pose_fragment_without_body():
    main = [face(f"main_{i}", "main_track", f"shot_{i // 7}", float(i),
                 (10, 10, 90, 90), (1, 0) if i < 11 else (0, 1))
            for i in range(28)]
    fragment = [face(f"fragment_{i}", "fragment_track", f"shot_{4 + i // 4}",
                     float(40 + i), (10, 10, 90, 90), (1, 0))
                for i in range(8)]

    groups, _ = build_person_results(
        [face_group("person_001", *main), face_group("person_002", *fragment)],
        main + fragment, [], duration_sec=50., sample_interval_sec=1.)

    assert len(groups) == 1
    assert len(groups[0].observation_ids) == 36
    assert groups[0].status == "needs_review"


def test_recurrent_face_support_does_not_join_people_seen_together():
    first = [face(f"a_{i}", "track_a", f"shot_{i // 4}", float(i),
                  (10, 10, 90, 90), (1, 0)) for i in range(8)]
    second = [face(f"b_{i}", "track_b", f"shot_{i // 4}", float(i),
                   (110, 10, 190, 90), (1, 0)) for i in range(8)]

    groups, _ = build_person_results(
        [face_group("person_001", *first), face_group("person_002", *second)],
        first + second, [], duration_sec=10., sample_interval_sec=1.)

    assert len(groups) == 2


def test_continuous_face_motion_rejoins_a_person_despite_another_face_on_the_body_track():
    first = face("first", "fa", "shot_0", 0.0, (20, 10, 100, 90), (1, 0))
    next_face = face("next", "fb", "shot_0", 1.0, (22, 11, 102, 91), (.57, .82))
    replacement = face("replacement", "fc", "shot_0", 3.0,
                       (21, 10, 101, 90), (0, 1))

    groups, _ = build_person_results(
        [face_group("person_001", replacement), face_group("person_002", first),
         face_group("person_003", next_face)],
        [first, next_face, replacement],
        [body("body_1", "shot_0", float(sec), (0, 0, 130, 130)) for sec in range(4)],
        duration_sec=5.0, sample_interval_sec=.5,
    )

    assert any({"first", "next"} <= set(group.observation_ids) for group in groups)
    assert not any({"first", "replacement"} <= set(group.observation_ids) for group in groups)


def test_body_linked_face_fragment_rejoins_next_nearby_face_group():
    first = face("first", "fa", "shot_0", 1.0, (20, 10, 100, 90), (1, 0))
    weak = face("weak", "fb", "shot_0", 1.5, (21, 10, 101, 90), (.6, .8))
    next_face = face("next", "fc", "shot_0", 2.0, (22, 10, 102, 90), (.7, .714))
    next_later = face("next_later", "fc", "shot_0", 2.5,
                      (23, 10, 103, 90), (.7, .714))

    groups, _ = build_person_results(
        [face_group("person_001", first), face_group("person_002", weak),
         face_group("person_003", next_face, next_later)],
        [first, weak, next_face, next_later],
        [body("body_1", "shot_0", sec, (0, 0, 130, 130)) for sec in (1.0, 1.5)],
        duration_sec=4.0, sample_interval_sec=.5,
    )

    assert len(groups) == 1
    assert set(groups[0].observation_ids) == {"first", "weak", "next", "next_later"}
    assert groups[0].status == "needs_review"


def test_adjacent_face_reconciliation_respects_prior_co_visibility():
    a_first = face("a_first", "fa", "shot_0", 0.0, (20, 10, 100, 90), (1, 0))
    b_first = face("b_first", "fb", "shot_0", 0.0, (120, 10, 200, 90), (.8, .6))
    a_later = face("a_later", "fa", "shot_0", 1.0,
                   (20, 10, 100, 90), (1, 0))
    b_later = face("b_later", "fb", "shot_0", 1.5,
                   (21, 10, 101, 90), (.8, .6))

    groups, _ = build_person_results(
        [face_group("person_001", a_first, a_later),
         face_group("person_002", b_first, b_later)],
        [a_first, b_first, a_later, b_later], [],
        duration_sec=3.0, sample_interval_sec=.5,
    )

    assert len(groups) == 2


def test_merged_person_selects_clear_face_from_final_observations():
    obscured = replace(face("obscured", "face_a", "shot_0", 0.0,
                            (10, 10, 150, 150), (1, 0)),
                       sharpness=1.0, detection_score=.69)
    clear = replace(face("clear", "face_b", "shot_0", 1.0,
                         (10, 10, 150, 150), (.99, .1)),
                    sharpness=.8, detection_score=.94)

    groups, _ = build_person_results(
        [face_group("person_001", obscured), face_group("person_002", clear)],
        [obscured, clear], [body("body_1", "shot_0", sec, (0, 0, 180, 180))
                            for sec in (0.0, 1.0)],
        duration_sec=2.0, sample_interval_sec=1.0,
    )

    assert len(groups) == 1
    assert groups[0].representative_observation_id == "clear"


def test_person_with_only_unreliable_face_has_no_representative_image():
    obscured = replace(face("obscured", "face_a", "shot_0", 0.0,
                            (10, 10, 150, 150), (1, 0)),
                       sharpness=1.0, detection_score=.69)

    groups, _ = build_person_results(
        [face_group("person_001", obscured)], [obscured], [],
        duration_sec=2.0, sample_interval_sec=1.0,
    )

    assert groups[0].representative_observation_id is None
    assert groups[0].status == "needs_review"


def test_repeated_clear_small_face_can_be_a_representative_despite_pose_change():
    first = replace(face("first", "same_track", "shot_0", 0.0,
                         (20, 10, 75, 80), (1, 0)), detection_score=.92, sharpness=.5)
    turned = replace(face("turned", "same_track", "shot_0", .5,
                          (22, 12, 77, 82), (.35, .94)), detection_score=.92, sharpness=.7)
    assert representative_candidates([first, turned])


def test_single_small_face_or_low_score_face_is_not_promoted_to_a_representative():
    clear = replace(face("single", "one", "shot_0", 0.0,
                         (20, 10, 75, 80), (1, 0)), detection_score=.92, sharpness=.5)
    low_score = replace(face("low", "one", "shot_0", .5,
                             (20, 10, 75, 80), (1, 0)), detection_score=.7, sharpness=.5)
    assert representative_candidates([clear]) == []
    assert representative_candidates([clear, low_score]) == []


def test_camera_cut_does_not_split_same_confirmed_person_appearance():
    first = face("face_1", "face_track_a", "shot_0", 0.0, (20, 10, 40, 30), (1, 0))
    last = face("face_2", "face_track_b", "shot_1", 1.2, (20, 10, 40, 30), (1, 0))
    groups, clips = build_person_results(
        [face_group("person_001", first, last)], [first, last],
        [body("body_1", "shot_0", 0.0), body("body_1", "shot_0", 1.0),
         body("body_2", "shot_1", 1.2), body("body_2", "shot_1", 2.0)],
        duration_sec=4.0, sample_interval_sec=.4,
    )

    assert len(groups) == 1
    assert len(groups[0].intervals) == 1
    assert (groups[0].intervals[0].start_sec, groups[0].intervals[0].end_sec) == (0.0, 2.4)
    assert len(clips) == 1


def test_camera_cut_does_not_join_different_people_from_overlapping_sample_windows():
    first = face("first", "fa", "shot_0", 1.0, (20, 10, 100, 90), (1, 0))
    next_person = face("next", "fb", "shot_1", 1.2, (20, 10, 100, 90), (0, 1))

    _, clips = build_person_results(
        [face_group("person_001", first), face_group("person_002", next_person)],
        [first, next_person], [], duration_sec=3.0, sample_interval_sec=.4,
    )

    assert len(clips) == 2
    assert [clip["person_ids"] for clip in clips] == [["person_001"], ["person_002"]]


def test_second_shot_person_joins_clip_with_person_continuing_across_cut():
    a_first = face("a_first", "fa", "shot_0", 1.0, (20, 10, 100, 90), (1, 0))
    a_second = face("a_second", "fb", "shot_1", 1.2, (20, 10, 100, 90), (1, 0))
    b_second = face("b_second", "fc", "shot_1", 1.4, (120, 10, 200, 90), (0, 1))

    _, clips = build_person_results(
        [face_group("person_001", a_first, a_second),
         face_group("person_002", b_second)],
        [a_first, a_second, b_second], [],
        duration_sec=3.0, sample_interval_sec=.4,
    )

    assert len(clips) == 1
    assert clips[0]["person_ids"] == ["person_001", "person_002"]


def test_representative_selection_has_bounded_pair_work_for_long_appearances(monkeypatch):
    vectors = np.eye(400, dtype=np.float32)
    vectors[1] = vectors[0]
    observations = [replace(face(f"f{i}", "fa", "shot_0", i * .2,
                                 (10, 10, 150, 150), vectors[i]),
                            detection_score=.95, sharpness=.8)
                    for i in range(400)]
    calls = 0
    original_dot = np.dot

    def count_dot(*args, **kwargs):
        nonlocal calls
        calls += 1
        return original_dot(*args, **kwargs)

    monkeypatch.setattr(np, "dot", count_dot)
    candidates = representative_candidates(observations)

    assert candidates
    assert calls < 25000


def test_representative_candidates_spread_across_time_instead_of_adjacent_frames():
    observations = [replace(face(f"f{i}", "track", "shot_0", float(i),
                                 (10, 10, 150, 150), (1, 0)),
                            detection_score=.95, sharpness=1.0 - i * .01)
                    for i in range(20)]
    selected = representative_candidates(observations)[:5]
    times = {item.observation_id: item.time_sec for item in observations}
    assert len(selected) == 4
    assert selected[0] == 'f0'
    assert all(abs(times[a] - times[b]) >= 5 for index, a in enumerate(selected)
               for b in selected[index + 1:])


def test_representative_candidates_prefer_another_shot_before_more_of_the_same_shot():
    observations = [replace(face(f"first_{i}", "t1", "shot_0", float(i * 6),
                                 (10, 10, 150, 150), (1, 0)),
                            detection_score=.95, sharpness=1.0 - i * .01)
                    for i in range(5)]
    observations.append(replace(face("other", "t2", "shot_1", 35.,
                                     (10, 10, 150, 150), (1, 0)),
                                detection_score=.95, sharpness=.6))
    selected = representative_candidates(observations)
    assert selected[0] == 'first_0'
    assert selected[1] == 'other'


def test_two_people_seen_together_remain_distinct():
    left = face("left", "face_track_a", "shot_0", 0.0, (20, 10, 40, 30), (1, 0))
    right = face("right", "face_track_b", "shot_0", 0.0, (120, 10, 140, 30), (0, 1))
    groups, clips = build_person_results(
        [face_group("person_001", left), face_group("person_002", right)],
        [left, right],
        [body("body_1", "shot_0", 0.0),
         body("body_2", "shot_0", 0.0, (100, 0, 160, 100), (0, 1))],
        duration_sec=3.0, sample_interval_sec=.2,
    )

    assert len(groups) == 2
    assert set(clips[0]["person_ids"]) == {"person_001", "person_002"}


def test_body_only_person_is_reviewable_without_claiming_face_identity():
    groups, clips = build_person_results([], [],
        [body("body_1", "shot_0", 1.0), body("body_1", "shot_0", 1.2)],
        duration_sec=3.0, sample_interval_sec=.2)

    assert len(groups) == 1
    assert groups[0].status == "needs_review"
    assert groups[0].representative_observation_id is None
    assert len(clips) == 1
    assert clips[0]["person_ids"] == [groups[0].group_id]


def test_padding_does_not_merge_separate_appearances():
    groups, clips = build_person_results([], [],
        [body("body_1", "shot_0", 1.0),
         body("body_2", "shot_0", 1.6, (100, 0, 160, 100), (0, 1))],
        duration_sec=3.0, sample_interval_sec=.2, padding_sec=.5)

    assert len(groups) == 1
    assert groups[0].group_id == "unidentified"
    assert groups[0].status == "needs_review"
    assert len(groups[0].intervals) == 2
    assert len(clips) == 2
    assert clips[0]["source_end_sec"] > clips[1]["source_start_sec"]
    assert clips[0]["person_ids"] == clips[1]["person_ids"] == ["unidentified"]


def test_touching_appearances_in_one_shot_make_one_clip():
    groups, clips = build_person_results([], [],
        [body("body_1", "shot_0", 1.0),
         body("body_2", "shot_0", 1.5, (100, 0, 160, 100), (0, 1))],
        duration_sec=3.0, sample_interval_sec=.5, padding_sec=.5)

    assert len(groups) == 1
    assert len(groups[0].intervals) == 2
    assert len(clips) == 1
    assert (clips[0]["appearance_start_sec"], clips[0]["appearance_end_sec"]) == (1.0, 2.0)


def test_unidentified_appearances_across_cut_remain_separate():
    _, clips = build_person_results([], [],
        [body("body_1", "shot_0", 1.0),
         body("body_2", "shot_1", 1.2, (100, 0, 160, 100), (0, 1))],
        duration_sec=3.0, sample_interval_sec=.5, padding_sec=.5)

    assert len(clips) == 2
    assert [clip["scene_id"] for clip in clips] == ["shot_0", "shot_1"]


def test_lower_false_face_inside_body_does_not_orphan_real_face_body():
    real = face("real", "face_real", "shot_0", 0.0, (20, 5, 40, 25), (1, 0))
    lower = face("lower", "face_false", "shot_0", 0.0, (20, 55, 40, 75), (0, 1))
    groups, _ = build_person_results(
        [face_group("person_001", real), face_group("person_002", lower)],
        [real, lower], [body("body_1", "shot_0", 0.0)],
        duration_sec=2.0, sample_interval_sec=.5)

    by_id = {group.group_id: group for group in groups}
    assert "body_1" in by_id["person_001"].track_ids
    assert "body_1" not in by_id["person_002"].track_ids
    assert len(groups) == 2


def test_confident_repeated_face_match_across_cuts_reconciles_groups():
    a = [face(f"a{i}", "fa", "shot_0", float(i), (20, 10, 40, 30), vector)
         for i, vector in enumerate(((1, 0), (.98, .2)))]
    b = [face(f"b{i}", "fb", "shot_1", float(i + 4), (20, 10, 40, 30), vector)
         for i, vector in enumerate(((1, 0), (.98, .2)))]
    groups, _ = build_person_results(
        [face_group("person_001", *a), face_group("person_002", *b)], a + b,
        [body("body_1", "shot_0", float(i)) for i in range(2)]
        + [body("body_2", "shot_1", float(i + 4)) for i in range(2)],
        duration_sec=7.0, sample_interval_sec=1.0)
    assert len(groups) == 1
    assert len(groups[0].intervals) == 2


def test_middle_face_group_does_not_bridge_two_incompatible_identities():
    a = [face(f"a{i}", "fa", "shot_0", float(i), (20, 10, 100, 90), (1, 0))
         for i in range(2)]
    b = [face(f"b{i}", "fb", "shot_1", float(i + 4), (20, 10, 100, 90),
              (.819, .574)) for i in range(2)]
    c = [face(f"c{i}", "fc", "shot_2", float(i + 8), (20, 10, 100, 90),
              (.342, .94)) for i in range(2)]

    groups, _ = build_person_results(
        [face_group("person_001", *a), face_group("person_002", *b),
         face_group("person_003", *c)], a + b + c, [],
        duration_sec=12.0, sample_interval_sec=1.0,
    )

    assert not any({"a0", "c0"} <= set(group.observation_ids) for group in groups)


def test_recurrent_face_fragments_do_not_bridge_incompatible_end_groups():
    a = [face(f'a{i}', 'fa', f'shot_a{i // 4}', float(i), (20, 10, 100, 90),
              (1, 0)) for i in range(8)]
    b = [face(f'b{i}', 'fb', f'shot_b{i // 4}', float(20 + i), (20, 10, 100, 90),
              (.8, .6)) for i in range(8)]
    c = [face(f'c{i}', 'fc', f'shot_c{i // 4}', float(40 + i), (20, 10, 100, 90),
              (.28, .96)) for i in range(8)]
    groups, _ = build_person_results(
        [face_group('person_001', *a), face_group('person_002', *b),
         face_group('person_003', *c)], a + b + c, [],
        duration_sec=50., sample_interval_sec=1.)

    assert not any({'a0', 'c0'} <= set(group.observation_ids) for group in groups)


def test_recurrent_face_match_ignores_one_pose_outlier_when_repeated_faces_agree():
    clear = [face(f'a{i}', 'clear', f'shot_a{i // 4}', float(i),
                  (20, 10, 100, 90), (1, 0)) for i in range(12)]
    profile = [face(f'profile{i}', 'profile', f'shot_profile{i}', float(20 + i),
                    (20, 10, 100, 90), (.38, .925)) for i in range(2)]
    return_faces = [face(f'b{i}', 'return', f'shot_b{i // 4}', float(40 + i),
                         (20, 10, 100, 90), (.995, .1)) for i in range(12)]

    groups, _ = build_person_results(
        [face_group('person_001', *(clear + profile)),
         face_group('person_002', *return_faces)],
        clear + profile + return_faces, [],
        duration_sec=55., sample_interval_sec=1.)

    assert len(groups) == 1
    assert {'a0', 'profile0', 'b0'} <= set(groups[0].observation_ids)


def test_recurrent_face_match_uses_stable_anchor_across_two_head_angles():
    anchor = [face(f'a{i}', 'anchor', f'shot_a{i // 4}', float(i),
                   (20, 10, 100, 90), (1, 0)) for i in range(12)]
    profile = [face(f'profile{i}', 'profile', f'shot_profile{i}', float(20 + i),
                    (20, 10, 100, 90), (.38, .925)) for i in range(2)]
    first_return = [face(f'b{i}', 'return_b', f'shot_b{i // 4}', float(40 + i),
                         (20, 10, 100, 90), (.995, .1)) for i in range(12)]
    second_return = [face(f'c{i}', 'return_c', f'shot_c{i // 4}', float(60 + i),
                          (20, 10, 100, 90), (.995, -.1)) for i in range(12)]

    groups, _ = build_person_results(
        [face_group('person_001', *(anchor + profile)),
         face_group('person_002', *first_return),
         face_group('person_003', *second_return)],
        anchor + profile + first_return + second_return, [],
        duration_sec=75., sample_interval_sec=1.)

    assert len(groups) == 1
    assert {'a0', 'profile0', 'b0', 'c0'} <= set(groups[0].observation_ids)


def test_recurrent_auraface_match_accepts_repeated_moderate_pair_scores():
    first = [face(f'a{i}', 'first', f'shot_a{i // 4}', float(i),
                  (20, 10, 100, 90), (.883, .469 if i % 2 else -.469, 0))
             for i in range(12)]
    profile = [face('profile', 'profile', 'shot_profile', 20.,
                    (20, 10, 100, 90), (.4, 0, .916))]
    second = [face(f'b{i}', 'second', f'shot_b{i // 4}', float(40 + i),
                   (20, 10, 100, 90), (.883, 0, .469 if i % 2 else -.469))
              for i in range(12)]

    groups, _ = build_person_results(
        [face_group('person_001', *(first + profile)),
         face_group('person_002', *second)],
        first + profile + second, [], duration_sec=55., sample_interval_sec=1.)

    assert len(groups) == 1
    assert {'a0', 'profile', 'b0'} <= set(groups[0].observation_ids)


def _noisy_shot_faces(label, direction, offset, *, shots=3, noise_axis=2):
    observations = []
    for index in range(12):
        vector = np.zeros(5, np.float32)
        vector[:2] = .7 * np.asarray(direction, np.float32)
        vector[noise_axis] = np.sqrt(.51) * (1 if index % 2 else -1)
        observations.append(face(f'{label}{index}', f'{label}_track',
                                 f'{label}_shot_{index // (12 // shots)}',
                                 offset + index * .5, (20, 10, 100, 90), vector))
    return observations


def test_independent_shot_averages_rejoin_noisy_views_of_one_person():
    first = _noisy_shot_faces('a', (1., 0.), 0.)
    second = _noisy_shot_faces('b', (.75, np.sqrt(1 - .75 ** 2)), 20., noise_axis=3)
    groups, _ = build_person_results(
        [face_group('person_001', *first), face_group('person_002', *second)],
        first + second, [], duration_sec=30., sample_interval_sec=.5)

    assert len(groups) == 1
    assert len(groups[0].observation_ids) == 24
    assert groups[0].status == 'needs_review'


def test_shot_consensus_requires_independent_scenes_and_respects_co_visibility():
    first = _noisy_shot_faces('a', (1., 0.), 0.)
    for scenario in ('one_shot', 'co_visible', 'single_frame_shots'):
        second = _noisy_shot_faces('b', (.75, np.sqrt(1 - .75 ** 2)), 20.,
                                   shots=1 if scenario == 'one_shot' else 3, noise_axis=3)
        if scenario == 'co_visible':
            second[0] = replace(second[0], shot_id=first[0].shot_id,
                                time_sec=first[0].time_sec + .0005,
                                bbox_px=(120, 10, 200, 90))
        elif scenario == 'single_frame_shots':
            second = [replace(item, time_sec=20. + index // 4)
                      for index, item in enumerate(second)]
        groups, _ = build_person_results(
            [face_group('person_001', *first), face_group('person_002', *second)],
            first + second, [], duration_sec=30., sample_interval_sec=.5)
        assert len(groups) == 2, scenario


def test_shot_consensus_does_not_merge_incompatible_people_through_middle_group():
    first = _noisy_shot_faces('a', (1., 0.), 0.)
    middle = _noisy_shot_faces('b', (.8, .6), 20., noise_axis=3)
    last = _noisy_shot_faces('c', (.28, .96), 40., noise_axis=4)
    groups, _ = build_person_results(
        [face_group('person_001', *first), face_group('person_002', *middle),
         face_group('person_003', *last)], first + middle + last, [],
        duration_sec=50., sample_interval_sec=.5)
    assert not any({'a0', 'c0'} <= set(group.observation_ids) for group in groups)


def test_shot_consensus_keeps_original_identity_anchors_after_earlier_merges():
    first = [face(f'a{i}', 'a', f'a_shot_{i // 4}', i * .5,
                  (20, 10, 100, 90), (1., 0., 0., 0., 0.)) for i in range(8)]
    angle = np.deg2rad(35)
    middle = [face(f'b{i}', 'b', f'b_shot_{i // 4}', 20. + i * .5,
                   (20, 10, 100, 90), (np.cos(angle), np.sin(angle), 0., 0., 0.))
              for i in range(24)]
    last = _noisy_shot_faces('c', (np.cos(2 * angle), np.sin(2 * angle)), 40.)
    groups, _ = build_person_results(
        [face_group('person_001', *first), face_group('person_002', *middle),
         face_group('person_003', *last)], first + middle + last, [],
        duration_sec=50., sample_interval_sec=.5)
    assert not any({'a0', 'c0'} <= set(group.observation_ids) for group in groups)


def test_full_grouping_does_not_hide_incompatible_constituent_tracks():
    observations = []
    for label, vector, offset in [('a', (1, 0), 0),
                                  ('b', (.819, .574), 20),
                                  ('c', (.342, .94), 40)]:
        for index in range(12):
            item = face(f'{label}{index}', f'{label}{index // 6}',
                        f'{label}{index // 6}', offset + index * .5,
                        (0, 0, 80, 80), vector)
            observations.append(replace(item, detection_score=.99, sharpness=.9))

    initial = group_observations(observations)
    people, _ = build_person_results(initial, observations, [],
                                     duration_sec=50., sample_interval_sec=.5)

    assert not any({'a0', 'c0'} <= set(group.observation_ids) for group in people)


def test_early_face_reconciliation_checks_every_constituent_track():
    observations = []
    for label, vector, offset in [('a', (1, 0), 0),
                                  ('b', (.85, .527), 20),
                                  ('c', (.45, .893), 40)]:
        for index in range(12):
            item = face(f'{label}{index}', f'{label}{index // 6}',
                        f'{label}{index // 6}', offset + index * .5,
                        (0, 0, 80, 80), vector)
            observations.append(replace(item, detection_score=.99, sharpness=.9))

    initial = group_observations(observations)
    people, _ = build_person_results(initial, observations, [],
                                     duration_sec=50., sample_interval_sec=.5)

    assert not any({'a0', 'c0'} <= set(group.observation_ids) for group in people)


def test_recurrent_face_support_uses_bounded_similarity_blocks(monkeypatch):
    from person_highlight import occurrences

    original = np.matmul
    largest = 0

    def bounded(left, right):
        nonlocal largest
        largest = max(largest, left.shape[0] * right.shape[1])
        return original(left, right)

    monkeypatch.setattr(occurrences.np, 'matmul', bounded)
    first = np.tile(np.array([[1., 0.]], np.float32), (600, 1))
    second = first.copy()
    left, right, best = occurrences._pairwise_maxima(first, second)

    assert np.allclose(left, 1.)
    assert np.allclose(right, 1.)
    assert best == 1.
    assert largest <= 512 * 512


def test_large_cross_group_face_match_can_be_cancelled_between_blocks():
    from person_highlight.occurrences import _strong_face_match

    first = [face(f'a{i}', 'fa', 'shot_a', float(i), (20, 10, 100, 90), (1, 0))
             for i in range(600)]
    second = [face(f'b{i}', 'fb', 'shot_b', float(i), (20, 10, 100, 90), (1, 0))
              for i in range(600)]
    checks = 0

    def cancelled():
        nonlocal checks
        checks += 1
        return checks >= 2

    with np.testing.assert_raises(InterruptedError):
        _strong_face_match(first, second, cancelled=cancelled)
    assert checks == 2


def test_empty_person_result_build_still_honors_cancellation():
    with np.testing.assert_raises(InterruptedError):
        build_person_results([], [], [], duration_sec=1., sample_interval_sec=.5,
                             cancelled=lambda: True)


def test_strong_repeated_face_match_precedes_weak_body_continuity():
    first = [face(f"a{i}", "fa", "shot_0", i * .5,
                  (20, 10, 100, 90), (1, 0)) for i in range(2)]
    weak = face("weak", "fb", "shot_0", 1.0,
                (20, 10, 100, 90), (.72, .694))
    later = [face(f"c{i}", "fc", "shot_1", 4 + i * .5,
                  (20, 10, 100, 90), (.98, -.2)) for i in range(2)]

    groups, _ = build_person_results(
        [face_group("person_001", *first), face_group("person_002", weak),
         face_group("person_003", *later)], first + [weak] + later,
        [body("body_1", "shot_0", sec, (0, 0, 130, 130))
         for sec in (0.0, .5, 1.0)],
        duration_sec=6.0, sample_interval_sec=.5,
    )

    assert any({"a0", "c0"} <= set(group.observation_ids) for group in groups)
    assert not any({"weak", "c0"} <= set(group.observation_ids) for group in groups)


def test_face_groups_visible_together_never_reconcile_even_if_embeddings_match():
    a = [face(f"a{i}", "fa", "shot_0", float(i), (20, 10, 40, 30), (1, 0))
         for i in range(2)]
    b = [face(f"b{i}", "fb", "shot_0", float(i), (120, 10, 140, 30), (1, 0))
         for i in range(2)]
    groups, _ = build_person_results(
        [face_group("person_001", *a), face_group("person_002", *b)], a + b,
        [body("body_1", "shot_0", float(i)) for i in range(2)]
        + [body("body_2", "shot_0", float(i), (100, 0, 160, 100)) for i in range(2)],
        duration_sec=3.0, sample_interval_sec=1.0)
    assert len(groups) == 2


def test_sparse_picture_in_picture_visibility_does_not_split_repeated_identity():
    # A recap can show the same person in the main frame and a small inset.
    # One such frame should not override repeated independent appearances.
    first = [face(f"a{i}", "fa", f"shot_{i // 4}", float(i),
                  (20, 10, 60, 50), (1, .04)) for i in range(12)]
    second = [face(f"b{i}", "fb", f"shot_{10 + i // 4}", float(30 + i),
                   (120, 10, 160, 50), (.99, .05)) for i in range(12)]
    first[0] = face("a0", "fa", "shot_montage", 50.0,
                    (20, 10, 60, 50), (1, .04))
    second[0] = face("b0", "fb", "shot_montage", 50.0,
                     (120, 10, 160, 50), (.99, .05))

    groups, _ = build_person_results(
        [face_group("person_001", *first), face_group("person_002", *second)],
        first + second, [], duration_sec=55.0, sample_interval_sec=1.0)

    assert len(groups) == 1
    assert groups[0].status == "needs_review"


def test_sparse_montage_evidence_is_rechecked_after_face_fragments_join():
    def fragment(prefix, x, offset):
        separate = [face(f"{prefix}{i}", prefix, f"shot_{prefix}_{i}",
                         float(offset + i), (x, 10, x + 40, 50), (1, .04))
                    for i in range(10)]
        montage = [face(f"{prefix}m{i}", prefix, "shot_montage", float(100 + i),
                        (x, 10, x + 40, 50), (1, .04)) for i in range(2)]
        return separate + montage

    a1, b1 = fragment("a1", 20, 0), fragment("b1", 120, 25)
    a2, b2 = fragment("a2", 20, 50), fragment("b2", 120, 75)
    groups, _ = build_person_results(
        [face_group("person_001", *a1), face_group("person_002", *b1),
         face_group("person_003", *a2), face_group("person_004", *b2)],
        a1 + b1 + a2 + b2, [], duration_sec=103.0, sample_interval_sec=1.0)

    assert len(groups) == 1
    assert len(groups[0].observation_ids) == 48


def test_repeated_co_visible_lookalikes_stay_separate():
    first = [face(f"a{i}", "fa", "shot_shared", float(i),
                  (20, 10, 60, 50), (1, .04)) for i in range(12)]
    second = [face(f"b{i}", "fb", "shot_shared", float(i),
                   (120, 10, 160, 50), (.99, .05)) for i in range(12)]

    groups, _ = build_person_results(
        [face_group("person_001", *first), face_group("person_002", *second)],
        first + second, [], duration_sec=13.0, sample_interval_sec=1.0)

    assert len(groups) == 2


def test_repeated_overlapping_face_detections_inside_one_body_are_one_person():
    a = [face(f"a{i}", "fa", "shot_0", float(i), (20, 15, 65, 65),
              (1, .05 * i)) for i in range(3)]
    b = [face(f"b{i}", "fb", "shot_0", float(i), (25, 35, 70, 85),
              (1, .08 * i)) for i in range(3)]
    groups, _ = build_person_results(
        [face_group("person_001", *a), face_group("person_002", *b)], a + b,
        [body("body_1", "shot_0", float(i), (0, 0, 100, 120)) for i in range(3)],
        duration_sec=4.0, sample_interval_sec=1.0)
    assert len(groups) == 1
    assert "body_1" in groups[0].track_ids
    assert groups[0].status == "needs_review"


def test_overlap_duplicate_check_does_not_materialize_all_simultaneous_pairs():
    from person_highlight.occurrences import _overlapping_duplicate_faces

    first = [face(f'a{i}', 'fa', 'shot', 1., (20, 15, 65, 65), (1, 0))
             for i in range(400)]
    second = [face(f'b{i}', 'fb', 'shot', 1., (25, 20, 70, 70), (1, 0))
              for i in range(400)]

    tracemalloc.start()
    try:
        assert _overlapping_duplicate_faces(first, second)
        _, peak = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
    assert peak < 4 * 1024 * 1024


def test_overlap_duplicate_check_indexes_right_faces_once():
    from person_highlight.occurrences import _overlapping_duplicate_faces

    class CountedFaces(list):
        iterations = 0

        def __iter__(self):
            self.iterations += 1
            return super().__iter__()

    first = [face(f'a{i}', 'fa', 'shot', float(i), (20, 15, 65, 65), (1, 0))
             for i in range(300)]
    second = CountedFaces(face(f'b{i}', 'fb', 'shot', float(i),
                               (25, 20, 70, 70), (1, 0)) for i in range(300))

    assert _overlapping_duplicate_faces(first, second)
    assert second.iterations <= 3


def test_overlap_duplicate_check_keeps_submillisecond_timestamp_tolerance():
    from person_highlight.occurrences import _overlapping_duplicate_faces

    first = [face(f'a{i}', 'fa', 'shot', float(i) + .0004,
                  (20, 15, 65, 65), (1, 0)) for i in (1, 2)]
    near = [face(f'b{i}', 'fb', 'shot', float(i) + .0011,
                 (25, 20, 70, 70), (1, 0)) for i in (1, 2)]
    distant = [face(f'c{i}', 'fc', 'shot', float(i) + .002,
                    (25, 20, 70, 70), (1, 0)) for i in (1, 2)]

    assert _overlapping_duplicate_faces(first, near)
    assert not _overlapping_duplicate_faces(first, distant)


def test_body_observations_are_indexed_once_for_many_face_frames():
    class CountedBodies(list):
        iterations = 0

        def __iter__(self):
            self.iterations += 1
            return super().__iter__()

    faces = [face(f"face_{index}", "face_track", "shot_0", float(index),
                  (20, 10, 40, 30), (1, 0)) for index in range(20)]
    bodies = CountedBodies(body("body_1", "shot_0", float(index))
                           for index in range(20))

    groups, _ = build_person_results([face_group("person_001", *faces)], faces, bodies,
                                     duration_sec=21.0, sample_interval_sec=1.0)

    assert len(groups) == 1
    assert bodies.iterations <= 2


def test_body_adjacency_does_not_materialize_every_cross_group_pair():
    import tracemalloc

    first = [replace(face(f'a{i}', 'fa', 'shot', i * .5,
                          (20, 10, 100, 90), (1, 0)), detection_score=.99)
             for i in range(350)]
    second = [replace(face(f'b{i}', 'fb', 'shot', (350 + i) * .5,
                           (20, 10, 100, 90), (0, 1)), detection_score=.99)
              for i in range(350)]
    bodies = [body('body', 'shot', item.time_sec, (0, 0, 150, 200))
              for item in first + second]

    tracemalloc.start()
    try:
        groups, _ = build_person_results(
            [face_group('person_001', *first), face_group('person_002', *second)],
            first + second, bodies, duration_sec=400., sample_interval_sec=.5)
        _, peak = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()

    assert len(groups) >= 2
    assert peak < 6 * 1024 * 1024


def test_body_adjacency_polls_cancellation_during_dense_candidate_scan():
    from person_highlight.occurrences import _adjacent_face_support

    first = [face(f'a{i}', 'fa', 'shot', 1., (0, 0, 20, 20), (1, 0))
             for i in range(300)]
    second = [face(f'b{i}', 'fb', 'shot', 1., (100, 0, 120, 20), (0, 1))
              for i in range(300)]
    checks = 0

    def cancelled():
        nonlocal checks
        checks += 1
        return checks >= 5

    with np.testing.assert_raises(InterruptedError):
        _adjacent_face_support(first, second, 1.05, cancelled)
    assert checks == 5


def test_body_adjacency_keeps_nearest_gap_and_local_overlap_semantics():
    from person_highlight.occurrences import _adjacent_face_support

    first = [face('a1', 'fa', 'shot_1', 1., (0, 0, 50, 50), (1, 0)),
             face('a2', 'fa', 'shot_2', 10., (0, 0, 50, 50), (1, 0))]
    second = [face('b1', 'fb', 'shot_1', 1.5, (10, 0, 60, 50), (1, 0)),
              face('b2', 'fb', 'shot_2', 9.8, (100, 0, 150, 50), (1, 0))]

    gap, local = _adjacent_face_support(first, second, 1.05)

    assert np.isclose(gap, .2)
    assert local


def test_face_and_body_with_submillisecond_timestamp_difference_still_link():
    observed_face = face("face_1", "face_track", "shot_0", 1.0004,
                         (20, 10, 40, 30), (1, 0))
    groups, _ = build_person_results(
        [face_group("person_001", observed_face)], [observed_face],
        [body("body_1", "shot_0", 1.0011)],
        duration_sec=2.0, sample_interval_sec=.5,
    )

    assert len(groups) == 1
    assert "body_1" in groups[0].track_ids
