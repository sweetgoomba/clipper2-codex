"""Recover supported pose fragments without making attachment evidence recursive.

The conservative face groups remain the seeds. Reliable seeds can form only a
mutual, unambiguous pair during this pass. Short fragments then use frozen banks
of those seeds; an attached fragment never recruits another fragment. This can
leave a real identity split into several groups, by design, when evidence ties.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import TYPE_CHECKING, Callable, Sequence

import numpy as np

from clipper_face_core import FaceGroup, FaceObservation, rank_representatives
from clipper_face_core.grouping import _intervals, _normalized
from clipper_face_core.view_templates import (
    ViewMatch, ViewTemplates, build_view_templates, compare_observation_evidence,
    compare_view_templates, eligible_observations,
)


if TYPE_CHECKING:
    from .occurrences import PersonGroup


def _check_cancelled(cancelled: Callable[[], bool] | None) -> None:
    if cancelled is not None and cancelled():
        raise InterruptedError("Face identity refinement cancelled")


def _clear_best(candidates: list[tuple[float, str, bool]], margin: float) -> str | None:
    candidates.sort(key=lambda item: (-item[0], item[1]))
    if not candidates or not candidates[0][2]:
        return None
    if len(candidates) > 1 and candidates[0][0] - candidates[1][0] < margin:
        return None
    return candidates[0][1]


def _remember_candidate(candidates: list[tuple[float, str, bool]],
                        candidate: tuple[float, str, bool]) -> None:
    # Only the best and runner-up can affect a decision. Retaining all pair
    # scores would make memory quadratic in the number of seed identities.
    candidates[:] = [item for item in candidates if item[1] != candidate[1]]
    candidates.append(candidate)
    candidates.sort(key=lambda item: (-item[0], item[1]))
    del candidates[2:]


def _repeated_match(match: ViewMatch, left: ViewTemplates, right: ViewTemplates) -> bool:
    smaller_fraction = (match.left_fraction if left.sample_count <= right.sample_count
                        else match.right_fraction)
    repeated = min(match.left_hits, match.right_hits)
    return ((repeated >= 2 and smaller_fraction >= .6)
            # Different view banks can share one well-observed pose without
            # most of either bank matching. One or two outliers cannot qualify.
            or (repeated >= 3 and match.score >= .75))


def _observed_structure(observations: Sequence[FaceObservation]) -> tuple[float, int]:
    """Count usable runs and their duration, excluding time between appearances."""
    intervals = _intervals(observations, 1.5)
    return sum(item.end_sec - item.start_sec + .5 for item in intervals), len(intervals)


def refine_face_groups(
    groups: Sequence[FaceGroup], observations: Sequence[FaceObservation], *,
    cancelled: Callable[[], bool] | None = None,
    _can_merge: Callable[[str, str], bool] | None = None,
) -> list[FaceGroup]:
    """Refine only supported identities, retaining every original observation.

    Reliable anchors need six clear observed instants. A seed may still need
    review: uncertain/failed observations are excluded individually from its
    evidence bank. Existing grouping does not identify tracks responsible for
    its ambiguity status, so repeated unflagged tracking errors remain a risk.
    Anchor pairs require repeated .70 cosine support and a .06 candidate margin.
    When recurring anchors exist, fragments have at most 30 seconds of usable
    observations in eight runs. Their evidence is never promoted into anchors.
    Multi-observation fragments need repeated .70/.72 support; a single clear
    observation needs .86 support from three anchor samples and a .08 margin.
    Lookup uses bounded banks; every plausible competitor is verified against
    all eligible observations before applying the same candidate margin.
    These deliberately conservative constants need validation on real footage;
    changed groups keep ``needs_review`` rather than implying certainty.
    """
    _check_cancelled(cancelled)
    spaces = {(item.model_sha256, item.config_sha256) for item in observations
              if item.embedding is not None}
    if len(spaces) > 1:
        raise ValueError("Cannot mix face embedding model/config spaces")
    by_id = {item.observation_id: item for item in observations}
    counts = Counter(identifier for group in groups for identifier in group.observation_ids)
    if (len(by_id) != len(observations) or set(counts) != set(by_id)
            or any(count != 1 for count in counts.values())
            or len({group.group_id for group in groups}) != len(groups)
            or any(not group.observation_ids for group in groups)):
        raise ValueError("Face groups must partition observations exactly once")
    original = {group.group_id: group for group in groups}
    items = {group.group_id: sorted((by_id[key] for key in group.observation_ids),
                                    key=lambda item: (item.time_sec, item.observation_id))
             for group in groups}
    banks: dict[str, ViewTemplates] = {}
    frames: dict[str, dict[tuple[str, int], list[float]]] = {}
    for group_id in sorted(original):
        _check_cancelled(cancelled)
        banks[group_id] = build_view_templates(items[group_id], cancelled=cancelled)
        frame_index: dict[tuple[str, int], list[float]] = defaultdict(list)
        for item in items[group_id]:
            _check_cancelled(cancelled)
            frame_index[(item.shot_id, int(item.time_sec * 1000))].append(item.time_sec)
        frames[group_id] = frame_index

    def co_visible(first: str, second: str) -> bool:
        if len(items[first]) > len(items[second]):
            first, second = second, first
        for item in items[first]:
            _check_cancelled(cancelled)
            bucket = int(item.time_sec * 1000)
            if any(abs(item.time_sec - sec) < .001
                   for offset in (-1, 0, 1)
                   for sec in frames[second].get((item.shot_id, bucket + offset), ())):
                return True
        return False

    evidence = {group_id: eligible_observations(group_items, cancelled=cancelled)
                for group_id, group_items in items.items()}
    structure = {group_id: _observed_structure(group_items)
                 for group_id, group_items in evidence.items()}
    short = {group_id for group_id, (duration, runs) in structure.items()
             if duration <= 30. and runs <= 8}
    reliable = sorted(group_id for group_id, bank in banks.items()
                      if bank.sample_count >= 6 and len(bank.vectors) >= 3)
    established = [group_id for group_id in reliable if group_id not in short]
    # Reconcile recurring identities first. Otherwise twelve sampled faces in a
    # six-second fragment compete as an independent established identity. Short
    # videos without recurring anchors retain the conservative mutual-pair rule.
    if established:
        reliable = established
    lookup_best: dict[str, list[tuple[float, str, bool]]] = defaultdict(list)
    for index, first in enumerate(reliable):
        for second in reliable[index + 1:]:
            _check_cancelled(cancelled)
            if co_visible(first, second):
                continue
            lookup = compare_view_templates(banks[first], banks[second], cancelled=cancelled)
            _remember_candidate(lookup_best[first], (lookup.score, second, True))
            _remember_candidate(lookup_best[second], (lookup.score, first, True))
    candidates: dict[str, list[tuple[float, str, bool]]] = defaultdict(list)

    def verify_pair(first: str, second: str) -> None:
        match = compare_observation_evidence(evidence[first], evidence[second],
                                             cancelled=cancelled)
        eligible = _repeated_match(match, banks[first], banks[second])
        if eligible and _can_merge is not None:
            eligible = _can_merge(first, second)
        _remember_candidate(candidates[first], (match.score, second, eligible))
        _remember_candidate(candidates[second], (match.score, first, eligible))

    for index, first in enumerate(reliable):
        for second in reliable[index + 1:]:
            _check_cancelled(cancelled)
            if co_visible(first, second):
                continue
            lookup = compare_view_templates(banks[first], banks[second], cancelled=cancelled)
            # Always verify the two nearest lookup identities, including a
            # below-gate runner-up whose useful view may have been omitted.
            if (lookup.score < .50
                    and second not in {item[1] for item in lookup_best[first]}
                    and first not in {item[1] for item in lookup_best[second]}):
                continue
            verify_pair(first, second)

    # Lookup can hide an arbitrarily low-ranked rival's useful pose. Before a
    # seed can choose a partner, verify every non-co-visible rival using exactly
    # the same full evidence. Symmetric updates may make another seed eligible;
    # drain those seeds too before freezing reciprocal choices. Only two scores
    # per seed and a linear set survive; pair matrices/caches are never retained.
    verified: set[str] = set()
    while True:
        first = next((group_id for group_id in reliable if group_id not in verified
                      and candidates[group_id] and candidates[group_id][0][2]), None)
        if first is None:
            break
        for second in reliable:
            _check_cancelled(cancelled)
            if second != first and second not in verified and not co_visible(first, second):
                verify_pair(first, second)
        verified.add(first)
    choices = {group_id: _clear_best(candidates[group_id], .06) for group_id in reliable}
    components: dict[str, list[str]] = {}
    paired: set[str] = set()
    for first in reliable:
        if first in paired:
            continue
        second = choices[first]
        if second is not None and choices[second] == first:
            members = sorted((first, second))
            components[members[0]] = members
            paired.update(members)
        else:
            components[first] = [first]

    # Merge evidence only from already reliable seeds. This dictionary remains
    # unchanged throughout fragment assignment, including after accepted joins.
    anchor_banks = {
        anchor: (banks[anchor] if len(members) == 1 else build_view_templates(
            [item for member in members for item in items[member]], cancelled=cancelled))
        for anchor, members in components.items()
    }
    anchor_evidence = {anchor: tuple(item for member in members for item in evidence[member])
                       for anchor, members in components.items()}
    anchor_durations = {anchor: sum(structure[member][0] for member in members)
                        for anchor, members in components.items()}
    proposed: dict[str, str] = {}
    for fragment in sorted(set(original) - set(reliable)):
        _check_cancelled(cancelled)
        bank = banks[fragment]
        if (fragment not in short or not len(bank.vectors)
                or bank.sample_count / len(items[fragment]) < .6):
            continue
        singleton = bank.sample_count == 1
        if singleton and by_id[bank.observation_ids[0]].quality < .65:
            continue
        matches: list[tuple[float, str, bool]] = []
        lookup_matches: list[tuple[float, str]] = []
        for anchor, anchor_bank in anchor_banks.items():
            _check_cancelled(cancelled)
            if any(co_visible(fragment, member) for member in components[anchor]):
                continue
            lookup = compare_view_templates(bank, anchor_bank, cancelled=cancelled)
            lookup_matches.append((lookup.score, anchor))
        lookup_matches.sort(key=lambda item: (-item[0], item[1]))

        def verify_anchor(anchor: str) -> None:
            anchor_bank = anchor_banks[anchor]
            threshold = .86 if singleton else (.70 if bank.sample_count >= 6 else .72)
            match = compare_observation_evidence(evidence[fragment], anchor_evidence[anchor],
                                                 threshold=threshold, cancelled=cancelled)
            if singleton:
                eligible = match.left_hits == 1 and match.right_hits >= 3
            elif bank.sample_count >= 6:
                eligible = _repeated_match(match, bank, anchor_bank)
                # Four repeated observations on both sides can validate a shared
                # view at the ordinary .70 gate, even when other views differ.
                eligible |= min(match.left_hits, match.right_hits) >= 4 and match.score >= .70
            else:
                eligible = (match.left_hits >= 2 and match.right_hits >= 2
                            and match.left_fraction >= .6)
            if established and anchor_durations[anchor] < 3 * structure[fragment][0]:
                eligible = False
            if eligible and _can_merge is not None:
                eligible = all(_can_merge(fragment, member) for member in components[anchor])
            # Scores below the acceptance threshold still compete for the
            # ambiguity margin: .87 versus .85 is not an unambiguous singleton.
            _remember_candidate(matches, (match.score, anchor, eligible))

        for index, (score, anchor) in enumerate(lookup_matches):
            if index < 2 or score >= .50:
                verify_anchor(anchor)
        if matches and matches[0][2]:
            # Candidate lookup saves work only when there is no proposed join.
            # An eligible proposal must survive every remaining comparable
            # anchor, even one whose matching pose is absent from its bank.
            for index, (score, anchor) in enumerate(lookup_matches):
                if index >= 2 and score < .50:
                    verify_anchor(anchor)
        best = _clear_best(matches, .08 if singleton else .06)
        if best is not None:
            proposed[fragment] = best

    # Two co-visible fragments can both resemble the same anchor. Reject both
    # proposals instead of letting traversal order decide which person wins.
    conflicted: set[str] = set()
    by_anchor: dict[str, list[str]] = defaultdict(list)
    for fragment, anchor in proposed.items():
        by_anchor[anchor].append(fragment)
    for fragments in by_anchor.values():
        for index, first in enumerate(fragments):
            for second in fragments[index + 1:]:
                if co_visible(first, second):
                    conflicted.update((first, second))
    for fragment, anchor in proposed.items():
        if fragment not in conflicted:
            components[anchor].append(fragment)
    assigned = {member for members in components.values() for member in members}
    for group_id in sorted(set(original) - assigned):
        components[group_id] = [group_id]

    result: list[FaceGroup] = []
    for members in components.values():
        _check_cancelled(cancelled)
        if len(members) == 1:
            result.append(original[members[0]])
            continue
        merged = sorted((item for member in members for item in items[member]),
                        key=lambda item: (item.time_sec, item.observation_id))
        result.append(FaceGroup(
            group_id=min(members),
            track_ids=tuple(dict.fromkeys(item.track_id for item in merged)),
            observation_ids=tuple(item.observation_id for item in merged),
            intervals=_intervals(merged, 1.5),
            representative_observation_id=rank_representatives(merged)[0],
            status="needs_review",
        ))
    return sorted(result, key=lambda group: (min(by_id[key].time_sec
                                                for key in group.observation_ids), group.group_id))


def refine_person_groups(
    groups: Sequence[PersonGroup], observations: Sequence[FaceObservation], *,
    interval_gap: float, cancelled: Callable[[], bool] | None = None,
) -> list[PersonGroup]:
    """Run once after ordinary reconciliation, preserving body-backed intervals.

    The call freezes those completed identities before any attachment. Calling
    it again on its own output would promote attached evidence and is unsafe.
    """
    from .occurrences import PersonGroup, _merge_intervals, representative_candidates

    _check_cancelled(cancelled)
    by_id = {item.observation_id: item for item in observations}
    face_groups = [FaceGroup(group.group_id, group.track_ids, group.observation_ids, (),
                             group.representative_observation_id, group.status)
                   for group in groups if group.observation_ids]
    used = {key for group in face_groups for key in group.observation_ids}
    evidence = {group.group_id: eligible_observations(
        [by_id[key] for key in group.observation_ids], cancelled=cancelled)
        for group in face_groups}
    structure = {key: _observed_structure(items) for key, items in evidence.items()}

    def stable_centers(group_id: str):
        tracks: dict[str, list[FaceObservation]] = defaultdict(list)
        for item in evidence[group_id]:
            tracks[item.track_id].append(item)
        for items in tracks.values():
            _check_cancelled(cancelled)
            if len(items) < 2:
                continue
            center = np.zeros(np.asarray(items[0].embedding).size, np.float32)
            for item in items:
                _check_cancelled(cancelled)
                center += _normalized(item.embedding)
            norm = float(np.linalg.norm(center))
            if norm > 1e-8:
                yield center / norm

    def can_merge(first: str, second: str) -> bool:
        first_duration, first_runs = structure[first]
        second_duration, second_runs = structure[second]
        first_short = first_duration <= 30. and first_runs <= 8
        second_short = second_duration <= 30. and second_runs <= 8
        if ((first_short and not second_short and second_duration >= 3 * first_duration)
                or (second_short and not first_short and first_duration >= 3 * second_duration)):
            return True
        # Comparable completed groups must keep the existing constituent-track
        # veto. Otherwise a prior A+B merge could recruit C through B alone.
        # A brief pose attaching to a recurring frozen anchor is the explicitly
        # bounded exception; its repeated evidence cannot recruit other groups.
        return all(float(np.dot(left, right)) >= .50
                   for left in stable_centers(first) for right in stable_centers(second))

    refined = refine_face_groups(face_groups, [item for item in observations
                                               if item.observation_id in used], cancelled=cancelled,
                                 _can_merge=can_merge)
    owner = {key: index for index, group in enumerate(groups) for key in group.observation_ids}
    result = [group for group in groups if not group.observation_ids]
    for group in refined:
        _check_cancelled(cancelled)
        members = [groups[index] for index in sorted({owner[key] for key in group.observation_ids})]
        if len(members) == 1:
            result.append(members[0])
            continue
        candidates = representative_candidates([by_id[key] for key in group.observation_ids])
        result.append(PersonGroup(
            group.group_id,
            tuple(sorted({track for member in members for track in member.track_ids})),
            group.observation_ids,
            _merge_intervals([interval for member in members for interval in member.intervals],
                             interval_gap),
            candidates[0] if candidates else None,
            "needs_review",
        ))
    return sorted(result, key=lambda group: (min((interval.start_sec for interval in group.intervals),
                                                 default=float("inf")), group.group_id))
