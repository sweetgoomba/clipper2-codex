"""Bounded forward sampling around uncertain faces; no retained video frames."""
from __future__ import annotations

from math import floor
from typing import Sequence

from clipper_face_core import FaceObservation
from .body_tracking import _appearance_similarity, _iou


class AdaptiveSampling:
    def __init__(self, interval_sec: float, duration_sec: float):
        if interval_sec <= 0:
            raise ValueError('Sampling interval must be positive')
        self.interval = interval_sec
        self.max_extra = max(2, min(120, int(max(0., duration_sec) / interval_sec * .1)))
        self.base_count = self.extra_count = 0
        self._next_base = 0.
        self._pending: list[float] = []
        self._last_trigger = float('-inf')
        self._last_kind: str | None = None

    def due(self, time_sec: float) -> str | None:
        if time_sec + 1e-6 >= self._next_base:
            self._next_base = (floor((time_sec + 1e-6) / self.interval) + 1) * self.interval
            self._pending.clear()
            self.base_count += 1
            self._last_kind = 'base'
        elif self._pending and time_sec + 1e-6 >= self._pending[0]:
            self._pending.pop(0)
            self.extra_count += 1
            self._last_kind = 'extra'
        else:
            self._last_kind = None
        return self._last_kind

    def observe(self, time_sec: float, *, ambiguous: bool, shot_changed: bool = False) -> None:
        if shot_changed:
            self._pending.clear()
            return
        if not ambiguous or self._last_kind != 'base' or time_sec - self._last_trigger < 2.:
            return
        # Accrue the allowance through the video, so its beginning cannot spend
        # the whole budget. At most two extra samples are ever queued.
        available = min(self.max_extra, max(2, int(self.base_count * .1))) - self.extra_count
        self._pending = [time_sec + self.interval * step / 3 for step in (1, 2)
                         if time_sec + self.interval * step / 3 < self._next_base - 1e-6][:max(0, available)]
        if self._pending:
            self._last_trigger = time_sec


def needs_more_samples(previous: Sequence[FaceObservation],
                       current: Sequence[FaceObservation]) -> bool:
    if not previous:
        return False
    if not current:
        return True
    if previous[0].shot_id != current[0].shot_id:
        return False
    if any(face.association_uncertain or face.quality < .6 for face in current):
        return True
    previous_ids = {face.track_id for face in previous}
    return any(face.track_id not in previous_ids and _iou(face.bbox_px, old.bbox_px) >= .25
               and (score := _appearance_similarity(face.embedding, old.embedding)) is not None
               and .15 <= score < .5
               for face in current for old in previous)
