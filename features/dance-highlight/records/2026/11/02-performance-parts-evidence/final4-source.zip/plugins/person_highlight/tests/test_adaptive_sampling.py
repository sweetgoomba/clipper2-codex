import numpy as np

from clipper_face_core import FaceObservation
from person_highlight.adaptive_sampling import AdaptiveSampling, needs_more_samples


def face(key, time, vector=(1., 0.), quality=.8, uncertain=False, shot='shot'):
    return FaceObservation(key, key, shot, time, (10, 10, 90, 90),
                           np.array(vector, np.float32), quality,
                           association_uncertain=uncertain)


def test_ambiguous_sample_adds_intermediate_frames_without_moving_base_cadence():
    sampler = AdaptiveSampling(.5, 100.)
    assert sampler.due(0.) == 'base'
    sampler.observe(0., ambiguous=True)
    assert sampler.due(.1) is None
    assert sampler.due(.2) == 'extra'
    assert sampler.due(.35) == 'extra'
    assert sampler.due(.5) == 'base'
    assert sampler.due(1.) == 'base'


def test_clear_video_has_no_extra_inference_and_ambiguity_cannot_exhaust_memory():
    sampler = AdaptiveSampling(.5, 100.)
    sampled = []
    for frame in range(3000):
        time = frame / 30
        kind = sampler.due(time)
        if kind:
            sampled.append(kind)
            sampler.observe(time, ambiguous=False)
    assert sampled == ['base'] * 200

    sampler = AdaptiveSampling(.5, 100.)
    sampled = []
    for frame in range(3000):
        time = frame / 30
        kind = sampler.due(time)
        if kind:
            sampled.append(kind)
            sampler.observe(time, ambiguous=True)
    assert sampled.count('base') == 200
    assert 0 < sampled.count('extra') <= 20


def test_cut_clears_pending_burst_and_sparse_video_does_not_backfill_old_frames():
    sampler = AdaptiveSampling(.5, 100.)
    assert sampler.due(0.) == 'base'
    sampler.observe(0., ambiguous=True)
    assert sampler.due(.2) == 'extra'
    sampler.observe(.2, ambiguous=True, shot_changed=True)
    assert sampler.due(.35) is None
    assert sampler.due(4.) == 'base'
    assert sampler.due(4.1) is None


def test_extra_sampling_targets_uncertainty_and_disappearance_only_within_shot():
    previous = [face('a', 0.)]
    assert not needs_more_samples(previous, [face('a', .5)])
    assert needs_more_samples(previous, [face('a', .5, uncertain=True)])
    assert needs_more_samples(previous, [face('b', .5, vector=(.3, .954))])
    assert needs_more_samples(previous, [])
    assert not needs_more_samples([], [])
    assert not needs_more_samples(previous, [face('b', .5, shot='new')])
