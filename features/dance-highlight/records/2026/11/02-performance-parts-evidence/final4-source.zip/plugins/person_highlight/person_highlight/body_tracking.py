"""Shot-local tracking for all visible people, independent of face identity."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np


Box = tuple[int, int, int, int]


@dataclass(frozen=True)
class BodyDetection:
    bbox_px: Box
    score: float
    appearance: np.ndarray | None = None


@dataclass(frozen=True)
class BodyObservation:
    track_id: str
    shot_id: str
    time_sec: float
    bbox_px: Box
    score: float
    appearance: np.ndarray | None


def _iou(left: Box, right: Box) -> float:
    x1, y1 = max(left[0], right[0]), max(left[1], right[1])
    x2, y2 = min(left[2], right[2]), min(left[3], right[3])
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    left_area = max(0, left[2] - left[0]) * max(0, left[3] - left[1])
    right_area = max(0, right[2] - right[0]) * max(0, right[3] - right[1])
    return intersection / max(1, left_area + right_area - intersection)


def _appearance_similarity(left: np.ndarray | None, right: np.ndarray | None) -> float | None:
    if left is None or right is None:
        return None
    a, b = np.asarray(left, np.float32).reshape(-1), np.asarray(right, np.float32).reshape(-1)
    if a.shape != b.shape:
        return None
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    if denominator <= 1e-8:
        return None
    return float(np.dot(a, b) / denominator)


class BodyTracker:
    """Two-pass association retains weak detections without creating weak tracks."""

    def __init__(self, *, high_score: float = .25, low_score: float = .10,
                 max_gap_sec: float = 1.0):
        self.high_score = high_score
        self.low_score = low_score
        self.max_gap_sec = max_gap_sec
        self._last: dict[str, BodyObservation] = {}
        self._serial = 0
        self.observations: list[BodyObservation] = []

    def _candidate(self, old: BodyObservation, detection: BodyDetection,
                   shot_id: str, time_sec: float) -> float | None:
        if old.shot_id != shot_id or not 0 <= time_sec - old.time_sec <= self.max_gap_sec:
            return None
        overlap = _iou(old.bbox_px, detection.bbox_px)
        ox = (old.bbox_px[0] + old.bbox_px[2]) / 2
        oy = (old.bbox_px[1] + old.bbox_px[3]) / 2
        nx = (detection.bbox_px[0] + detection.bbox_px[2]) / 2
        ny = (detection.bbox_px[1] + detection.bbox_px[3]) / 2
        size = max(1, old.bbox_px[2] - old.bbox_px[0], old.bbox_px[3] - old.bbox_px[1],
                   detection.bbox_px[2] - detection.bbox_px[0],
                   detection.bbox_px[3] - detection.bbox_px[1])
        distance = float(np.hypot(nx - ox, ny - oy)) / size
        similarity = _appearance_similarity(old.appearance, detection.appearance)
        if similarity is not None and similarity < .55:
            return None
        if overlap < .08 and (distance > 1.5 or similarity is None or similarity < .8):
            return None
        return .55 * overlap + .4 * (similarity if similarity is not None else 0) - .05 * distance

    def add_frame(self, shot_id: str, time_sec: float,
                  detections: list[BodyDetection]) -> list[BodyObservation]:
        self._last = {track_id: observation for track_id, observation in self._last.items()
                      if observation.shot_id == shot_id
                      and 0 <= time_sec - observation.time_sec <= self.max_gap_sec}
        assigned: dict[int, str] = {}
        occupied: set[str] = set()
        for threshold in (self.high_score, self.low_score):
            edges: list[tuple[float, int, str]] = []
            for index, detection in enumerate(detections):
                if index in assigned or detection.score < threshold:
                    continue
                if threshold == self.low_score and detection.score >= self.high_score:
                    continue
                for track_id, old in self._last.items():
                    if track_id in occupied:
                        continue
                    score = self._candidate(old, detection, shot_id, time_sec)
                    if score is not None:
                        edges.append((score, index, track_id))
            for _, index, track_id in sorted(edges, reverse=True):
                if index not in assigned and track_id not in occupied:
                    assigned[index] = track_id
                    occupied.add(track_id)
        frame: list[BodyObservation] = []
        for index, detection in enumerate(detections):
            if detection.score < self.low_score:
                continue
            track_id = assigned.get(index)
            if track_id is None:
                if detection.score < self.high_score:
                    continue
                self._serial += 1
                track_id = f"body_{self._serial:06d}"
            observation = BodyObservation(track_id, shot_id, time_sec, detection.bbox_px,
                                          detection.score, detection.appearance)
            self._last[track_id] = observation
            self.observations.append(observation)
            frame.append(observation)
        return frame
