import numpy as np

from person_highlight.body_tracking import BodyDetection, BodyTracker


def body(box, score=0.9, appearance=(1.0, 0.0)):
    return BodyDetection(box, score, np.asarray(appearance, np.float32))


def test_weak_middle_detection_keeps_one_visible_person_track():
    tracker = BodyTracker()
    first = tracker.add_frame("shot_0", 0.0, [body((10, 10, 50, 90))])
    middle = tracker.add_frame("shot_0", 0.2, [body((12, 10, 52, 90), 0.16)])
    last = tracker.add_frame("shot_0", 0.4, [body((14, 10, 54, 90))])

    assert [first[0].track_id, middle[0].track_id, last[0].track_id] == [
        first[0].track_id,
    ] * 3


def test_two_crossing_people_keep_distinct_tracks_when_appearance_differs():
    tracker = BodyTracker()
    first = tracker.add_frame("shot_0", 0.0, [
        body((0, 0, 40, 100), appearance=(1, 0)),
        body((60, 0, 100, 100), appearance=(0, 1)),
    ])
    crossed = tracker.add_frame("shot_0", 0.2, [
        body((45, 0, 85, 100), appearance=(1, 0)),
        body((15, 0, 55, 100), appearance=(0, 1)),
    ])

    assert crossed[0].track_id == first[0].track_id
    assert crossed[1].track_id == first[1].track_id
    assert crossed[0].track_id != crossed[1].track_id


def test_shot_cut_starts_new_body_track():
    tracker = BodyTracker()
    before = tracker.add_frame("shot_0", 0.0, [body((10, 10, 50, 90))])
    after = tracker.add_frame("shot_1", 0.2, [body((10, 10, 50, 90))])

    assert before[0].track_id != after[0].track_id


def test_expired_body_tracks_are_removed_from_live_matching_state():
    tracker = BodyTracker(max_gap_sec=1.0)
    first = tracker.add_frame("shot_0", 0.0, [body((10, 10, 50, 90))])
    tracker.add_frame("shot_0", 2.0, [])
    assert len(tracker._last) == 0
    later = tracker.add_frame("shot_0", 2.5, [body((10, 10, 50, 90))])
    assert later[0].track_id != first[0].track_id


def test_shot_cut_discards_previous_body_matching_state():
    tracker = BodyTracker()
    tracker.add_frame("shot_0", 0.0, [body((10, 10, 50, 90))])
    tracker.add_frame("shot_1", 0.5, [])
    assert len(tracker._last) == 0
