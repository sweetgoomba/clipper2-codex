"""Run Person transcription in a cancellable child process."""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable

from clipper_speech_core import TimedTranscript
from clipper_speech_core.assets import ModelFilesUnavailableError

logger = logging.getLogger(__name__)


def _stop(process: subprocess.Popen) -> None:
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def run_person_speech(media_path: Path, output_path: Path, cache_dir: Path | None,
                      source_sha256: str, cancelled: Callable[[], bool], *,
                      diagnostics: dict | None = None, device: str = "cpu") -> TimedTranscript | None:
    if cancelled():
        raise InterruptedError("Person highlight cancelled")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    status_path = output_path.with_suffix(".status.json")
    output_path.unlink(missing_ok=True)
    status_path.unlink(missing_ok=True)
    command = [sys.executable, "-m", "clipper_speech_core.worker", str(media_path),
               str(output_path), device, str(cache_dir) if cache_dir else "-", source_sha256]
    process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        while process.poll() is None:
            if cancelled():
                _stop(process)
                raise InterruptedError("Person highlight cancelled")
            time.sleep(.1)
        if cancelled():
            raise InterruptedError("Person highlight cancelled")
        try:
            status = json.loads(status_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            status = {}
        if process.poll() == 4 or status.get("error") == "MODEL_FILES_MISSING":
            raise ModelFilesUnavailableError(status.get("detail") or "Whisper model files are missing")
        if process.poll() != 0:
            logger.warning("Person speech unavailable: %s", status.get("detail", "worker failed"))
            if diagnostics is not None:
                diagnostics.update(status="unavailable", error=status.get("detail", "worker failed"))
            output_path.unlink(missing_ok=True)
            return None
        try:
            transcript = TimedTranscript.from_stt_json(
                json.loads(output_path.read_text(encoding="utf-8")))
        except (OSError, ValueError, KeyError, TypeError) as exc:
            logger.warning("Person speech output unusable: %s", exc)
            if diagnostics is not None:
                diagnostics.update(status="unavailable", error="transcript invalid")
            output_path.unlink(missing_ok=True)
            return None
        if diagnostics is not None:
            diagnostics.update(status="completed" if transcript.words else "no_speech",
                               cache_hit=bool(status.get("cache_hit", False)))
        return transcript
    except InterruptedError:
        output_path.unlink(missing_ok=True)
        raise
    finally:
        status_path.unlink(missing_ok=True)
