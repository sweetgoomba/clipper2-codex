"""Generate scene previews with one decode and JPEG encode per requested timestamp."""

from __future__ import annotations

from collections.abc import Callable
from itertools import groupby
from pathlib import Path
import shutil

import cv2


def generate_scene_thumbnails(
    video_path: Path,
    output_root: Path,
    clips: list[dict],
    *,
    cancelled: Callable[[], bool],
    progress: Callable[[float], None],
) -> dict[str, int]:
    """Preserve every requested path, retaining only the current decoded frame.

    Unreadable timestamps are skipped and counted once in ``failed_reads``.
    Other failures propagate. Progress includes skipped requests so it reaches
    one even when a preview cannot be read; ``written`` counts successful paths.
    """
    counters = {"requested": len(clips), "unique_timestamps": 0, "decoded": 0,
                "written": 0, "reused": 0, "failed_reads": 0}
    if not clips:
        return counters
    requests = sorted(clips, key=lambda clip: clip["source_start_sec"])
    cap = cv2.VideoCapture(str(video_path))
    completed = 0
    try:
        for sec, matching_clips in groupby(requests, key=lambda clip: clip["source_start_sec"]):
            if cancelled():
                raise InterruptedError("Person highlight cancelled")
            counters["unique_timestamps"] += 1
            # Keep the existing timestamp seek semantics, including VFR videos.
            if not cap.set(cv2.CAP_PROP_POS_MSEC, sec * 1000):
                raise RuntimeError(f"Cannot seek scene thumbnail at {sec}s: {video_path}")
            okay, frame = cap.read()
            if okay:
                counters["decoded"] += 1
                height, width = frame.shape[:2]
                longest = max(width, height)
                if longest > 480:
                    scale = 480 / longest
                    frame = cv2.resize(frame, (round(width * scale), round(height * scale)),
                                       interpolation=cv2.INTER_AREA)
            else:
                counters["failed_reads"] += 1
            first_target = None
            for clip in matching_clips:
                if cancelled():
                    raise InterruptedError("Person highlight cancelled")
                if okay:
                    target = output_root / clip["thumbnail_path"]
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if first_target is None:
                        if not cv2.imwrite(str(target), frame, [cv2.IMWRITE_JPEG_QUALITY, 80]):
                            raise RuntimeError(f"Cannot write scene thumbnail: {target}")
                        first_target = target
                        frame = None
                    else:
                        shutil.copyfile(first_target, target)
                        counters["reused"] += 1
                    counters["written"] += 1
                completed += 1
                progress(completed / len(clips))
    finally:
        cap.release()
    return counters
