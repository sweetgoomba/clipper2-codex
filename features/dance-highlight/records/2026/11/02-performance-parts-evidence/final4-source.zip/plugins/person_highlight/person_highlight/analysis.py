"""Video observation, shot-local multi-face tracking and source intervals."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Literal, Sequence
import hashlib
import cv2
import numpy as np

from clipper_face_core import FaceDetection, FaceObservation, FaceGroup, group_observations
from .body_tracking import BodyObservation, BodyTracker, _appearance_similarity, _iou
from .occurrences import build_person_results
from .identity_continuity import head_position
from .frame_inference import FrameInference
from .performance import PerformanceStats
from .adaptive_sampling import AdaptiveSampling, needs_more_samples


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _same_face_box(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> bool:
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    smaller = min((a[2] - a[0]) * (a[3] - a[1]),
                  (b[2] - b[0]) * (b[3] - b[1]))
    return smaller > 0 and intersection / smaller >= .75 and _iou(a, b) >= .2


def _same_face_detection(a: FaceDetection, b: FaceDetection) -> bool:
    if _same_face_box(a.bbox_px, b.bbox_px):
        return True
    if _iou(a.bbox_px, b.bbox_px) < .28 or a.embedding is None or b.embedding is None:
        return False
    first = np.asarray(a.embedding, np.float32).reshape(-1)
    second = np.asarray(b.embedding, np.float32).reshape(-1)
    if first.shape != second.shape:
        return False
    denominator = float(np.linalg.norm(first) * np.linalg.norm(second))
    if denominator <= 1e-8 or float(np.dot(first, second) / denominator) < .55:
        return False
    ax, ay = (a.bbox_px[0] + a.bbox_px[2]) / 2, (a.bbox_px[1] + a.bbox_px[3]) / 2
    bx, by = (b.bbox_px[0] + b.bbox_px[2]) / 2, (b.bbox_px[1] + b.bbox_px[3]) / 2
    size = max(a.bbox_px[2] - a.bbox_px[0], a.bbox_px[3] - a.bbox_px[1],
               b.bbox_px[2] - b.bbox_px[0], b.bbox_px[3] - b.bbox_px[1])
    return float(np.hypot(ax - bx, ay - by)) <= .65 * size


def _identity_usable_detection(detection: FaceDetection) -> bool:
    """Leave weak face evidence to body tracking instead of inventing an identity."""
    x1, y1, x2, y2 = detection.bbox_px
    return (detection.embedding is not None and detection.score >= .85
            and min(x2 - x1, y2 - y1) >= 48)


def _confirmed_detections(frame: np.ndarray, detections: Sequence[FaceDetection],
                          bodies: Sequence[BodyObservation], backend,
                          cancelled: Callable[[], bool] = lambda: False) -> list[FaceDetection]:
    """Recheck isolated face-like objects in a crop before assigning an identity.

    A single-frame appearance remains valid; repeat frames are not required.
    Body-supported detections retain the existing single inference path.
    """
    result = []
    height, width = frame.shape[:2]
    for detection in detections:
        if cancelled():
            raise InterruptedError("Person highlight cancelled")
        if not _identity_usable_detection(detection):
            continue
        if any(body.score >= .5 and head_position(detection.bbox_px, body.bbox_px) is not None
               for body in bodies):
            result.append(detection)
            continue
        x1, y1, x2, y2 = detection.bbox_px
        left, top = max(0, x1 - (x2 - x1) // 2), max(0, y1 - (y2 - y1) // 2)
        right, bottom = min(width, x2 + (x2 - x1) // 2), min(height, y2 + (y2 - y1) // 2)
        crop = frame[top:bottom, left:right]
        if not crop.size:
            continue
        scale = min(1., 640 / max(crop.shape[:2]))
        if scale < 1.:
            crop = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        expected = tuple(round(value * scale) for value in
                         (x1 - left, y1 - top, x2 - left, y2 - top))
        if any(candidate.score >= .8 and _iou(expected, candidate.bbox_px) >= .5
               for candidate in getattr(backend, "detect_boxes", backend.detect)(crop)):
            result.append(detection)
    return result


def _retain_confirmed_groups(faces: list[FaceObservation], groups: list[FaceGroup],
                             confirmed_ids: set[str]) -> tuple[list[FaceObservation], list[FaceGroup]]:
    # A missed crop confirmation must not erase a tracked/recognized appearance
    # when another observation already corroborates that same face group.
    kept_groups = [group for group in groups if confirmed_ids.intersection(group.observation_ids)]
    kept_ids = {key for group in kept_groups for key in group.observation_ids}
    return [face for face in faces if face.observation_id in kept_ids], kept_groups


def _filter_low_prominence_scenes(
        faces: list[FaceObservation], bodies: list[BodyObservation],
        sampled_frames: dict[str, int],
        scene_faces: Sequence[_SceneFace] | None = None,
        ) -> tuple[list[FaceObservation], list[BodyObservation]]:
    """Ignore dense, uniformly tiny people in overview graphics such as thumbnail grids."""
    counts: dict[str, dict[int, int]] = defaultdict(lambda: defaultdict(int))
    small_counts: dict[str, dict[int, int]] = defaultdict(lambda: defaultdict(int))
    dominant_frames: set[tuple[str, int]] = set()
    frame_size: dict[str, tuple[int, int]] = {}
    max_face_width: dict[str, float] = defaultdict(float)
    for face in scene_faces if scene_faces is not None else faces:
        if face.frame_width <= 0 or face.frame_height <= 0:
            continue
        frame_size[face.shot_id] = (face.frame_width, face.frame_height)
        frame_key = round(face.time_sec * 1000)
        counts[face.shot_id][frame_key] += 1
        width = (face.bbox_px[2] - face.bbox_px[0]) / face.frame_width
        if width < .055:
            small_counts[face.shot_id][frame_key] += 1
        if width >= .10:
            dominant_frames.add((face.shot_id, frame_key))
        max_face_width[face.shot_id] = max(
            max_face_width[face.shot_id], width)

    max_body_height: dict[str, float] = defaultdict(float)
    for body in bodies:
        size = frame_size.get(body.shot_id)
        if size:
            max_body_height[body.shot_id] = max(
                max_body_height[body.shot_id],
                (body.bbox_px[3] - body.bbox_px[1]) / size[1])

    excluded: set[str] = set()
    overlay_frames: set[tuple[str, int]] = set()
    for shot_id, frame_counts in counts.items():
        dense_count = sum(count >= 8 for count in frame_counts.values())
        if (dense_count >= 2 and sampled_frames.get(shot_id, 0) >= 2
                and 5 * dense_count >= 3 * sampled_frames[shot_id]
                and max_face_width[shot_id] < .055
                and max_body_height[shot_id] < .23):
            excluded.add(shot_id)
            continue
        matching = {(shot_id, time) for time, small_count in small_counts[shot_id].items()
                    if small_count >= 6 and (shot_id, time) in dominant_frames}
        if len(matching) >= 2:
            overlay_frames.update(matching)

    return ([face for face in faces if face.shot_id not in excluded
             and not (face.frame_width > 0
                      and (face.bbox_px[2] - face.bbox_px[0]) / face.frame_width < .055
                      and (face.shot_id, round(face.time_sec * 1000)) in overlay_frames)],
            [body for body in bodies if body.shot_id not in excluded
             and not (body.shot_id in frame_size
                      and (body.bbox_px[3] - body.bbox_px[1]) / frame_size[body.shot_id][1] < .30
                      and (body.shot_id, round(body.time_sec * 1000)) in overlay_frames)])


def _shot_changed(previous_bgr: np.ndarray, current_bgr: np.ndarray) -> bool:
    """Detect a visual cut from both luminance and color, including dark footage."""
    previous_gray = cv2.cvtColor(previous_bgr, cv2.COLOR_BGR2GRAY)
    current_gray = cv2.cvtColor(current_bgr, cv2.COLOR_BGR2GRAY)
    luma_change = float(cv2.absdiff(previous_gray, current_gray).mean())
    if luma_change <= 10:
        return False

    def color_histogram(frame: np.ndarray) -> np.ndarray:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        histogram = cv2.calcHist([hsv], [0, 1], None, [16, 8], [0, 180, 0, 256])
        return cv2.normalize(histogram, histogram)

    color_change = cv2.compareHist(color_histogram(previous_bgr),
                                   color_histogram(current_bgr), cv2.HISTCMP_BHATTACHARYYA)
    return (luma_change > 45 and color_change > .27) or (
        luma_change > 20 and color_change > .28) or (
        luma_change > 10 and color_change > .5)


def _continuous_faces_across_visual_change(
        previous_bgr: np.ndarray, current_bgr: np.ndarray,
        previous_faces: Sequence[FaceObservation], detections: Sequence[FaceDetection],
        time_sec: float, size: tuple[int, int]) -> bool:
    """Veto a color-only cut when structure and every usable face remain continuous.

    Stage lighting can change the histogram without an editorial cut. A face
    alone cannot veto a cut: composition, scale, identity, recency and unique
    correspondence must agree. Only the existing tiny frame and last sample
    are used; no extra full-resolution frame is retained.
    """
    current = [face for face in detections if _identity_usable_detection(face)]
    if not previous_faces or len(previous_faces) != len(current):
        return False
    if any(face.association_uncertain or face.quality < .6
           or not 0 < time_sec - face.time_sec <= .75 for face in previous_faces):
        return False
    if any(face.quality < .6 for face in current):
        return False
    # A small inset/thumbnail must not mask a cut in the main picture.
    if not any((face.bbox_px[2] - face.bbox_px[0]) * (face.bbox_px[3] - face.bbox_px[1])
               >= .006 * size[0] * size[1] for face in current):
        return False
    previous_gray = cv2.cvtColor(previous_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    current_gray = cv2.cvtColor(current_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    # Fixed letterboxing must not outweigh a changed main picture. Trim only
    # outer bands that are flat in both samples; preserve textured composition.
    textured_rows = np.flatnonzero(np.maximum(previous_gray.std(axis=1),
                                              current_gray.std(axis=1)) >= 2.)
    textured_columns = np.flatnonzero(np.maximum(previous_gray.std(axis=0),
                                                 current_gray.std(axis=0)) >= 2.)
    if not len(textured_rows) or not len(textured_columns):
        return False
    active = (slice(textured_rows[0], textured_rows[-1] + 1),
              slice(textured_columns[0], textured_columns[-1] + 1))
    previous_gray, current_gray = previous_gray[active], current_gray[active]
    previous_gray -= previous_gray.mean()
    current_gray -= current_gray.mean()
    if min(float(previous_gray.std()), float(current_gray.std())) < 8.:
        return False
    correlation = float(np.sum(previous_gray * current_gray) /
                        (np.linalg.norm(previous_gray) * np.linalg.norm(current_gray)))
    if correlation < .4:
        return False
    matches: list[tuple[int, int]] = []
    competing_matches = 0
    for left, old in enumerate(previous_faces):
        ow, oh = old.bbox_px[2] - old.bbox_px[0], old.bbox_px[3] - old.bbox_px[1]
        for right, face in enumerate(current):
            nw, nh = face.bbox_px[2] - face.bbox_px[0], face.bbox_px[3] - face.bbox_px[1]
            similarity = _appearance_similarity(old.embedding, face.embedding)
            overlap = _iou(old.bbox_px, face.bbox_px)
            # Include every strong edge the downstream tracker may choose,
            # even if it is too weak to certify continuity across a visual cut.
            if overlap >= .18 and similarity is not None and similarity >= .45:
                competing_matches += 1
            if (min(ow, oh, nw, nh) > 0 and .7 <= nw / ow <= 1.4
                    and .7 <= nh / oh <= 1.4 and overlap >= .18
                    and similarity is not None and similarity >= .5):
                matches.append((left, right))
    return (len(matches) == len(current) == competing_matches
            and len({left for left, _ in matches}) == len(current)
            and len({right for _, right in matches}) == len(current))


@dataclass
class _Track:
    track_id: str
    shot_id: str
    last_sec: float
    box: tuple[int, int, int, int]
    embedding: np.ndarray | None
    bodies: tuple[BodyObservation, ...] = ()
    recent: tuple[tuple[float, np.ndarray], ...] = ()


def _recent_face_support(track: _Track, detection: FaceDetection, time_sec: float) -> bool:
    """Recover a noisy last sample only from repeated, recent trusted faces."""
    if detection.quality < .6 or detection.score < .85:
        return False
    hits = [time for time, vector in track.recent
            if 0 < time_sec - time <= 1.5
            and (score := _appearance_similarity(vector, detection.embedding)) is not None
            and score >= .65]
    return len(set(hits)) >= 2


def _stable_body_link(previous: Sequence[BodyObservation],
                      current: Sequence[BodyObservation]) -> bool:
    pairs = [(a, b) for a in previous for b in current if a.track_id == b.track_id]
    if len(pairs) != 1:
        return False
    a, b = pairs[0]
    similarity = _appearance_similarity(a.appearance, b.appearance)
    return (min(a.score, b.score) >= .5 and _iou(a.bbox_px, b.bbox_px) >= .5
            and similarity is not None and similarity >= .9)


@dataclass(frozen=True)
class _SceneFace:
    shot_id: str
    time_sec: float
    bbox_px: tuple[int, int, int, int]
    frame_width: int
    frame_height: int


class ObservationTracker:
    """Greedy one-to-one IoU assignment; never treats a main face specially."""

    def __init__(self, *, source_sha256: str, model_sha256: str, config_sha256: str,
                 max_gap_sec: float = 1.25, min_iou: float = .18):
        self.source_sha256 = source_sha256
        self.model_sha256 = model_sha256
        self.config_sha256 = config_sha256
        self.max_gap_sec = max_gap_sec
        self.min_iou = min_iou
        self.observations: list[FaceObservation] = []
        self._tracks: dict[str, _Track] = {}
        self._track_serial = 0

    def continues_across_visual_change(
            self, previous: np.ndarray, current: np.ndarray,
            previous_faces: Sequence[FaceObservation], detections: Sequence[FaceDetection],
            time_sec: float, size: tuple[int, int]) -> bool:
        # A recently occluded track must not steal a certified last-frame match.
        active_ids = {key for key, track in self._tracks.items()
                      if 0 <= time_sec - track.last_sec <= self.max_gap_sec}
        return (active_ids == {face.track_id for face in previous_faces}
                and _continuous_faces_across_visual_change(
                    previous, current, previous_faces, detections, time_sec, size))

    def add_frame(self, shot_id: str, time_sec: float, size: tuple[int, int],
                  detections: Sequence[FaceDetection], *,
                  bodies: Sequence[BodyObservation] = ()) -> None:
        self._tracks = {track_id: track for track_id, track in self._tracks.items()
                        if track.shot_id == shot_id
                        and 0 <= time_sec - track.last_sec <= self.max_gap_sec}
        width, height = size
        kept: list[int] = []
        for index in sorted(range(len(detections)),
                            key=lambda item: detections[item].score, reverse=True):
            if not any(_same_face_detection(detections[index], detections[other])
                       for other in kept):
                kept.append(index)
        unique_detections = [detections[index] for index in sorted(kept)]
        face_bodies: dict[int, list[BodyObservation]] = defaultdict(list)
        for body in bodies:
            if body.shot_id != shot_id or abs(body.time_sec - time_sec) >= .001:
                continue
            x1, y1, x2, y2 = body.bbox_px
            contained = [index for index, face in enumerate(unique_detections)
                         if x1 <= (face.bbox_px[0] + face.bbox_px[2]) / 2 <= x2
                         and y1 <= (face.bbox_px[1] + face.bbox_px[3]) / 2 <= y2]
            if len(contained) == 1:
                face_bodies[contained[0]].append(body)
        edges: list[tuple[float, int, str, bool]] = []
        body_edges: list[tuple[int, str]] = []
        history_edges: list[tuple[int, str]] = []
        for index, detection in enumerate(unique_detections):
            for track_id, track in self._tracks.items():
                if track.shot_id != shot_id or time_sec - track.last_sec > self.max_gap_sec:
                    continue
                overlap = _iou(track.box, detection.bbox_px)
                if overlap >= self.min_iou:
                    weak_match = False
                    if track.embedding is not None and detection.embedding is not None:
                        old = np.asarray(track.embedding, np.float32).reshape(-1)
                        new = np.asarray(detection.embedding, np.float32).reshape(-1)
                        denominator = float(np.linalg.norm(old) * np.linalg.norm(new))
                        if denominator <= 1e-8:
                            continue
                        similarity = float(np.dot(old, new) / denominator)
                        weak_match = similarity < .45
                        if weak_match and not (similarity >= .35 and overlap >= .6
                                               and time_sec - track.last_sec <= .75):
                            if (similarity >= .15 and overlap >= .45
                                    and time_sec - track.last_sec <= .75
                                    and _recent_face_support(track, detection, time_sec)):
                                history_edges.append((index, track_id))
                            if (similarity >= .2 and overlap >= .5
                                    and time_sec - track.last_sec <= .75
                                    and _stable_body_link(track.bodies, face_bodies[index])):
                                body_edges.append((index, track_id))
                            continue
                    edges.append((overlap, index, track_id, weak_match))
        edges.sort(key=lambda edge: (not edge[3], edge[0]), reverse=True)
        assignments: dict[int, str] = {}
        weak_assignments: set[int] = set()
        occupied: set[str] = set()
        for _, index, track_id, weak_match in edges:
            if index not in assignments and track_id not in occupied:
                assignments[index] = track_id
                occupied.add(track_id)
                if weak_match:
                    weak_assignments.add(index)
        # Strong face matches take priority. A body bridge must be unique in
        # both directions so overlapping/crossing people cannot steal a track.
        body_edges = [(index, track_id) for index, track_id in body_edges
                      if index not in assignments and track_id not in occupied]
        detection_counts = Counter(index for index, _ in body_edges)
        track_counts = Counter(track_id for _, track_id in body_edges)
        for index, track_id in body_edges:
            if detection_counts[index] == 1 and track_counts[track_id] == 1:
                assignments[index] = track_id
                occupied.add(track_id)
                weak_assignments.add(index)
        # A face history may recover a transient bad frame, but cannot choose
        # between two crossing detections or steal an established assignment.
        history_edges = [(index, track_id) for index, track_id in history_edges
                         if index not in assignments and track_id not in occupied]
        detection_counts = Counter(index for index, _ in history_edges)
        track_counts = Counter(track_id for _, track_id in history_edges)
        for index, track_id in history_edges:
            if detection_counts[index] == 1 and track_counts[track_id] == 1:
                assignments[index] = track_id
                occupied.add(track_id)
                weak_assignments.add(index)
        active = [track for track in self._tracks.values()
                  if track.shot_id == shot_id and 0 <= time_sec - track.last_sec <= .75]
        if len(unique_detections) == 1 and not assignments and len(active) == 1:
            previous_track = active[0]
            current = unique_detections[0]
            if previous_track.embedding is not None and current.embedding is not None:
                x1, y1, x2, y2 = previous_track.box
                a1, b1, a2, b2 = current.bbox_px
                distance = float(np.hypot((x1 + x2 - a1 - a2) / 2,
                                          (y1 + y2 - b1 - b2) / 2))
                face_size = max(x2 - x1, y2 - y1, a2 - a1, b2 - b1)
                old_vector = previous_track.embedding
                new_vector = current.embedding
                denominator = float(np.linalg.norm(old_vector) * np.linalg.norm(new_vector))
                similarity = (float(np.dot(old_vector.reshape(-1), new_vector.reshape(-1))) /
                              denominator if denominator > 1e-8 else -1.0)
                if distance <= 1.5 * face_size and similarity >= .38:
                    assignments[0] = previous_track.track_id
                    weak_assignments.add(0)
        for index, detection in enumerate(unique_detections):
            track_id = assignments.get(index)
            if track_id is None:
                self._track_serial += 1
                track_id = f"track_{self._track_serial:06d}"
            previous_track = self._tracks.get(track_id)
            recent = tuple((sec, vector) for sec, vector in previous_track.recent
                           if time_sec - sec <= 1.5) if previous_track else ()
            if (index not in weak_assignments and detection.embedding is not None
                    and detection.quality >= .6 and detection.score >= .85):
                recent = (*recent, (time_sec, detection.embedding))[-4:]
            self._tracks[track_id] = _Track(track_id, shot_id, time_sec,
                                            detection.bbox_px, detection.embedding,
                                            tuple(face_bodies[index]), recent)
            self.observations.append(FaceObservation(
                observation_id=f"obs_{len(self.observations)+1:07d}",
                track_id=track_id, shot_id=shot_id, time_sec=time_sec,
                bbox_px=detection.bbox_px, embedding=detection.embedding,
                quality=detection.quality, source_sha256=self.source_sha256,
                model_sha256=self.model_sha256, config_sha256=self.config_sha256,
                frame_width=width, frame_height=height,
                failure="embedding" if detection.embedding is None else "none",
                sharpness=detection.sharpness,
                association_uncertain=index in weak_assignments,
                detection_score=detection.score,
            ))


def analyze_video(video_path: Path, backend, body_detector, *, sample_fps: float = 2.0,
                  cancelled: Callable[[], bool] = lambda: False,
                  progress: Callable[[float], None] = lambda _: None,
                  on_phase: Callable[[Literal["grouping", "intervals"]], None] = lambda _: None,
                  face_detector: Callable | None = None, parallel_inference: bool = False,
                  metrics: PerformanceStats | None = None):
    metrics = metrics if metrics is not None else PerformanceStats()
    with metrics.measure("source_hash"):
        source_hash = sha256_file(video_path)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError(f"Cannot open source video: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = frame_count / fps
    sample_interval_sec = 1 / sample_fps
    tracker = ObservationTracker(source_sha256=source_hash,
                                 model_sha256=backend.model_sha256,
                                 config_sha256=backend.config_sha256)
    body_tracker = BodyTracker(max_gap_sec=max(1.0, 2.1 / sample_fps))
    previous: np.ndarray | None = None
    shot = 0
    shot_bounds: dict[str, tuple[float, float]] = {}
    sampled_frames: dict[str, int] = defaultdict(int)
    scene_faces: list[_SceneFace] = []
    confirmed_ids: set[str] = set()
    shot_start = 0.0
    frame_index = 0
    first_pts_ms: float | None = None
    last_time_sec = 0.0
    sampler = AdaptiveSampling(sample_interval_sec, duration)
    previous_faces: list[FaceObservation] = []
    pending_sample: tuple[str, float] | None = None
    last_sample: tuple[str, float] | None = None
    sample_end_sec: dict[tuple[str, float], float] = {}
    try:
        with FrameInference(face_detector or backend.detect, body_detector,
                            parallel=parallel_inference, metrics=metrics) as inference:
            while True:
                if cancelled():
                    raise InterruptedError("Person highlight cancelled")
                with metrics.measure("video_decode"):
                    grabbed = cap.grab()
                if not grabbed:
                    break
                raw_pts_ms = float(cap.get(cv2.CAP_PROP_POS_MSEC))
                if first_pts_ms is None:
                    first_pts_ms = raw_pts_ms if np.isfinite(raw_pts_ms) else 0.0
                pts_sec = (raw_pts_ms - first_pts_ms) / 1000.0
                time_sec = (pts_sec if np.isfinite(pts_sec) and
                            (frame_index == 0 or pts_sec > last_time_sec + 1e-6)
                            else max(frame_index / fps, last_time_sec + 1 / fps))
                last_time_sec = time_sec
                if pending_sample is not None:
                    sample_end_sec[pending_sample] = max(
                        pending_sample[1] + sample_interval_sec, time_sec)
                    pending_sample = None
                sample_kind = sampler.due(time_sec)
                if sample_kind is not None:
                    with metrics.measure("video_decode"):
                        okay, frame = cap.retrieve()
                    if not okay:
                        break
                    small = cv2.resize(frame, (64, 36))
                    shot_changed = previous is not None and _shot_changed(previous, small)
                    h, w = frame.shape[:2]
                    detections, body_detections = inference.detect(frame)
                    if shot_changed and tracker.continues_across_visual_change(
                            previous, small, previous_faces, detections, time_sec, (w, h)):
                        shot_changed = False
                        metrics.increment("color_cut_continuity_recoveries")
                    if shot_changed:
                        cut_sec = time_sec
                        shot_bounds[f"shot_{shot:04d}"] = (shot_start, cut_sec)
                        shot += 1
                        shot_start = cut_sec
                    previous = small
                    shot_id = f"shot_{shot:04d}"
                    if last_sample is not None:
                        sample_end_sec[last_sample] = min(
                            sample_end_sec.get(last_sample, time_sec), time_sec)
                    pending_sample = (shot_id, time_sec)
                    last_sample = pending_sample
                    sampled_frames[shot_id] += 1
                    frame_bodies = body_tracker.add_frame(shot_id, time_sec, body_detections)
                    metrics.increment("sampled_frames")
                    metrics.increment(f"{sample_kind}_sampled_frames")
                    metrics.increment("detected_faces", len(detections))
                    metrics.increment("embedded_faces", sum(d.embedding is not None for d in detections))
                    scene_faces.extend(_SceneFace(shot_id, time_sec, detection.bbox_px, w, h)
                                       for detection in detections if detection.score >= .85)
                    with metrics.measure("face_confirmation"):
                        confirmed_boxes = {detection.bbox_px for detection in _confirmed_detections(
                            frame, detections, frame_bodies, backend, cancelled)}
                    previous_count = len(tracker.observations)
                    tracker.add_frame(shot_id, time_sec, (w, h), [detection for detection
                                      in detections if _identity_usable_detection(detection)],
                                      bodies=frame_bodies)
                    confirmed_ids.update(face.observation_id
                                         for face in tracker.observations[previous_count:]
                                         if face.bbox_px in confirmed_boxes)
                    current_faces = tracker.observations[previous_count:]
                    sampler.observe(time_sec,
                                    ambiguous=needs_more_samples(previous_faces, current_faces),
                                    shot_changed=shot_changed)
                    previous_faces = current_faces
                    if frame_count:
                        progress(min(1.0, frame_index / frame_count))
                frame_index += 1
    finally:
        cap.release()
    if frame_index and duration <= last_time_sec:
        duration = last_time_sec + 1 / fps
    if pending_sample is not None:
        sample_end_sec[pending_sample] = max(
            pending_sample[1] + sample_interval_sec, duration)
    shot_bounds[f"shot_{shot:04d}"] = (shot_start, duration)
    face_observations, body_observations = _filter_low_prominence_scenes(
        tracker.observations, body_tracker.observations, sampled_frames, scene_faces)
    on_phase("grouping")
    with metrics.measure("identity_grouping"):
        groups = group_observations(
            face_observations, cosine_threshold=.50,
            on_intervals_start=lambda: on_phase("intervals"),
            cancelled=cancelled)
        face_observations, groups = _retain_confirmed_groups(face_observations, groups, confirmed_ids)
        metrics.increment("identity_seed_groups", len(groups))
        person_groups, clips = build_person_results(
            groups, face_observations, body_observations,
            duration_sec=duration, sample_interval_sec=sample_interval_sec,
            cancelled=cancelled, sample_end_sec=sample_end_sec, metrics=metrics)
    return (face_observations, body_observations,
            person_groups, clips, duration, source_hash, shot_bounds)
