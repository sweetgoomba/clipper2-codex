"""Local identity evidence from an uninterrupted body and an unambiguous head."""
from collections import defaultdict
from typing import Callable, Sequence

from clipper_face_core import FaceObservation
from .body_tracking import BodyObservation, _appearance_similarity, _iou


def head_position(face_box: tuple[int, int, int, int],
                  body_box: tuple[int, int, int, int]) -> tuple[float, float] | None:
    x1, y1, x2, y2 = body_box
    if x2 <= x1 or y2 <= y1:
        return None
    x = ((face_box[0] + face_box[2]) / 2 - x1) / (x2 - x1)
    y = ((face_box[1] + face_box[3]) / 2 - y1) / (y2 - y1)
    return (x, y) if 0 <= x <= 1 and 0 <= y <= .5 else None


def body_face_links(faces: Sequence[FaceObservation], bodies: Sequence[BodyObservation],
                    sample_interval: float, cancelled: Callable[[], bool] | None = None,
                    ) -> list[tuple[str, str]]:
    """Return local links only; never infer identity from clothing across cuts."""
    frames: dict[tuple[str, int], list[FaceObservation]] = defaultdict(list)
    body_frames: dict[tuple[str, int], list[BodyObservation]] = defaultdict(list)
    for face in faces:
        frames[face.shot_id, round(face.time_sec * 1000)].append(face)
    for body in bodies:
        body_frames[body.shot_id, round(body.time_sec * 1000)].append(body)
    tracks: dict[str, list[tuple[FaceObservation, BodyObservation, bool]]] = defaultdict(list)
    for (shot, ms), frame_faces in frames.items():
        if cancelled is not None and cancelled():
            raise InterruptedError('Person highlight cancelled')
        frame_bodies = [body for offset in (-1, 0, 1)
                        for body in body_frames.get((shot, ms + offset), ())
                        if body.score >= .5]
        proposals: dict[str, list[tuple[float, FaceObservation, BodyObservation, bool]]] = defaultdict(list)
        for face in frame_faces:
            options = []
            for body in frame_bodies:
                if abs(face.time_sec - body.time_sec) >= .001:
                    continue
                position = head_position(face.bbox_px, body.bbox_px)
                if position is not None:
                    x, y = position
                    options.append(((x - .5) ** 2 + (y - .18) ** 2, body))
            options.sort(key=lambda item: (item[0], item[1].track_id))
            if not options:
                continue
            confident = len(options) == 1 or options[1][0] - options[0][0] >= .04
            cost, body = options[0]
            proposals[body.track_id].append((cost, face, body, confident))
        for track, proposals_for_body in proposals.items():
            proposals_for_body.sort(key=lambda item: item[0])
            if (len(proposals_for_body) > 1
                    and proposals_for_body[1][0] - proposals_for_body[0][0] < .04):
                continue
            _, face, body, confident = proposals_for_body[0]
            tracks[track].append((face, body, confident))
    links = []
    for samples in tracks.values():
        samples.sort(key=lambda item: item[0].time_sec)
        # A geometrically ambiguous head is usable only when the same face
        # track was already assigned to this body in the preceding sample.
        accepted = []
        for face, body, confident in samples:
            previous = accepted[-1] if accepted else None
            if confident or (previous is not None and face.track_id == previous[0].track_id
                             and face.shot_id == previous[0].shot_id
                             and 0 < face.time_sec - previous[0].time_sec <= sample_interval * 1.25):
                accepted.append((face, body))
        for (left, a), (right, b) in zip(accepted, accepted[1:]):
            if cancelled is not None and cancelled():
                raise InterruptedError('Person highlight cancelled')
            if (left.shot_id != right.shot_id
                    or not 0 < right.time_sec - left.time_sec <= sample_interval * 1.25
                    or _iou(a.bbox_px, b.bbox_px) < .25):
                continue
            appearance = _appearance_similarity(a.appearance, b.appearance)
            identity = _appearance_similarity(left.embedding, right.embedding)
            if appearance is None or appearance < .8 or identity is None or identity < .15:
                continue
            links.append((left.observation_id, right.observation_id))
    return links
