import numpy as np

from clipper_face_core import FaceDetection
from clipper_face_core import FaceObservation
from person_highlight.analysis import ObservationTracker, analyze_video, _shot_changed
from person_highlight.body_tracking import BodyObservation
from clipper_face_core import group_observations


def detection(box, vector):
    return FaceDetection(box, np.asarray(vector, np.float32), 0.8, 0.9, 'none')


def test_stage_color_changes_preserve_unique_face_continuity():
    from person_highlight.analysis import _continuous_faces_across_visual_change

    # Geometry/cosines from the reported 20.5205 -> 21.021 -> 21.5215 s split.
    boxes = [(1118, 352, 1257, 528), (1061, 355, 1198, 532), (975, 358, 1106, 532)]
    radians = np.array([0., np.arccos(.6779), np.arccos(.6779) + np.arccos(.5159)])
    vectors = [np.array([np.cos(angle), np.sin(angle)], np.float32) for angle in radians]
    pattern = np.indices((36, 64)).sum(axis=0) % 2
    frames = [np.clip(np.full((36, 64, 3), color) + pattern[:, :, None] * 50, 0, 255).astype(np.uint8)
              for color in [(20, 20, 90), (90, 200, 20), (180, 40, 120)]]
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    tracker.add_frame('shot', 20.5205, (1920, 1080), [detection(boxes[0], vectors[0])])
    for index, sec in [(1, 21.021), (2, 21.5215)]:
        current = [detection(boxes[index], vectors[index])]
        assert _shot_changed(frames[index - 1], frames[index])
        assert _continuous_faces_across_visual_change(
            frames[index - 1], frames[index], tracker.observations[-1:], current, sec, (1920, 1080))
        tracker.add_frame('shot', sec, (1920, 1080), current)
    assert len({face.track_id for face in tracker.observations}) == 1


def test_visual_change_continuity_requires_structure_unique_identity_and_recent_geometry():
    from person_highlight.analysis import _continuous_faces_across_visual_change

    rng = np.random.default_rng(41)
    previous = rng.integers(0, 150, (36, 64, 3), dtype=np.uint8)
    current = np.minimum(previous.astype(int) + 60, 255).astype(np.uint8)
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    tracker.add_frame('shot', 0., (400, 300), [detection((50, 40, 130, 140), [1, 0])])
    faces = tracker.observations
    same = detection((55, 40, 135, 140), [1, 0])
    assert _continuous_faces_across_visual_change(previous, current, faces, [same], .5, (400, 300))
    for image, next_faces, sec in [
        (current[::-1].copy(), [same], .5),  # changed composition, same face
        (np.full_like(current, 100), [same], .5),  # no structural evidence
        (current, [detection(same.bbox_px, [0, 1])], .5),
        (current, [same, same], .5),
        (current, [detection((250, 40, 330, 140), [1, 0])], .5),
        (current, [same], 1.5),
        (current, [], .5),
    ]:
        assert not _continuous_faces_across_visual_change(previous, image, faces, next_faces, sec, (400, 300))


def test_video_validates_visual_cut_before_resetting_face_and_body_tracks(tmp_path, monkeypatch):
    from person_highlight import analysis
    from person_highlight.body_tracking import BodyDetection
    from person_highlight.performance import PerformanceStats

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, key):
            return {analysis.cv2.CAP_PROP_FPS: 2,
                    analysis.cv2.CAP_PROP_FRAME_COUNT: 3,
                    analysis.cv2.CAP_PROP_POS_MSEC: self.index * 500}[key]

        def grab(self):
            self.index += 1
            return self.index < 3

        def retrieve(self):
            pattern = (np.indices((36, 64)).sum(axis=0) % 2)[:, :, None] * 50
            color = [(20, 20, 90), (90, 200, 20), (180, 40, 120)][self.index]
            frame = np.clip(np.full((36, 64, 3), color) + pattern, 0, 255).astype(np.uint8)
            return True, analysis.cv2.resize(frame, (640, 360), interpolation=analysis.cv2.INTER_NEAREST)

        def release(self):
            pass

    class Faces:
        model_sha256 = config_sha256 = 'fixture'

        def detect(self, _frame):
            return [detection((200, 100, 280, 200), (1., 0.))]

    class Bodies:
        def detect(self, _frame):
            return [BodyDetection((160, 80, 340, 350), .95)]

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _: 'fixture')
    metrics = PerformanceStats()
    faces, bodies, _, _, _, _, bounds = analyze_video(
        tmp_path / 'source.mp4', Faces(), Bodies(), metrics=metrics)
    assert bounds == {'shot_0000': (0., 1.5)}
    assert len({face.track_id for face in faces}) == 1
    assert len({body.track_id for body in bodies}) == 1
    assert metrics.snapshot()['counters']['color_cut_continuity_recoveries'] == 2


def test_cut_veto_does_not_ignore_recently_occluded_competing_track():
    rng = np.random.default_rng(41)
    previous = rng.integers(0, 150, (36, 64, 3), dtype=np.uint8)
    current = np.minimum(previous.astype(int) + 60, 255).astype(np.uint8)
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    target = detection((50, 40, 130, 140), [1, 0])
    tracker.add_frame('shot', 0., (400, 300), [target, detection((250, 40, 330, 140), [0, 1])])
    tracker.add_frame('shot', .5, (400, 300), [target])
    assert not tracker.continues_across_visual_change(
        previous, current, tracker.observations[-1:], [target], 1., (400, 300))


def test_recent_clear_faces_recover_track_after_transient_turn_and_motion():
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    for sec, box, vector in [
        (0., (10, 10, 90, 90), (1., 0., 0.)),
        (.5, (10, 10, 90, 90), (1., 0., 0.)),
        (1., (10, 10, 90, 90), (.38, .925, 0.)),
        (1.5, (34, 10, 114, 90), (1., 0., 0.)),
    ]:
        tracker.add_frame('shot', sec, (400, 300), [
            detection(box, vector), detection((250, 10, 330, 90), (0., 0., 1.))])
    target = tracker.observations[::2]
    assert len({face.track_id for face in target}) == 1
    assert target[-1].association_uncertain
    assert len({face.track_id for face in tracker.observations[1::2]}) == 1


def test_recent_face_history_does_not_recover_two_competing_faces():
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    for sec, vector in [(0., (1., 0.)), (.5, (1., 0.)), (1., (.38, .925))]:
        tracker.add_frame('shot', sec, (400, 300), [detection((10, 10, 90, 90), vector)])
    original = tracker.observations[0].track_id
    tracker.add_frame('shot', 1.5, (400, 300), [
        detection((34, 10, 114, 90), (1., 0.)),
        detection((-14, 10, 66, 90), (1., 0.))])
    assert all(face.track_id != original for face in tracker.observations[-2:])


def test_recent_face_history_does_not_cross_a_cut_or_rescue_conflicting_identity():
    for shot, vector in [('other-shot', (1., 0., 0.)), ('shot', (0., 0., 1.))]:
        tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
        for sec, prior in [(0., (1., 0., 0.)), (.5, (1., 0., 0.)), (1., (.38, .925, 0.))]:
            tracker.add_frame('shot', sec, (400, 300), [detection((10, 10, 90, 90), prior)])
        tracker.add_frame(shot, 1.5, (400, 300), [detection((34, 10, 114, 90), vector)])
        assert tracker.observations[0].track_id != tracker.observations[-1].track_id


def test_ambiguous_video_gets_extra_faces_without_extending_presence_across_cut(tmp_path, monkeypatch):
    from person_highlight import analysis
    from person_highlight.body_tracking import BodyDetection
    from person_highlight.performance import PerformanceStats

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, key):
            return {analysis.cv2.CAP_PROP_FPS: 10,
                    analysis.cv2.CAP_PROP_FRAME_COUNT: 30,
                    analysis.cv2.CAP_PROP_POS_MSEC: self.index * 100}[key]

        def grab(self):
            self.index += 1
            return self.index < 30

        def retrieve(self):
            color = (20, 20, 90) if self.index < 9 else (90, 200, 20)
            return True, np.full((200, 200, 3), color, np.uint8)

        def release(self):
            pass

    cap = Capture()

    class Faces:
        model_sha256 = config_sha256 = 'fixture'

        def detect(self, frame):
            vector = ((.38, .925, 0.) if cap.index == 5 else
                      (1., 0., 0.) if cap.index < 9 else (0., 0., 1.))
            return [detection((20, 20, 100, 100), vector)]

    class Bodies:
        def detect(self, frame):
            return [BodyDetection((0, 0, 180, 190), .95)]

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _: cap)
    monkeypatch.setattr(analysis, 'sha256_file', lambda _: 'fixture')
    metrics = PerformanceStats()
    faces, _, people, _, _, _, bounds = analyze_video(
        tmp_path / 'source.mp4', Faces(), Bodies(), metrics=metrics)
    assert [round(face.time_sec, 2) for face in faces] == [0., .5, .7, .9, 1., 1.5, 2., 2.5]
    target = next(group for group in people if faces[0].observation_id in group.observation_ids)
    assert max(interval.end_sec for interval in target.intervals) <= .9 + 1e-6
    assert bounds['shot_0000'] == (0., .9)
    assert metrics.snapshot()['counters']['extra_sampled_frames'] == 2
    assert metrics.snapshot()['counters']['base_sampled_frames'] == 6


def test_analysis_final_refinement_preserves_constituent_identity_guard(tmp_path, monkeypatch):
    from person_highlight import analysis

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, key):
            return {analysis.cv2.CAP_PROP_FPS: 2,
                    analysis.cv2.CAP_PROP_FRAME_COUNT: 18,
                    analysis.cv2.CAP_PROP_POS_MSEC: self.index * 500}[key]

        def grab(self):
            self.index += 1
            return self.index < 18

        def retrieve(self):
            color = [(20, 20, 90), (90, 200, 20), (200, 20, 180)][self.index // 6]
            return True, np.full((200, 200, 3), color, np.uint8)

        def release(self):
            pass

    cap = Capture()

    class Faces:
        model_sha256 = config_sha256 = 'fixture'

        def detect(self, _frame):
            radians = np.deg2rad([0., 35., 75.][cap.index // 6])
            return [detection((20, 20, 100, 100), (np.cos(radians), np.sin(radians)))]

    class Bodies:
        def detect(self, _frame):
            return []

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _: cap)
    monkeypatch.setattr(analysis, 'sha256_file', lambda _: 'fixture')
    faces, _, people, *_ = analyze_video(tmp_path / 'source.mp4', Faces(), Bodies())
    assert len(faces) == 18
    # The middle view cannot recruit the last identity when its similarity to
    # the first constituent is only cos(75 degrees). All evidence is retained.
    assert len(people) == 2
    assert not any({faces[0].observation_id, faces[-1].observation_id}
                   <= set(group.observation_ids) for group in people)
    assert {key for group in people for key in group.observation_ids} == {
        face.observation_id for face in faces}


def test_head_turn_keeps_face_track_when_exclusive_body_track_is_stable():
    for gap, next_box in ((.5, (30, 20, 100, 100)), (.5, (40, 20, 110, 100))):
        tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
        for sec, vector in [(0., (1., 0.)), (gap, (.25, .968))]:
            bodies = [BodyObservation('body', 'shot', sec, (0, 0, 150, 250), .9,
                                      np.array([1., 0.], np.float32))]
            # A transient nested body box must not hide the stable body track.
            if sec:
                bodies.append(BodyObservation('duplicate', 'shot', sec, (10, 0, 140, 190),
                                              .8, np.array([1., 0.], np.float32)))
            box = next_box if sec else (30, 20, 100, 100)
            tracker.add_frame('shot', sec, (400, 300), [detection(box, vector)], bodies=bodies)

        assert len({face.track_id for face in tracker.observations}) == 1
        assert tracker.observations[-1].association_uncertain


def test_body_continuity_does_not_link_replacement_or_ambiguous_people():
    for scenario in ('changed_track', 'changed_appearance', 'two_faces', 'face_mismatch',
                     'shot_cut'):
        tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
        for sec in (0., .5):
            shot = 'cut' if sec and scenario == 'shot_cut' else 'shot'
            track = 'replacement' if sec and scenario == 'changed_track' else 'body'
            visual = (0., 1.) if sec and scenario == 'changed_appearance' else (1., 0.)
            vector = ((0., 1.) if scenario == 'face_mismatch' else (.25, .968)) if sec else (1., 0.)
            faces = [detection((30, 20, 100, 100), vector)]
            if scenario == 'two_faces':
                faces.append(detection((180, 20, 250, 100), (0., 1.)))
            tracker.add_frame(shot, sec, (400, 300), faces, bodies=[
                BodyObservation(track, shot, sec, (0, 0, 300, 250), .9,
                                np.asarray(visual, np.float32))])
        first, last = tracker.observations[0], tracker.observations[-2 if scenario == 'two_faces' else -1]
        assert first.track_id != last.track_id, scenario


def test_small_faces_inside_thumbnail_grid_do_not_create_appearances():
    from person_highlight import analysis

    faces = [FaceObservation(
        observation_id=f'face_{frame}_{index}', track_id=f'face_track_{index}',
        shot_id='thumbnail_grid', time_sec=frame * .5,
        bbox_px=(100 + index * 190, 280, 168 + index * 190, 370),
        embedding=np.array([1., 0.], np.float32), quality=.9,
        frame_width=1920, frame_height=1080)
        for frame in range(4) for index in range(8)]
    bodies = [BodyObservation(
        track_id=f'body_{index}', shot_id='thumbnail_grid', time_sec=frame * .5,
        bbox_px=(100 + index * 190, 250, 250 + index * 190, 470),
        score=.9, appearance=None)
        for frame in range(4) for index in range(8)]

    kept_faces, kept_bodies = analysis._filter_low_prominence_scenes(
        faces, bodies, {'thumbnail_grid': 4})

    assert kept_faces == []
    assert kept_bodies == []


def test_small_people_in_a_real_wide_shot_remain_when_body_is_visible():
    from person_highlight import analysis

    faces = [FaceObservation(
        observation_id=f'face_{frame}_{index}', track_id=f'face_track_{index}',
        shot_id='wide_shot', time_sec=frame * .5,
        bbox_px=(100 + index * 190, 280, 168 + index * 190, 370),
        embedding=np.array([1., 0.], np.float32), quality=.9,
        frame_width=1920, frame_height=1080)
        for frame in range(4) for index in range(8)]
    bodies = [BodyObservation(
        track_id=f'body_{index}', shot_id='wide_shot', time_sec=frame * .5,
        bbox_px=(100 + index * 190, 250, 250 + index * 190, 530),
        score=.9, appearance=None)
        for frame in range(4) for index in range(8)]

    kept_faces, kept_bodies = analysis._filter_low_prominence_scenes(
        faces, bodies, {'wide_shot': 4})

    assert kept_faces == faces
    assert kept_bodies == bodies


def test_thumbnail_overlay_people_do_not_join_a_large_live_person():
    from person_highlight import analysis

    faces = [FaceObservation(
        observation_id=f'main_{frame}', track_id='main', shot_id='overlay',
        time_sec=frame * .5, bbox_px=(700, 250, 980, 560),
        embedding=np.array([1., 0.], np.float32), quality=.9,
        frame_width=1920, frame_height=1080)
        for frame in range(3)]
    faces += [FaceObservation(
        observation_id=f'inset_{frame}_{index}', track_id=f'inset_{index}',
        shot_id='overlay', time_sec=frame * .5,
        bbox_px=(100 + index * 190, 120, 168 + index * 190, 210),
        embedding=np.array([0., 1.], np.float32), quality=.9,
        frame_width=1920, frame_height=1080)
        for frame in range(3) for index in range(8)]
    bodies = [BodyObservation(
        track_id='main_body', shot_id='overlay', time_sec=frame * .5,
        bbox_px=(500, 100, 1100, 1000), score=.9, appearance=None)
        for frame in range(3)]
    bodies += [BodyObservation(
        track_id=f'inset_body_{index}', shot_id='overlay', time_sec=frame * .5,
        bbox_px=(100 + index * 190, 100, 250 + index * 190, 320),
        score=.9, appearance=None)
        for frame in range(3) for index in range(8)]

    kept_faces, kept_bodies = analysis._filter_low_prominence_scenes(
        faces, bodies, {'overlay': 3})

    assert {face.track_id for face in kept_faces} == {'main'}
    assert {body.track_id for body in kept_bodies} == {'main_body'}


def test_video_analysis_does_not_publish_thumbnail_grid_people(tmp_path, monkeypatch):
    from person_highlight import analysis
    from person_highlight.body_tracking import BodyDetection

    class Capture:
        def __init__(self):
            self.index = 0

        def isOpened(self):
            return True

        def get(self, property_id):
            return 2 if property_id == analysis.cv2.CAP_PROP_FPS else 4

        def grab(self):
            self.index += 1
            return self.index <= 4

        def retrieve(self):
            return True, np.zeros((1080, 1920, 3), np.uint8)

        def release(self):
            pass

    class Backend:
        model_sha256 = 'model'
        config_sha256 = 'config'

        def detect(self, _frame):
            return [detection((100 + i * 190, 280, 168 + i * 190, 370), [1, i + 1])
                    for i in range(8)]

    class Bodies:
        def detect(self, _frame):
            return [BodyDetection((100 + i * 190, 250, 250 + i * 190, 470), .9)
                    for i in range(8)]

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')

    observations, bodies, people, clips, *_ = analyze_video(
        tmp_path / 'source.mp4', Backend(), Bodies())

    assert observations == []
    assert bodies == []
    assert people == []
    assert clips == []


def test_shot_cut_uses_color_change_when_luma_change_is_below_old_threshold():
    previous = np.full((36, 64, 3), (20, 20, 90), np.uint8)
    current = np.full((36, 64, 3), (90, 20, 20), np.uint8)
    assert _shot_changed(previous, current)


def test_motion_with_stable_color_palette_does_not_create_shot_cut():
    previous = np.zeros((36, 64, 3), np.uint8)
    previous[:, :32] = (25, 35, 45)
    current = np.zeros_like(previous)
    current[:, 32:] = (25, 35, 45)
    assert not _shot_changed(previous, current)


def test_fast_pan_with_large_luma_change_and_stable_palette_is_not_a_cut():
    # Source audit: a large moving foreground can change mean brightness at
    # consecutive samples without an editorial cut (e.g. 599.5 and 1003 s).
    previous = np.zeros((36, 64, 3), np.uint8)
    previous[:, :32] = (230, 230, 230)
    current = np.zeros_like(previous)
    current[:, 32:] = (230, 230, 230)

    assert not _shot_changed(previous, current)


def test_large_luma_change_with_new_color_remains_a_cut():
    previous = np.full((36, 64, 3), (20, 20, 90), np.uint8)
    current = np.full((36, 64, 3), (90, 200, 20), np.uint8)

    assert _shot_changed(previous, current)


def test_all_faces_get_distinct_tracks():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (100, 100), [
        detection((0, 0, 20, 20), [1, 0]),
        detection((50, 0, 70, 20), [0, 1]),
    ])
    tracker.add_frame('shot_000', 0.5, (100, 100), [
        detection((1, 0, 21, 20), [1, 0]),
        detection((51, 0, 71, 20), [0, 1]),
    ])
    groups = group_observations(tracker.observations, cosine_threshold=0.6)
    assert len(groups) == 2


def test_overlapping_face_boxes_do_not_join_conflicting_face_embeddings():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (100, 100), [detection((10, 10, 40, 40), [1, 0])])
    tracker.add_frame('shot_000', 0.5, (100, 100), [detection((10, 10, 40, 40), [0, 1])])

    assert tracker.observations[0].track_id != tracker.observations[1].track_id


def test_stable_face_position_survives_a_low_similarity_head_turn_in_a_crowd():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (100, 100), [
        detection((0, 0, 20, 20), [1, 0]),
        detection((50, 0, 70, 20), [0, 1]),
    ])
    tracker.add_frame('shot_000', .5, (100, 100), [
        detection((1, 0, 21, 20), [.38, .925]),
        detection((51, 0, 71, 20), [0, 1]),
    ])

    assert tracker.observations[0].track_id == tracker.observations[2].track_id
    assert tracker.observations[2].association_uncertain
    assert tracker.observations[1].track_id == tracker.observations[3].track_id


def test_turning_face_at_frame_edge_keeps_track_with_moderate_box_overlap():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_0387', 1133.5324, (1920, 1080), [
        detection((1850, 229, 1918, 365), [1, 0]),
        detection((1474, 379, 1568, 500), [0, 1]),
    ])
    tracker.add_frame('shot_0387', 1134.0329, (1920, 1080), [
        detection((1824, 239, 1916, 374), [.353, .935623]),
        detection((1469, 354, 1574, 491), [0, 1]),
    ])

    assert tracker.observations[0].track_id == tracker.observations[2].track_id
    assert tracker.observations[2].association_uncertain
    assert tracker.observations[1].track_id == tracker.observations[3].track_id


def test_weak_face_similarity_requires_a_strong_position_match():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (120, 100), [
        detection((0, 0, 20, 20), [1, 0]),
        detection((80, 0, 100, 20), [0, 1]),
    ])
    tracker.add_frame('shot_000', .5, (120, 100), [
        detection((8, 0, 28, 20), [.38, .925]),
    ])

    assert tracker.observations[0].track_id != tracker.observations[2].track_id


def test_strong_face_match_wins_over_a_closer_weak_position_match():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (100, 100), [
        detection((0, 0, 20, 20), [1, 0]),
        detection((8, 0, 28, 20), [0, 1]),
    ])
    tracker.add_frame('shot_000', .5, (100, 100), [
        detection((3, 0, 23, 20), [.38, .925]),
    ])

    assert tracker.observations[2].track_id == tracker.observations[1].track_id


def test_detection_confidence_is_preserved_for_representative_selection():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (100, 100), [detection((10, 10, 40, 40), [1, 0])])

    assert getattr(tracker.observations[0], 'detection_score', None) == .9


def test_same_frame_nested_face_detections_are_one_observation():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 4.5, (1280, 720), [
        detection((887, 296, 955, 397), [1, 0]),
        detection((826, 316, 955, 469), [0, 1]),
    ])
    assert len(tracker.observations) == 1


def test_shifted_duplicate_face_boxes_with_matching_embeddings_are_one_observation():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (1080, 1920), [
        detection((348, 938, 849, 1461), [1, 0]),
        detection((317, 679, 810, 1192), [.6, .8]),
    ])
    assert len(tracker.observations) == 1


def test_partially_overlapping_people_remain_two_observations():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 0.0, (100, 100), [
        detection((0, 0, 20, 20), [1, 0]),
        detection((10, 0, 30, 20), [0, 1]),
    ])
    assert len(tracker.observations) == 2


def test_one_face_moving_fast_within_a_shot_keeps_its_track():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 13.5, (1280, 720), [
        detection((831, 194, 896, 282), [1, 0]),
    ])
    tracker.add_frame('shot_000', 14.0, (1280, 720), [
        detection((719, 213, 789, 316), [1, 0]),
    ])

    assert tracker.observations[0].track_id == tracker.observations[1].track_id
    assert tracker.observations[1].association_uncertain
    assert group_observations(tracker.observations)[0].status == 'needs_review'


def test_fast_motion_fallback_does_not_link_when_two_people_were_visible():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 13.5, (1280, 720), [
        detection((831, 194, 896, 282), [1, 0]),
        detection((100, 194, 165, 282), [0, 1]),
    ])
    tracker.add_frame('shot_000', 14.0, (1280, 720), [
        detection((719, 213, 789, 316), [1, 0]),
    ])

    assert len({observation.track_id for observation in tracker.observations}) == 3


def test_fast_motion_fallback_does_not_link_visually_different_solo_faces():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 13.5, (1280, 720), [
        detection((831, 194, 896, 282), [1, 0]),
    ])
    tracker.add_frame('shot_000', 14.0, (1280, 720), [
        detection((719, 213, 789, 316), [0, 1]),
    ])

    assert tracker.observations[0].track_id != tracker.observations[1].track_id


def test_fast_motion_fallback_stops_at_shot_cut():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 13.5, (1280, 720), [
        detection((831, 194, 896, 282), [1, 0]),
    ])
    tracker.add_frame('shot_001', 14.0, (1280, 720), [
        detection((719, 213, 789, 316), [1, 0]),
    ])

    assert tracker.observations[0].track_id != tracker.observations[1].track_id


def test_color_cut_keeps_overlapping_faces_on_different_tracks():
    previous = np.full((36, 64, 3), (20, 20, 90), np.uint8)
    current = np.full((36, 64, 3), (90, 20, 20), np.uint8)
    assert _shot_changed(previous, current)

    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_000', 199.0, (1280, 720), [
        detection((769, 144, 1048, 508), [1, 0]),
    ])
    tracker.add_frame('shot_001', 199.5, (1280, 720), [
        detection((799, 264, 993, 492), [0, 1]),
    ])

    assert tracker.observations[0].track_id != tracker.observations[1].track_id
    assert len(group_observations(tracker.observations)) == 2


def test_expired_face_tracks_are_removed_from_live_matching_state():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_0', 0.0, (100, 100), [detection((0, 0, 20, 20), [1, 0])])
    tracker.add_frame('shot_0', 2.0, (100, 100), [])
    assert len(tracker._tracks) == 0
    tracker.add_frame('shot_0', 2.5, (100, 100), [detection((0, 0, 20, 20), [1, 0])])
    assert tracker.observations[0].track_id != tracker.observations[1].track_id


def test_shot_cut_discards_previous_face_matching_state():
    tracker = ObservationTracker(source_sha256='source', model_sha256='model', config_sha256='config')
    tracker.add_frame('shot_0', 0.0, (100, 100), [detection((0, 0, 20, 20), [1, 0])])
    tracker.add_frame('shot_1', 0.5, (100, 100), [])
    assert len(tracker._tracks) == 0


def test_video_analysis_only_retrieves_sampled_frames(tmp_path, monkeypatch):
    from person_highlight import analysis

    class Capture:
        def __init__(self):
            self.grabbed = 0
            self.retrieved = 0

        def isOpened(self):
            return True

        def get(self, property_id):
            return 30 if property_id == analysis.cv2.CAP_PROP_FPS else 90

        def grab(self):
            if self.grabbed == 90:
                return False
            self.grabbed += 1
            return True

        def retrieve(self):
            self.retrieved += 1
            return True, np.zeros((40, 40, 3), np.uint8)

        def release(self):
            pass

    capture = Capture()
    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: capture)
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')
    backend = type('Backend', (), {'model_sha256': 'model', 'config_sha256': 'config',
                                   'detect': lambda self, frame: []})()
    body_detector = type('BodyDetector', (), {'detect': lambda self, frame: []})()

    *_, shot_bounds = analyze_video(tmp_path / 'source.mp4', backend, body_detector)

    assert capture.grabbed == 90
    assert capture.retrieved == 6
    assert shot_bounds == {'shot_0000': (0.0, 3.0)}


def test_variable_frame_rate_uses_capture_pts_for_faces_bodies_and_cut(tmp_path, monkeypatch):
    from person_highlight import analysis
    from person_highlight.body_tracking import BodyDetection

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, property_id):
            if property_id == analysis.cv2.CAP_PROP_FPS:
                return .6
            if property_id == analysis.cv2.CAP_PROP_FRAME_COUNT:
                return 3
            if property_id == analysis.cv2.CAP_PROP_POS_MSEC:
                return (0., 1000., 5000.)[self.index]
            raise AssertionError(property_id)

        def grab(self):
            self.index += 1
            return self.index < 3

        def retrieve(self):
            color = (20, 20, 90) if self.index < 2 else (90, 200, 20)
            return True, np.full((100, 100, 3), color, np.uint8)

        def release(self):
            pass

    class Backend:
        model_sha256 = 'model'
        config_sha256 = 'config'

        def detect(self, _frame):
            return [detection((10, 10, 70, 70), [1, 0])]

    class Bodies:
        def detect(self, _frame):
            return [BodyDetection((0, 0, 90, 90), .9)]

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')
    faces, bodies, _, _, duration, _, bounds = analyze_video(
        tmp_path / 'source.mp4', Backend(), Bodies(), sample_fps=2.)

    assert [face.time_sec for face in faces] == [0., 1., 5.]
    assert [body.time_sec for body in bodies] == [0., 1., 5.]
    assert bounds['shot_0000'] == (0., 5.)
    assert duration > 5.


def test_missing_pts_after_long_vfr_gap_keeps_time_monotonic(tmp_path, monkeypatch):
    from person_highlight import analysis

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, property_id):
            if property_id == analysis.cv2.CAP_PROP_FPS:
                return 1
            if property_id == analysis.cv2.CAP_PROP_FRAME_COUNT:
                return 3
            return (0., 5000., 0.)[self.index]

        def grab(self):
            self.index += 1
            return self.index < 3

        def retrieve(self):
            return True, np.zeros((100, 100, 3), np.uint8)

        def release(self):
            pass

    class Backend:
        model_sha256 = 'model'
        config_sha256 = 'config'

        def detect(self, _frame):
            return [detection((10, 10, 70, 70), [1, 0])]

    class Bodies:
        def detect(self, _frame):
            return []

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')
    faces, *_ = analyze_video(tmp_path / 'source.mp4', Backend(), Bodies())

    assert [face.time_sec for face in faces] == [0., 5., 6.]


def test_vfr_duration_uses_container_duration_when_it_covers_last_pts(tmp_path, monkeypatch):
    from person_highlight import analysis

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, property_id):
            if property_id == analysis.cv2.CAP_PROP_FPS:
                return 4 / 6.04
            if property_id == analysis.cv2.CAP_PROP_FRAME_COUNT:
                return 4
            return (0., 1000., 5000., 6000.)[self.index]

        def grab(self):
            self.index += 1
            return self.index < 4

        def retrieve(self):
            return True, np.zeros((100, 100, 3), np.uint8)

        def release(self):
            pass

    class Backend:
        model_sha256 = 'model'
        config_sha256 = 'config'

        def detect(self, _frame):
            return []

    class Bodies:
        def detect(self, _frame):
            return []

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')
    _, _, _, _, duration, _, bounds = analyze_video(
        tmp_path / 'source.mp4', Backend(), Bodies())

    assert np.isclose(duration, 6.04)
    assert np.isclose(bounds['shot_0000'][1], 6.04)


def _analyze_constant_face_pts(tmp_path, monkeypatch, pts, fps):
    from person_highlight import analysis

    class Capture:
        index = -1

        def isOpened(self):
            return True

        def get(self, property_id):
            if property_id == analysis.cv2.CAP_PROP_FPS:
                return fps
            if property_id == analysis.cv2.CAP_PROP_FRAME_COUNT:
                return len(pts)
            if property_id == analysis.cv2.CAP_PROP_POS_MSEC:
                return pts[self.index] * 1000
            raise AssertionError(property_id)

        def grab(self):
            self.index += 1
            return self.index < len(pts)

        def retrieve(self):
            return True, np.zeros((200, 200, 3), np.uint8)

        def release(self):
            pass

    class Faces:
        model_sha256 = 'fixture'
        config_sha256 = 'fixture'

        def detect(self, _frame):
            return [FaceDetection((20, 20, 100, 100),
                                  np.array([1., 0.], np.float32), .95, .99, 'none')]

    class Bodies:
        def detect(self, _frame):
            return []

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'fixture')
    return analyze_video(tmp_path / 'source.mp4', Faces(), Bodies())


def test_vfr_sampling_follows_pts_targets_across_sparse_and_dense_sections(tmp_path, monkeypatch):
    pts = list(range(10)) + [10 + index / 60 for index in range(600)]
    faces, _, people, clips, *_ = _analyze_constant_face_pts(
        tmp_path, monkeypatch, pts, 30.5)

    assert [face.time_sec for face in faces[:6]] == [0., 1., 2., 3., 4., 5.]
    assert len(people) == 1
    assert len(clips) == 1
    assert clips[0]['source_start_sec'] == 0.
    assert clips[0]['source_end_sec'] >= 19.5


def test_sparse_held_frames_bridge_separate_face_intervals(tmp_path, monkeypatch):
    faces, _, people, clips, *_ = _analyze_constant_face_pts(
        tmp_path, monkeypatch, [0., 4., 8., 12.], 1.)

    assert [face.time_sec for face in faces] == [0., 4., 8., 12.]
    assert len(people) == 1
    assert len(people[0].intervals) == 1
    assert len(clips) == 1
    assert clips[0]['source_start_sec'] == 0.
    assert clips[0]['source_end_sec'] >= 12.5


def test_sub_48px_grid_faces_still_exclude_thumbnail_bodies(tmp_path, monkeypatch):
    from person_highlight import analysis
    from person_highlight.body_tracking import BodyDetection

    class Capture:
        index = 0

        def isOpened(self):
            return True

        def get(self, property_id):
            return 2 if property_id == analysis.cv2.CAP_PROP_FPS else 3

        def grab(self):
            self.index += 1
            return self.index <= 3

        def retrieve(self):
            return True, np.zeros((1080, 1920, 3), np.uint8)

        def release(self):
            pass

    class Backend:
        model_sha256 = 'model'
        config_sha256 = 'config'

        def detect(self, _frame):
            return [detection((100 + i * 190, 280, 140 + i * 190, 320), [1, i + 1])
                    for i in range(8)]

    class Bodies:
        def detect(self, _frame):
            return [BodyDetection((100 + i * 190, 250, 250 + i * 190, 470), .9)
                    for i in range(8)]

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')
    faces, bodies, people, clips, *_ = analyze_video(
        tmp_path / 'source.mp4', Backend(), Bodies())

    assert faces == []
    assert bodies == []
    assert people == []
    assert clips == []


def test_weak_or_tiny_faces_do_not_create_separate_people(tmp_path, monkeypatch):
    from person_highlight import analysis
    from person_highlight.body_tracking import BodyDetection

    class Capture:
        def __init__(self):
            self.index = 0

        def isOpened(self):
            return True

        def get(self, property_id):
            return 2 if property_id == analysis.cv2.CAP_PROP_FPS else 2

        def grab(self):
            self.index += 1
            return self.index <= 2

        def retrieve(self):
            return True, np.zeros((200, 200, 3), np.uint8)

        def release(self):
            pass

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')

    class Backend:
        model_sha256 = 'model'
        config_sha256 = 'config'

        def detect(self, _frame):
            if _frame.shape[:2] != (200, 200):
                return [FaceDetection((30, 30, 90, 90), np.array([1, 1], np.float32), .94, .9, 'none')]
            return [
                FaceDetection((20, 20, 45, 45), np.array([1, 0], np.float32), .94, .9, 'none'),
                FaceDetection((80, 20, 140, 80), np.array([0, 1], np.float32), .9, .80, 'none'),
                FaceDetection((80, 90, 140, 150), np.array([1, 1], np.float32), .94, .9, 'none'),
            ]

    class Bodies:
        def detect(self, _frame):
            return [BodyDetection((10, 10, 60, 190), .9, np.array([1, 0], np.float32)),
                    BodyDetection((70, 10, 160, 190), .9, np.array([0, 1], np.float32))]

    observations, body_observations, people, _, _, _, _ = analyze_video(
        tmp_path / 'source.mp4', Backend(), Bodies())

    assert len(observations) == 2
    assert all(observation.bbox_px == (80, 90, 140, 150) for observation in observations)
    assert len(body_observations) == 4
    assert len([person for person in people if person.group_id != 'unidentified']) == 1
    assert any(person.group_id == 'unidentified' for person in people)


def test_pose_changed_face_returns_to_one_person_after_tracking_gap(tmp_path, monkeypatch):
    from person_highlight import analysis

    class Capture:
        def __init__(self):
            self.index = 0

        def isOpened(self):
            return True

        def get(self, property_id):
            return 2 if property_id == analysis.cv2.CAP_PROP_FPS else 4

        def grab(self):
            self.index += 1
            return self.index <= 4

        def retrieve(self):
            return True, np.zeros((200, 200, 3), np.uint8)

        def release(self):
            pass

    class Backend:
        model_sha256 = 'auraface'
        config_sha256 = 'config'

        def __init__(self):
            self.index = 0

        def detect(self, _frame):
            if _frame.shape[:2] != (200, 200):
                return [detection((37, 37, 112, 112), [1, 0])]
            self.index += 1
            if self.index == 1:
                return [detection((50, 40, 125, 115), [1, 0])]
            if self.index == 4:
                return [detection((50, 40, 125, 115), [.52, .854166])]
            return []

    class Bodies:
        def detect(self, _frame):
            return []

    monkeypatch.setattr(analysis.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(analysis, 'sha256_file', lambda _path: 'source')

    faces, _, people, _, *_ = analyze_video(tmp_path / 'source.mp4', Backend(), Bodies())

    assert len({face.track_id for face in faces}) == 2
    assert len([person for person in people if person.observation_ids]) == 1




def test_unbacked_object_detection_is_rechecked_but_one_frame_face_is_kept():
    from person_highlight.analysis import _confirmed_detections
    frame = np.zeros((300, 400, 3), np.uint8)
    candidate = detection((100, 100, 200, 200), (1., 0.))
    class Backend:
        def __init__(self, results):
            self.results = results
        def detect(self, _crop):
            return self.results
    # The crop's coordinates differ from source coordinates; a separate nearby
    # face must not corroborate a false detection at the requested position.
    for results, expected in (([], []),
                              ([detection((0, 0, 40, 40), (1., 0.))], []),
                              ([detection((50, 50, 150, 150), (1., 0.))], [candidate])):
        assert _confirmed_detections(frame, [candidate], [], Backend(results)) == expected


def test_body_supported_face_does_not_need_an_extra_inference():
    from person_highlight.analysis import _confirmed_detections
    candidate = detection((40, 20, 100, 100), (1., 0.))
    class Backend:
        def detect(self, _crop):
            raise AssertionError('already corroborated by a body')
    bodies = [BodyObservation('body', 'shot', 0., (0, 0, 160, 300), .9, None)]
    assert _confirmed_detections(np.zeros((300, 400, 3), np.uint8),
                                 [candidate], bodies, Backend()) == [candidate]


def test_group_confirmation_preserves_a_weak_frame_of_an_established_face():
    from person_highlight.analysis import _retain_confirmed_groups
    faces = [FaceObservation(str(i), str(i), 'shot', float(i), (10, 10, 80, 80),
                             np.array(v, np.float32), .9)
             for i, v in enumerate([(1, 0), (1, 0), (0, 1)])]
    groups = group_observations(faces)
    kept, kept_groups = _retain_confirmed_groups(faces, groups, {'0'})
    assert {face.observation_id for face in kept} == {'0', '1'}
    assert len(kept_groups) == 1


def test_persistent_inset_and_letterbox_do_not_veto_main_picture_cut():
    from person_highlight.analysis import _continuous_faces_across_visual_change

    rng = np.random.default_rng(111)
    previous, current = [
        rng.integers(0, 70, (36, 64, 3), dtype=np.uint8) + np.array(color, np.uint8)
        for color in [(10, 30, 100), (100, 120, 10)]
    ]
    for frame in (previous, current):
        frame[:5] = 0
        frame[-5:] = 0
        frame[7:15, 51:63] = 100  # Persistent presenter inset.
    face = FaceDetection((1610, 240, 1730, 360), np.array([1., 0.], np.float32), .8, .9, 'none')
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    tracker.add_frame('shot_0', 0., (1920, 1080), [face])
    assert _shot_changed(previous, current)
    assert not _continuous_faces_across_visual_change(
        previous, current, tracker.observations, [face], .5, (1920, 1080))


def test_cut_veto_requires_correspondence_compatible_with_tracker():
    from person_highlight.analysis import _continuous_faces_across_visual_change

    def face(box, vector):
        return FaceDetection(box, np.array(vector, np.float32), .8, .9, 'none')
    rng = np.random.default_rng(41)
    previous = rng.integers(0, 150, (36, 64, 3), dtype=np.uint8)
    current = np.minimum(previous.astype(int) + 60, 255).astype(np.uint8)
    tracker = ObservationTracker(source_sha256='s', model_sha256='m', config_sha256='c')
    left, right = (50, 40, 150, 140), (100, 40, 200, 140)
    tracker.add_frame('shot_0', 0., (400, 300), [face(left, [1, 0, 0]), face(right, [0, 1, 0])])
    z = np.sqrt(1 - .7 ** 2 - .49 ** 2)
    next_faces = [face(right, [.7, .49, z]), face(left, [.49, .7, -z])]
    old_ids = [f.track_id for f in tracker.observations]
    assert _shot_changed(previous, current)
    veto = _continuous_faces_across_visual_change(previous, current, tracker.observations, next_faces, .5, (400, 300))
    tracker.add_frame('shot_0', .5, (400, 300), next_faces)
    actual_ids = [f.track_id for f in tracker.observations[2:]]
    # Accepted continuity must preserve the uniquely supported identities.
    assert not veto or actual_ids == old_ids
