from pathlib import Path
from threading import Event, current_thread
import json
import numpy as np
import pytest


def test_frame_inference_overlaps_but_never_queues_next_frame():
    from person_highlight.frame_inference import FrameInference
    body_started, face_started = Event(), Event()
    calls = []
    frame = np.zeros((8, 8, 3), np.uint8)

    def face(image):
        face_started.set()
        assert body_started.wait(2)
        calls.append(('face', id(image)))
        return ['face']

    class Body:
        def detect(self, image):
            body_started.set()
            assert face_started.wait(2)
            calls.append(('body', id(image)))
            return ['body']

    with FrameInference(face, Body(), parallel=True) as inference:
        assert inference.detect(frame) == (['face'], ['body'])
    assert sorted(calls) == [('body', id(frame)), ('face', id(frame))]


def test_frame_inference_joins_body_before_propagating_face_error():
    from person_highlight.frame_inference import FrameInference
    body_started, face_failed, body_done = Event(), Event(), Event()

    def face(_frame):
        assert body_started.wait(2)
        face_failed.set()
        raise ValueError('face failed')

    class Body:
        def detect(self, _frame):
            body_started.set()
            assert face_failed.wait(2)
            body_done.set()
            return []

    with pytest.raises(ValueError, match='face failed'):
        with FrameInference(face, Body(), parallel=True) as inference:
            inference.detect(np.zeros((8, 8, 3), np.uint8))
    assert body_done.is_set()


def test_frame_inference_serial_preserves_same_thread_and_propagates_body_error():
    from person_highlight.frame_inference import FrameInference
    threads = []

    def face(_frame):
        threads.append(current_thread())
        return []

    class Body:
        def detect(self, _frame):
            threads.append(current_thread())
            raise RuntimeError('body failed')

    with pytest.raises(RuntimeError, match='body failed'):
        with FrameInference(face, Body(), parallel=False) as inference:
            inference.detect(np.zeros((8, 8, 3), np.uint8))
    assert threads and all(thread is current_thread() for thread in threads)


def test_metrics_record_aggregate_work_and_wall_time_without_frame_data(tmp_path: Path):
    from person_highlight.performance import PerformanceStats
    stats = PerformanceStats()
    with stats.measure('faces'):
        stats.increment('frames')
    with stats.measure('faces'):
        stats.increment('frames', 2)
    result = stats.snapshot()
    assert result['wall_time_sec'] >= result['stages_sec']['faces'] >= 0
    assert result['stage_calls']['faces'] == 2
    assert result['counters']['frames'] == 3
    json.dumps(result)


def test_job_releases_all_models_before_speech_and_on_failure(tmp_path: Path, monkeypatch):
    from person_highlight import app
    from clipper_plugin_sdk.base import CancelFlag
    from clipper_plugin_sdk.models import JobRequest
    from person_highlight.occurrences import PersonGroup
    source = tmp_path / 'source.mp4'
    source.write_bytes(b'fake')
    backend = type('Backend', (), {'model_sha256': 'm', 'config_sha256': 'c', 'backend_id': 'b',
                                  'detect': lambda *_a, **_k: []})()
    body = type('Body', (), {'detect': lambda *_a: []})()
    group = PersonGroup('unknown', (), (), (), None, 'needs_review')
    monkeypatch.setattr(app, 'analyze_video', lambda *_a, **_k:
                        ([], [], [group], [], 1., 'source', {'s': (0., 1.)}))
    plugin = app.PersonHighlightPlugin()
    plugin._backend, plugin._body_detector = backend, body
    checked = []

    def speech(*_args, **_kwargs):
        checked.append(True)
        assert plugin._backend is None and plugin._body_detector is None
        return None

    monkeypatch.setattr(app, 'run_person_speech', speech)
    result = plugin.run_job(JobRequest(job_id='release', params={
        'video_path': str(source), 'output_root': str(tmp_path/'output')}), CancelFlag())
    assert result['status'] == 'completed' and checked
    assert json.loads((tmp_path/'output/json/performance.json').read_text())['stages_sec']
    plugin._backend, plugin._body_detector = backend, body

    def failed(*_a, **_k):
        raise InterruptedError('cancelled')

    monkeypatch.setattr(app, 'analyze_video', failed)
    with pytest.raises(InterruptedError):
        plugin.run_job(JobRequest(job_id='cancel', params={
            'video_path': str(source), 'output_root': str(tmp_path/'output')}), CancelFlag())
    assert plugin._backend is None and plugin._body_detector is None


def test_failed_job_frees_traceback_model_references_before_gpu_cache_flush(tmp_path, monkeypatch):
    import sys
    import weakref
    from types import SimpleNamespace
    from person_highlight import app
    from clipper_plugin_sdk.base import CancelFlag
    from clipper_plugin_sdk.models import JobRequest

    class Backend:
        model_sha256, config_sha256, backend_id = 'm', 'c', 'b'
        def detect(self, *_a, **_k):
            return []

    class Body:
        pass

    plugin = app.PersonHighlightPlugin()
    plugin._backend, plugin._body_detector, plugin._device = Backend(), Body(), 'mps'
    face_ref, body_ref = weakref.ref(plugin._backend), weakref.ref(plugin._body_detector)
    observed = []
    monkeypatch.setitem(sys.modules, 'torch', SimpleNamespace(mps=SimpleNamespace(
        empty_cache=lambda: observed.append((face_ref() is None, body_ref() is None)))))

    def failed(_path, backend, body, **kwargs):
        raise RuntimeError('failed inference')

    monkeypatch.setattr(app, 'analyze_video', failed)
    source = tmp_path/'input.mp4'
    source.write_bytes(b'test')
    with pytest.raises(RuntimeError, match='failed inference'):
        plugin.run_job(JobRequest(job_id='failure', params={
            'video_path': str(source), 'output_root': str(tmp_path/'output')}), CancelFlag())
    assert observed == [(True, True)]


@pytest.mark.parametrize('device,available,expected', [
    ('cpu', 8 * 1024**3, False), ('mps', 2 * 1024**3, True),
    ('cuda:0', 2 * 1024**3, True), ('mps', 2 * 1024**3 - 1, False),
])
def test_parallel_inference_requires_memory_headroom(monkeypatch, device, available, expected):
    import sys
    from types import SimpleNamespace
    from person_highlight.frame_inference import allow_parallel_inference
    monkeypatch.setitem(sys.modules, 'psutil', SimpleNamespace(
        virtual_memory=lambda: SimpleNamespace(available=available)))
    assert allow_parallel_inference(device) is expected


def test_parallel_inference_falls_back_when_memory_measurement_fails(monkeypatch):
    import sys
    from types import SimpleNamespace
    from person_highlight.frame_inference import allow_parallel_inference
    def unavailable():
        raise OSError('memory query unavailable')
    monkeypatch.setitem(sys.modules, 'psutil', SimpleNamespace(virtual_memory=unavailable))
    assert not allow_parallel_inference('mps')
