from clipper_speech_core import TimedTranscript, TimedWord
from person_highlight.clip_composer import compose_person_clips
from person_highlight.occurrences import PersonGroup, PersonInterval


def person(person_id, *intervals, face=True):
    return PersonGroup(person_id, ("track",), ("face",) if face else (),
                       tuple(PersonInterval(shot, start, end) for shot, start, end in intervals),
                       "face" if face else None, "grouped" if face else "needs_review")


def words(*bounds):
    return TimedTranscript((), tuple(TimedWord(start, end, "말") for start, end in bounds),
                           "small", "cpu", "int8", "ko", 1.0, 60.0)


SHOTS = {"shot_0": (0., 5.), "shot_1": (5., 20.)}


def compose(groups, transcript=None, duration=20., shots=SHOTS):
    return compose_person_clips(groups, [], shots, transcript, duration)


def test_same_shot_detection_gap_becomes_one_clip_but_two_exact_appearances():
    clips = compose([person("person_1", ("shot_0", 1., 2.), ("shot_0", 3.5, 4.))])
    assert len(clips) == 1
    assert [(span["start_sec"], span["end_sec"]) for span in clips[0]["appearance_spans"]] == [
        (1., 2.), (3.5, 4.)]
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (.75, 4.25)


def test_confirmed_face_across_cut_uses_continuous_speech_as_clip_bridge():
    clips = compose([person("person_1", ("shot_0", 1., 2.), ("shot_1", 6., 7.))],
                    words((1., 2.4), (2.7, 3.7), (4., 5.), (5.3, 6.5)))
    assert len(clips) == 1
    assert len(clips[0]["appearance_spans"]) == 2
    assert clips[0]["appearance_spans"][0]["end_sec"] == 2.
    assert clips[0]["appearance_spans"][1]["start_sec"] == 6.


def test_speech_pause_prevents_cross_cut_bridge():
    clips = compose([person("person_1", ("shot_0", 1., 2.), ("shot_1", 6., 7.))],
                    words((1., 2.), (4., 5.), (6., 7.)))
    assert len(clips) == 2


def test_short_speech_pause_at_a_cut_keeps_continuously_visible_person_together():
    clips = compose([person("person_1", ("shot_0", 3., 5.),
                            ("shot_1", 5., 7.))],
                    words((3., 4.2), (5.8, 7.)))
    assert len(clips) == 1
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (2.75, 7.25)


def test_silent_cross_cut_return_within_two_seconds_joins_confirmed_face():
    shots = {"shot_0": (0., 5.), "shot_1": (5., 20.)}
    clips = compose([person("person_1", ("shot_0", 4., 4.5), ("shot_1", 5.5, 6.))],
                    shots=shots)
    assert len(clips) == 1


def test_body_only_cross_cut_needs_review_and_does_not_assert_identity():
    clips = compose([person("unidentified", ("shot_0", 4., 4.5),
                            ("shot_1", 5.5, 6.), face=False)])
    assert len(clips) == 2
    assert all(clip["needs_review"] for clip in clips)
    assert all(span["needs_review"] for clip in clips for span in clip["appearance_spans"])


def test_one_body_track_in_same_shot_bridges_short_detector_miss():
    body = PersonGroup("unidentified", ("body_1",), (),
                       (PersonInterval("shot_0", 1., 2., track_id="body_1"),
                        PersonInterval("shot_0", 3., 4., track_id="body_1")),
                       None, "needs_review")
    clips = compose([body])
    assert len(clips) == 1
    assert len(clips[0]["appearance_spans"]) == 2


def test_overlapping_unidentified_tracks_are_one_reviewable_scene_not_multiple_people():
    unknown = PersonGroup("unidentified", ("body_1", "body_2"), (),
                          (PersonInterval("shot_0", 1., 3., track_id="body_1"),
                           PersonInterval("shot_0", 1.5, 2.5, track_id="body_2")),
                          None, "needs_review")
    clips = compose([unknown])
    assert len(clips) == 1
    assert clips[0]["person_ids"] == ["unidentified"]
    assert clips[0]["needs_review"] is True
    assert [(span["start_sec"], span["end_sec"]) for span in clips[0]["appearance_spans"]] == [(1., 3.)]


def test_unidentified_presence_overlapping_known_person_is_review_on_that_scene():
    unknown = PersonGroup("unidentified", ("body_2",), (),
                          (PersonInterval("shot_0", 2., 3., track_id="body_2"),),
                          None, "needs_review")
    clips = compose([person("person_1", ("shot_0", 1., 4.)), unknown])
    assert len(clips) == 1
    assert clips[0]["person_ids"] == ["person_1", "unidentified"]
    assert len(clips[0]["appearance_spans"]) == 2
    assert clips[0]["needs_review"] is True


def test_unknown_tail_beyond_named_padding_remains_separately_reviewable():
    unknown = PersonGroup("unidentified", ("body_2",), (),
                          (PersonInterval("shot_1", 5.5, 6.4, track_id="body_2"),),
                          None, "needs_review")
    clips = compose([person("person_1", ("shot_1", 5., 6.)), unknown])
    assert len(clips) == 2
    assert clips[0]["appearance_start_sec"] == 5.
    assert clips[0]["appearance_end_sec"] == 6.25
    assert clips[0]["source_end_sec"] == 6.25
    assert clips[1]["person_ids"] == ["unidentified"]
    assert clips[1]["appearance_start_sec"] == 6.25
    assert clips[1]["appearance_end_sec"] == 6.4


def test_unidentified_presence_outside_known_scene_stays_reviewable_on_its_own():
    unknown = PersonGroup("unidentified", ("body_2",), (),
                          (PersonInterval("shot_0", 3., 4., track_id="body_2"),),
                          None, "needs_review")
    clips = compose([person("person_1", ("shot_0", 1., 2.)), unknown])
    assert len(clips) == 2
    assert clips[1]["person_ids"] == ["unidentified"]


def test_two_people_in_same_shot_keep_independent_overlapping_clips():
    clips = compose([person("person_1", ("shot_0", 1., 4.)),
                     person("person_2", ("shot_0", 2., 3.))])
    assert len(clips) == 2
    assert [clip["person_ids"] for clip in clips] == [["person_1"], ["person_2"]]
    assert clips[0]["source_end_sec"] > clips[1]["source_start_sec"]


def test_two_people_with_identical_bounds_share_one_virtual_clip_and_distinct_spans():
    clips = compose([person("person_1", ("shot_0", 1., 3.)),
                     person("person_2", ("shot_0", 1., 3.))])
    assert len(clips) == 1
    assert clips[0]["person_ids"] == ["person_1", "person_2"]
    assert {(span["person_id"], span["start_sec"], span["end_sec"])
            for span in clips[0]["appearance_spans"]} == {
                ("person_1", 1., 3.), ("person_2", 1., 3.)}


def test_dialogue_event_across_cuts_keeps_playback_local_to_each_person():
    shots = {"shot_0": (0., 5.), "shot_1": (5., 12.)}
    clips = compose([person("person_1", ("shot_0", 1., 2.)),
                     person("person_2", ("shot_1", 7., 8.))],
                    words((1., 2.), (2.3, 3.2), (3.5, 4.5), (4.8, 5.6),
                          (5.9, 6.8), (7., 8.)), duration=12., shots=shots)
    assert [(clip["person_ids"], clip["source_start_sec"], clip["source_end_sec"])
            for clip in clips] == [(["person_1"], .75, 2.25), (["person_2"], 6.75, 8.25)]


def test_brief_lead_in_dialogue_does_not_claim_the_other_persons_long_scene():
    shots = {"shot_0": (0., 120.)}
    speech = words(*((86.9 + index * .75, 87.45 + index * .75)
                     for index in range(25)))
    clips = compose([person("person_1", ("shot_0", 86.52, 87.52)),
                     person("person_2", ("shot_0", 87.521, 106.005))],
                    speech, duration=120., shots=shots)
    assert [(clip["person_ids"], clip["source_start_sec"], clip["source_end_sec"])
            for clip in clips] == [
                (["person_1"], 86.27, 87.77),
                (["person_2"], 87.271, 106.255),
            ]


def test_speech_before_a_brief_appearance_does_not_extend_its_clip_backwards():
    shots = {"shot_0": (0., 150.)}
    speech = words(*((110.28 + index * .55, 110.7 + index * .55)
                     for index in range(40)))
    clips = compose([person("person_2", ("shot_0", 112.58, 115.014)),
                     person("person_3", ("shot_0", 115.015, 132.2))],
                    speech, duration=150., shots=shots)
    brief = next(clip for clip in clips if "person_2" in clip["person_ids"])
    assert brief["person_ids"] == ["person_2"]
    assert (brief["source_start_sec"], brief["source_end_sec"]) == (112.33, 115.264)


def test_people_visible_together_during_speech_still_share_a_clip():
    clips = compose([person("person_1", ("shot_0", 1., 3.)),
                     person("person_2", ("shot_0", 1., 3.))],
                    words((1., 2.), (2.2, 3.)), duration=5.,
                    shots={"shot_0": (0., 5.)})
    assert len(clips) == 1
    assert clips[0]["person_ids"] == ["person_1", "person_2"]


def test_partial_coappearance_keeps_the_shorter_persons_speech_clip_local():
    clips = compose([person("person_1", ("shot_0", 0., 20.)),
                     person("person_2", ("shot_0", 5., 15.))],
                    words(*((5. + index * .9, 5.7 + index * .9) for index in range(11))),
                    duration=20., shots={"shot_0": (0., 20.)})
    shorter = next(clip for clip in clips if "person_2" in clip["person_ids"])
    assert shorter["person_ids"] == ["person_2"]
    assert (shorter["source_start_sec"], shorter["source_end_sec"]) == (4.75, 15.25)


def test_people_covisible_across_a_cut_keep_the_early_persons_unique_appearance():
    clips = compose([person("person_1", ("shot_0", 4., 5.), ("shot_1", 5., 7.)),
                     person("person_2", ("shot_1", 5., 7.))],
                    words((4., 4.8), (5., 5.8), (6., 6.8)), duration=12.,
                    shots={"shot_0": (0., 5.), "shot_1": (5., 12.)})
    assert [(c["person_ids"], c["source_start_sec"], c["source_end_sec"])
            for c in clips] == [(["person_1"], 3.75, 7.25), (["person_2"], 5., 7.25)]
    assert clips[0]["appearance_spans"][0]["start_sec"] == 4.


def test_dialogue_event_splits_at_cut_with_clear_pause():
    clips = compose([person("person_1", ("shot_0", 3., 5.),
                            ("shot_1", 5., 7.))],
                    words((3., 3.4), (6.6, 7.)))
    assert len(clips) == 2
    assert clips[0]["appearance_spans"][0]["end_sec"] == 5.
    assert clips[1]["appearance_spans"][0]["start_sec"] == 5.


def test_continuous_dialogue_within_playback_limit_is_not_split_by_speech_window_size():
    speech = words(*((float(index), float(index) + .8) for index in range(40)))
    clips = compose([person("person_1", ("shot_0", 0., 40.))], speech,
                    duration=40., shots={"shot_0": (0., 40.)})
    assert len(clips) == 1
    assert all(clip["source_end_sec"] - clip["source_start_sec"] <= 45. for clip in clips)
    assert [(span["start_sec"], span["end_sec"])
            for clip in clips for span in clip["appearance_spans"]] == [(0., 40.)]


def test_two_second_return_tolerates_frame_timestamp_drift_without_filling_face_gap():
    clips = compose([person("person_1", ("shot_0", 1., 4.),
                            ("shot_1", 6.0025, 9.))])
    assert len(clips) == 1
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (.75, 9.25)
    assert [(s["start_sec"], s["end_sec"]) for s in clips[0]["appearance_spans"]] == [
        (1., 4.), (6.003, 9.)]


def test_real_scenes_595_600_608_join_across_brief_absence_and_speech_pause():
    shots = {
        "shot_0430": (1252.517933, 1256.521933),
        "shot_0431": (1256.521933, 1258.523933),
        "shot_0432": (1258.523933, 1264.029433),
        "shot_0433": (1264.029433, 1265.530933),
        "shot_0434": (1265.530933, 1267.532933),
        "shot_0435": (1267.532933, 1274.506567),
    }
    group = PersonGroup("person_003", ("track",), ("face",), (
        PersonInterval("shot_0430", 1252.517933, 1256.521433),
        PersonInterval("shot_0432", 1258.523933, 1265.530433,
                       shot_ids=("shot_0432", "shot_0433")),
        PersonInterval("shot_0435", 1267.532933, 1270.001567),
        PersonInterval("shot_0435", 1271.503567, 1274.506067),
    ), "face", "grouped")
    speech = words((1248.82, 1251.26), (1251.98, 1252.62), (1253.36, 1254.),
                   (1263.82, 1264.98), (1266.46, 1267.44), (1268.2, 1269.32),
                   (1270.08, 1270.38), (1271.88, 1273.18), (1273.92, 1274.24))
    clips = compose([group], speech, duration=1345.377, shots=shots)
    assert len(clips) == 1
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (1252.518, 1274.507)
    assert [(s["start_sec"], s["end_sec"]) for s in clips[0]["appearance_spans"]] == [
        (1252.518, 1256.521), (1258.524, 1265.53),
        (1267.533, 1270.002), (1271.504, 1274.506)]


def test_sparse_reactions_are_not_combined_into_a_mostly_absent_persons_scene():
    clips = compose([person("person_1", ("shot_0", 1., 1.5),
                            ("shot_1", 3.5025, 4.))],
                    duration=5., shots={"shot_0": (0., 2.), "shot_1": (2., 5.)})
    assert len(clips) == 2
    assert [(c["source_start_sec"], c["source_end_sec"]) for c in clips] == [
        (.75, 1.75), (3.252, 4.25)]


def test_long_absence_and_different_identities_stay_separate():
    clips = compose([person("person_1", ("shot_0", 0., 5.), ("shot_1", 10., 15.)),
                     person("person_2", ("shot_1", 15.1, 19.))])
    assert len(clips) == 3
    assert [c["person_ids"] for c in clips] == [["person_1"], ["person_1"], ["person_2"]]


def test_isolated_word_does_not_pull_a_long_visual_span_into_one_speech_scene():
    clips = compose([person("person_1", ("shot_0", 0., 90.))],
                    words((43.5, 44.5)), duration=90., shots={"shot_0": (0., 90.)})
    assert all(clip["source_end_sec"] - clip["source_start_sec"] <= 45.
               for clip in clips)
    assert clips[0]["source_start_sec"] == 0.
    assert clips[-1]["source_end_sec"] == 90.


def test_continuous_action_around_a_short_utterance_stays_one_scene():
    clips = compose([person("person_1", ("shot_0", 0., 18.))],
                    words((8.5, 9.5)), duration=18., shots={"shot_0": (0., 18.)})
    assert len(clips) == 1
    assert clips[0]["source_start_sec"] == 0.
    assert clips[0]["source_end_sec"] == 18.
    assert clips[0]["appearance_spans"][0]["start_sec"] == 0.
    assert clips[0]["appearance_spans"][0]["end_sec"] == 18.


def test_long_continuous_appearance_splits_at_45_second_playback_limit():
    clips = compose([person("person_1", ("shot_0", 0., 60.))], duration=60.,
                    shots={"shot_0": (0., 60.)})
    assert len(clips) >= 2
    assert all(0 < clip["source_end_sec"] - clip["source_start_sec"] <= 45.
               for clip in clips)
    assert clips[0]["appearance_spans"][0]["start_sec"] == 0.
    assert clips[-1]["appearance_spans"][-1]["end_sec"] == 60.


def test_real_brief_appearance_only_gets_quarter_second_padding():
    clips = compose([person("person_1", ("shot_1", 10., 10.3))])
    assert len(clips) == 1
    assert (clips[0]["appearance_start_sec"], clips[0]["appearance_end_sec"]) == (10., 10.3)
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (9.75, 10.55)


def test_no_speech_keeps_visual_clips_and_marks_audio_limitation():
    clips = compose([person("person_1", ("shot_0", 1., 2.))], words())
    assert len(clips) == 1
    assert "speech_unavailable" in clips[0]["boundary_reasons"]


def test_scene_404_shared_people_keep_their_own_tail_and_intermittent_appearances():
    clips = compose([
        person("person_019", ("shot_0311", 879.512, 894.026)),
        person("person_145", ("shot_0311", 879.512, 882.014),
               ("shot_0311", 883.015, 896.528)),
        person("unidentified", ("shot_0311", 879.512, 896.528), face=False),
    ], words(*((880. + index, 880.8 + index) for index in range(16))),
        duration=900., shots={"shot_0311": (879.512, 900.)})
    selected = next(c for c in clips if "person_019" in c["person_ids"])
    other = next(c for c in clips if "person_145" in c["person_ids"])
    assert (selected["source_start_sec"], selected["source_end_sec"]) == (879.512, 894.276)
    assert other["source_end_sec"] == 896.778
    assert [(s["start_sec"], s["end_sec"]) for s in other["appearance_spans"]
            if s["person_id"] == "person_145"] == [(879.512, 882.014), (883.015, 896.528)]
    assert sum("person_019" in c["person_ids"] for c in clips) == 1
    assert sum("person_145" in c["person_ids"] for c in clips) == 1


def test_near_identical_people_keep_divergent_bounds_without_losing_early_appearance():
    clips = compose([person("person_1", ("shot_0", 1., 4.)),
                     person("person_2", ("shot_0", 1.2, 4.1))])
    assert [(c["person_ids"], c["source_start_sec"], c["source_end_sec"])
            for c in clips] == [(["person_1"], .75, 4.25), (["person_2"], .95, 4.35)]
    assert clips[0]["appearance_spans"][0]["start_sec"] == 1.


def test_padding_and_nearby_speech_stop_at_validated_scene_edges():
    clips = compose([person("person_1", ("shot_1", 5.1, 9.9))],
                    words((4., 5.2), (5.4, 6.4), (6.6, 7.6), (7.8, 8.8), (9., 11.)),
                    duration=15., shots={"shot_0": (0., 5.), "shot_1": (5., 10.),
                                         "shot_2": (10., 15.)})
    assert len(clips) == 1
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (5., 10.)


def test_speech_event_padding_does_not_cross_a_clear_scene_transition():
    clips = compose([person("person_1", ("shot_0", 3., 5.), ("shot_1", 5., 7.))],
                    words((3., 3.4), (6.6, 7.)))
    assert [(c["source_start_sec"], c["source_end_sec"]) for c in clips] == [
        (2.75, 5.), (5., 7.25)]


def test_nearby_speech_cannot_extend_person_relative_padding():
    clips = compose([person("person_1", ("shot_1", 10., 10.3))],
                    words((8., 9.2), (9.5, 11.5)))
    assert len(clips) == 1
    assert (clips[0]["source_start_sec"], clips[0]["source_end_sec"]) == (9.75, 10.55)
