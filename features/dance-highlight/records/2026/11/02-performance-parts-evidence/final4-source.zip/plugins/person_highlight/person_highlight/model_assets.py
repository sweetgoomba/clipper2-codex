"""Prepare the same verified YuNet/AuraFace assets used by Dance Highlight."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Callable, Sequence
from urllib.request import urlopen
from clipper_face_core.face_models import (
    AURAFACE_FILENAME, AURAFACE_URL, AURAFACE_SHA256, AURAFACE_SIZE,
)


FACE_MODEL_SPECS = (
    ("detector", "face_detection_yunet_2023mar.onnx",
     "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
     "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4", 232589),
    ("recognizer", AURAFACE_FILENAME, AURAFACE_URL, AURAFACE_SHA256, AURAFACE_SIZE),
)


def face_model_dir() -> Path:
    return Path(os.environ.get("CLIPPER_PERSON_FACE_MODEL_DIR")
                or os.environ.get("CLIPPER_DANCE_FACE_MODEL_DIR")
                or Path.cwd() / "plugin_models" / "dance_highlight")


def resolve_pose_model_path() -> Path:
    override = os.environ.get("CLIPPER_PERSON_POSE_MODEL_PATH")
    return Path(override) if override else Path("yolov8s-pose.pt")


def _valid(path: Path, size: int, expected_hash: str) -> bool:
    try:
        if path.stat().st_size != size:
            return False
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest() == expected_hash
    except OSError:
        return False


def _download(url: str, target: Path) -> None:
    with urlopen(url, timeout=120) as response, target.open("wb") as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)


def ensure_face_models(
    model_dir: Path | None = None, *,
    specs: Sequence[tuple[str, str, str, str, int]] = FACE_MODEL_SPECS,
    downloader: Callable[[str, Path], None] = _download,
) -> dict[str, Path]:
    directory = model_dir or face_model_dir()
    directory.mkdir(parents=True, exist_ok=True)
    paths: dict[str, Path] = {}
    for name, filename, url, digest, size in specs:
        target = directory / filename
        paths[name] = target
        if _valid(target, size, digest):
            continue
        part = target.with_name(target.name + ".part")
        part.unlink(missing_ok=True)
        try:
            downloader(url, part)
            if not _valid(part, size, digest):
                raise RuntimeError(f"Face model verification failed: {name}")
            part.replace(target)
        finally:
            part.unlink(missing_ok=True)
    return paths


def detect_yolo_device() -> str:
    import torch
    if torch.cuda.is_available():
        return "cuda:0"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"
