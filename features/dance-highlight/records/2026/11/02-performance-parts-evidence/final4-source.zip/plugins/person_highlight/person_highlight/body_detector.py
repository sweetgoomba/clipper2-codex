"""All-person YOLO detection for Person Highlight; no Dance selection policy."""

from __future__ import annotations

from pathlib import Path
from typing import Callable
import cv2
import numpy as np

from .body_tracking import BodyDetection, _iou


class YoloBodyDetector:
    def __init__(self, model_path: str | Path, *, device: str = "cpu",
                 model_factory: Callable | None = None):
        if model_factory is None:
            from ultralytics import YOLO
            model_factory = YOLO
        self.model_path = str(model_path)
        self.device = device
        self._model = model_factory(self.model_path)

    @staticmethod
    def _appearance(frame: np.ndarray, box: tuple[int, int, int, int]) -> np.ndarray:
        height, width = frame.shape[:2]
        x1, y1, x2, y2 = box
        x1, x2 = max(0, x1), min(width, x2)
        y1, y2 = max(0, y1), min(height, y2)
        if x2 <= x1 or y2 <= y1:
            return np.zeros(64, np.float32)
        crop = frame[y1:y2, x1:x2]
        left, right = int(crop.shape[1] * .2), max(1, int(crop.shape[1] * .8))
        top, bottom = int(crop.shape[0] * .2), max(1, int(crop.shape[0] * .75))
        torso = crop[top:bottom, left:right]
        if not torso.size:
            torso = crop
        hsv = cv2.cvtColor(torso, cv2.COLOR_BGR2HSV)
        histogram = cv2.calcHist([hsv], [0, 1], None, [8, 8], [0, 180, 0, 256])
        vector = histogram.astype(np.float32).reshape(-1)
        norm = float(np.linalg.norm(vector))
        return vector / norm if norm > 1e-8 else vector

    def detect(self, frame: np.ndarray) -> list[BodyDetection]:
        results = self._model(frame, conf=.1, classes=[0], device=self.device, verbose=False)
        if not results or results[0].boxes is None:
            return []
        boxes = results[0].boxes
        coords = boxes.xyxy.cpu().numpy()
        scores = boxes.conf.cpu().numpy()
        classes = boxes.cls.cpu().numpy()
        people: list[BodyDetection] = []
        for coords_row, score, category in zip(coords, scores, classes, strict=True):
            if int(category) != 0:
                continue
            box = tuple(int(round(float(value))) for value in coords_row)
            if box[2] <= box[0] or box[3] <= box[1]:
                continue
            people.append(BodyDetection(box, float(score), self._appearance(frame, box)))
        kept: list[BodyDetection] = []
        for candidate in sorted(people, key=lambda item: item.score, reverse=True):
            if any(_iou(candidate.bbox_px, previous.bbox_px) >= .6
                   and float(np.dot(candidate.appearance, previous.appearance)) >= .9
                   for previous in kept):
                continue
            kept.append(candidate)
        return kept
