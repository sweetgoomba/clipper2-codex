from pathlib import Path
import json
import os
import stat

import numpy as np
import pytest

from clipper_face_core import FaceObservation


def _observations(*vectors):
    return [FaceObservation(
        observation_id=f"observation_{index}", track_id="track_0", shot_id="shot_0",
        time_sec=float(index), bbox_px=(1, 2, 20, 30), embedding=vector, quality=.9,
    ) for index, vector in enumerate(vectors)]


def _manifest(observations):
    return {
        "schema_version": "person-highlight.v3", "groups": [], "clips": [],
        "observations": [{"observation_id": item.observation_id, "time_sec": item.time_sec}
                         for item in observations],
    }


def test_result_keeps_metadata_lean_and_round_trips_float32_vectors(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings, write_person_result

    vectors = [np.array([.1, -.2, .3], np.float32), None,
               np.array([.7, .8, -.9], np.float32)]
    observations = _observations(*vectors)
    manifest = _manifest(observations)

    path = write_person_result(tmp_path, manifest, observations)

    assert path == tmp_path / "json/person_highlight.json"
    saved = json.loads(path.read_text())
    assert saved["groups"] == []
    assert saved["clips"] == []
    assert [row["embedding_row"] for row in saved["observations"]] == [0, None, 1]
    assert all("embedding" not in row for row in saved["observations"])
    assert "embedding_storage" not in manifest
    assert all("embedding_row" not in row for row in manifest["observations"])
    storage = saved["embedding_storage"]
    assert storage["format"] == "npy"
    assert storage["dtype"] == "float32"
    assert storage["shape"] == [2, 3]
    matrix = np.load(tmp_path / storage["path"], allow_pickle=False)
    assert matrix.dtype == np.dtype("float32")
    np.testing.assert_array_equal(matrix, np.array([[.1, -.2, .3], [.7, .8, -.9]], np.float32))
    loaded = load_person_embeddings(tmp_path, saved)
    np.testing.assert_array_equal(loaded[0], vectors[0])
    assert loaded[1] is None
    np.testing.assert_array_equal(loaded[2], vectors[2])


def test_legacy_inline_vectors_remain_readable(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings

    manifest = {"observations": [{"embedding": [.25, -.5]}, {"embedding": None}, {}]}
    loaded = load_person_embeddings(tmp_path, manifest)

    np.testing.assert_array_equal(loaded[0], np.array([.25, -.5], np.float32))
    assert loaded[0].dtype == np.dtype("float32")
    assert loaded[1:] == [None, None]


@pytest.mark.parametrize("vectors", [[], [None, None]])
def test_empty_embeddings_keep_observation_positions(tmp_path: Path, vectors):
    from person_highlight.result_storage import load_person_embeddings, write_person_result

    observations = _observations(*vectors)
    path = write_person_result(tmp_path, _manifest(observations), observations)
    manifest = json.loads(path.read_text())

    assert manifest["embedding_storage"]["shape"] == [0, 0]
    assert load_person_embeddings(tmp_path, manifest) == vectors


def test_save_succeeds_when_file_sync_requires_a_writable_handle(tmp_path: Path, monkeypatch):
    from person_highlight.result_storage import load_person_embeddings, write_person_result

    fsync = os.fsync

    def sync_writable_file(descriptor):
        if stat.S_ISREG(os.fstat(descriptor).st_mode):
            # Like Windows FlushFileBuffers, reject read-only file handles.
            # A zero-byte write checks access without altering file contents.
            os.write(descriptor, b"")
        fsync(descriptor)

    monkeypatch.setattr(os, "fsync", sync_writable_file)
    observations = _observations(np.array([.25, -.5], np.float32))

    path = write_person_result(tmp_path, _manifest(observations), observations)

    saved = json.loads(path.read_text())
    np.testing.assert_array_equal(load_person_embeddings(tmp_path, saved)[0], [.25, -.5])


def test_a_new_generation_preserves_previously_loaded_manifest(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings, write_person_result

    old = _observations(np.array([1, 0], np.float32))
    path = write_person_result(tmp_path, _manifest(old), old)
    old_manifest = json.loads(path.read_text())
    new = _observations(np.array([0, 1], np.float32))

    write_person_result(tmp_path, _manifest(new), new)

    new_manifest = json.loads(path.read_text())
    assert new_manifest["embedding_storage"]["path"] != old_manifest["embedding_storage"]["path"]
    np.testing.assert_array_equal(load_person_embeddings(tmp_path, old_manifest)[0], [1, 0])
    np.testing.assert_array_equal(load_person_embeddings(tmp_path, new_manifest)[0], [0, 1])


@pytest.mark.parametrize("failure", ["json", "publish_array", "publish_manifest", "sync"])
def test_failed_save_preserves_previous_result_and_removes_partial_files(
        tmp_path: Path, monkeypatch, failure):
    from person_highlight.result_storage import load_person_embeddings, write_person_result

    old = _observations(np.array([1, 0], np.float32))
    path = write_person_result(tmp_path, _manifest(old), old)
    original = path.read_bytes()
    original_files = {item.relative_to(tmp_path) for item in tmp_path.rglob("*") if item.is_file()}
    new = _observations(np.array([0, 1], np.float32))
    manifest = _manifest(new)
    if failure == "json":
        manifest["invalid"] = object()
    elif failure == "sync":
        def fail_sync(_fd):
            raise OSError("disk sync failed")
        monkeypatch.setattr(os, "fsync", fail_sync)
    else:
        replace = os.replace

        def fail_publish(source, target):
            if ((failure == "publish_manifest" and Path(target) == path)
                    or (failure == "publish_array" and Path(target).suffix == ".npy")):
                raise OSError("disk replace failed")
            replace(source, target)

        monkeypatch.setattr(os, "replace", fail_publish)

    with pytest.raises((TypeError, OSError)):
        write_person_result(tmp_path, manifest, new)

    assert path.read_bytes() == original
    assert {item.relative_to(tmp_path) for item in tmp_path.rglob("*") if item.is_file()} == original_files
    np.testing.assert_array_equal(load_person_embeddings(tmp_path, json.loads(original))[0], [1, 0])


@pytest.mark.parametrize("vectors", [
    [np.array([[1, 2]], np.float32)], [np.array([], np.float32)],
    [np.array([1, np.nan], np.float32)], [np.array([1, np.inf], np.float32)],
    [np.array([1, 2], np.float32), np.array([1, 2, 3], np.float32)],
])
def test_writer_rejects_invalid_vectors_without_leaving_files(tmp_path: Path, vectors):
    from person_highlight.result_storage import write_person_result

    observations = _observations(*vectors)
    with pytest.raises(ValueError):
        write_person_result(tmp_path, _manifest(observations), observations)

    assert not [item for item in tmp_path.rglob("*") if item.is_file()]


@pytest.mark.parametrize("mismatch", ["count", "order"])
def test_writer_rejects_metadata_that_does_not_match_observations(tmp_path: Path, mismatch):
    from person_highlight.result_storage import write_person_result

    observations = _observations(np.array([1, 0], np.float32), None)
    manifest = _manifest(observations)
    if mismatch == "count":
        manifest["observations"].pop()
    else:
        manifest["observations"].reverse()

    with pytest.raises(ValueError):
        write_person_result(tmp_path, manifest, observations)
    assert not [item for item in tmp_path.rglob("*") if item.is_file()]


@pytest.mark.parametrize("bad_vector", [[[1, 2]], [], [1, float("nan")], [float("inf")]])
def test_reader_rejects_invalid_legacy_vectors(tmp_path: Path, bad_vector):
    from person_highlight.result_storage import load_person_embeddings

    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, {"observations": [{"embedding": bad_vector}]})


def _external_manifest(path="embeddings.npy", *, shape=None, dtype="float32"):
    return {"observations": [{"embedding_row": 0}], "embedding_storage": {
        "format": "npy", "path": path, "dtype": dtype,
        "shape": [1, 2] if shape is None else shape,
    }}


@pytest.mark.parametrize("bad_row", [-1, 1, True, .5, "0"])
def test_reader_rejects_invalid_embedding_indices(tmp_path: Path, bad_row):
    from person_highlight.result_storage import load_person_embeddings

    np.save(tmp_path / "embeddings.npy", np.array([[1, 0]], np.float32), allow_pickle=False)
    manifest = _external_manifest()
    manifest["observations"][0]["embedding_row"] = bad_row
    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, manifest)


def test_reader_rejects_missing_row_mapping(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings

    np.save(tmp_path / "embeddings.npy", np.array([[1, 0]], np.float32), allow_pickle=False)
    manifest = _external_manifest()
    manifest["observations"] = [{}]
    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, manifest)


@pytest.mark.parametrize("array, metadata", [
    (np.array([[1, 0]], np.float64), _external_manifest()),
    (np.array([1, 0], np.float32), _external_manifest()),
    (np.array([[1, np.nan]], np.float32), _external_manifest()),
    (np.array([[1, np.inf]], np.float32), _external_manifest()),
    (np.array([[1, 0]], np.float32), _external_manifest(shape=[2, 2])),
    (np.array([[1, 0]], np.float32), _external_manifest(shape=[True, 2])),
    (np.array([[1, 0]], np.float32), _external_manifest(dtype="float64")),
])
def test_reader_rejects_invalid_array_or_metadata(tmp_path: Path, array, metadata):
    from person_highlight.result_storage import load_person_embeddings

    np.save(tmp_path / "embeddings.npy", array, allow_pickle=False)
    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, metadata)


@pytest.mark.parametrize("path", ["../outside.npy", "/tmp/outside.npy", "..\\outside.npy"])
def test_reader_rejects_paths_outside_result_directory(tmp_path: Path, path):
    from person_highlight.result_storage import load_person_embeddings

    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, _external_manifest(path))


def test_reader_rejects_symlink_to_an_external_array(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings

    output = tmp_path / "result"
    output.mkdir()
    np.save(tmp_path / "outside.npy", np.array([[1, 0]], np.float32), allow_pickle=False)
    (output / "embeddings.npy").symlink_to(tmp_path / "outside.npy")
    with pytest.raises(ValueError):
        load_person_embeddings(output, _external_manifest())


def test_reader_reports_missing_array(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings

    with pytest.raises(FileNotFoundError):
        load_person_embeddings(tmp_path, _external_manifest())


def test_reader_refuses_pickle_arrays(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings

    np.save(tmp_path / "embeddings.npy", np.array([[object()]], dtype=object))
    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, _external_manifest(shape=[1, 1]))


def test_reader_rejects_archives_in_place_of_an_array(tmp_path: Path):
    from person_highlight.result_storage import load_person_embeddings

    with (tmp_path / "embeddings.npy").open("wb") as stream:
        np.savez(stream, embeddings=np.array([[1, 0]], np.float32))
    with pytest.raises(ValueError):
        load_person_embeddings(tmp_path, _external_manifest())
