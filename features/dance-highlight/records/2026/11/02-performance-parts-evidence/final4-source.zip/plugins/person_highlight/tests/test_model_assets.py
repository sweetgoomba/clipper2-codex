from pathlib import Path

import pytest

from person_highlight.model_assets import FACE_MODEL_SPECS, ensure_face_models, resolve_pose_model_path


def test_person_uses_the_same_auraface_asset_as_dance():
    from dance_highlight.services.face_models import FACE_MODEL_SPECS as dance_specs

    person = FACE_MODEL_SPECS[1]
    dance = dance_specs[1]
    assert person[1:] == (dance.filename, dance.url, dance.sha256, dance.size)
    assert person[1] == "glintr100.onnx"


def test_face_models_are_verified_and_reused(tmp_path: Path, monkeypatch):
    import person_highlight.model_assets as assets
    data = b"verified model"
    digest = __import__("hashlib").sha256(data).hexdigest()
    specs = (("detector", "yunet.onnx", "https://example.test/yunet", digest, len(data)),)
    target = tmp_path / "yunet.onnx"
    target.write_bytes(data)
    called = []
    files = ensure_face_models(tmp_path, specs=specs,
                               downloader=lambda *_args: called.append(True))
    assert files["detector"] == target
    assert not called


def test_corrupt_face_model_is_replaced_only_after_sha_verification(tmp_path: Path):
    data = b"verified model"
    digest = __import__("hashlib").sha256(data).hexdigest()
    specs = (("detector", "yunet.onnx", "https://example.test/yunet", digest, len(data)),)
    (tmp_path / "yunet.onnx").write_bytes(b"corrupt")
    files = ensure_face_models(tmp_path, specs=specs,
                               downloader=lambda _url, target: target.write_bytes(data))
    assert files["detector"].read_bytes() == data
    (tmp_path / "yunet.onnx").write_bytes(b"corrupt")
    with pytest.raises(RuntimeError, match="verification"):
        ensure_face_models(tmp_path, specs=specs,
                           downloader=lambda _url, target: target.write_bytes(b"wrong"))
    assert (tmp_path / "yunet.onnx").read_bytes() == b"corrupt"


def test_pose_path_reuses_override_or_ultralytics_default(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("CLIPPER_PERSON_POSE_MODEL_PATH", str(tmp_path / "pose.pt"))
    assert resolve_pose_model_path() == tmp_path / "pose.pt"
    monkeypatch.delenv("CLIPPER_PERSON_POSE_MODEL_PATH")
    monkeypatch.chdir(tmp_path)
    assert resolve_pose_model_path() == Path("yolov8s-pose.pt")


def test_person_pipeline_uses_stricter_face_detection_without_changing_shared_default(
        tmp_path: Path, monkeypatch):
    from person_highlight import app

    selected = {}

    class FaceBackend:
        def __init__(self, _files, *, score_threshold):
            selected["threshold"] = score_threshold

    monkeypatch.setattr(app, "existing_model_files", lambda: object())
    monkeypatch.setattr(app, "OpenCvFaceBackend", FaceBackend)
    monkeypatch.setattr(app, "YoloBodyDetector", lambda *_args, **_kwargs: object())
    monkeypatch.setattr(app, "resolve_pose_model_path", lambda: tmp_path / "pose.pt")
    monkeypatch.setattr(app, "detect_yolo_device", lambda: "cpu")

    app.PersonHighlightPlugin().load_models()

    assert selected["threshold"] == .75


def test_person_prepares_shared_whisper_without_loading_it(tmp_path: Path, monkeypatch):
    from person_highlight import app

    calls = []
    monkeypatch.setattr(app, "existing_model_files", lambda: object())
    monkeypatch.setattr(app, "OpenCvFaceBackend", lambda *_args, **_kwargs: object())
    monkeypatch.setattr(app, "YoloBodyDetector", lambda *_args, **_kwargs: object())
    monkeypatch.setattr(app, "resolve_pose_model_path", lambda: tmp_path / "pose.pt")
    monkeypatch.setattr(app, "detect_yolo_device", lambda: "cpu")
    monkeypatch.setattr(app, "ensure_whisper_files", lambda on_progress=None: calls.append("whisper"))

    app.PersonHighlightPlugin().load_models()

    assert calls == ["whisper"]
