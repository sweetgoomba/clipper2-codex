import json
from pathlib import Path

import pytest

from clipper_speech_core import TimedTranscript
from clipper_speech_core.assets import ModelFilesUnavailableError
from person_highlight import speech_stage


def transcript() -> TimedTranscript:
    return TimedTranscript((), (), "small", "cpu", "int8", None, None, 3.)


def test_person_speech_returns_timeline_and_cache_hit_diagnostic(tmp_path: Path, monkeypatch):
    video = tmp_path / "video.mp4"
    video.write_bytes(b"video")
    output = tmp_path / "speech.json"
    commands = []

    class Process:
        def __init__(self, command, **_kwargs):
            commands.append(command)
            output.write_text(json.dumps(transcript().to_stt_json(str(video))))
            output.with_suffix(".status.json").write_text('{"cache_hit": true}')

        def poll(self):
            return 0

    monkeypatch.setattr(speech_stage.subprocess, "Popen", Process)
    diagnostics = {}
    result = speech_stage.run_person_speech(video, output, tmp_path / "owner", "hash",
                                            lambda: False, diagnostics=diagnostics)
    assert result == transcript()
    assert diagnostics == {"status": "no_speech", "cache_hit": True}
    assert commands[0][1:3] == ["-m", "clipper_speech_core.worker"]
    assert commands[0][-2:] == [str(tmp_path / "owner"), "hash"]
    assert not output.with_suffix(".status.json").exists()


def test_audio_decode_failure_keeps_visual_fallback_and_removes_partial_result(tmp_path: Path,
                                                                                monkeypatch):
    video = tmp_path / "video.mp4"
    output = tmp_path / "speech.json"

    class Process:
        def __init__(self, *_args, **_kwargs):
            output.write_text('{"ok":')
            output.with_suffix(".status.json").write_text(
                '{"error": "SPEECH_UNAVAILABLE", "detail": "decode failed"}')

        def poll(self):
            return 3

    monkeypatch.setattr(speech_stage.subprocess, "Popen", Process)
    diagnostics = {}
    assert speech_stage.run_person_speech(video, output, None, "hash", lambda: False,
                                          diagnostics=diagnostics) is None
    assert diagnostics["status"] == "unavailable"
    assert diagnostics["error"] == "decode failed"
    assert not output.exists()


def test_missing_model_is_a_hard_failure(tmp_path: Path, monkeypatch):
    output = tmp_path / "speech.json"

    class Process:
        def __init__(self, *_args, **_kwargs):
            output.with_suffix(".status.json").write_text('{"error": "MODEL_FILES_MISSING"}')

        def poll(self):
            return 4

    monkeypatch.setattr(speech_stage.subprocess, "Popen", Process)
    with pytest.raises(ModelFilesUnavailableError):
        speech_stage.run_person_speech(tmp_path / "video.mp4", output, None,
                                       "hash", lambda: False)


def test_cancellation_terminates_child_and_cleans_partial_files(tmp_path: Path, monkeypatch):
    output = tmp_path / "speech.json"
    process = None

    class Process:
        terminated = False

        def __init__(self, *_args, **_kwargs):
            nonlocal process
            process = self
            output.write_text("partial")

        def poll(self):
            return None

        def terminate(self):
            self.terminated = True

        def wait(self, timeout=None):
            return 0

    monkeypatch.setattr(speech_stage.subprocess, "Popen", Process)
    called = []
    with pytest.raises(InterruptedError):
        speech_stage.run_person_speech(tmp_path / "video.mp4", output, None, "hash",
                                       lambda: (called.append(1), len(called) > 1)[1])
    assert process is not None and process.terminated
    assert not output.exists()
