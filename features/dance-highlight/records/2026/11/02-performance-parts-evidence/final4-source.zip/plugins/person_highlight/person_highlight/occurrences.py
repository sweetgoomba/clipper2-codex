"""Turn face identity and body presence into reviewable appearances and clips."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Callable, Sequence
import numpy as np

from clipper_face_core import FaceGroup, FaceObservation, rank_representatives

from .body_tracking import BodyObservation, _iou, _appearance_similarity
from .identity_continuity import body_face_links
from .identity_refinement import refine_person_groups
from .performance import PerformanceStats


@dataclass(frozen=True)
class PersonInterval:
    shot_id: str
    start_sec: float
    end_sec: float
    shot_ids: tuple[str, ...] = ()
    track_id: str | None = None


@dataclass(frozen=True)
class PersonGroup:
    group_id: str
    track_ids: tuple[str, ...]
    observation_ids: tuple[str, ...]
    intervals: tuple[PersonInterval, ...]
    representative_observation_id: str | None
    status: str


def _contains(body: BodyObservation, face: FaceObservation) -> bool:
    cx = (face.bbox_px[0] + face.bbox_px[2]) / 2
    cy = (face.bbox_px[1] + face.bbox_px[3]) / 2
    x1, y1, x2, y2 = body.bbox_px
    return x1 <= cx <= x2 and y1 <= cy <= y2


def _merge_intervals(intervals: list[PersonInterval], gap: float) -> tuple[PersonInterval, ...]:
    merged: list[PersonInterval] = []
    for item in sorted(intervals, key=lambda value: (value.start_sec, value.end_sec)):
        previous = merged[-1] if merged else None
        if previous and item.start_sec <= previous.end_sec + gap:
            merged[-1] = PersonInterval(previous.shot_id, previous.start_sec,
                                        max(previous.end_sec, item.end_sec),
                                        tuple(dict.fromkeys((previous.shot_ids or (previous.shot_id,))
                                                            + (item.shot_ids or (item.shot_id,)))),
                                        previous.track_id if previous.track_id == item.track_id else None)
        else:
            merged.append(item)
    return tuple(merged)


def _face_groups_seen_together(left: FaceGroup, right: FaceGroup,
                               by_face_id: dict[str, FaceObservation]) -> bool:
    for a_id in left.observation_ids:
        for b_id in right.observation_ids:
            a, b = by_face_id[a_id], by_face_id[b_id]
            if a.shot_id == b.shot_id and abs(a.time_sec - b.time_sec) < .001:
                return True
    return False


def _pairwise_maxima(left: np.ndarray, right: np.ndarray,
                     cancelled: Callable[[], bool] | None = None,
                     ) -> tuple[np.ndarray, np.ndarray, float]:
    """Return cross-group support without allocating a full pairwise matrix."""
    left_scores = np.full(len(left), -1., np.float32)
    right_scores = np.full(len(right), -1., np.float32)
    best = -1.
    for left_start in range(0, len(left), 512):
        for right_start in range(0, len(right), 512):
            if cancelled is not None and cancelled():
                raise InterruptedError("Person highlight cancelled")
            scores = np.matmul(left[left_start:left_start + 512],
                               right[right_start:right_start + 512].T)
            left_slice = slice(left_start, left_start + len(scores))
            right_slice = slice(right_start, right_start + scores.shape[1])
            np.maximum(left_scores[left_slice], scores.max(axis=1),
                       out=left_scores[left_slice])
            np.maximum(right_scores[right_slice], scores.max(axis=0),
                       out=right_scores[right_slice])
            best = max(best, float(scores.max()))
    return left_scores, right_scores, best


def _strong_face_match(left: list[FaceObservation], right: list[FaceObservation],
                       *, center_threshold: float = .6,
                       pair_threshold: float = .65,
                       min_smaller_fraction: float = 0,
                       min_larger_hits: int = 2,
                       cancelled: Callable[[], bool] | None = None) -> bool:
    """Require repeated cross-group support before joining interrupted identities."""
    a = [np.asarray(item.embedding, np.float32).reshape(-1) for item in left
         if item.embedding is not None]
    b = [np.asarray(item.embedding, np.float32).reshape(-1) for item in right
         if item.embedding is not None]
    if len(a) < 2 or len(b) < 2:
        return False
    a = [vector / norm for vector in a if (norm := float(np.linalg.norm(vector))) > 1e-8]
    b = [vector / norm for vector in b if (norm := float(np.linalg.norm(vector))) > 1e-8]
    if len(a) < 2 or len(b) < 2 or any(vector.shape != a[0].shape for vector in a + b):
        return False
    left_scores, right_scores, _ = _pairwise_maxima(np.stack(a), np.stack(b), cancelled)
    left_hits = int(np.count_nonzero(left_scores >= pair_threshold))
    right_hits = int(np.count_nonzero(right_scores >= pair_threshold))
    larger_hits = left_hits if len(a) >= len(b) else right_hits
    if min(left_hits, right_hits) < 2 or larger_hits < min_larger_hits:
        return False
    smaller_fraction = (right_hits / len(b) if len(b) <= len(a)
                        else left_hits / len(a))
    if smaller_fraction < min_smaller_fraction:
        return False
    center_a, center_b = np.mean(a, axis=0), np.mean(b, axis=0)
    denominator = float(np.linalg.norm(center_a) * np.linalg.norm(center_b))
    return denominator > 1e-8 and float(np.dot(center_a, center_b) / denominator) >= center_threshold


def _overlapping_duplicate_faces(left: list[FaceObservation],
                                 right: list[FaceObservation],
                                 cancelled: Callable[[], bool] | None = None) -> bool:
    right_by_frame: dict[tuple[str, int], list[FaceObservation]] = defaultdict(list)
    for face in right:
        right_by_frame[(face.shot_id, int(face.time_sec * 1000))].append(face)
    simultaneous_count = 0
    for face in left:
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        bucket = int(face.time_sec * 1000)
        for offset in (-1, 0, 1):
            for other in right_by_frame.get((face.shot_id, bucket + offset), ()):
                if abs(face.time_sec - other.time_sec) < .001:
                    simultaneous_count += 1
                    if _iou(face.bbox_px, other.bbox_px) < .1:
                        return False
    return simultaneous_count >= 2 and _strong_face_match(
        left, right, center_threshold=.8, pair_threshold=.7, cancelled=cancelled)


def _sparse_montage_duplicate_faces(left: list[FaceObservation],
                                    right: list[FaceObservation],
                                    cancelled: Callable[[], bool] | None = None) -> bool:
    """Allow one identity in a rare inset without joining recurring co-stars."""
    if min(len(left), len(right)) < 8:
        return False
    left_frames = {(face.shot_id, round(face.time_sec, 3)) for face in left}
    right_frames = {(face.shot_id, round(face.time_sec, 3)) for face in right}
    shared_frames = left_frames & right_frames
    if not shared_frames or len(shared_frames) > min(len(left_frames), len(right_frames)) * .1:
        return False
    left_shots = {face.shot_id for face in left}
    right_shots = {face.shot_id for face in right}
    if len(left_shots - right_shots) < 2 or len(right_shots - left_shots) < 2:
        return False
    vectors = []
    for faces in (left, right):
        normalized = []
        for face in faces:
            if face.embedding is None:
                continue
            vector = np.asarray(face.embedding, np.float32).reshape(-1)
            norm = float(np.linalg.norm(vector))
            if norm > 1e-8:
                normalized.append(vector / norm)
        if len(normalized) < 8:
            return False
        vectors.append(np.stack(normalized))
    first, second = vectors
    if first.shape[1] != second.shape[1]:
        return False
    center_a, center_b = first.mean(axis=0), second.mean(axis=0)
    denominator = float(np.linalg.norm(center_a) * np.linalg.norm(center_b))
    if denominator <= 1e-8 or float(np.dot(center_a, center_b) / denominator) < .87:
        return False
    left_scores, right_scores, _ = _pairwise_maxima(first, second, cancelled)
    smaller_support = right_scores if len(second) <= len(first) else left_scores
    larger_support = left_scores if len(second) <= len(first) else right_scores
    return (float(np.mean(smaller_support >= .7)) >= .7
            and int(np.count_nonzero(larger_support >= .7)) >= 8)


def representative_candidates(observations: Sequence[FaceObservation]) -> list[str]:
    """Return only source frames with a sufficiently clear detected face."""
    def supported_faces(min_side: int, min_score: float, min_quality: float,
                        min_sharpness: float, allow_track_support: bool) -> list[FaceObservation]:
        eligible = [item for item in observations
                    if item.embedding is not None and item.detection_score is not None
                    and item.detection_score >= min_score and item.quality >= min_quality
                    and min(item.bbox_px[2] - item.bbox_px[0],
                            item.bbox_px[3] - item.bbox_px[1]) >= min_side
                    and (item.sharpness is None or item.sharpness >= min_sharpness)]
        if len(eligible) > 256:
            strongest = sorted(eligible, key=lambda item: (
                item.quality + (item.sharpness or 0), item.detection_score or 0),
                reverse=True)[:128]
            chronological = sorted(eligible, key=lambda item: item.time_sec)
            spread = [chronological[index * (len(chronological) - 1) // 127]
                      for index in range(128)]
            eligible = list({item.observation_id: item for item in strongest + spread}.values())
        if len(eligible) > 1:
            vectors = np.stack([np.asarray(item.embedding, np.float32) for item in eligible])
            vectors /= np.maximum(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-8)
            similarity = vectors @ vectors.T
            np.fill_diagonal(similarity, -1)
            track_counts = Counter(item.track_id for item in eligible) if allow_track_support else {}
            eligible = [item for item, score in zip(eligible, similarity.max(axis=1))
                        if score >= .55 or (allow_track_support and track_counts[item.track_id] >= 2)]
        elif allow_track_support:
            eligible = []
        return eligible

    eligible = supported_faces(64, .85, .6, .15, False)
    if not eligible:
        # A small, repeatedly detected face can still make a useful thumbnail.
        eligible = supported_faces(48, .9, .58, .3, True)
    if not eligible:
        return []
    ranked = rank_representatives(eligible)
    by_id = {item.observation_id: item for item in eligible}
    selected: list[str] = [ranked[0]]
    for prefer_new_shot in (True, False):
        for observation_id in ranked[1:]:
            if len(selected) == 5:
                break
            item = by_id[observation_id]
            if prefer_new_shot and any(item.shot_id == by_id[other].shot_id for other in selected):
                continue
            if all(abs(item.time_sec - by_id[other].time_sec) >= 5. for other in selected):
                selected.append(observation_id)
    return selected


def _combine_person_groups(groups: Sequence[PersonGroup],
                           by_face_id: dict[str, FaceObservation],
                           interval_gap: float) -> PersonGroup:
    ordered = sorted(groups, key=lambda group: (-len(group.observation_ids), group.group_id))
    observation_ids = tuple(dict.fromkeys(item_id for group in ordered
                                          for item_id in group.observation_ids))
    candidates = representative_candidates([by_face_id[item_id] for item_id in observation_ids])
    return PersonGroup(
        ordered[0].group_id, tuple(sorted({track for group in ordered for track in group.track_ids})),
        observation_ids,
        _merge_intervals([interval for group in ordered for interval in group.intervals], interval_gap),
        candidates[0] if candidates else None, "needs_review")


def _merge_shot_consensus_fragments(groups: list[PersonGroup],
                                    by_face_id: dict[str, FaceObservation],
                                    interval_gap: float,
                                    cancelled: Callable[[], bool] | None = None, *,
                                    source_groups: Sequence[FaceGroup] = ()) -> list[PersonGroup]:
    """Use independent shot averages to recover noisy recurring face views.

    Keep the original group centers fixed during merging. Every component must
    remain compatible with every other component; a matching middle group must
    not bridge two different identities.
    """
    def prepare(observation_ids: Sequence[str]):
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        if len(observation_ids) < 8:
            return None
        sums: dict[str, np.ndarray] = {}
        counts: Counter[str] = Counter()
        shot_times: dict[str, list[float]] = defaultdict(list)
        frame_times: dict[tuple[str, int], list[float]] = defaultdict(list)
        for item_id in observation_ids:
            face = by_face_id[item_id]
            frame_times[(face.shot_id, int(face.time_sec * 1000))].append(face.time_sec)
            if face.embedding is None:
                continue
            vector = np.asarray(face.embedding, np.float32).reshape(-1)
            norm = float(np.linalg.norm(vector))
            if not np.isfinite(norm) or norm <= 1e-8:
                continue
            vector = vector / norm
            sums[face.shot_id] = sums.get(face.shot_id, np.zeros_like(vector)) + vector
            counts[face.shot_id] += 1
            shot_times[face.shot_id].append(face.time_sec)
        repeated = [value / norm for shot, value in sums.items()
                    if max(shot_times[shot]) - min(shot_times[shot]) >= .001
                    and (norm := float(np.linalg.norm(value))) > 1e-8]
        if len(repeated) < 2 or sum(counts.values()) < 8:
            return None
        center = np.sum(list(sums.values()), axis=0)
        norm = float(np.linalg.norm(center))
        if norm <= 1e-8:
            return None
        return center / norm, np.stack(repeated), frame_times

    source_centers = {group.group_id: evidence[0] for group in source_groups
                      if (evidence := prepare(group.observation_ids)) is not None}
    source_owner = {item_id: group.group_id for group in source_groups
                    if group.group_id in source_centers for item_id in group.observation_ids}
    centers: dict[str, np.ndarray] = {}
    shot_vectors: dict[str, np.ndarray] = {}
    frames: dict[str, dict[tuple[str, int], list[float]]] = {}
    anchors: dict[str, list[np.ndarray]] = {}
    for group in groups:
        evidence = prepare(group.observation_ids)
        if evidence is None:
            continue
        centers[group.group_id], shot_vectors[group.group_id], frames[group.group_id] = evidence
        originals = {source_owner[item_id] for item_id in group.observation_ids
                     if item_id in source_owner}
        anchors[group.group_id] = ([source_centers[item_id] for item_id in sorted(originals)]
                                   or [centers[group.group_id]])

    def co_visible(first: str, second: str) -> bool:
        return any(abs(time - other) < .001
                   for (shot, bucket), times in frames[first].items()
                   for offset in (-1, 0, 1)
                   for other in frames[second].get((shot, bucket + offset), ())
                   for time in times)

    ids = sorted(centers)
    blocked: set[tuple[str, str]] = set()
    candidates: list[tuple[float, str, str]] = []
    for index, first in enumerate(ids):
        for second in ids[index + 1:]:
            if cancelled is not None and cancelled():
                raise InterruptedError("Person highlight cancelled")
            score = (float(np.dot(centers[first], centers[second]))
                     if centers[first].shape == centers[second].shape else -1.)
            if (score < .6 or co_visible(first, second)
                    or any(a.shape != b.shape or float(np.dot(a, b)) < .6
                           for a in anchors[first] for b in anchors[second])):
                blocked.add((first, second))
                continue
            if score < .7:
                continue
            left, right, best = _pairwise_maxima(shot_vectors[first], shot_vectors[second], cancelled)
            smaller = left if len(left) <= len(right) else right
            if (best >= .7 and float(np.mean(smaller >= .65)) >= .6
                    and min(int(np.count_nonzero(left >= .65)),
                            int(np.count_nonzero(right >= .65))) >= 2):
                candidates.append((score, first, second))

    parent = {group_id: group_id for group_id in ids}
    members = {group_id: {group_id} for group_id in ids}

    def root(group_id: str) -> str:
        while parent[group_id] != group_id:
            group_id = parent[group_id]
        return group_id

    for _, first_id, second_id in sorted(candidates, reverse=True):
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        first, second = root(first_id), root(second_id)
        if first == second or any(tuple(sorted((a, b))) in blocked
                                  for a in members[first] for b in members[second]):
            continue
        parent[second] = first
        members[first].update(members.pop(second))
    by_group_id = {group.group_id: group for group in groups}
    merged_ids = {item_id for component in members.values() if len(component) > 1
                  for item_id in component}
    result = [group for group in groups if group.group_id not in merged_ids]
    result.extend(_combine_person_groups([by_group_id[item_id] for item_id in sorted(component)],
                                          by_face_id, interval_gap)
                  for component in members.values() if len(component) > 1)
    return sorted(result, key=lambda group: group.group_id)


def _merge_recurrent_face_fragments(groups: list[PersonGroup],
                                   by_face_id: dict[str, FaceObservation],
                                   interval_gap: float,
                                   cancelled: Callable[[], bool] | None = None,
                                   source_members: dict[str, frozenset[str]] | None = None,
                                   source_centers: dict[str, np.ndarray | None] | None = None,
                                   ) -> list[PersonGroup]:
    """Join repeated pose fragments with broad face support and no co-visibility."""
    remaining = list(groups)
    members = (dict(source_members) if source_members is not None else
               {group.group_id: frozenset((group.group_id,)) for group in groups})
    original_centers = dict(source_centers) if source_centers is not None else {}
    anchor_centers: dict[str, np.ndarray] = {}
    anchor_sizes: dict[str, int] = {}
    while True:
        prepared: dict[str, tuple[list[FaceObservation], np.ndarray]] = {}
        for group in remaining:
            if cancelled is not None and cancelled():
                raise InterruptedError("Person highlight cancelled")
            faces: list[FaceObservation] = []
            vectors: list[np.ndarray] = []
            for item_id in group.observation_ids:
                face = by_face_id[item_id]
                if face.embedding is None:
                    continue
                vector = np.asarray(face.embedding, np.float32).reshape(-1)
                norm = float(np.linalg.norm(vector))
                if norm > 1e-8:
                    faces.append(face)
                    vectors.append(vector / norm)
            if (len(faces) >= 8 and all(vector.shape == vectors[0].shape
                                        for vector in vectors)):
                prepared[group.group_id] = faces, np.stack(vectors)
                center = np.mean(vectors, axis=0)
                norm = float(np.linalg.norm(center))
                normalized_center = center / norm if norm > 1e-8 else center
                if group.group_id not in original_centers:
                    original_centers[group.group_id] = normalized_center
                if group.group_id not in anchor_centers:
                    anchor_centers[group.group_id] = normalized_center
                    anchor_sizes[group.group_id] = len(faces)
        candidates: list[tuple[float, float, float, str, str]] = []
        for index, left in enumerate(remaining):
            if left.group_id not in prepared:
                continue
            left_faces, left_vectors = prepared[left.group_id]
            left_frames = {(face.shot_id, round(face.time_sec, 3)) for face in left_faces}
            for right in remaining[index + 1:]:
                if cancelled is not None and cancelled():
                    raise InterruptedError("Person highlight cancelled")
                if right.group_id not in prepared:
                    continue
                right_faces, right_vectors = prepared[right.group_id]
                if left_vectors.shape[1] != right_vectors.shape[1]:
                    continue
                compatible = True
                needs_consensus = False
                for a in members[left.group_id]:
                    for b in members[right.group_id]:
                        first_center, second_center = original_centers.get(a), original_centers.get(b)
                        if (first_center is None or second_center is None
                                or first_center.shape != second_center.shape):
                            compatible = False
                            break
                        if float(np.dot(first_center, second_center)) < .5:
                            needs_consensus = True
                    if not compatible:
                        break
                if not compatible:
                    continue
                if needs_consensus and float(np.dot(anchor_centers[left.group_id],
                                                   anchor_centers[right.group_id])) < .84:
                    continue
                if left_frames.intersection(
                        (face.shot_id, round(face.time_sec, 3)) for face in right_faces):
                    continue
                left_center, right_center = left_vectors.mean(axis=0), right_vectors.mean(axis=0)
                denominator = float(np.linalg.norm(left_center) * np.linalg.norm(right_center))
                center_score = float(np.dot(left_center, right_center) / denominator) if denominator > 1e-8 else -1.
                if center_score < (.84 if needs_consensus else .5):
                    continue
                left_scores, right_scores, best = _pairwise_maxima(
                    left_vectors, right_vectors, cancelled)
                smaller_faces, smaller_scores, larger_scores = (
                    (left_faces, left_scores, right_scores)
                    if len(left_faces) <= len(right_faces)
                    else (right_faces, right_scores, left_scores))
                supported = smaller_scores >= .65
                fraction = float(np.mean(supported))
                supported_shots = {face.shot_id for face, okay in zip(smaller_faces, supported) if okay}
                if (fraction >= (.7 if needs_consensus else .5) and len(supported_shots) >= 2
                        and int(np.count_nonzero(larger_scores >= .65)) >= 8
                        and best >= .75):
                    candidates.append((fraction, center_score, best,
                                       left.group_id, right.group_id))
        if not candidates:
            return sorted(remaining, key=lambda group: group.group_id)
        _, _, _, left_id, right_id = max(candidates)
        left = next(group for group in remaining if group.group_id == left_id)
        right = next(group for group in remaining if group.group_id == right_id)
        primary, secondary = sorted((left, right),
                                    key=lambda group: (-len(group.observation_ids), group.group_id))
        merged = _combine_person_groups((primary, secondary), by_face_id, interval_gap)
        anchor_source = max((left_id, right_id), key=lambda group_id: anchor_sizes[group_id])
        anchor_centers[primary.group_id] = anchor_centers[anchor_source]
        anchor_sizes[primary.group_id] = anchor_sizes[anchor_source]
        members[primary.group_id] = members[left_id] | members[right_id]
        if secondary.group_id != primary.group_id:
            del members[secondary.group_id]
            del anchor_centers[secondary.group_id]
            del anchor_sizes[secondary.group_id]
        remaining = [group for group in remaining
                     if group.group_id not in (left_id, right_id)] + [merged]


def _merge_local_body_fragments(groups: list[PersonGroup],
                                by_face_id: dict[str, FaceObservation],
                                bodies: Sequence[BodyObservation], interval: float,
                                cancelled: Callable[[], bool] | None) -> list[PersonGroup]:
    # Keep the established global identities intact. Local head/body evidence
    # can attach a short fragment without repartitioning their face galleries.
    current = {group.group_id: group for group in groups}
    owner = {obs_id: group.group_id for group in groups for obs_id in group.observation_ids}
    source_anchors = {}
    members = {group.group_id: {group.group_id} for group in groups}
    for group in groups:
        items = [by_face_id[key] for key in group.observation_ids]
        vectors = [face.embedding for face in items if face.embedding is not None]
        if vectors and (len(items) >= 8 or len({face.shot_id for face in items}) > 1):
            source_anchors[group.group_id] = np.mean(vectors, axis=0)
    links = body_face_links(list(by_face_id.values()), bodies, interval, cancelled)
    neighbors = defaultdict(set)
    for left_id, right_id in links:
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        neighbors[left_id].add(right_id)
        neighbors[right_id].add(left_id)
    runs = {}
    for obs_id in neighbors:
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        if obs_id in runs:
            continue
        pending, run = [obs_id], set()
        while pending:
            key = pending.pop()
            if key in run:
                continue
            run.add(key)
            pending.extend(neighbors[key] - run)
        for key in run:
            runs[key] = run
    # Freeze the original owners: newly attached fragments cannot manufacture
    # additional anchor support for a later merge.
    original_owner = dict(owner)
    for left_id, right_id in links:
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        first, second = owner.get(left_id), owner.get(right_id)
        if first is None or second is None or first == second:
            continue
        left, right = current[first], current[second]
        if any((score := _appearance_similarity(source_anchors[x], source_anchors[y])) is None
               or score < .5 for x in members[first] if x in source_anchors
               for y in members[second] if y in source_anchors):
            continue
        a = [by_face_id[key] for key in left.observation_ids]
        b = [by_face_id[key] for key in right.observation_ids]
        frames = defaultdict(list)
        for face in a:
            frames[face.shot_id, int(face.time_sec * 1000)].append(face.time_sec)
        if any(abs(face.time_sec - time) < .001 for face in b for offset in (-1, 0, 1)
               for time in frames.get((face.shot_id, int(face.time_sec * 1000) + offset), ())):
            continue
        # Protect independently observed identity anchors from a weak local
        # link. Such fragments need independent global face agreement instead.
        run = runs[left_id]
        anchor_support = Counter(original_owner[key] for key in run)
        anchor_sides = [anchors for group_id in (first, second)
                        if (anchors := members[group_id] & source_anchors.keys())]
        sustained = len(run) >= 4 and bool(anchor_sides) and all(
            any(anchor_support[anchor] >= 2 for anchor in anchors) for anchors in anchor_sides)
        if not sustained and any(len({face.shot_id for face in items}) > 1 for items in (a, b)):
            def track_means(items):
                tracks = defaultdict(list)
                for face in items:
                    if face.embedding is not None:
                        tracks[face.track_id].append(face.embedding)
                return [np.mean(vectors, axis=0) for vectors in tracks.values()]
            if any((score := _appearance_similarity(x, y)) is None or score < .65
                   for x in track_means(a) for y in track_means(b)):
                continue
        # Two established identities need face agreement as well as local
        # continuity; a body tracker switch cannot join them through one frame.
        if min(len(a), len(b)) >= 8:
            centers = [np.mean([face.embedding for face in items
                                if face.embedding is not None], axis=0) for items in (a, b)]
            similarity = _appearance_similarity(*centers)
            if similarity is None or similarity < .5:
                continue
        merged = _combine_person_groups((left, right), by_face_id, interval * .5)
        del current[first], current[second]
        current[merged.group_id] = merged
        members[merged.group_id] = members[first] | members[second]
        for obs_id in merged.observation_ids:
            owner[obs_id] = merged.group_id
    return sorted(current.values(), key=lambda group: group.group_id)


def _adjacent_face_support(left: list[FaceObservation], right: list[FaceObservation],
                           window_sec: float,
                           cancelled: Callable[[], bool] | None = None,
                           ) -> tuple[float, bool]:
    """Find nearest same-shot time and local box support with linear memory."""
    by_shot_left: dict[str, list[FaceObservation]] = defaultdict(list)
    by_shot_right: dict[str, list[FaceObservation]] = defaultdict(list)
    for face in left:
        by_shot_left[face.shot_id].append(face)
    for face in right:
        by_shot_right[face.shot_id].append(face)
    gap = float("inf")
    local = False
    for shot_id in by_shot_left.keys() & by_shot_right.keys():
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        first = sorted(by_shot_left[shot_id], key=lambda face: face.time_sec)
        second = sorted(by_shot_right[shot_id], key=lambda face: face.time_sec)
        a_index = b_index = 0
        shot_gap = float("inf")
        while a_index < len(first) and b_index < len(second):
            shot_gap = min(shot_gap, abs(first[a_index].time_sec - second[b_index].time_sec))
            if (a_index + b_index) % 256 == 0 and cancelled is not None and cancelled():
                raise InterruptedError("Person highlight cancelled")
            if first[a_index].time_sec < second[b_index].time_sec:
                a_index += 1
            else:
                b_index += 1
        gap = min(gap, shot_gap)
        if local or shot_gap > window_sec:
            continue
        lower = upper = comparisons = 0
        for face in first:
            if cancelled is not None and cancelled():
                raise InterruptedError("Person highlight cancelled")
            while lower < len(second) and second[lower].time_sec < face.time_sec - window_sec:
                lower += 1
            upper = max(upper, lower)
            while upper < len(second) and second[upper].time_sec <= face.time_sec + window_sec:
                upper += 1
            for index in range(lower, upper):
                comparisons += 1
                if comparisons % 256 == 0 and cancelled is not None and cancelled():
                    raise InterruptedError("Person highlight cancelled")
                if _iou(face.bbox_px, second[index].bbox_px) >= .25:
                    local = True
                    break
            if local:
                break
    return gap, local


def build_person_results(
    face_groups: Sequence[FaceGroup], face_observations: Sequence[FaceObservation],
    body_observations: Sequence[BodyObservation], *, duration_sec: float,
    sample_interval_sec: float, padding_sec: float = .25,
    cancelled: Callable[[], bool] | None = None,
    sample_end_sec: dict[tuple[str, float], float] | None = None,
    metrics: PerformanceStats | None = None,
) -> tuple[list[PersonGroup], list[dict]]:
    """Keep body presence and face identity separate until evidence connects them."""
    if duration_sec < 0 or sample_interval_sec <= 0 or padding_sec < 0:
        raise ValueError("Invalid Person timing")
    if cancelled is not None and cancelled():
        raise InterruptedError("Person highlight cancelled")

    def observed_end(shot_id: str, time_sec: float) -> float:
        # An adaptive sample can be followed by a frame/cut sooner than the
        # base interval. Its measured end takes precedence over the fallback.
        held_end = (sample_end_sec or {}).get((shot_id, time_sec), time_sec + sample_interval_sec)
        return min(duration_sec, max(time_sec, held_end))

    by_face_id = {item.observation_id: item for item in face_observations}
    face_group_by_id = {group.group_id: group for group in face_groups}
    face_to_group = {obs_id: group.group_id for group in face_groups
                     for obs_id in group.observation_ids}
    by_body_track: dict[str, list[BodyObservation]] = defaultdict(list)
    body_by_frame: dict[tuple[str, int], list[BodyObservation]] = defaultdict(list)
    body_by_key: dict[tuple[str, float, str], BodyObservation] = {}
    for item in body_observations:
        by_body_track[item.track_id].append(item)
        body_by_frame[(item.shot_id, int(item.time_sec * 1000))].append(item)
        body_by_key[(item.shot_id, item.time_sec, item.track_id)] = item
    body_candidates: dict[tuple[str, float, str], list[FaceObservation]] = defaultdict(list)
    for face in face_observations:
        millisecond = int(face.time_sec * 1000)
        containing = [body for bucket in (millisecond - 1, millisecond, millisecond + 1)
                      for body in body_by_frame.get((face.shot_id, bucket), ())
                      if abs(body.time_sec - face.time_sec) < .001 and _contains(body, face)]
        if len(containing) == 1:
            body = containing[0]
            body_candidates[(body.shot_id, body.time_sec, body.track_id)].append(face)
    body_to_faces: dict[str, list[FaceObservation]] = defaultdict(list)
    for body_key, faces in body_candidates.items():
        body = body_by_key[body_key]
        body_id = body.track_id
        ordered = sorted(faces, key=lambda face: (
            (face.bbox_px[1] + face.bbox_px[3] - 2 * body.bbox_px[1]) /
            max(1, 2 * (body.bbox_px[3] - body.bbox_px[1]))))
        if len(ordered) == 1:
            body_to_faces[body_id].append(ordered[0])
        else:
            first_y = (ordered[0].bbox_px[1] + ordered[0].bbox_px[3]) / 2
            next_y = (ordered[1].bbox_px[1] + ordered[1].bbox_px[3]) / 2
            if next_y - first_y >= .12 * (body.bbox_px[3] - body.bbox_px[1]):
                body_to_faces[body_id].append(ordered[0])

    parent = {group.group_id: group.group_id for group in face_groups}
    members = {group.group_id: [group.group_id] for group in face_groups}
    by_face_track: dict[str, list[np.ndarray]] = defaultdict(list)
    for face in face_observations:
        if face.embedding is not None:
            by_face_track[face.track_id].append(np.asarray(face.embedding, np.float32).reshape(-1))
    track_centers: dict[str, np.ndarray | None] = {}
    for track_id, vectors in by_face_track.items():
        average = np.mean(vectors, axis=0)
        norm = float(np.linalg.norm(average))
        track_centers[track_id] = average / norm if norm > 1e-8 else None

    def root(group_id: str) -> str:
        while parent[group_id] != group_id:
            group_id = parent[group_id]
        return group_id

    def join(first: str, second: str) -> None:
        parent[second] = first
        members[first].extend(members.pop(second))

    def components_compatible(first: str, second: str, threshold: float) -> bool:
        left = [track_centers[track] for group_id in members[first]
                for track in face_group_by_id[group_id].track_ids
                if track_centers.get(track) is not None]
        right = [track_centers[track] for group_id in members[second]
                 for track in face_group_by_id[group_id].track_ids
                 if track_centers.get(track) is not None]
        return bool(left and right) and all(
            a.shape == b.shape and float(np.dot(a, b)) >= threshold
            for a in left for b in right)

    def component_faces(group_id: str) -> list[FaceObservation]:
        return [by_face_id[item_id] for member in members[group_id]
                for item_id in face_group_by_id[member].observation_ids]

    def face_center(faces: list[FaceObservation]) -> np.ndarray | None:
        vectors = [np.asarray(face.embedding, np.float32).reshape(-1) for face in faces
                   if face.embedding is not None]
        normalized = [vector / norm for vector in vectors
                      if (norm := float(np.linalg.norm(vector))) > 1e-8]
        if not normalized or any(vector.shape != normalized[0].shape for vector in normalized):
            return None
        average = np.mean(normalized, axis=0)
        norm = float(np.linalg.norm(average))
        return average / norm if norm > 1e-8 else None

    joined_groups: set[str] = set()
    face_confirmed_roots: set[str] = set()
    # Confirm repeated face evidence before weaker body continuity can attach
    # a fragment that would prevent two clear identity groups from joining.
    for index, left in enumerate(face_groups):
        for right in face_groups[index + 1:]:
            if cancelled is not None and cancelled():
                raise InterruptedError("Person highlight cancelled")
            first, second = root(left.group_id), root(right.group_id)
            if first == second:
                continue
            if not components_compatible(first, second, .65):
                continue
            left_component = [face_group_by_id[group_id] for group_id in members[first]]
            right_component = [face_group_by_id[group_id] for group_id in members[second]]
            left_faces = [by_face_id[item_id] for group in left_component
                          for item_id in group.observation_ids]
            right_faces = [by_face_id[item_id] for group in right_component
                           for item_id in group.observation_ids]
            co_visible = any(_face_groups_seen_together(a, b, by_face_id)
                             for a in left_component for b in right_component)
            if ((not co_visible and _strong_face_match(left_faces, right_faces,
                                                        cancelled=cancelled)) or
                    (co_visible and (_overlapping_duplicate_faces(left_faces, right_faces,
                                                                   cancelled)
                                     or _sparse_montage_duplicate_faces(left_faces, right_faces,
                                                                         cancelled)))):
                join(first, second)
                joined_groups.add(first)
                face_confirmed_roots.discard(second)
                face_confirmed_roots.add(first)

    for faces in body_to_faces.values():
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        ids = sorted({face_to_group[face.observation_id] for face in faces
                      if face.observation_id in face_to_group})
        pairs: list[tuple[float, str, str, bool]] = []
        for index, a_id in enumerate(ids):
            a_faces = [face for face in faces if face_to_group.get(face.observation_id) == a_id]
            for b_id in ids[index + 1:]:
                b_faces = [face for face in faces if face_to_group.get(face.observation_id) == b_id]
                gap, local = _adjacent_face_support(
                    a_faces, b_faces, sample_interval_sec * 2.1, cancelled)
                pairs.append((gap, a_id, b_id, local))
        for _, a_id, b_id, local in sorted(pairs):
            first = root(a_id)
            second = root(b_id)
            if first == second:
                continue
            left_faces = [by_face_id[item_id] for group_id in members[first]
                          for item_id in face_group_by_id[group_id].observation_ids]
            right_faces = [by_face_id[item_id] for group_id in members[second]
                           for item_id in face_group_by_id[group_id].observation_ids]
            local_threshold = .65 if (first in face_confirmed_roots or
                                      second in face_confirmed_roots) else .55
            if not (_overlapping_duplicate_faces(left_faces, right_faces, cancelled) or
                    ((components_compatible(first, second, .8) or
                      (local and components_compatible(first, second, local_threshold))) and
                     not any(a.shot_id == b.shot_id and abs(a.time_sec - b.time_sec) < .001
                             for a in left_faces for b in right_faces))):
                continue
            face_confirmed = first in face_confirmed_roots or second in face_confirmed_roots
            join(first, second)
            joined_groups.add(first)
            face_confirmed_roots.discard(second)
            if face_confirmed:
                face_confirmed_roots.add(first)

    # A stable, high-confidence body track can reconnect short face fragments
    # after a head turn. Keep a face similarity floor and a co-visibility veto
    # so a tracker switch cannot assert two different people as one identity.
    for body_id, faces in body_to_faces.items():
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        body_items = sorted(by_body_track[body_id], key=lambda item: item.time_sec)
        by_time = {item.time_sec: item for item in body_items}
        ordered_faces = sorted(faces, key=lambda item: item.time_sec)
        for left, right in zip(ordered_faces, ordered_faces[1:]):
            gap = right.time_sec - left.time_sec
            if (left.shot_id != right.shot_id or not 0 < gap <= sample_interval_sec * 2.1):
                continue
            first_body, second_body = by_time.get(left.time_sec), by_time.get(right.time_sec)
            if (first_body is None or second_body is None
                    or min(first_body.score, second_body.score) < .5
                    or _iou(first_body.bbox_px, second_body.bbox_px) < .4):
                continue
            visual_a, visual_b = first_body.appearance, second_body.appearance
            if visual_a is None or visual_b is None:
                continue
            denominator = float(np.linalg.norm(visual_a) * np.linalg.norm(visual_b))
            if denominator <= 1e-8 or float(np.dot(visual_a, visual_b) / denominator) < .8:
                continue
            path = [item for item in body_items if left.time_sec <= item.time_sec <= right.time_sec]
            if any(b.time_sec - a.time_sec > sample_interval_sec * 1.25
                   for a, b in zip(path, path[1:])):
                continue
            first = root(face_to_group[left.observation_id])
            second = root(face_to_group[right.observation_id])
            if first == second:
                continue
            left_faces, right_faces = component_faces(first), component_faces(second)
            if any(a.shot_id == b.shot_id and abs(a.time_sec - b.time_sec) < .001
                   for a in left_faces for b in right_faces):
                continue
            left_center, right_center = face_center(left_faces), face_center(right_faces)
            if (left_center is None or right_center is None
                    or float(np.dot(left_center, right_center)) < .4
                    or not components_compatible(first, second, .4)
                    or ((first in face_confirmed_roots or second in face_confirmed_roots)
                        and not components_compatible(first, second, .65))):
                continue
            join(first, second)
            joined_groups.add(first)

    # Revisit brief face gaps after body links have supplied more identity
    # evidence. A weak single-frame face must not block a nearby clear track.
    faces_by_shot: dict[str, list[FaceObservation]] = defaultdict(list)
    for face in face_observations:
        faces_by_shot[face.shot_id].append(face)
    adjacent_candidates: dict[tuple[str, str], float] = {}
    for shot_faces in faces_by_shot.values():
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        shot_faces.sort(key=lambda face: face.time_sec)
        for index, face in enumerate(shot_faces):
            for neighbor in shot_faces[index + 1:]:
                gap = neighbor.time_sec - face.time_sec
                if gap > 1.25:
                    break
                first_id = face_to_group.get(face.observation_id)
                second_id = face_to_group.get(neighbor.observation_id)
                if (gap < .001 or first_id is None or second_id is None
                        or first_id == second_id
                        or _iou(face.bbox_px, neighbor.bbox_px) < .5):
                    continue
                key = tuple(sorted((first_id, second_id)))
                adjacent_candidates[key] = min(gap, adjacent_candidates.get(key, float("inf")))

    for (a_id, b_id), _ in sorted(adjacent_candidates.items(), key=lambda item: item[1]):
        first, second = root(a_id), root(b_id)
        if first == second:
            continue
        left_faces, right_faces = component_faces(first), component_faces(second)
        if len(left_faces) < 2 or len(right_faces) < 2:
            continue
        if any(a.shot_id == b.shot_id and abs(a.time_sec - b.time_sec) < .001
               for a in left_faces for b in right_faces):
            continue
        left_center, right_center = face_center(left_faces), face_center(right_faces)
        if (left_center is None or right_center is None
                or float(np.dot(left_center, right_center)) < .65
                or not components_compatible(first, second, .55)):
            continue
        join(first, second)
        joined_groups.add(first)

    # Montage duplicates can be split into several shot-local groups. Check
    # completed components after the ordinary face/body reconciliation, when
    # the rare co-visible frames can be weighed against the full history.
    roots = sorted({root(group_id) for group_id in parent})
    centers = {group_id: face_center(component_faces(group_id)) for group_id in roots}
    montage_candidates = sorted((float(np.dot(centers[a], centers[b])), a, b)
                                for index, a in enumerate(roots)
                                for b in roots[index + 1:]
                                if centers[a] is not None and centers[b] is not None
                                and centers[a].shape == centers[b].shape
                                and float(np.dot(centers[a], centers[b])) >= .84)
    # Merge independently recurring faces first. The smaller groups may contain
    # side profiles whose center is far from a larger frontal-face group, but
    # can still be connected through a well-supported intermediate group.
    for _, a_id, b_id in reversed(montage_candidates):
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        first, second = root(a_id), root(b_id)
        if first == second:
            continue
        left_faces, right_faces = component_faces(first), component_faces(second)
        if (min(len(left_faces), len(right_faces)) < 12
                or not components_compatible(first, second, .5)
                or len({face.shot_id for face in left_faces}) < 2
                or len({face.shot_id for face in right_faces}) < 2
                or any(_face_groups_seen_together(face_group_by_id[a], face_group_by_id[b],
                                                   by_face_id)
                       for a in members[first] for b in members[second])):
            continue
        if _strong_face_match(left_faces, right_faces, center_threshold=.84,
                              pair_threshold=.65, min_smaller_fraction=.7,
                              min_larger_hits=8, cancelled=cancelled):
            join(first, second)
            joined_groups.add(first)

    for _, a_id, b_id in reversed(montage_candidates):
        if cancelled is not None and cancelled():
            raise InterruptedError("Person highlight cancelled")
        first, second = root(a_id), root(b_id)
        if first == second:
            continue
        if not components_compatible(first, second, .5):
            continue
        if _sparse_montage_duplicate_faces(component_faces(first), component_faces(second),
                                           cancelled):
            join(first, second)
            joined_groups.add(first)

    group_to_body: dict[str, set[str]] = defaultdict(set)
    for body_id, faces in body_to_faces.items():
        ids = {root(face_to_group[face.observation_id]) for face in faces
               if face.observation_id in face_to_group}
        if len(ids) == 1:
            group_to_body[ids.pop()].add(body_id)

    person_groups: list[PersonGroup] = []
    used_body_tracks: set[str] = set()
    for canonical in sorted({root(group_id) for group_id in parent}):
        component = [face_group_by_id[group_id] for group_id in members[canonical]]
        body_ids = group_to_body.get(canonical, set())
        used_body_tracks.update(body_ids)
        intervals = [PersonInterval(items[0].shot_id, min(o.time_sec for o in items),
                                    max(observed_end(o.shot_id, o.time_sec) for o in items),
                                    track_id=body_id)
                     for body_id in sorted(body_ids)
                     if (items := by_body_track[body_id])]
        linked_face_ids = {face.observation_id for body_id in body_ids
                           for face in body_to_faces[body_id]}
        for group in component:
            for original in group.intervals:
                if any(face_id not in linked_face_ids for face_id in original.observation_ids):
                    intervals.append(PersonInterval(original.shot_id, original.start_sec,
                        observed_end(original.shot_id, original.end_sec)))
        observations = tuple(dict.fromkeys(obs_id for group in component
                                            for obs_id in group.observation_ids))
        candidates = representative_candidates([by_face_id[obs_id] for obs_id in observations])
        person_groups.append(PersonGroup(
            canonical,
            tuple(sorted(set(body_ids) | {track for group in component for track in group.track_ids})),
            observations, _merge_intervals(intervals, sample_interval_sec * .5),
            candidates[0] if candidates else None,
            "needs_review" if not candidates or any(root(joined) == canonical for joined in joined_groups) or any(
                group.status == "needs_review" for group in component) else "grouped",
        ))

    person_groups = _merge_recurrent_face_fragments(
        person_groups, by_face_id, sample_interval_sec * .5, cancelled,
        {group.group_id: frozenset(track for member in members[group.group_id]
                                   for track in face_group_by_id[member].track_ids)
         for group in person_groups},
        track_centers)
    person_groups = _merge_shot_consensus_fragments(
        person_groups, by_face_id, sample_interval_sec * .5, cancelled,
        source_groups=face_groups)
    person_groups = _merge_local_body_fragments(
        person_groups, by_face_id, body_observations, sample_interval_sec, cancelled)
    # Freeze the established identities only after the existing face/body
    # reconciliation has assembled their useful views. Refine once so newly
    # attached fragments cannot recruit more evidence in a second pass.
    metrics = metrics if metrics is not None else PerformanceStats()
    metrics.increment("identity_established_groups", len(person_groups))
    with metrics.measure("identity_refinement"):
        person_groups = refine_person_groups(
            person_groups, face_observations, interval_gap=sample_interval_sec * .5,
            cancelled=cancelled)
    metrics.increment("identity_refined_groups", len(person_groups))

    unresolved_tracks = sorted(set(by_body_track) - used_body_tracks)
    if unresolved_tracks:
        unresolved_intervals = [PersonInterval(
            by_body_track[body_id][0].shot_id,
            min(item.time_sec for item in by_body_track[body_id]),
            max(observed_end(item.shot_id, item.time_sec)
                for item in by_body_track[body_id]), track_id=body_id)
            for body_id in unresolved_tracks]
        person_groups.append(PersonGroup(
            "unidentified", tuple(unresolved_tracks), (),
            tuple(sorted(unresolved_intervals, key=lambda item: (item.start_sec, item.end_sec))),
            None, "needs_review"))

    appearances = sorted((interval.start_sec, interval.end_sec, interval.shot_id,
                          interval.shot_ids or (interval.shot_id,), group.group_id)
                         for group in person_groups for interval in group.intervals)
    windows: list[dict] = []
    for start, end, shot_id, shot_ids, person_id in appearances:
        previous = windows[-1] if windows else None
        if (previous and start <= previous["appearance_end_sec"] + 1e-6
                and (previous["scene_ids"].intersection(shot_ids)
                     or (person_id != "unidentified" and person_id in previous["person_ids"]))):
            previous["appearance_end_sec"] = max(previous["appearance_end_sec"], end)
            previous["person_ids"].add(person_id)
            previous["scene_ids"].update(shot_ids)
        else:
            windows.append({"scene_id": shot_id, "appearance_start_sec": start,
                            "appearance_end_sec": end, "person_ids": {person_id},
                            "scene_ids": set(shot_ids)})
    clips: list[dict] = []
    for index, window in enumerate(windows, 1):
        clips.append({
            "clip_id": f"clip_{index:04d}", "scene_id": window["scene_id"],
            "appearance_start_sec": round(window["appearance_start_sec"], 3),
            "appearance_end_sec": round(window["appearance_end_sec"], 3),
            "source_start_sec": round(max(0., window["appearance_start_sec"] - padding_sec), 3),
            "source_end_sec": round(min(duration_sec, window["appearance_end_sec"] + padding_sec), 3),
            "person_ids": sorted(window["person_ids"]),
            "thumbnail_path": f"thumbnails/clip_{index:04d}.jpg",
        })
    return person_groups, clips
