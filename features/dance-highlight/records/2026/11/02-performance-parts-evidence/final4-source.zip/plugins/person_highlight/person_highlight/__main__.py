import argparse
from .app import PersonHighlightPlugin


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("port", type=int)
    parser.add_argument("--idle-timeout", type=float, default=300.0)
    args = parser.parse_args()
    PersonHighlightPlugin().run(port=args.port, idle_timeout=args.idle_timeout)


if __name__ == "__main__":
    main()
