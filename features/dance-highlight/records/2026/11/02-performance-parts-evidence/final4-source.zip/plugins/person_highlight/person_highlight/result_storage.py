"""Lean UI manifests and lossless float32 embeddings for offline replay."""

from __future__ import annotations

from collections.abc import Sequence
import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any
from uuid import uuid4

import numpy as np

if TYPE_CHECKING:
    from clipper_face_core import FaceObservation


def _vector(value: Any, width: int | None = None) -> np.ndarray:
    vector = np.asarray(value, dtype=np.float32)
    if vector.ndim != 1 or not vector.size or not np.isfinite(vector).all():
        raise ValueError("Embedding must be a finite, nonempty vector")
    if width is not None and vector.size != width:
        raise ValueError("Embedding dimensions do not match")
    return vector


def _sync_directory(path: Path) -> None:
    # Windows does not support opening directories for fsync.
    if os.name != "nt":
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def write_person_result(output_root: Path, manifest: dict[str, Any],
                        observations: Sequence[FaceObservation]) -> Path:
    """Publish a manifest and an immutable array generation, without mutating inputs.

    Observation metadata must have the same order as ``observations``. Only the
    manifest replace commits the result; failed saves remove their own files.
    Prior successful arrays remain readable by consumers holding an old manifest.
    """
    output_root = Path(output_root)
    metadata = manifest.get("observations", [])
    if len(metadata) != len(observations):
        raise ValueError("Observation metadata count does not match")
    rows = []
    count, width = 0, None
    for item, observation in zip(metadata, observations):
        if item.get("observation_id") != observation.observation_id:
            raise ValueError("Observation metadata order does not match")
        row = dict(item)
        row.pop("embedding", None)
        row["embedding_row"] = None
        if observation.embedding is not None:
            vector = _vector(observation.embedding, width)
            width = vector.size
            row["embedding_row"] = count
            count += 1
        rows.append(row)

    directory = output_root / "json"
    directory.mkdir(parents=True, exist_ok=True)
    generation = uuid4().hex
    array_path = directory / f"person_embeddings.{generation}.npy"
    array_part = directory / f".{array_path.name}.part"
    json_path = directory / "person_highlight.json"
    json_part = directory / f".person_highlight.{generation}.json.part"
    shape = (count, width or 0)
    saved = {**manifest, "observations": rows, "embedding_storage": {
        "format": "npy", "path": array_path.relative_to(output_root).as_posix(),
        "dtype": "float32", "shape": list(shape),
    }}
    committed = False
    try:
        matrix = np.lib.format.open_memmap(array_part, mode="w+", dtype=np.float32, shape=shape)
        try:
            index = 0
            for observation in observations:
                if observation.embedding is not None:
                    matrix[index] = _vector(observation.embedding, width)
                    index += 1
            matrix.flush()
        finally:
            matrix._mmap.close()
        with array_part.open("r+b") as stream:
            os.fsync(stream.fileno())
        with json_part.open("w", encoding="utf-8") as stream:
            json.dump(saved, stream, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(array_part, array_path)
        _sync_directory(directory)
        os.replace(json_part, json_path)
        committed = True
        _sync_directory(directory)
        return json_path
    finally:
        array_part.unlink(missing_ok=True)
        json_part.unlink(missing_ok=True)
        if not committed:
            array_path.unlink(missing_ok=True)


def load_person_embeddings(output_root: Path, manifest: dict[str, Any]) -> list[np.ndarray | None]:
    """Read embeddings in observation order, including legacy inline manifests.

    External vectors are read-only views of one memory-mapped float32 array.
    Validation scans that array in bounded chunks and never enables pickle.
    """
    observations = manifest.get("observations", [])
    if "embedding_storage" not in manifest:
        result = []
        width = None
        for observation in observations:
            value = observation.get("embedding")
            vector = None if value is None else _vector(value, width)
            if vector is not None:
                width = vector.size
            result.append(vector)
        return result

    storage = manifest["embedding_storage"]
    if not isinstance(storage, dict) or storage.get("format") != "npy":
        raise ValueError("Unsupported embedding storage format")
    if storage.get("dtype") != "float32":
        raise ValueError("Embedding storage must use float32")
    shape = storage.get("shape")
    if (not isinstance(shape, list) or len(shape) != 2
            or any(type(size) is not int or size < 0 for size in shape)
            or (shape[0] > 0 and shape[1] == 0)):
        raise ValueError("Invalid embedding storage shape")
    relative = storage.get("path")
    if (not isinstance(relative, str) or not relative or "\\" in relative
            or Path(relative).is_absolute() or ".." in Path(relative).parts):
        raise ValueError("Embedding path must stay inside the result directory")
    root = Path(output_root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Embedding path must stay inside the result directory")

    matrix = np.load(path, mmap_mode="r", allow_pickle=False)
    if isinstance(matrix, np.lib.npyio.NpzFile):
        matrix.close()
        raise ValueError("Embedding storage must contain one NumPy array")
    try:
        if matrix.dtype != np.dtype("float32") or matrix.shape != tuple(shape):
            raise ValueError("Embedding array does not match its metadata")
        for start in range(0, shape[0], 1024):
            if not np.isfinite(matrix[start:start + 1024]).all():
                raise ValueError("Embedding array must contain finite values")
        result = []
        for observation in observations:
            if "embedding_row" not in observation:
                raise ValueError("Missing observation embedding row")
            row = observation["embedding_row"]
            if row is None:
                result.append(None)
            elif type(row) is not int or not 0 <= row < shape[0]:
                raise ValueError("Invalid observation embedding row")
            else:
                result.append(matrix[row])
        if not any(vector is not None for vector in result):
            matrix._mmap.close()
        return result
    except BaseException:
        matrix._mmap.close()
        raise
