from collections import Counter
from dataclasses import replace

import numpy as np
import pytest

from clipper_face_core import FaceObservation, group_observations


def run(track, angle, count=6, start=0., *, shot=None):
    radians = np.deg2rad(angle)
    return [FaceObservation(f"{track}_{i}", track, shot or track, start + i * .5,
                            (0, 0, 100, 100),
                            np.asarray([np.cos(radians), np.sin(radians)], np.float32), .9)
            for i in range(count)]


def seeds(*runs):
    return [replace(group_observations(list(items))[0], group_id=f"person_{index:03}")
            for index, items in enumerate(runs, 1)]


def memberships(groups):
    return {frozenset(group.track_ids) for group in groups}


def test_supported_off_axis_views_rejoin_groups_rejected_by_all_track_gate():
    from person_highlight.identity_refinement import refine_face_groups

    observations = run("front", 0, 20) + run("side", 55, 3, 20.) + run("turned", 100, 6, 30.)
    initial = group_observations(observations, cosine_threshold=.50)
    assert len(initial) == 2

    [result] = refine_face_groups(initial, observations)

    assert set(result.track_ids) == {"front", "side", "turned"}
    assert result.status == "needs_review"
    assert Counter(result.observation_ids) == Counter(item.observation_id for item in observations)


def test_many_competing_anchors_do_not_retain_quadratic_candidate_payloads():
    import tracemalloc
    from person_highlight.identity_refinement import refine_face_groups

    runs = [[replace(item, embedding=np.pad(item.embedding, (0, 510)))
             for item in run(f'track_{index}', 0, start=index * 10.)]
            for index in range(200)]
    groups = seeds(*runs)
    observations = [item for items in runs for item in items]
    tracemalloc.start()
    try:
        result = refine_face_groups(groups, observations)
        _, peak = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
    assert len(result) == 200  # equally plausible identities stay unresolved
    assert peak < 4 * 1024**2


def test_two_observation_fragment_in_one_shot_can_use_supported_profile():
    from person_highlight.identity_refinement import refine_face_groups

    observations = run("front", 0, 20) + run("side", 55, 3, 20.) + run("brief", 98, 2, 30.)
    initial = group_observations(observations, cosine_threshold=.50)
    assert len(initial) == 2

    [result] = refine_face_groups(initial, observations)

    assert set(result.track_ids) == {"front", "side", "brief"}
    brief = [interval for interval in result.intervals if interval.shot_id == "brief"]
    assert [(interval.start_sec, interval.end_sec) for interval in brief] == [(30., 30.5)]


def test_repeated_shared_view_can_join_banks_with_other_unmatched_angles():
    from person_highlight.identity_refinement import refine_face_groups

    for shared_count, expected_count in [(3, 1), (1, 2)]:
        first = run('front', 0, 20) + run('left_view', 55, shared_count, 20.)
        second = run('profile', 110, 20, 30.) + run('right_view', 55, shared_count, 50.)
        groups = seeds(first, second)
        assert len(refine_face_groups(groups, first + second)) == expected_count


def test_singleton_uses_strong_repeated_anchor_support():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0)
    strong = run("strong", 20, 1, 10.)
    weak = run("weak", 40, 1, 20.)

    result = refine_face_groups(seeds(anchor, strong, weak), anchor + strong + weak)

    assert memberships(result) == {frozenset({"anchor", "strong"}), frozenset({"weak"})}
    assert all(group.status == "needs_review" for group in result)


def test_singleton_near_tie_between_known_people_remains_separate():
    from person_highlight.identity_refinement import refine_face_groups

    first = run("first", 0, shot="together")
    second = run("second", 30, shot="together")
    fragment = run("fragment", 15, 1, 10.)

    result = refine_face_groups(seeds(first, second, fragment), first + second + fragment)

    assert memberships(result) == {frozenset({"first"}), frozenset({"second"}),
                                   frozenset({"fragment"})}


def test_runner_up_below_singleton_threshold_still_blocks_a_near_tie():
    from person_highlight.identity_refinement import refine_face_groups

    first = run("first", 29, shot="together")  # cos(29) = .875
    second = run("second", -32, shot="together")  # cos(32) = .848
    fragment = run("fragment", 0, 1, 10.)

    result = refine_face_groups(seeds(first, second, fragment), first + second + fragment)

    assert len(result) == 3


def test_clear_evidence_in_review_group_is_usable_without_recruiting_from_uncertain_faces():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0, 10)
    anchor += [replace(item, track_id="anchor", association_uncertain=True)
               for item in run("uncertain", 90, 2, 8.)]
    fragment, stranger = run("fragment", 20, 2, 10.), run("stranger", 90, 2, 20.)
    groups = seeds(anchor, fragment, stranger)
    assert groups[0].status == "needs_review"

    result = refine_face_groups(groups, anchor + fragment + stranger)

    assert memberships(result) == {frozenset({"anchor", "fragment"}), frozenset({"stranger"})}
    assert result[0].status == "needs_review"
    assert {"uncertain_0", "uncertain_1"} <= set(result[0].observation_ids)


def test_anchor_pairs_cannot_chain_into_a_third_reliable_identity():
    from person_highlight.identity_refinement import refine_face_groups

    first = run("first", 0)
    bridge = run("bridge", 20, start=10.)
    other = run("other", 55, start=20.)

    result = refine_face_groups(seeds(first, bridge, other), first + bridge + other)

    assert memberships(result) == {frozenset({"first", "bridge"}), frozenset({"other"})}


def test_mutually_competing_reliable_anchors_do_not_merge():
    from person_highlight.identity_refinement import refine_face_groups

    middle, left, right = run("middle", 0), run("left", -40, start=10.), run("right", 40, start=20.)

    result = refine_face_groups(seeds(middle, left, right), middle + left + right)

    assert len(result) == 3


def test_co_visible_people_veto_even_identical_embedding_matches():
    from person_highlight.identity_refinement import refine_face_groups

    first = run("first", 0, shot="same_shot")
    second = run("second", 0, start=.0007, shot="same_shot")

    assert len(refine_face_groups(seeds(first, second), first + second)) == 2


def test_two_co_visible_fragments_cannot_attach_to_the_same_anchor():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0)
    first = run("first", 10, 2, 10., shot="same_shot")
    second = run("second", 10, 2, 10., shot="same_shot")

    result = refine_face_groups(seeds(anchor, first, second), anchor + first + second)

    assert len(result) == 3


def test_attached_fragment_cannot_poison_evidence_for_the_next_fragment():
    from person_highlight.identity_refinement import refine_face_groups

    anchor, bridge, stranger = run("anchor", 0), run("bridge", 40, 2, 10.), run("stranger", 75, 2, 20.)

    result = refine_face_groups(seeds(anchor, bridge, stranger), anchor + bridge + stranger)

    assert memberships(result) == {frozenset({"anchor", "bridge"}), frozenset({"stranger"})}


def test_one_bad_anchor_observation_cannot_pull_in_an_unrelated_fragment():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0) + [replace(run("bad", 90, 1, 8.)[0], track_id="anchor")]
    fragment = run("fragment", 90, 2, 10.)
    # Keep a noisy frame inside the original tracked identity, as in real input.
    result = refine_face_groups(seeds(anchor, fragment), anchor + fragment)

    assert len(result) == 2


def test_low_quality_or_uncertain_singletons_are_preserved_without_attachment():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0)
    weak = [replace(run("weak", 0, 1, 10.)[0], quality=.2)]
    uncertain = [replace(run("uncertain", 0, 1, 20.)[0], association_uncertain=True)]
    missing = [replace(run("missing", 0, 1, 30.)[0], embedding=None)]

    result = refine_face_groups(seeds(anchor, weak, uncertain, missing),
                                anchor + weak + uncertain + missing)

    assert len(result) == 4
    assert Counter(identifier for group in result for identifier in group.observation_ids) == Counter(
        item.observation_id for item in anchor + weak + uncertain + missing)
    assert all(group.status == "needs_review" for group in result if group.track_ids != ("anchor",))


def test_reassignment_preserves_inputs_ids_intervals_and_existing_uncertainty():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0)
    brief = run("brief", 20, 1, 10.)
    observations = anchor + brief
    groups = seeds(anchor, brief)
    before = tuple(groups)
    vectors = [item.embedding.copy() for item in observations]

    [result] = refine_face_groups(groups, observations)
    reversed_result = refine_face_groups(list(reversed(groups)), list(reversed(observations)))

    assert tuple(groups) == before
    for original, vector in zip(observations, vectors):
        np.testing.assert_array_equal(original.embedding, vector)
    assert result == reversed_result[0]
    assert result.group_id == "person_001"
    assert result.status == "needs_review"
    assert result.representative_observation_id in result.observation_ids
    assert [(i.shot_id, i.start_sec, i.end_sec) for i in result.intervals] == [
        ("anchor", 0., 2.5), ("brief", 10., 10.)]


@pytest.mark.parametrize("field", ["model_sha256", "config_sha256"])
def test_refinement_refuses_mixed_spaces_before_any_assignment(field):
    from person_highlight.identity_refinement import refine_face_groups

    first = [replace(item, **{field: "first"}) for item in run("first", 0)]
    second = [replace(item, **{field: "second"}) for item in run("second", 0, 1, 10.)]

    with pytest.raises(ValueError, match="model/config spaces"):
        refine_face_groups(seeds(first, second), first + second)


def test_refinement_checks_cancellation_during_work_and_on_empty_input():
    from person_highlight.identity_refinement import refine_face_groups

    checks = 0

    def cancelled():
        nonlocal checks
        checks += 1
        return checks == 12

    runs = [run(f"track_{i}", float(i * 20), start=float(i * 10)) for i in range(10)]
    with pytest.raises(InterruptedError):
        refine_face_groups(seeds(*runs), [item for track in runs for item in track],
                           cancelled=cancelled)
    with pytest.raises(InterruptedError):
        refine_face_groups([], [], cancelled=lambda: True)


def test_malformed_seed_partition_cannot_silently_duplicate_or_drop_observations():
    from person_highlight.identity_refinement import refine_face_groups

    first, second = run("first", 0), run("second", 90)
    groups = seeds(first, second)
    with pytest.raises(ValueError, match="partition"):
        refine_face_groups(groups[:1], first + second)
    with pytest.raises(ValueError, match="partition"):
        refine_face_groups([groups[0], replace(groups[0], group_id="duplicate")], first)


def test_many_observation_short_fragments_do_not_compete_with_their_established_anchor():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0, 100)
    first = run("first", 10, 12, 100.)
    second = run("second", -10, 12, 200.)

    result = refine_face_groups(seeds(anchor, first, second), anchor + first + second)

    assert memberships(result) == {frozenset({"anchor", "first", "second"})}


def test_fragment_duration_counts_observed_runs_instead_of_elapsed_video_span():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0, 100)
    fragment = [replace(item, track_id="fragment")
                for i in range(4) for item in run(f"scene_{i}", 20, 4, 100. + i * 200.)]

    result = refine_face_groups(seeds(anchor, fragment), anchor + fragment)

    assert memberships(result) == {frozenset({"anchor", "fragment"})}


def omitted_view_anchor():
    observations = [replace(run(f"v{v}", 0, 5, v * 5.)[i], track_id="anchor",
                            shot_id="anchor", embedding=np.eye(13, dtype=np.float32)[v])
                    for v in range(12) for i in range(5)]
    query = .55 * np.eye(13, dtype=np.float32)[0] + np.sqrt(1 - .55**2) * np.eye(13)[12]
    observations += [replace(item, track_id="anchor", embedding=query, quality=.65)
                     for item in run("omitted", 0, 4, 70.)]
    return observations, query.astype(np.float32)


def test_final_verification_uses_observations_missing_from_the_template_bank():
    from person_highlight.identity_refinement import refine_face_groups

    anchor, query = omitted_view_anchor()
    fragment = [replace(item, embedding=query) for item in run("fragment", 0, 10, 100.)]

    result = refine_face_groups(seeds(anchor, fragment), anchor + fragment)

    assert memberships(result) == {frozenset({"anchor", "fragment"})}


def test_runner_up_is_also_verified_with_all_observations_before_fragment_assignment():
    from person_highlight.identity_refinement import refine_face_groups

    anchor, query = omitted_view_anchor()
    rival = [replace(item, shot_id="anchor", embedding=.95 * query +
                     np.sqrt(1 - .95**2) * np.eye(13, dtype=np.float32)[1])
             for item in run("rival", 0, 80)]
    fragment = [replace(item, embedding=query) for item in run("fragment", 0, 2, 100.)]

    result = refine_face_groups(seeds(anchor, rival, fragment), anchor + rival + fragment)

    assert len(result) == 3


def test_best_lookup_runner_up_is_verified_even_when_its_bank_score_is_below_retrieval_gate():
    from person_highlight.identity_refinement import refine_face_groups

    query = np.eye(14)[0]
    anchor = [replace(item, embedding=query) for item in run("anchor", 0, 100)]
    rival = [replace(item, shot_id="anchor", track_id="rival", embedding=np.eye(14)[v])
             for v in range(1, 13) for item in run(f"v{v}", 0, 5, float(v * 5))]
    rival += [replace(item, track_id="rival", quality=.65,
                      embedding=.95 * query + np.sqrt(1 - .95**2) * np.eye(14)[13])
              for item in run("omitted", 0, 4, 80.)]
    fragment = [replace(item, embedding=query) for item in run("fragment", 0, 2, 100.)]

    result = refine_face_groups(seeds(anchor, rival, fragment), anchor + rival + fragment)

    assert len(result) == 3


def test_many_observation_fragment_cannot_recruit_a_later_fragment():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = run("anchor", 0, 100)
    bridge = run("bridge", 40, 12, 100.)
    stranger = run("stranger", 75, 12, 200.)

    result = refine_face_groups(seeds(anchor, bridge, stranger), anchor + bridge + stranger)

    assert memberships(result) == {frozenset({"anchor", "bridge"}), frozenset({"stranger"})}


def test_four_repeated_supports_can_verify_a_short_group_with_other_unmatched_views():
    from person_highlight.identity_refinement import refine_face_groups

    anchor = [replace(item, embedding=np.eye(14)[0]) for item in run("anchor", 0, 100)]
    anchor += [replace(item, track_id="anchor", embedding=np.eye(14)[v])
               for v in range(2, 14) for item in run(f"view{v}", 0, 5, 200. + v * 5.)]
    vector = np.cos(np.deg2rad(43)) * np.eye(14)[0] + np.sin(np.deg2rad(43)) * np.eye(14)[1]
    matching = [replace(item, track_id="fragment", embedding=vector)
                for item in run("matching", 43, 4, 100.)]
    other = [replace(item, track_id="fragment", embedding=np.eye(14)[1])
             for item in run("other", 100, 20, 110.)]
    fragment = matching + other

    result = refine_face_groups(seeds(anchor, fragment), anchor + fragment)

    assert memberships(result) == {frozenset({"anchor", "fragment"})}


def test_person_adapter_retains_body_tracks_and_original_appearance_intervals():
    from person_highlight.identity_refinement import refine_person_groups
    from person_highlight.occurrences import PersonGroup, PersonInterval

    anchor = run("anchor", 0, 100)
    fragment = run("fragment", 20, 12, 100.)
    first_interval = PersonInterval("anchor", 0., 55., track_id="body_anchor")
    second_interval = PersonInterval("fragment", 99., 108., track_id="body_fragment")
    groups = [PersonGroup("main", ("anchor", "body_anchor"),
                          tuple(item.observation_id for item in anchor), (first_interval,),
                          anchor[0].observation_id, "grouped"),
              PersonGroup("brief", ("fragment", "body_fragment"),
                          tuple(item.observation_id for item in fragment), (second_interval,),
                          fragment[0].observation_id, "grouped")]

    [result] = refine_person_groups(groups, anchor + fragment, interval_gap=.25)

    assert set(result.track_ids) == {"anchor", "body_anchor", "fragment", "body_fragment"}
    assert result.intervals == (first_interval, second_interval)
    assert set(result.observation_ids) == {item.observation_id for item in anchor + fragment}
    assert result.status == "needs_review"


def test_person_adapter_cannot_bridge_comparable_groups_through_a_merged_constituent():
    from person_highlight.identity_refinement import refine_person_groups
    from person_highlight.occurrences import PersonGroup, PersonInterval

    first = run("first", 0, 8)
    bridge = run("bridge", 35, 8, 20.)
    last = run("last", 70, 8, 40.)
    combined = first + bridge
    groups = [PersonGroup("combined", ("first", "bridge"),
                          tuple(item.observation_id for item in combined),
                          (PersonInterval("first", 0., 4.), PersonInterval("bridge", 20., 24.)),
                          first[0].observation_id, "needs_review"),
              PersonGroup("last", ("last",), tuple(item.observation_id for item in last),
                          (PersonInterval("last", 40., 44.),), last[0].observation_id, "grouped")]

    result = refine_person_groups(groups, combined + last, interval_gap=.25)

    assert len(result) == 2


@pytest.mark.parametrize("query_count", [2, 100])
@pytest.mark.parametrize("use_person_adapter", [False, True])
def test_hidden_third_lookup_rival_blocks_fragment_and_reliable_anchor_merges(
        query_count, use_person_adapter):
    from person_highlight.identity_refinement import refine_face_groups, refine_person_groups
    from person_highlight.occurrences import PersonGroup, PersonInterval

    eye = np.eye(14, dtype=np.float32)
    anchor = [replace(item, embedding=eye[0])
              for item in run("anchor", 0, 100, shot="together")]
    rival = [replace(item, track_id="rival", embedding=eye[v])
             for v in range(1, 13)
             for item in run(f"v{v}", 0, 5, float(v * 5), shot="together")]
    rival += [replace(item, track_id="rival", quality=.65,
                      embedding=.95 * eye[0] + np.sqrt(1 - .95**2) * eye[13])
              for item in run("omitted", 0, 4, 80.)]
    distractor = [replace(item, embedding=.4 * eye[0] + np.sqrt(1 - .4**2) * eye[13])
                  for item in run("distractor", 0, 100, shot="together")]
    query = [replace(item, embedding=eye[0])
             for item in run("query", 0, query_count, 100., shot="later")]
    # These co-visible alternatives push query below the rival's own lookup
    # top two as well, exercising reciprocal reliable-anchor verification.
    others = [[replace(item, embedding=eye[v])
               for item in run(f"other{v}", 0, 100, 100., shot="later")]
              for v in (1, 2)]
    runs = [anchor, rival, distractor, query, *others]
    observations = [item for items in runs for item in items]
    groups = seeds(*runs)
    if use_person_adapter:
        person_groups = [PersonGroup(group.group_id, group.track_ids, group.observation_ids,
                                     tuple(PersonInterval(i.shot_id, i.start_sec, i.end_sec)
                                           for i in group.intervals),
                                     group.representative_observation_id, group.status)
                         for group in groups]
        result = refine_person_groups(person_groups, observations, interval_gap=.25)
    else:
        result = refine_face_groups(groups, observations)

    assert not any({"anchor", "query"} <= set(group.track_ids) for group in result)
