"""Incoming preparation is overlapping clip context, never a main-role rewrite."""
from dataclasses import replace
import copy

import numpy as np
import pytest

from dance_highlight.services.face_evidence import FaceObservation
from dance_highlight.services.incoming_context import incoming_preparation_context
from dance_highlight.services.reference_matcher import SegmentReferenceDecision
from dance_highlight.services.segment import FrameRec, Segment


def person(index, x, size=7., y=20., scale=1.):
    pose = np.zeros((17, 3), dtype=float)
    pose[:, 2] = .99
    pose[:5, :2] = [[x, y], [x-1, y-1], [x+1, y-1], [x-2, y], [x+2, y]]
    pose[[5, 6], :2] = [[x-4*scale, y+7], [x+4*scale, y+7]]
    pose[[11, 12], :2] = [[x-3*scale, y+23*scale], [x+3*scale, y+23*scale]]
    pose[[13, 14], :2] = [[x-3, y+34*scale], [x+3, y+34*scale]]
    pose[[15, 16], :2] = [[x-3, y+45*scale], [x+3, y+45*scale]]
    pose[[7, 8, 9, 10], :2] = [x, y+20]
    return dict(index=index, x=x, size=size, box=[x-7, y-4, x+7, y+47*scale],
                pose_keypoints=pose, head_keypoints=pose[:5], source='detected')


def observation(row, feature):
    x, y = feature['pose_keypoints'][0, :2]
    return FaceObservation(row['frame'], row['time'], feature['index'], tuple(feature['box']),
        tuple(feature['box']), face_bbox=(x-3, y-3, x+3, y+3),
        embedding=np.array([1., 0.]), detector_score=.99, association='confirmed')


class CapturedQuery:
    """Captured detector/recognizer results; the policy under test is real."""
    width = height = 100

    def __init__(self, rows):
        self.rows = {r['frame']: r for r in rows}
        self.answers = {}
        self.calls = []
        for row in rows:
            for f in row['features']:
                obs = observation(row, f)
                self.answers[(row['frame'], f['index'])] = (obs,
                    dict(status='accepted', name='A' if f['index'] == 0 else 'B'))

    def geometry(self, record):
        return self.rows[round(record.t*100)]

    def observe(self, record, body_index):
        key = (round(record.t*100), body_index)
        self.calls.append(key)
        return self.answers.get(key, (None, {}))


def case():
    rows, records = [], []
    for frame in range(100, 241, 10):
        before = frame < 200
        x = 32+(frame-100)*.1 if before else 50
        features = [person(0, x, size=8 if before else 12, scale=1 if before else 1.35),
                    person(1, 65, size=7), person(2, 20, size=6)]
        row = dict(frame=frame, time=frame/100, features=features)
        rows.append(row)
        main = features[1 if before else 0]
        records.append(FrameRec(frame/100, main['index'], np.array(main['box']), False,
            person_bboxes=[np.array(f['box']) for f in features],
            person_head_keypoints=[f['head_keypoints'] for f in features],
            person_pose_keypoints=[f['pose_keypoints'] for f in features],
            candidate_main_bbox=np.array(main['box']), candidate_main_id=main['index']))
    query = CapturedQuery(rows)
    own = [query.answers[(f, 0)][0] for f in range(200, 241, 10)]
    identity = dict(segments=[Segment('main', 1, 1., 2., []), Segment('main', 2, 2., 2.5, [])],
        decisions=[SegmentReferenceDecision('B', 'matched', 'existing'),
                   SegmentReferenceDecision('A', 'matched', 'existing')],
        labels=[1, 2], evidence=[[], [(o, 'A') for o in own]],
        previews=[[], []], preview_sources=[({}, {}), ({}, {})], accurate_indices=[0, 1])
    joint = {o.frame_index: dict(status='accepted', name='A') for o in own}
    return identity, records, joint, query


def run(data, cuts=(100, 200)):
    identity, records, joint, query = data
    return incoming_preparation_context(identity, records, joint, fps=100., cut_frames=cuts, query=query)


def test_named_preparation_path_returns_context_and_preserves_outgoing_evidence():
    data = case()
    original = copy.deepcopy(data[0])
    contexts, audit = run(data)
    assert len(contexts) == 1
    context = contexts[0]
    assert (context['source_index'], context['start'], context['end'], context['reference_id']) == (1, 1., 2., 'A')
    assert context['visible_targets'] == [dict(frame=f, index=0) for f in range(100, 200, 10)]
    assert all(o.body_bbox == tuple(data[3].rows[o.frame_index]['features'][0]['box'])
               for o in context['observations'])
    assert [(s.start, s.end) for s in data[0]['segments']] == [(s.start, s.end) for s in original['segments']]
    assert data[0]['decisions'] == original['decisions']
    assert audit['accepted'][0]['reason'] == 'named_incoming_preparation'


@pytest.mark.parametrize('problem', ['wrong_body', 'contrary_name', 'missing_faces', 'ambiguous_owner'])
def test_incoming_context_requires_original_unique_owned_name(problem):
    data = case()
    query = data[3]
    for frame in range(100, 200, 10):
        obs, match = query.answers[(frame, 0)]
        if problem == 'wrong_body':
            obs = replace(obs, body_bbox=tuple(query.rows[frame]['features'][1]['box']))
        elif problem == 'contrary_name':
            match = dict(status='accepted', name='B')
        elif problem == 'missing_faces':
            obs, match = None, {}
        else:
            obs = replace(obs, association='ambiguous')
        query.answers[(frame, 0)] = obs, match
    assert run(data)[0] == []


@pytest.mark.parametrize('problem', ['outgoing_closeup', 'distant_group', 'static_formation', 'missing_cut', 'missing_previous_cut'])
def test_no_blanket_backfill_of_formation_or_unobserved_cut(problem):
    data = case()
    if problem in ('outgoing_closeup', 'distant_group', 'static_formation'):
        for row in data[3].rows.values():
            if row['frame'] >= 200:
                continue
            if problem == 'outgoing_closeup':
                row['features'][1]['box'] = [45, 0, 85, 100]
            elif problem == 'distant_group':
                for f in row['features']:
                    f['box'][3] = f['box'][1]+15
            else:
                row['features'][0] = person(0, 32, size=8)
                data[3].answers[(row['frame'], 0)] = (observation(row, row['features'][0]), dict(status='accepted', name='A'))
    cuts = [100] if problem == 'missing_cut' else [200] if problem == 'missing_previous_cut' else [100, 200]
    assert run(data, cuts)[0] == []


def test_incoming_name_needs_two_owned_independent_joint_observations():
    data = case()
    data[2].clear()
    data[2][200] = dict(status='accepted', name='A')
    assert run(data)[0] == []
    assert data[3].calls == []


def test_source_sampling_gap_stops_context_at_observed_path():
    data = case()
    data[1][:] = [r for r in data[1] if not 1.1 <= r.t <= 1.4]
    contexts, _ = run(data)
    assert contexts[0]['start'] == 1.5
    assert contexts[0]['visible_targets'][0] == dict(frame=150, index=0)


def test_ambiguous_body_edge_cannot_use_weak_names_to_join_paths():
    data = case()
    for frame in range(100, 160, 10):
        row = data[3].rows[frame]
        row['features'][0] = person(0, row['features'][0]['x']-12, size=8)
        data[3].answers[(frame, 0)] = observation(row, row['features'][0]), dict(status='insufficient', name=None)
    contexts, _ = run(data)
    assert contexts[0]['start'] == 1.6


def test_frozen_query_matches_without_overwriting_same_frame_original_anchor():
    from dance_highlight.services.incoming_context import match_frozen_query
    row = observation(dict(frame=100, time=1.), person(0, 50))
    frozen = dict(observations={}, vectors={}, anchors=[], roster={'A', 'B'})
    for name, frames, vector in [('A', (100, 1000, 1100), [1., 0.]), ('B', (1200, 1300), [0., 1.])]:
        for frame in frames:
            own = replace(row, frame_index=frame, time_seconds=frame/100, embedding=np.array(vector))
            frozen['observations'][frame] = own
            frozen['vectors'][frame] = np.array(vector)
            frozen['anchors'].append(dict(name=name, frame_index=frame))
    original = frozen['observations'][100]
    query = replace(row, embedding=np.array([0., 1.]))
    result = match_frozen_query(query, np.array([0., 1.]), frozen)
    assert result['status'] == 'accepted' and result['name'] == 'B'
    assert frozen['observations'][100] is original
    assert len(frozen['anchors']) == 5
    assert all(abs(frame/100-query.time_seconds) > 2. for frames in result['support_frames'] for frame in frames)


def test_extraction_adapter_caches_detection_and_keeps_separate_body_observations(monkeypatch):
    import cv2
    from types import SimpleNamespace
    from dance_highlight.services.incoming_context import IncomingFaceQuery
    data = case()
    record = data[1][0]
    features = data[3].rows[100]['features']
    detected = np.asarray([[f['x']-3, 17, 6, 6, f['x']-1, 19, f['x']+1, 19, f['x'], 20,
                            f['x']-1, 22, f['x']+1, 22, .99] for f in features], dtype=np.float32)

    class Capture:
        frame = 0
        closed = False
        def isOpened(self): return True
        def get(self, key): return {cv2.CAP_PROP_FPS: 100., cv2.CAP_PROP_FRAME_WIDTH: 100,
                                    cv2.CAP_PROP_FRAME_HEIGHT: 100, cv2.CAP_PROP_POS_FRAMES: self.frame}.get(key, 0)
        def set(self, key, value): self.frame = value; return True
        def read(self): self.frame += 1; return True, np.zeros((100, 100, 3), np.uint8)
        def release(self): self.closed = True
    capture = Capture()
    monkeypatch.setattr(cv2, 'VideoCapture', lambda path: capture)
    class Detector:
        calls = 0
        def setInputSize(self, size): pass
        def detect(self, image): self.calls += 1; return None, detected
    detector = Detector()
    def inspect(image, **kwargs):
        body = tuple(kwargs['source_body'])
        index = next(i for i, f in enumerate(features) if tuple(f['box']) == body)
        face = detected[index]
        return SimpleNamespace(embedding=np.eye(3)[index], quality=1., face_bbox=tuple(np.r_[face[:2], face[:2]+face[2:4]]),
            landmarks=tuple(map(tuple, face[4:14].reshape(5, 2))), candidate_boxes=(), detector_score=.99,
            face_sharpness=10., detection_rotation_degrees=0.), None
    class Secondary:
        def alignCrop(self, image, face): return face
        def feature(self, face): return np.array([1., 0.])
    query = IncomingFaceQuery(SimpleNamespace(_detector=detector, _inspect_face=inspect), 'source.mp4', 100.,
                              dict(observations={}, vectors={}, anchors=[], roster=set()), Secondary())
    assert len(query.geometry(record)['features']) == 3
    first, _ = query.observe(record, 0)
    second, _ = query.observe(record, 1)
    assert first is query.observe(record, 0)[0]
    assert first.frame_index == second.frame_index == 100
    assert first.body_bbox != second.body_bbox
    assert detector.calls == 1
    query.close()
    assert capture.closed


def test_applying_context_preserves_parallel_arrays_and_outgoing_member():
    from dance_highlight.services.incoming_context import apply_preparation_contexts
    data = case()
    contexts, _ = run(data)
    result = apply_preparation_contexts(data[0], contexts)
    assert [(s.start, s.end) for s in result['segments']] == [(1., 2.), (1., 2.5)]
    assert result['segments'][0] is data[0]['segments'][0]
    assert result['decisions'] == data[0]['decisions']
    assert result['labels'] == data[0]['labels']
    assert result['accurate_indices'] == data[0]['accurate_indices']
    assert all(len(result[key]) == 2 for key in ('segments', 'decisions', 'labels', 'evidence', 'previews', 'preview_sources'))
    assert result['evidence'][0] is data[0]['evidence'][0]
    assert [(o, name) for o, name in result['evidence'][1] if o.time_seconds < 2.] == [(o, None) for o in contexts[0]['observations']]
    assert all(track_id == -1 for _, _, track_id in result['segments'][1].bboxes)
    assert result['preview_sources'] is data[0]['preview_sources']
    assert data[0]['segments'][1].start == 2.


@pytest.mark.parametrize('problem', ['wrong_end', 'wrong_name', 'wrong_index', 'nonfinite_start'])
def test_apply_context_rejects_stale_or_wrong_target(problem):
    from dance_highlight.services.incoming_context import apply_preparation_contexts
    data = case()
    contexts, _ = run(data)
    contexts[0][{'wrong_end':'end', 'wrong_name':'reference_id', 'wrong_index':'source_index', 'nonfinite_start':'start'}[problem]] = {
        'wrong_end':2.1, 'wrong_name':'B', 'wrong_index':0, 'nonfinite_start':float('nan')}[problem]
    assert apply_preparation_contexts(data[0], contexts) is data[0]


def test_obviously_incompatible_previous_view_requires_no_detector_or_face_queries():
    data = case()
    for record in data[1]:
        if record.t < 2:
            record.person_bboxes[1] = np.array([45., 0., 85., 100.])
    def unexpected_geometry(record):
        pytest.fail('closeup was not rejected from existing pose/body observations')
    data[3].geometry = unexpected_geometry
    assert run(data)[0] == []


def test_named_owned_endpoints_can_bridge_a_small_ambiguous_pose_step():
    data = case()
    for frame in range(100, 160, 10):
        row = data[3].rows[frame]
        row['features'][0] = person(0, row['features'][0]['x']-6, size=8)
        record = next(r for r in data[1] if round(r.t*100) == frame)
        record.person_bboxes[0] = np.asarray(row['features'][0]['box'])
        record.person_pose_keypoints[0] = row['features'][0]['pose_keypoints']
        record.person_head_keypoints[0] = row['features'][0]['head_keypoints']
        data[3].answers[(frame, 0)] = observation(row, row['features'][0]), dict(status='accepted', name='A')
    contexts, _ = run(data)
    assert contexts[0]['start'] == 1.
    assert contexts[0]['bridges'] == [dict(previous_frame=150, frame=160, reason='independently_named_owned_endpoints')]


def test_reviewed_preparation_uses_captured_owned_faces_and_one_named_pose_bridge():
    import json
    from pathlib import Path
    from dance_highlight.services.incoming_context import apply_preparation_contexts
    data = json.loads((Path(__file__).parent/'fixtures/dance_incoming_preparation_reviewed.json').read_text())
    def own(value):
        if value is None:
            return None
        value = dict(value, embedding=np.asarray(value['embedding']))
        for key in ('body_bbox', 'roi_bbox', 'face_bbox'):
            value[key] = tuple(value[key]) if value[key] is not None else None
        return FaceObservation(**value)
    records = [FrameRec(**dict(r, person_bboxes=[np.asarray(b) for b in r['person_bboxes']],
        person_pose_keypoints=[np.asarray(p) for p in r['person_pose_keypoints']],
        person_head_keypoints=[np.asarray(p) for p in r['person_head_keypoints']])) for r in data['records']]
    rows = {r['frame']:dict(r, features=[dict(f, pose_keypoints=np.asarray(f['pose_keypoints'])) for f in r['features']]) for r in data['rows']}
    answers = {(q['frame'], q['index']):(own(q['observation']),q['match']) for q in data['queries']}
    class Captured:
        width=data['width']; height=data['height']
        def geometry(self, record): return rows[round(record.t*data['fps'])]
        def observe(self, record, index): return answers.get((round(record.t*data['fps']),index),(None,{}))
    s = data['segment']
    identity = dict(segments=[Segment('main', 1, s['start'], s['end'], [])],
        decisions=[SegmentReferenceDecision(s['name'], 'matched', 'existing')],
        evidence=[[(own(o), s['name']) for o in data['evidence']]])
    contexts, audit = incoming_preparation_context(identity, records, {int(f):m for f,m in data['joint'].items()},
        fps=data['fps'], cut_frames=data['cuts'], query=Captured())
    assert len(contexts) == 1
    assert contexts[0]['start'] == data['expected_start']
    assert contexts[0]['end'] == data['expected_end']
    assert len(contexts[0]['visible_targets']) == 17
    assert contexts[0]['bridges'] == [dict(previous_frame=2768, frame=2772, reason='independently_named_owned_endpoints')]
    result = apply_preparation_contexts(identity, contexts)
    assert result['segments'][0].end == s['end']
    assert identity['segments'][0].start == s['start']
    assert audit['accepted'][0]['context_observations']
    # With that independent same-name endpoint removed, geometry cannot borrow
    # the earlier preparation across the ambiguous crossing.
    frame, index = 2768, 3
    old, match = answers[(frame,index)]
    answers[(frame,index)] = old, dict(status='insufficient', name=None)
    bounded, _ = incoming_preparation_context(identity, records, {int(f):m for f,m in data['joint'].items()},
        fps=data['fps'], cut_frames=data['cuts'], query=Captured())
    assert bounded[0]['start'] == pytest.approx(2772/data['fps'])


def test_a_contrary_accepted_incoming_name_vetoes_preparation():
    data = case()
    data[2][210] = dict(status='accepted', name='B')
    assert run(data)[0] == []


def test_contrary_accepted_name_inside_backwards_path_vetoes_context():
    data = case()
    own, _ = data[3].answers[(140, 0)]
    data[3].answers[(140, 0)] = own, dict(status='accepted', name='B')
    assert run(data)[0] == []


def test_valid_lower_detector_rival_in_incoming_evidence_still_vetoes_context():
    data = case()
    data[0]['evidence'][1] = [(replace(o, detector_score=.89) if o.frame_index == 210 else o, n)
                             for o, n in data[0]['evidence'][1]]
    data[2][210] = dict(status='accepted', name='B')
    assert run(data)[0] == []


def test_valid_lower_detector_rival_on_backwards_path_still_vetoes_context():
    data = case()
    own, _ = data[3].answers[(140, 0)]
    data[3].answers[(140, 0)] = replace(own, detector_score=.89), dict(status='accepted', name='B')
    assert run(data)[0] == []


@pytest.mark.parametrize('positive', ['incoming', 'tail_seed', 'repeated_path'])
def test_lower_detector_observations_cannot_supply_positive_context_support(positive):
    data = case()
    if positive == 'incoming':
        data[0]['evidence'][1] = [(replace(o, detector_score=.89), n) for o, n in data[0]['evidence'][1]]
    else:
        frames = [190] if positive == 'tail_seed' else range(100, 190, 10)
        for frame in frames:
            own, match = data[3].answers[(frame, 0)]
            data[3].answers[(frame, 0)] = replace(own, detector_score=.89), match
    assert run(data)[0] == []


def test_incoming_contradiction_must_belong_to_its_actual_selected_body():
    data = case()
    foreign, _ = data[3].answers[(210, 1)]
    data[0]['evidence'][1] = [(foreign if o.frame_index == 210 else o, n) for o, n in data[0]['evidence'][1]]
    data[2][210] = dict(status='accepted', name='B')
    assert len(run(data)[0]) == 1


@pytest.mark.parametrize('low_frame', [150, 160])
def test_both_ambiguous_edge_endpoints_need_strict_positive_detector_support(low_frame):
    data = case()
    for frame in range(100, 160, 10):
        row = data[3].rows[frame]
        row['features'][0] = person(0, row['features'][0]['x']-6, size=8)
        record = next(r for r in data[1] if round(r.t*100) == frame)
        record.person_bboxes[0] = np.asarray(row['features'][0]['box'])
        record.person_pose_keypoints[0] = row['features'][0]['pose_keypoints']
        record.person_head_keypoints[0] = row['features'][0]['head_keypoints']
        data[3].answers[(frame, 0)] = observation(row, row['features'][0]), dict(status='accepted', name='A')
    own, match = data[3].answers[(low_frame, 0)]
    data[3].answers[(low_frame, 0)] = replace(own, detector_score=.89), match
    contexts, _ = run(data)
    assert contexts[0]['start'] == 1.6
    assert contexts[0]['bridges'] == []
