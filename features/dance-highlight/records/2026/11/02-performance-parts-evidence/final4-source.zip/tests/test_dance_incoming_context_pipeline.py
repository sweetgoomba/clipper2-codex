"""The last clip stage shares the original models and preserves core results."""
from types import SimpleNamespace
import pytest
from test_dance_incoming_context import case
from dance_highlight.services.pipeline import _include_incoming_preparation


def test_pipeline_uses_existing_models_and_keeps_outgoing_main(monkeypatch):
    from dance_highlight.services import incoming_context
    identity, records, joint, query = case()
    closed=[];query.close=lambda:closed.append(True)
    recognizer=object();service=object()
    frozen=dict(anchors=[dict(name='A',frame_index=200)],secondary_recognizer=recognizer)
    def create(received_service,path,fps,received_frozen,received_model):
        assert received_service is service and received_model is recognizer and received_frozen is frozen
        return query
    monkeypatch.setattr(incoming_context,'IncomingFaceQuery',create)
    result,audit=_include_incoming_preparation(identity,records,joint,video_path='unused',fps=100.,
        cut_frames=[100,200],face_service=service,joint_context=frozen)
    assert [(s.start,s.end)for s in result['segments']]==[(1.,2.),(1.,2.5)]
    assert result['decisions']==identity['decisions']
    assert identity['segments'][1].start==2.
    assert audit['accepted'][0]['reference_id']=='A' and closed==[True]


@pytest.mark.parametrize('failure',[None,'source_read'])
def test_missing_gallery_or_context_read_failure_preserves_completed_clips(monkeypatch,failure):
    from dance_highlight.services import incoming_context
    identity,records,joint,query=case();closed=[]
    query.close=lambda:closed.append(True)
    if failure is None:
        frozen={}
        def create(*args):raise AssertionError('must not load another model or open source')
    else:
        frozen=dict(anchors=[dict(name='A',frame_index=200)],secondary_recognizer=object())
        def create(*args):return query
        def broken(*args):raise ValueError('source frame unavailable')
        query.geometry=broken
    monkeypatch.setattr(incoming_context,'IncomingFaceQuery',create)
    result,audit=_include_incoming_preparation(identity,records,joint,video_path='unused',fps=100.,
        cut_frames=[100,200],face_service=SimpleNamespace(),joint_context=frozen)
    assert result is identity and not audit['accepted']
    assert closed==([True]if failure else [])
