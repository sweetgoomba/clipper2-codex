from types import SimpleNamespace

import numpy as np
import pytest

from dance_highlight.services import pipeline, segment


@pytest.mark.parametrize('fps,skip', [(24, 1), (24, 4), (30, 4), (60, 4)])
def test_main_change_waits_for_elapsed_time_independent_of_sampling(monkeypatch, fps, skip):
    """Counting source-frame fps at sampled cadence delays the actual B part."""
    class Capture:
        index = 0
        def isOpened(self): return True
        def get(self, key):
            return {pipeline.cv2.CAP_PROP_FPS: fps, pipeline.cv2.CAP_PROP_FRAME_COUNT: fps*2}.get(key, 0)
        def read(self):
            if self.index >= fps*2: return False, None
            frame = np.full((100, 200, 3), self.index, np.uint8)
            self.index += 1
            return True, frame
        def release(self): pass
    a = {'bbox': np.array([0., 0., 50., 90.]), 'rank': 1.}
    b = {'bbox': np.array([100., 0., 150., 90.]), 'rank': 1.1}
    monkeypatch.setattr(pipeline.cv2, 'VideoCapture', lambda _: Capture())
    monkeypatch.setattr(segment, 'main_score', lambda person, *_: person['rank'])
    worker = pipeline.DancePipeline.__new__(pipeline.DancePipeline)
    worker.config = SimpleNamespace(analyze_skip=skip, track_match_iou=.35, track_ttl_sec=1.)
    worker.pose = SimpleNamespace(run_pose_on_frame=lambda frame: [a] if frame[0, 0, 0] == 0 else [a, b])
    worker.face = SimpleNamespace(detect_face_boxes=lambda _: [])
    records, _, _ = worker.analyze_video_to_records('synthetic.mp4')
    first_b = next(r.t for r in records if np.array_equal(r.main_bbox, b['bbox']))
    first_candidate = skip/fps
    assert first_b >= first_candidate + .25 - 1e-6
    assert first_b <= first_candidate + .25 + skip/fps + 1e-6


def test_interrupted_candidate_does_not_inherit_earlier_wait(monkeypatch):
    monkeypatch.setattr(segment, 'main_score', lambda person, *_: person['rank'])
    a = {'bbox': np.array([0., 0., 50., 90.]), 'rank': 1.}
    b = {'bbox': np.array([100., 0., 150., 90.]), 'rank': 1.1}
    selector = segment.MainSelector(fps=60)
    for time, people in [(0., [a]), (.1, [a,b]), (.3, [a]), (.4, [a,b]), (.6, [a,b])]:
        chosen, _ = selector.select(people, (100, 200, 3), time_seconds=time)
        assert chosen is a
    chosen, _ = selector.select([a,b], (100, 200, 3), time_seconds=.7)
    assert chosen is b


def test_weakened_main_uses_short_wait_and_empty_frame_resets_candidate(monkeypatch):
    monkeypatch.setattr(segment, 'main_score', lambda person, *_: person['rank'])
    a = {'bbox': np.array([0., 0., 50., 90.]), 'rank': 1.}
    b = {'bbox': np.array([100., 0., 150., 90.]), 'rank': 1.1}
    selector = segment.MainSelector(fps=60)
    selector.select([a], (100, 200, 3), time_seconds=0.)
    small_a = {'bbox': np.array([0., 0., 30., 90.]), 'rank': 1.}
    chosen, _ = selector.select([small_a,b], (100, 200, 3), time_seconds=.1)
    assert chosen is small_a
    # Keep the weakened-area condition on the next observation.
    smaller_a = {'bbox': np.array([0., 0., 15., 90.]), 'rank': 1.}
    chosen, _ = selector.select([smaller_a,b], (100, 200, 3), time_seconds=.2)
    assert chosen is b
    selector.select([], (100, 200, 3), time_seconds=.3)
    assert selector.select([a], (100, 200, 3), time_seconds=.4)[0] is a


def test_candidate_wait_is_not_delayed_by_an_old_higher_scene_score(monkeypatch):
    monkeypatch.setattr(segment, 'main_score', lambda person, *_: person['rank'])
    a = {'bbox': np.array([0.,0.,50.,90.]), 'rank': 1.}
    b = {'bbox': np.array([100.,0.,150.,90.]), 'rank': 1.}
    selector = segment.MainSelector(fps=60)
    selector.select([a], (100,200,3), time_seconds=0.)
    a['rank'] = .9
    for t in (.1,.2,.3):
        assert selector.select([a,b], (100,200,3), time_seconds=t)[0] is a
    # B has exceeded current A by >6% for .3s. A's older score must not
    # postpone the start of the existing .25s candidate wait.
    assert selector.select([a,b], (100,200,3), time_seconds=.4)[0] is b


def test_global_score_increase_does_not_invent_a_hard_member_switch(monkeypatch):
    monkeypatch.setattr(segment, 'main_score', lambda person, *_: person['rank'])
    a = {'bbox': np.array([0.,0.,50.,90.]), 'rank': .5}
    b = {'bbox': np.array([100.,0.,150.,90.]), 'rank': .95}
    selector = segment.MainSelector(fps=60)
    selector.select([a], (100,200,3), time_seconds=0.)
    a['rank'] = .9
    # A camera/pose scale change raises every score; B is still <6% above
    # current A, so A's old .5 cannot justify an immediate >16% handoff.
    for t in (.1,.2,.3,.4):
        assert selector.select([a,b], (100,200,3), time_seconds=t)[0] is a


@pytest.mark.parametrize('reverse_order', [False,True])
@pytest.mark.parametrize('new_score', [.6,1.])
def test_lost_main_reacquires_current_best_independent_of_detection_order(monkeypatch, reverse_order, new_score):
    monkeypatch.setattr(segment, 'main_score', lambda person, *_: person['rank'])
    a = {'bbox': np.array([0.,0.,50.,90.]), 'rank': 1.}
    b = {'bbox': np.array([100.,0.,150.,90.]), 'rank': new_score}
    c = {'bbox': np.array([200.,0.,250.,90.]), 'rank': new_score*.95}
    selector = segment.MainSelector(fps=60)
    selector.select([a], (100,300,3), time_seconds=0.)
    people = [b,c] if reverse_order else [c,b]
    # No detection is the prior body. An arbitrary IoU=0 winner cannot be
    # treated as the incumbent while the actual best candidate waits.
    assert selector.select(people, (100,300,3), time_seconds=.1)[0] is b
    assert selector.cand_since is None


@pytest.mark.parametrize('case_index',[0,1])
@pytest.mark.parametrize('factor',[.5,2./3.,1.,2.])
def test_same_measured_composition_keeps_scores_and_main_at_every_resolution(case_index,factor):
    import json
    from pathlib import Path
    case=json.loads((Path(__file__).parent/'fixtures/dance_scene_review/main-resolution-source.json').read_text())[case_index]
    width,height=case['size']
    original=[{key:np.asarray(value,np.float64) for key,value in p.items()} for p in case['persons']]
    scaled=[{key:value*factor for key,value in p.items()} for p in original]
    scores=[segment.main_score(p,width,height) for p in original]
    assert [segment.main_score(p,width*factor,height*factor) for p in scaled]==pytest.approx(scores)
    selector=segment.MainSelector()
    selected,_=selector.select(scaled,(height*factor,width*factor,3),time_seconds=0.)
    assert selected is scaled[case['expected_body']]
