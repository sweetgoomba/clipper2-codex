import cv2
import numpy as np
import torch
import pytest

from dance_highlight.services.mask_tracker import MaskTracker


def test_reverse_decode_preserves_pixels_and_order_with_fewer_seeks():
    from dance_highlight.services.mask_frame_cache import source_frames

    class Capture:
        position = 0
        seeks = 0
        def get(self, prop):
            return {cv2.CAP_PROP_POS_FRAMES: self.position,
                    cv2.CAP_PROP_FRAME_WIDTH: 10, cv2.CAP_PROP_FRAME_HEIGHT: 10}[prop]
        def set(self, prop, value):
            self.position = value
            self.seeks += 1
            return True
        def grab(self):
            self.position += 1
            return True
        def read(self):
            image = np.full((10, 10, 3), self.position, np.uint8)
            self.position += 1
            return True, image

    frames = list(range(100, 19, -4))
    baseline, optimized = Capture(), Capture()
    expected = [MaskTracker._read(baseline, f) for f in frames]
    actual = list(source_frames(optimized, frames, MaskTracker._read, max_bytes=300*4))
    assert all(np.array_equal(a, b) for a, b in zip(actual, expected, strict=True))
    assert optimized.seeks <= 6 < baseline.seeks


def test_forward_decode_is_lazy_and_has_no_read_ahead():
    from dance_highlight.services.mask_frame_cache import source_frames
    calls = []
    iterator = source_frames(None, [1, 5, 9], lambda cap, f: calls.append(f) or f)
    assert next(iterator) == 1
    iterator.close()
    assert calls == [1]


def test_image_features_reuse_only_same_source_frame_and_geometry():
    from dance_highlight.services.mask_frame_cache import SamImageFeatures
    cache = SamImageFeatures(max_bytes=128)
    calls = []
    def compute():
        calls.append(1)
        return [torch.ones(4)], [torch.zeros(4)], [(2, 2)]
    image = torch.zeros(1, 3, 8, 8)
    first = cache.get(10, image, compute)
    assert all(torch.equal(a, b) for a, b in zip(first[0], cache.get(10, image, compute)[0]))
    assert len(calls) == 1
    cache.get(11, image, compute)
    cache.get(10, image.double(), compute)
    SamImageFeatures(max_bytes=128).get(10, image, compute)
    assert len(calls) == 4


def test_feature_eviction_bounds_memory_and_does_not_change_values():
    from dance_highlight.services.mask_frame_cache import SamImageFeatures
    cache = SamImageFeatures(max_bytes=48)  # 16-byte positions + two 16-byte feature sets
    calls = []
    image = torch.zeros(1, 3, 8, 8)
    def compute(value):
        calls.append(value)
        return [torch.full((4,), value, dtype=torch.float32)], [torch.zeros(4)], [(2, 2)]
    for frame in (1, 2, 3, 2, 1):
        features, _, _ = cache.get(frame, image, lambda: compute(frame))
        assert torch.equal(features[0], torch.full((4,), float(frame)))
        assert cache.retained_bytes <= 48
    assert calls == [1, 2, 3, 1]


def test_reverse_read_ahead_failure_does_not_hide_an_available_first_frame():
    from dance_highlight.services.mask_frame_cache import source_frames
    class Capture:
        def get(self, prop):
            return 10
    def read(cap, frame):
        if frame == 2:
            raise ValueError('source_frame_unavailable')
        return frame
    iterator = source_frames(Capture(), [3, 2, 1], read, max_bytes=900)
    assert next(iterator) == 3
    with pytest.raises(ValueError, match='source_frame_unavailable'):
        next(iterator)


def test_oversized_feature_is_returned_without_retaining_it():
    from dance_highlight.services.mask_frame_cache import SamImageFeatures
    cache = SamImageFeatures(max_bytes=8)
    features = [torch.ones(4)]
    actual, _, _ = cache.get(1, torch.zeros(1, 3, 8, 8),
                             lambda: (features, [torch.zeros(4)], [(2, 2)]))
    assert torch.equal(actual[0], features[0])
    assert cache.retained_bytes == 0
