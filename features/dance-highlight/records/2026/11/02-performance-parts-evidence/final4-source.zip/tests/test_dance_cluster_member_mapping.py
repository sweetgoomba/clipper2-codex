from __future__ import annotations

import math

import numpy as np

from dance_highlight.services.pipeline import DancePipeline


def _unit(dot_a: float, dot_b: float) -> np.ndarray:
    rest = math.sqrt(max(0.0, 1.0 - dot_a * dot_a - dot_b * dot_b))
    return np.array([dot_a, dot_b, rest], dtype=np.float32)


def test_cluster_mapping_assigns_distinct_members_before_duplicate_matches() -> None:
    pipeline = DancePipeline.__new__(DancePipeline)

    mapping = pipeline._map_cluster_to_member_name(
        cluster_centroids={
            1: _unit(0.70, 0.52),
            2: _unit(0.68, 0.51),
        },
        ref_embs={
            "A": np.array([1.0, 0.0, 0.0], dtype=np.float32),
            "B": np.array([0.0, 1.0, 0.0], dtype=np.float32),
        },
        threshold=0.60,
    )

    assert mapping == {1: "A", 2: "B"}


def test_single_reference_does_not_absorb_every_cluster() -> None:
    """참조 멤버가 1명일 때, 임계값 안이라는 이유만으로 모든 클러스터가 흡수되면 안 된다."""
    pipeline = DancePipeline.__new__(DancePipeline)

    mapping = pipeline._map_cluster_to_member_name(
        cluster_centroids={
            1: _unit(0.85, 0.0),   # dist 0.15 — 본인
            2: _unit(0.50, 0.0),   # dist 0.50 — 남 (0.60 이내지만 본인과 한참 멀다)
            3: _unit(0.42, 0.0),   # dist 0.58 — 남
        },
        ref_embs={"A": np.array([1.0, 0.0, 0.0], dtype=np.float32)},
        threshold=0.60,
    )

    assert mapping == {1: "A"}


def test_split_clusters_of_same_person_still_merge() -> None:
    """같은 사람이 두 클러스터로 쪼개진 경우는 계속 한 멤버로 묶여야 한다."""
    pipeline = DancePipeline.__new__(DancePipeline)

    mapping = pipeline._map_cluster_to_member_name(
        cluster_centroids={
            1: _unit(0.85, 0.0),   # dist 0.15
            2: _unit(0.80, 0.0),   # dist 0.20 — 주인(0.15) + 마진(0.08) 이내
        },
        ref_embs={"A": np.array([1.0, 0.0, 0.0], dtype=np.float32)},
        threshold=0.60,
    )

    assert mapping == {1: "A", 2: "A"}


def test_dance_config_exposes_member_matching_thresholds() -> None:
    from dance_highlight.services.config import DanceConfig

    config = DanceConfig()

    assert config.member_match_threshold == 0.60
    assert config.member_duplicate_threshold == 0.45
    assert config.member_duplicate_margin == 0.08
    # 중복 상한은 클러스터링 기준(0.42) 근처여야 한다 — 클러스터러가 '남'이라 부른
    # 거리를 중복으로 붙이지 않는다는 것이 이 값의 존재 이유다.
    assert config.member_duplicate_threshold < config.member_match_threshold


def test_mapping_uses_config_thresholds() -> None:
    """호출부가 하드코딩 0.60이 아니라 config를 읽는지 — config를 조여 결과가 바뀌는지로 본다."""
    pipeline = DancePipeline.__new__(DancePipeline)

    loose = pipeline._map_cluster_to_member_name(
        cluster_centroids={1: _unit(0.85, 0.0), 2: _unit(0.80, 0.0)},
        ref_embs={"A": np.array([1.0, 0.0, 0.0], dtype=np.float32)},
        duplicate_margin=0.08,
    )
    strict = pipeline._map_cluster_to_member_name(
        cluster_centroids={1: _unit(0.85, 0.0), 2: _unit(0.80, 0.0)},
        ref_embs={"A": np.array([1.0, 0.0, 0.0], dtype=np.float32)},
        duplicate_margin=0.01,
    )

    assert loose == {1: "A", 2: "A"}
    assert strict == {1: "A"}


def test_duplicate_absolute_ceiling_wins_over_margin() -> None:
    """주인이 멀면 마진만으로 붙지 않는다 — 절대 상한(0.45)이 먼저 막는다."""
    pipeline = DancePipeline.__new__(DancePipeline)

    mapping = pipeline._map_cluster_to_member_name(
        cluster_centroids={
            1: _unit(0.60, 0.0),   # dist 0.40 — 주인
            2: _unit(0.53, 0.0),   # dist 0.47 — 마진(0.48)엔 들지만 상한 0.45 초과
        },
        ref_embs={"A": np.array([1.0, 0.0, 0.0], dtype=np.float32)},
        threshold=0.60,
    )

    assert mapping == {1: "A"}
