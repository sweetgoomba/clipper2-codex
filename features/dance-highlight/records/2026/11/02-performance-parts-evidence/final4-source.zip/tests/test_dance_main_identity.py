from dataclasses import replace
import numpy as np
import pytest
from dance_highlight.services.face_evidence import FaceObservation
from dance_highlight.services.segment import Segment


def obs(t, embedding, box):
    return FaceObservation(round(t*30),t,7,(0.,0.,100.,100.),(0.,0.,100.,100.),
                           face_bbox=box,embedding=np.array(embedding,dtype=np.float32),
                           detector_score=.95,association='confirmed')


def fixture():
    a=(5.,5.,15.,15.);b=(30.,20.,70.,60.)
    rows=[obs(t,(1.,0.),a) for t in (.1,.3,.5,.7,.9)]
    rows += [obs(t,(0.,1.),b) for t in (1.1,1.3,1.5,1.7,1.9)]
    return Segment('main',7,0.,2.,[(o.time_seconds,np.array(o.body_bbox),7) for o in rows]),rows


def test_repeated_identity_and_spatial_change_splits_even_when_track_id_is_same():
    from dance_highlight.services.main_identity import find_identity_switches, split_segment
    seg,rows=fixture()
    boundaries=find_identity_switches(seg,rows)
    assert len(boundaries)==1
    assert .9 < boundaries[0]['time'] <= 1.1
    pieces=split_segment(seg,boundaries)
    assert len(pieces)==2
    assert pieces[0].start==0. and pieces[-1].end==2.
    assert pieces[0].end==pieces[1].start
    assert sum(len(p.bboxes) for p in pieces)==len(seg.bboxes)
    assert seg.end==2. and len(seg.bboxes)==10


def test_motion_lighting_one_bad_face_and_same_named_identity_do_not_split():
    from dance_highlight.services.main_identity import find_identity_switches
    seg,rows=fixture()
    assert not find_identity_switches(seg,[replace(o,embedding=np.array([1.,0.])) for o in rows])
    assert not find_identity_switches(seg,[replace(o,face_bbox=rows[0].face_bbox) for o in rows])
    bad=[replace(o,embedding=np.array([1.,0.])) for o in rows]
    bad[5]=rows[5]
    assert not find_identity_switches(seg,bad)
    assert not find_identity_switches(seg,rows,reference_names={o.frame_index:'A' for o in rows})


def test_unconfirmed_ownership_and_short_side_do_not_create_tiny_clips():
    from dance_highlight.services.main_identity import find_identity_switches
    seg,rows=fixture()
    assert not find_identity_switches(seg,[replace(o,association='ambiguous') for o in rows])
    assert not find_identity_switches(replace(seg,end=1.45),[o for o in rows if o.time_seconds<1.45])


def test_split_piece_is_named_from_its_own_repeated_faces_and_rejects_conflicts():
    from types import SimpleNamespace
    from dance_highlight.services.main_identity import match_identity_piece
    seg,rows=fixture()
    piece=replace(seg,start=1.,bboxes=seg.bboxes[5:])
    rows=rows[5:]
    def match(name):
        return SimpleNamespace(reference_id=name,status='matched',reason='accepted',
                               candidates=[SimpleNamespace(reference_id=name,distance=.2)])
    matches=[match('B') for _ in rows]
    assert match_identity_piece(piece,rows,matches).reference_id=='B'
    matches[-1]=match('A')
    assert match_identity_piece(piece,rows,matches).reference_id is None
    assert match_identity_piece(piece,rows[:1],matches[:1]).reference_id is None


def test_unregistered_face_in_named_piece_is_not_silently_ignored():
    from types import SimpleNamespace
    from dance_highlight.services.main_identity import match_identity_piece
    seg,rows=fixture();rows=[replace(o,embedding=np.array([1.,0.])) for o in rows]
    matched=SimpleNamespace(reference_id='A',status='matched',reason='accepted',candidates=[SimpleNamespace(reference_id='A',distance=.2)])
    unknown=SimpleNamespace(reference_id=None,status='unmatched',reason='distance_exceeded',candidates=[])
    rows[5]=replace(rows[5],embedding=np.array([-1.,0.]))
    rows[6]=replace(rows[6],embedding=np.array([-1.,0.]))
    matches=[matched]*len(rows);matches[5]=unknown;matches[6]=unknown
    assert match_identity_piece(seg,rows,matches).reference_id is None


def test_low_confidence_motion_blur_does_not_veto_repeated_clear_faces():
    from types import SimpleNamespace
    from dance_highlight.services.main_identity import match_identity_piece
    seg,rows=fixture();rows=[replace(o,embedding=np.array([1.,0.])) for o in rows]
    matched=SimpleNamespace(reference_id='A',status='matched',reason='accepted',candidates=[SimpleNamespace(reference_id='A',distance=.2)])
    unknown=SimpleNamespace(reference_id=None,status='unmatched',reason='distance_exceeded',candidates=[])
    rows[5]=replace(rows[5],embedding=np.array([-1.,0.]),detector_score=.8)
    matches=[matched]*len(rows);matches[5]=unknown
    assert match_identity_piece(seg,rows,matches).reference_id=='A'
    assert match_identity_piece(seg,[replace(o,detector_score=.8) for o in rows],matches).reference_id is None


def test_isolated_noisy_vector_does_not_outvote_repeated_direct_identity():
    from types import SimpleNamespace
    from dance_highlight.services.main_identity import match_identity_piece
    seg,rows=fixture();rows=[replace(o,embedding=np.array([1.,0.])) for o in rows]
    matched=SimpleNamespace(reference_id='A',status='matched',reason='accepted',candidates=[SimpleNamespace(reference_id='A',distance=.2)])
    unknown=SimpleNamespace(reference_id=None,status='unmatched',reason='distance_exceeded',candidates=[])
    rows[5]=replace(rows[5],embedding=np.array([-1.,0.]))
    matches=[matched]*len(rows);matches[5]=unknown
    assert match_identity_piece(seg,rows,matches).reference_id=='A'


def test_boundary_refinement_uses_actual_decoded_frame_transition(tmp_path):
    import cv2
    from dance_highlight.services.main_identity import refine_switch_boundaries
    path=tmp_path/'cut.avi'
    writer=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'MJPG'),10.,(32,32))
    assert writer.isOpened()
    for i in range(10):writer.write(np.full((32,32,3),0 if i<5 else 255,dtype=np.uint8))
    writer.release()
    result=refine_switch_boundaries(str(path),[{'time':.7,'left_time':.3,'right_time':.7}])
    assert result[0]['time']==.5
    assert result[0]['boundary_frame_index']==5


@pytest.mark.parametrize("include_thumbnails", [False, True])
def test_refinement_applies_only_useful_splits_and_keeps_existing_named_scopes(include_thumbnails):
    from types import SimpleNamespace
    from dance_highlight.services.main_identity import refine_main_identities
    from dance_highlight.services.reference_matcher import SegmentReferenceDecision
    seg,rows=fixture()
    result=SimpleNamespace(seg=seg,owned_observations=rows,
                           owned_previews={o.frame_index:b'legacy-face' for o in rows})
    if include_thumbnails:
        result.owned_thumbnails={o.frame_index:b'source-face' for o in rows[:5]}
    unknown=SegmentReferenceDecision(None,'unmatched','distance_exceeded')
    class Matcher:
        def match(self,o,*_args):
            name='B' if o.time_seconds>1. else None
            return SimpleNamespace(reference_id=name,status='matched' if name else 'unmatched',reason='accepted' if name else 'distance_exceeded',
                                   candidates=[SimpleNamespace(reference_id='B',distance=.2)] if name else [])
    output=refine_main_identities([seg],[unknown],[3],[[]],[result],Matcher())
    assert len(output['segments'])==2
    assert [d.reference_id for d in output['decisions']]==[None,'B']
    assert output['accurate_indices']==[0,1]
    assert output['labels'][0]!=3
    assert output['previews']==[[b'source-face' if include_thumbnails else b'legacy-face']*5,
                                [b'legacy-face']*5]
    named=SegmentReferenceDecision('A','matched','accepted')
    kept=refine_main_identities([seg],[named],[3],[[]],[result],Matcher())
    assert kept['segments']==[seg] and kept['decisions']==[named]


def test_split_preserves_raw_builder_final_endpoint_sample():
    from dance_highlight.services.segment import FrameRec, build_raw_main_segments
    from dance_highlight.services.main_identity import split_segment
    box=np.array([0.,0.,100.,100.])
    parent=build_raw_main_segments([FrameRec(t,7,box,False) for t in (0.,1.,2.)])[0]
    assert parent.end==2. and parent.bboxes[-1][0]==parent.end
    pieces=split_segment(parent,[{'time':1.}])
    assert [[row[0] for row in piece.bboxes] for piece in pieces]==[[0.],[1.,2.]]
