"""Camera attention survives visible foreground crossings without assigning hidden faces."""
import json
from pathlib import Path

import numpy as np
import pytest

from dance_highlight.services.focal_composition import camera_focal_evidence


def person(index, x, size, *, box=None, y=300):
    pose = np.zeros((17, 3))
    pose[:7] = [[x, y, .99], [x-size*.18, y-size*.15, .99],
                [x+size*.18, y-size*.15, .99], [x-size*.35, y, .99],
                [x+size*.35, y, .99], [x-size*.7, y+size, .99],
                [x+size*.7, y+size, .99]]
    return dict(index=index, x=x, size=size, pose_keypoints=pose,
                box=box or [x-size, y-size, x+size, y+4*size])


def crossing(*, missing=(), zoom=True):
    rows = []
    for i in range(15):
        features = [person(1, 800-i*40, 120, box=[250, 150, 750, 800])]
        if i not in missing:
            features.insert(0, person(0, 500, 40+i*4 if zoom else 80))
        rows.append(dict(frame=i*10, time=i*.1, features=features))
    return rows


def test_camera_push_in_keeps_stationary_center_over_large_crossing_face():
    result = camera_focal_evidence(crossing(), 1000, 1000, [])
    assert len(result) == 1
    assert {sample['index'] for sample in result[0]['visible_targets']} == {0}
    assert len(result[0]['visible_targets']) == 15
    assert result[0]['role_only_frames'] == []


def test_short_foreground_occlusion_is_role_context_without_fake_body_or_name():
    result = camera_focal_evidence(crossing(missing=(6, 7)), 1000, 1000, [])
    assert len(result) == 1
    assert result[0]['role_only_frames'] == [60, 70]
    assert {v['frame'] for v in result[0]['visible_targets']} == set(range(0, 150, 10))-{60, 70}
    assert 'name' not in result[0]
    assert 'box' not in result[0]


def test_uncovered_missing_target_is_not_extended_through_another_person():
    rows = crossing(missing=(6, 7))
    for i in (6, 7):
        rows[i]['features'][0]['box'] = [700, 100, 950, 900]
    result = camera_focal_evidence(rows, 1000, 1000, [])
    assert not any(e['role_only_frames'] for e in result)
    assert not any(e['start_frame'] < 60 < e['end_frame'] for e in result)


def test_long_absence_does_not_link_center_people_across_a_gap():
    result = camera_focal_evidence(crossing(missing=(5, 6, 7, 8, 9)), 1000, 1000, [])
    assert not any(e['start_frame'] < 50 < e['end_frame'] for e in result)


def test_source_cut_blocks_camera_episode_and_role_context():
    result = camera_focal_evidence(crossing(missing=(6, 7)), 1000, 1000, [65])
    assert not any(e['start_frame'] < 65 < e['end_frame'] for e in result)


def test_two_stationary_center_candidates_do_not_create_a_main():
    rows = crossing()
    for i, row in enumerate(rows):
        row['features'].append(person(2, 540, 35+i*5, y=480))
    assert camera_focal_evidence(rows, 1000, 1000, []) == []


def test_static_group_without_push_in_does_not_create_a_main():
    assert camera_focal_evidence(crossing(zoom=False), 1000, 1000, []) == []


def test_visible_center_handoff_is_not_overridden_by_shot_context():
    rows = crossing()
    for i, row in enumerate(rows):
        row['features'][0]['x'] = 500 if i < 7 else 500-(i-6)*45
        row['features'][0]['pose_keypoints'][:, 0] += row['features'][0]['x']-500
        row['features'].append(person(2, 800-i*45 if i < 7 else 500, 50+i*4, y=460))
    assert camera_focal_evidence(rows, 1000, 1000, []) == []


def reviewed(name):
    raw = json.loads((Path(__file__).parent/'fixtures/dance_focal_composition_reviewed.json').read_text())
    case = raw[name]
    for row in case['rows']:
        for f in row['features']:
            f['pose_keypoints'] = np.array(f['pose_keypoints'])
    return case


@pytest.mark.parametrize('name', ['foreground_crossing_69', 'camera_push_in_89'])
def test_reviewed_camera_subject_owns_every_supported_sample(name):
    case = reviewed(name)
    result = camera_focal_evidence(case['rows'], 1920, 1080, case['cuts'])
    assert len(result) == 1
    actual = {v['frame']: v['index'] for v in result[0]['visible_targets']}
    for frame, expected in case['expected_targets'].items():
        assert actual.get(int(frame)) == expected
    assert not set(actual) & set(result[0]['role_only_frames'])
    if name == 'foreground_crossing_69':
        assert {4184, 4196, 4200} <= set(result[0]['role_only_frames'])


def test_ambiguous_duplicate_head_at_shot_start_is_not_a_visible_target():
    case = reviewed('foreground_crossing_69')
    result = camera_focal_evidence(case['rows'], 1920, 1080, case['cuts'])
    assert len(result) == 1
    assert 4164 not in {v['frame'] for v in result[0]['visible_targets']}
    assert result[0]['start_frame'] == 4168


def test_missing_shoulder_ownership_cannot_link_faces_into_camera_subject():
    rows = crossing()
    for row in rows:
        row['features'][0]['pose_keypoints'][5:7, 2] = .1
    assert camera_focal_evidence(rows, 1000, 1000, []) == []


def test_unobserved_source_interval_is_not_treated_as_foreground_occlusion():
    rows = [r for i, r in enumerate(crossing()) if i not in (6, 7)]
    result = camera_focal_evidence(rows, 1000, 1000, [])
    assert not any(e['start_frame'] < 60 < e['end_frame'] for e in result)


def test_far_group_push_in_without_resolvable_central_face_is_not_a_main():
    rows = crossing()
    for row in rows:
        row['features'][0]['size'] *= .3
    assert camera_focal_evidence(rows, 1000, 1000, []) == []
