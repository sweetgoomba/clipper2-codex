"""T12 Task 1: 안무 인물별 ffmpeg 합본(montage) 단계 제거.

메타 빌더 결과에 montages 키가 없고 persons는 그대로 유지되는지,
파이프라인/설정/렌더 서비스에 합본 전용 헬퍼가 더 이상 없는지 확인한다.
"""
from __future__ import annotations

from dance_highlight.services.config import DanceConfig
from dance_highlight.services.dance_meta import DanceClipItem, DanceMetaBuilder


def _builder() -> DanceMetaBuilder:
    return DanceMetaBuilder(DanceConfig())


def test_build_result_has_no_montages_key_and_keeps_persons():
    persons = [
        {"person_id": "p1", "person_name": "p1", "num_clips": 2, "clip_paths": ["a.mp4", "b.mp4"]},
    ]
    result = _builder().build(
        project_id=1,
        input_video_rel="input.mp4",
        main_items=[],
        group_items=[],
        persons=persons,
        stats={},
        dance_setup=None,
    )
    assert "montages" not in result
    assert result["persons"] == persons


def test_group_clip_serializes_confirmed_member_ids():
    item = DanceClipItem(0, "group", 1.0, 3.0, "clips/group/group_0000.mp4", None,
                         person_ids=("김채원", "허윤진"))
    result = _builder().build(1, "input.mp4", [], [item], [], {})
    assert result["lists"]["group"][0]["person_ids"] == ["김채원", "허윤진"]


def test_pipeline_module_has_no_montage_helpers():
    from dance_highlight.services import pipeline

    assert not hasattr(pipeline.DancePipeline, "_make_montage")
    assert "ThreadPoolExecutor" not in dir(pipeline)


def test_config_has_no_montage_or_renders_settings():
    config = DanceConfig()

    for name in (
        "montage_min_sec",
        "montage_max_sec",
        "montage_max_clips",
        "montage_reencode_normalize",
        "renders_dir_rel",
    ):
        assert not hasattr(config, name)


def test_render_service_has_no_montage_only_methods():
    from dance_highlight.services.render import RenderService

    for name in (
        "normalize_clip",
        "concat_clips",
        "select_clips_for_duration",
        "probe_has_audio",
        "probe_duration",
    ):
        assert not hasattr(RenderService, name)
