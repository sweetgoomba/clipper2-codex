from dataclasses import replace
import numpy as np
import pytest


def score_inputs():
    from test_dance_member_timeline import observation
    a,b=np.eye(2)
    rows={}
    anchors=[]
    for name,vector,base in [('A',a,0.),('B',b,1.)]:
        for t in (base,base+.2):
            row=replace(observation(t,name),embedding=vector)
            rows[row.frame_index]=row
            anchors.append(dict(name=name,frame_index=row.frame_index))
    query=replace(observation(5.,'?'),embedding=a)
    rows[query.frame_index]=query
    vectors={f:r.embedding.copy() for f,r in rows.items()}
    return rows,vectors,anchors,query.frame_index


def test_joint_score_requires_two_independent_views_from_every_registered_member():
    from dance_highlight.services.joint_identity import joint_video_matches
    rows,vectors,anchors,frame=score_inputs()
    result=joint_video_matches(rows,vectors,anchors,{'A','B'})[frame]
    assert result['status']=='accepted' and result['name']=='A'
    assert all(len(s)==2 for s in result['support_frames'])
    assert joint_video_matches(rows,vectors,anchors,{'A','B','C'})[frame]['status']=='insufficient'
    assert joint_video_matches(rows,vectors,anchors[1:],{'A','B'})[frame]['status']=='insufficient'


def test_joint_audit_retains_each_models_actual_competing_roster_distances():
    from dance_highlight.services.joint_identity import joint_video_matches
    rows,vectors,anchors,frame=score_inputs()
    vectors[frame]=np.array([0.,1.])
    result=joint_video_matches(rows,vectors,anchors,{'A','B'})[frame]
    assert result['status']=='conflict' and result['name'] is None
    assert result['model_candidates']==[
        [{'name':'A','distance':0.},{'name':'B','distance':1.}],
        [{'name':'B','distance':0.},{'name':'A','distance':1.}],
    ]


def test_targeted_joint_query_keeps_the_full_original_gallery_without_rescoring_anchors():
    from dance_highlight.services.joint_identity import joint_video_matches
    rows,vectors,anchors,frame=score_inputs()
    expected=joint_video_matches(rows,vectors,anchors,{'A','B'})[frame]
    actual=joint_video_matches(rows,vectors,anchors,{'A','B'},query_frames={frame})
    assert actual=={frame:expected}
    assert actual[frame]['status']=='accepted'
    assert joint_video_matches(rows,vectors,anchors,{'A','B'},query_frames=set())=={}
    # The query filter must not turn a missing competitor into an easier match.
    assert joint_video_matches(rows,vectors,anchors[2:],{'A','B'},query_frames={frame})[frame]['status']=='insufficient'


@pytest.mark.parametrize('case',['different_model','close_competitor','model_tie','nonfinite','duplicate_frame','near_query'])
def test_unsafe_joint_evidence_cannot_correct_a_name(case):
    from dance_highlight.services.joint_identity import joint_video_matches
    rows,vectors,anchors,frame=score_inputs()
    if case=='different_model':vectors[frame]=np.array([0.,1.])
    if case=='model_tie':rows[frame]=replace(rows[frame],embedding=np.array([1.,1.])/np.sqrt(2))
    if case=='close_competitor':
        rows[frame]=replace(rows[frame],embedding=np.array([1.,1.])/np.sqrt(2))
        vectors[frame]=rows[frame].embedding
    if case=='nonfinite':vectors[frame]=np.array([np.nan,1.])
    if case=='duplicate_frame':anchors[1]=anchors[0]
    if case=='near_query':rows={f:replace(r,time_seconds=5.+i*.1) for i,(f,r) in enumerate(rows.items())}
    result=joint_video_matches(rows,vectors,anchors,{'A','B'})[frame]
    assert result['name'] is None and result['status']!='accepted'
    if case=='different_model':assert result['status']=='conflict'


def correction_inputs():
    from test_dance_mask_continuity import recovery_example
    from dance_highlight.services.reference_matcher import SegmentReferenceDecision
    output,records,_=recovery_example()
    output['decisions'][1]=SegmentReferenceDecision('B','matched','primary_photo')
    matches={f:dict(name='A',status='accepted') for f in (18,22)}
    return output,records,matches


def proof(anchor,path,targets):
    return dict(accepted=True,reason='confirmed_visual_path',support_frames=targets,
                trace=[dict(frame=round(r.t*10),forward=(0,),reverse=(0,),cycle_iou=1.) for r in path])


def test_repeated_independent_identity_can_correct_existing_name_and_merge_without_cap():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=proof)
    assert [(s.start,s.end,d.reference_id) for s,d in zip(result['segments'],result['decisions'])]==[(0.,6.,'A')]
    assert audit['corrected_seconds']==pytest.approx(2.)
    assert original['decisions'][1].reference_id=='B'
    assert sum(len(e) for e in result['evidence'])==60
    assert result['anchors']==original['anchors']==[]


def test_single_joint_hit_and_cross_cut_repeats_do_not_replace_name():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    for matches,cuts in [({22:matches[22]},()),(matches,(20,))]:
        result,_=revalidate_named_segments(original,records,'unused',10.,matches,[],cut_frames=cuts,verify_track=proof)
        assert result is original


def test_tracking_failure_preserves_only_locally_supported_conflict_as_unknown():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    matches[24]=dict(name='A',status='accepted')
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],
        verify_track=lambda *args:dict(accepted=False,reason='cycle_inconsistent'))
    spans=[(s.start,s.end,d.reference_id) for s,d in zip(result['segments'],result['decisions'])]
    assert (2.,2.45,None) in spans and (2.45,4.,'B') in spans
    assert audit['corrected_seconds']==0. and audit['conflict_seconds']==pytest.approx(.45)
    assert result['accurate_indices']==list(range(len(result['segments'])))


def test_opposite_frozen_direct_face_vetoes_correction():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    frozen=[dict(name='B',frame_index=23)]
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,frozen,verify_track=proof)
    assert all(d.reference_id!='A' for s,d in zip(result['segments'],result['decisions']) if s.start>=2 and s.end<=4)
    assert audit['candidates'][0]['attempts'][0]['reason']=='conflicting_direct_face_anchor'


def test_partial_tracking_does_not_rename_the_following_main():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    def partial(anchor,path,targets):
        if 30 in targets:return dict(accepted=False,reason='unconfirmed_main_ownership',frame=30)
        return proof(anchor,path,targets)
    result,_=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=partial)
    assert [(s.start,s.end,d.reference_id) for s,d in zip(result['segments'],result['decisions'])]==[(0.,2.95,'A'),(2.95,4.,'B'),(4.,6.,'A')]


def test_missing_cut_inventory_is_not_assumed_to_be_one_continuous_shot(monkeypatch):
    from dance_highlight.services.joint_identity import revalidate_named_segments
    from dance_highlight.services import camera_transitions
    original,records,matches=correction_inputs()
    monkeypatch.setattr(camera_transitions,'scan_source_transitions',lambda *args: ({20:dict(cut=True,color_candidate=True)},'complete'))
    result,_=revalidate_named_segments(original,records,'unused',10.,matches,[],cut_frames=None,verify_track=proof)
    assert result is original
    monkeypatch.setattr(camera_transitions,'scan_source_transitions',lambda *args: ({},'incomplete_source_decode'))
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],cut_frames=None,verify_track=proof)
    assert result is original and audit['reason']=='incomplete_source_decode'


def test_structural_proposal_only_admits_candidate_for_full_person_verification():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    transitions=[dict(frame=20,cut=True,color_candidate=True,structure=dict(continuous=True))]
    result,_=revalidate_named_segments(original,records,'unused',10.,matches,[],cut_frames=[20],
        camera_transitions=transitions,verify_track=proof)
    assert [(s.start,s.end,d.reference_id) for s,d in zip(result['segments'],result['decisions'])]==[(0.,6.,'A')]
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],cut_frames=[20],
        camera_transitions=transitions,verify_track=lambda *args:dict(accepted=False,reason='unconfirmed_foreground'))
    assert audit['corrected_seconds']==0.
    assert any(d.reference_id is None for d in result['decisions'])


def test_single_opposing_accepted_face_is_a_veto_even_without_positive_repetition():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    matches[21]=dict(name='B',status='accepted')
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=proof)
    assert result is original
    assert audit['corrected_seconds']==audit['conflict_seconds']==0.
    assert audit['candidates']==[]


def test_partial_proof_cannot_rename_past_an_unvisited_proposed_cut():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,matches=correction_inputs()
    # Sparse target observations 2.0,2.2,...; cut2.85 lies after the accepted2.8.
    records=[replace(r,t=r.t*2) for r in records[:30]]
    original['evidence']=[[(replace(o,frame_index=o.frame_index*2),n) for o,n in e] for e in original['evidence']]
    matches={36:dict(name='A',status='accepted'),44:dict(name='A',status='accepted')}
    def partial(anchor,path,targets):
        if 60 in targets:return dict(accepted=False,reason='unconfirmed_main_ownership',frame=60)
        return dict(accepted=True,reason='confirmed_visual_path',support_frames=targets,trace=[])
    result,_=revalidate_named_segments(original,records,'unused',20.,matches,[],cut_frames=[57],
        camera_transitions=[dict(frame=57,structure=dict(continuous=True))],verify_track=partial)
    corrected=[s for s,d in zip(result['segments'],result['decisions']) if d.reference_id=='A' and s.start<3.]
    assert max(s.end for s in corrected)==pytest.approx(2.85)


def test_joint_identity_restores_unknown_with_the_same_full_body_proof():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    from test_dance_mask_continuity import recovery_example
    original,records,_=recovery_example()
    matches={f:dict(name='A',status='accepted') for f in (18,22)}
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=proof)
    assert [(s.start,s.end,d.reference_id) for s,d in zip(result['segments'],result['decisions'])]==[(0.,6.,'A')]
    assert audit['recovered_seconds']==pytest.approx(2.)
    assert audit['corrected_seconds']==audit['conflict_seconds']==0.
    assert sum(len(e) for e in result['evidence'])==60
    assert original['decisions'][1].reference_id is None
    assert result['anchors']==[]


def test_joint_unknown_failure_keeps_unknown_and_does_not_count_new_conflict():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    from test_dance_mask_continuity import recovery_example
    original,records,_=recovery_example()
    matches={f:dict(name='A',status='accepted') for f in (18,22)}
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],
        verify_track=lambda *args:dict(accepted=False,reason='inconsistent_visual_path'))
    assert result is original
    assert audit['recovered_seconds']==audit['corrected_seconds']==audit['conflict_seconds']==0.
    assert audit['candidates'][0]['attempts'][0]['reason']=='inconsistent_visual_path'


def test_joint_unknown_partial_path_ends_before_main_ownership_changes():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    from test_dance_mask_continuity import recovery_example
    original,records,_=recovery_example()
    matches={f:dict(name='A',status='accepted') for f in (18,22)}
    def partial(anchor,path,targets):
        if 30 in targets:return dict(accepted=False,reason='unconfirmed_main_ownership',frame=30)
        return proof(anchor,path,targets)
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=partial)
    assert [(s.start,s.end,d.reference_id) for s,d in zip(result['segments'],result['decisions'])]==[(0.,2.95,'A'),(2.95,4.,None),(4.,6.,'A')]
    assert audit['recovered_seconds']==pytest.approx(.95)
    assert audit['conflict_seconds']==0.


def test_joint_unknown_opposing_original_face_vetoes_recovery():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    from test_dance_mask_continuity import recovery_example
    original,records,_=recovery_example()
    matches={f:dict(name='A',status='accepted') for f in (18,22)}
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,
        [dict(name='B',frame_index=23)],verify_track=proof)
    assert result is original
    assert audit['recovered_seconds']==0.
    assert audit['candidates'][0]['attempts'][0]['reason']=='conflicting_direct_face_anchor'


def name_at(output,time):
    return next(d.reference_id for s,d in zip(output['segments'],output['decisions']) if s.start <= time < s.end)


@pytest.mark.parametrize('reverse_matches',[False,True])
def test_returning_main_is_verified_separately_without_disputing_middle_member(reverse_matches):
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,_=correction_inputs()
    sequence=[(f,'A') for f in (18,20,22)]+[(f,'B') for f in (24,26)]+[(f,'A') for f in (28,30,32)]
    if reverse_matches:sequence.reverse()
    matches={f:dict(name=n,status='accepted') for f,n in sequence}
    calls=[]
    def verify(anchor,path,targets):
        calls.append((anchor.frame_index,tuple(round(r.t*10) for r in path)))
        if anchor.frame_index < 24:return dict(accepted=False,reason='inconsistent_visual_path')
        return proof(anchor,path,targets)
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=verify)
    assert name_at(result,2.2) is None
    assert name_at(result,2.4)==name_at(result,2.5)==name_at(result,2.6)=='B'
    assert name_at(result,3.1)=='A'
    assert any(anchor>=28 for anchor,_ in calls)
    assert all(24 not in frames and 26 not in frames for _,frames in calls)
    assert sum(s.end-s.start for s in result['segments'])==pytest.approx(6.)
    assert sum(len(e) for e in result['evidence'])==60
    assert audit['corrected_seconds']>0


def test_short_runs_cannot_borrow_repetition_across_one_other_accepted_main():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,_=correction_inputs()
    matches={f:dict(name=n,status='accepted') for f,n in [(20,'A'),(21,'A'),(22,'B'),(23,'A'),(24,'A')]}
    calls=[]
    def verify(*args):
        calls.append(args)
        return proof(*args)
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=verify)
    assert result is original
    assert calls==[]
    assert audit['conflict_seconds']==audit['corrected_seconds']==0.


def test_dense_repeated_faces_dispute_their_own_span_when_body_proof_fails():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,_=correction_inputs()
    matches={f:dict(name='A',status='accepted') for f in (20,21,22,23)}
    result,audit=revalidate_named_segments(original,records,'unused',10.,matches,[],
        verify_track=lambda *args:dict(accepted=False,reason='inconsistent_visual_path'))
    assert all(name_at(result,t) is None for t in (2.0,2.1,2.3))
    assert name_at(result,2.4)=='B'
    assert audit['conflict_seconds']==pytest.approx(.35)


def test_separate_evidence_after_long_gap_gets_its_own_verification():
    from dance_highlight.services.joint_identity import revalidate_named_segments
    original,records,_=correction_inputs()
    matches={f:dict(name='A',status='accepted') for f in (20,22,30,32)}
    def verify(anchor,path,targets):
        if anchor.frame_index < 30:return dict(accepted=False,reason='inconsistent_visual_path')
        return proof(anchor,path,targets)
    result,_=revalidate_named_segments(original,records,'unused',10.,matches,[],verify_track=verify)
    assert name_at(result,2.1) is None
    assert name_at(result,3.1)=='A'
