from dataclasses import replace
import numpy as np
from dance_highlight.services import face_evidence as evidence


def observation(**kw):
    values=dict(frame_index=10,time_seconds=1.,track_id=7,body_bbox=(0.,0.,100.,200.),
                roi_bbox=(0.,0.,100.,200.),face_bbox=(30.,10.,70.,50.),
                candidate_boxes=((30.,10.,70.,50.),),embedding=np.array([1.,0.]))
    values.update(kw)
    return evidence.FaceObservation(**values)


def association(obs,bodies):
    assert hasattr(evidence,'face_body_association')
    return evidence.face_body_association(obs,bodies)


def test_unique_face_in_main_body_head_region_has_geometric_ownership():
    assert association(observation(),[(0,0,100,200),(110,0,210,200)]) == 'confirmed'


def test_overlapping_bodies_do_not_confirm_the_highest_score_face():
    assert association(observation(),[(0,0,100,200),(20,0,120,200)]) == 'ambiguous'


def test_multiple_faces_in_the_same_body_region_remain_ambiguous():
    obs=observation(candidate_boxes=((30,10,70,50),(5,5,25,35)))
    assert association(obs,[(0,0,100,200)]) == 'ambiguous'


def test_face_outside_main_head_region_or_missing_body_context_is_unassigned():
    assert association(observation(face_bbox=(30,140,70,180)),[(0,0,100,200)]) == 'unassigned'
    assert association(observation(),[]) == 'unassigned'


def test_pose_head_association_selects_unique_main_face_and_vetoes_competitor():
    from dance_highlight.services.face_evidence import select_pose_face
    from dance_highlight.services.segment import FrameRec
    body = np.array([0., 20., 100., 200.])
    main = np.array([[30, 40, .9], [40, 40, .9], [35, 45, .9]])
    other = np.array([[30, 10, .9], [40, 10, .9], [35, 15, .9]])
    rec = FrameRec(0., 1, body, False, person_bboxes=[body, body + 200],
                   person_head_keypoints=[main, other])
    boxes = [(20., 0., 50., 20.), (20., 30., 50., 50.)]
    assert select_pose_face(boxes, body, rec) == (1, None)
    rec.person_head_keypoints[1] = main.copy()
    assert select_pose_face(boxes, body, rec) == (None, 'pose_face_ambiguous')


def test_pose_missing_confidence_or_wrong_body_never_confirms():
    from dance_highlight.services.face_evidence import select_pose_face
    from dance_highlight.services.segment import FrameRec
    body = np.array([0., 0., 100., 200.])
    rec = FrameRec(0., 1, body, False, person_bboxes=[body],
                   person_head_keypoints=[np.array([[30, 40, .1], [40, 40, .1]])])
    assert select_pose_face([(20., 30., 50., 50.)], body, rec)[1] == 'pose_head_unconfirmed'
    assert select_pose_face([(20., 30., 50., 50.)], body + 300, rec)[1] == 'pose_body_unconfirmed'


def test_evidence_records_the_face_pair_selection_code_fingerprint(tmp_path):
    import hashlib
    import json
    from pathlib import Path
    from types import SimpleNamespace
    from dance_highlight.services import temporal_support
    source = tmp_path / 'source.mp4'
    source.write_bytes(b'original-source')
    destination = tmp_path / 'evidence.json'
    evidence.write_face_evidence(destination, input_video=source,
        config=SimpleNamespace(), face_service=SimpleNamespace(),
        results=[], records=[], references=[])
    modules = json.loads(destination.read_text())['runtime']['modules']
    assert modules['temporal_support']['sha256'] == hashlib.sha256(
        Path(temporal_support.__file__).read_bytes()).hexdigest()
