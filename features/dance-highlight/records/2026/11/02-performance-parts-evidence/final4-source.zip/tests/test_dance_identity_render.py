from types import SimpleNamespace
from dance_highlight.services import render


def test_split_clip_uses_accurate_encoding_even_when_default_is_stream_copy(tmp_path,monkeypatch):
    commands=[]
    monkeypatch.setattr(render,'run_cmd',lambda cmd:commands.append(cmd))
    service=render.RenderService.__new__(render.RenderService)
    service.config=SimpleNamespace(use_stream_copy=True,ffmpeg_hw_encoder=None,encode_preset='medium',encode_crf=18)
    service.ffmpeg='ffmpeg'
    service.extract_clip('source.mp4',tmp_path/'new.mp4',1.2,2.4,accurate=True)
    assert 'copy' not in commands[0]
    assert 'libx264' in commands[0]
    assert commands[0][commands[0].index('-ss')+1]=='1.2'
