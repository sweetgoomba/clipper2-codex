from __future__ import annotations

import sys

import pytest


def test_dance_run_cmd_raises_on_timeout():
    from dance_highlight.services.render import run_cmd

    with pytest.raises(RuntimeError) as ei:
        run_cmd([sys.executable, "-c", "import time; time.sleep(5)"], timeout=0.3)
    assert "timed out" in str(ei.value).lower()
