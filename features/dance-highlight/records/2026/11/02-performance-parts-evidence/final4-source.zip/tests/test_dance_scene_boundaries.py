from dataclasses import replace
import numpy as np
import pytest
from dance_highlight.services.segment import (
    FrameRec,
    Segment,
    build_raw_main_segments,
    build_main_evidence_scopes,
    build_raw_group_segments,
    intersect_main_segments,
)
from dance_highlight.services.scene_boundaries import align_scene_segment_boundaries


def records(kinds, frames=None):
    box = np.array([0.0, 0.0, 100.0, 300.0])
    return [
        FrameRec(
            f / 60,
            1 if kind == "main" else None,
            box if kind == "main" else None,
            kind == "group",
            scene_kind=kind,
        )
        for f, kind in zip(frames or range(0, 4 * len(kinds), 4), kinds, strict=True)
    ]


def align(rows, cuts, step=4):
    main = build_main_evidence_scopes(build_raw_main_segments(rows))
    group = build_raw_group_segments(rows)
    return align_scene_segment_boundaries(
        rows,
        main,
        group,
        fps=60.0,
        cut_frames=cuts,
        sample_step=step,
        verify_cut=lambda f: dict(
            cut=True, structure=dict(continuous=False, matches=4)
        ),
    )


def test_exact_group_cut_removes_unsupported_two_frame_solo_tail_without_deleting_time():
    rows = records(["main", "main", "group", "group"], [480, 484, 488, 492])
    main, group, audit = align(rows, [486])
    identity = [
        Segment("main", None, 480 / 60, 486 / 60, []),
        Segment("main", None, 486 / 60, 492 / 60, []),
    ]
    assert [
        (i, s.start, s.end) for i, s in intersect_main_segments(identity, main)
    ] == [(0, 480 / 60, 486 / 60)]
    assert [(s.start, s.end) for s in group] == [(486 / 60, 492 / 60)]
    assert [(r.t, r.scene_kind) for r in rows] == [
        (480 / 60, "main"),
        (484 / 60, "main"),
        (488 / 60, "group"),
        (492 / 60, "group"),
    ]
    assert len(audit["changes"]) == 1


def test_group_to_main_cut_preserves_a_genuine_two_frame_closeup_and_long_main():
    rows = records(["group", "main", "group", "main", "main"], [0, 4, 8, 12, 372])
    main, group, _ = align(rows, [3, 5, 10])
    assert [(s.start, s.end) for s in main] == [(3 / 60, 5 / 60), (10 / 60, 372 / 60)]
    assert [(s.start, s.end) for s in group] == [(0.0, 3 / 60), (5 / 60, 10 / 60)]


@pytest.mark.parametrize("cuts", [[], [1, 2], [0], [5]])
def test_missing_ambiguous_or_outside_cut_keeps_observed_boundary(cuts):
    rows = records(["main", "group", "group"])
    main, group, audit = align(rows, cuts)
    assert main[0].end == group[0].start == 4 / 60
    assert not audit["changes"]


def test_never_aligns_across_missing_pose_samples_or_no_person_scene():
    rows = records(["main", "group", "no_person", "main", "main"], [0, 8, 12, 16, 20])
    main, group, audit = align(rows, [6, 10, 14])
    assert [(s.start, s.end) for s in main] == [(0.0, 8 / 60), (16 / 60, 20 / 60)]
    assert group[0].end == 12 / 60
    assert not audit["changes"]


def test_main_identity_handoff_is_not_a_scene_transition():
    rows = records(["main", "main", "main"])
    rows[1] = replace(rows[1], main_id=2)
    main, group, audit = align(rows, [2, 6])
    assert [(s.start, s.end) for s in main] == [(0.0, 8 / 60)]
    assert not group and not audit["changes"]


@pytest.mark.parametrize('kind', ['same_color_cut', 'flash', 'two_cuts'])
def test_source_spatial_proof_supplements_color_inventory_only_for_scene_output(tmp_path, kind):
    import cv2
    from dance_highlight.services.scene_boundaries import align_scene_segments_from_source
    rng = np.random.default_rng(135)
    before, after = [cv2.GaussianBlur(rng.integers(20, 220, (288, 512, 3), dtype=np.uint8),
                                    (5, 5), 0) for _ in range(2)]
    frames = [before] * 10 + [after] * 20
    if kind == 'flash':
        bright = np.clip(before.astype(np.int16) + 135, 0, 255).astype(np.uint8)
        frames = [before] * 10 + [bright] + [before] * 19
    elif kind == 'two_cuts':
        frames = [before] * 10 + [after] + [before] * 19
    source = tmp_path / 'scene.avi'
    writer = cv2.VideoWriter(str(source), cv2.VideoWriter_fourcc(*'MJPG'), 60., (512, 288))
    for image in frames:
        writer.write(image)
    writer.release()
    rows = records(['main', 'group', 'group'], [6, 12, 16])
    main = build_main_evidence_scopes(build_raw_main_segments(rows))
    groups = build_raw_group_segments(rows)
    result, group, audit = align_scene_segments_from_source(rows, main, groups,
        video_path=source, fps=60., cut_frames=[], sample_step=6)
    assert result[0].end == group[0].start == (10 if kind == 'same_color_cut' else 12) / 60
    assert rows[1].t == 12 / 60
    if kind == 'same_color_cut':
        proof = audit['changes'][0]['source_proof']
        assert not proof['cut']  # Does not redefine the identity cut inventory.
        assert proof['spatial']['accepted']
    else:
        assert not audit['changes']


def test_normal_eof_context_abstains_locally_without_discarding_earlier_proof(tmp_path):
    import cv2
    from dance_highlight.services.scene_boundaries import align_scene_segments_from_source
    rng = np.random.default_rng(45)
    a, b, c = [cv2.GaussianBlur(rng.integers(20, 220, (288, 512, 3), dtype=np.uint8),
                               (5, 5), 0) for _ in range(3)]
    source = tmp_path / 'end.avi'
    writer = cv2.VideoWriter(str(source), cv2.VideoWriter_fourcc(*'MJPG'), 60., (512, 288))
    for image in [a] * 8 + [b] * 10 + [c] * 2:
        writer.write(image)
    writer.release()
    rows = records(['group', 'main', 'main', 'group'], [6, 10, 16, 19])
    main = build_main_evidence_scopes(build_raw_main_segments(rows))
    groups = build_raw_group_segments(rows)
    result, _, audit = align_scene_segments_from_source(rows, main, groups,
        video_path=source, fps=60., cut_frames=[], sample_step=4)
    assert audit['reason'] == 'complete'
    assert result[0].start == 8 / 60
    assert result[0].end == 19 / 60
    assert [c['cut_frame'] for c in audit['changes']] == [8]


@pytest.mark.parametrize(
    "proof",
    [
        {},
        {"cut": False},
        {"cut": True},
        {"cut": True, "structure": {"continuous": True}},
        {
            "cut": True,
            "structure": {"continuous": False, "reason": "insufficient_structure"},
        },
    ],
)
def test_flash_or_unavailable_cut_structure_keeps_observed_boundary(proof):
    rows = records(["main", "group", "group"])
    main = build_main_evidence_scopes(build_raw_main_segments(rows))
    groups = build_raw_group_segments(rows)
    actual, group, audit = align_scene_segment_boundaries(
        rows,
        main,
        groups,
        fps=60.0,
        cut_frames=[2],
        sample_step=4,
        verify_cut=lambda _: proof,
    )
    assert actual[0].end == group[0].start == 4 / 60
    assert not audit["changes"]


def test_source_read_failure_discards_partial_boundary_adjustments(tmp_path):
    from dance_highlight.services.scene_boundaries import (
        align_scene_segments_from_source,
    )

    rows = records(["main", "group", "group"])
    main = build_main_evidence_scopes(build_raw_main_segments(rows))
    group = build_raw_group_segments(rows)
    actual, groups, audit = align_scene_segments_from_source(
        rows,
        main,
        group,
        video_path=tmp_path / "missing.mp4",
        fps=60.0,
        cut_frames=[2],
        sample_step=4,
    )
    assert actual is main and groups is group
    assert audit["reason"] == "source_unavailable" and not audit["changes"]


def test_original_exact_frame_pair_is_verified_before_moving_scene_edge(monkeypatch):
    import cv2
    from dance_highlight.services import camera_transitions
    from dance_highlight.services.scene_boundaries import (
        align_scene_segments_from_source,
    )

    class Capture:
        position = 0
        released = False

        def isOpened(self):
            return True

        def get(self, key):
            return 60.0 if key == cv2.CAP_PROP_FPS else self.position

        def set(self, key, value):
            self.position = value
            return True

        def read(self):
            value = self.position
            self.position += 1
            return True, np.full((16, 16, 3), value, dtype=np.uint8)

        def release(self):
            self.released = True

    cap = Capture()
    monkeypatch.setattr(cv2, "VideoCapture", lambda _: cap)
    pairs = []

    def proof(a, b):
        pairs.append((int(a[0, 0, 0]), int(b[0, 0, 0])))
        return dict(cut=int(b[0, 0, 0]) == 2, structure=dict(continuous=False, matches=4))

    monkeypatch.setattr(camera_transitions, "classify_transition", proof)
    rows = records(["main", "group", "group"])
    main = build_main_evidence_scopes(build_raw_main_segments(rows))
    group = build_raw_group_segments(rows)
    actual, groups, audit = align_scene_segments_from_source(
        rows,
        main,
        group,
        video_path="source.mp4",
        fps=60.0,
        cut_frames=[2],
        sample_step=4,
    )
    assert pairs == [(0, 1), (1, 2), (2, 3), (3, 4)] and cap.released
    assert actual[0].end == groups[0].start == 2 / 60


def test_soft_group_export_overlap_does_not_inflate_strict_group_seconds():
    rows = records(["main", "group", "main", "main"])
    rows[0] = replace(rows[0], is_group=True)
    rows[2] = replace(rows[2], is_group=True)
    main, groups, audit = align(rows, [2, 6])
    assert [(s.start, s.end) for s in groups] == [(0.0, 12 / 60)]
    assert [(s.start, s.end) for s in main] == [(0.0, 2 / 60), (6 / 60, 12 / 60)]
    assert audit["scene_group_ranges"] == [dict(start=2 / 60, end=6 / 60)]
    assert audit["scene_group_seconds"] == pytest.approx(4 / 60)


@pytest.mark.parametrize('cuts,expected_end', [([2], 2/60), ([1, 2], 4/60), ([], 4/60)])
def test_without_inventory_reads_every_source_pair_in_scene_bracket(monkeypatch, cuts, expected_end):
    import cv2
    from dance_highlight.services import camera_transitions
    from dance_highlight.services.scene_boundaries import align_scene_segments_from_source
    class Capture:
        position = 0
        released = False
        def isOpened(self):return True
        def get(self,key):return 60. if key==cv2.CAP_PROP_FPS else self.position
        def set(self,key,value):self.position=value;return True
        def read(self):
            value=self.position;self.position+=1
            return True,np.full((16,16,3),value,dtype=np.uint8)
        def release(self):self.released=True
    cap=Capture();monkeypatch.setattr(cv2,'VideoCapture',lambda _:cap)
    pairs=[]
    def proof(a,b):
        pair=int(a[0,0,0]),int(b[0,0,0]);pairs.append(pair)
        return dict(cut=pair[1] in cuts,structure=dict(continuous=False,matches=4))
    monkeypatch.setattr(camera_transitions,'classify_transition',proof)
    rows=records(['main','group','group'])
    main=build_main_evidence_scopes(build_raw_main_segments(rows));groups=build_raw_group_segments(rows)
    actual,group,audit=align_scene_segments_from_source(rows,main,groups,video_path='source.mp4',fps=60.,cut_frames=None,sample_step=4)
    assert actual[0].end==group[0].start==expected_end
    assert pairs==[(0,1),(1,2),(2,3),(3,4)] and cap.released
    assert audit['cut_inventory']=='complete_scene_brackets'


def test_anonymous_dance_does_not_run_registered_scene_alignment(tmp_path, monkeypatch):
    from dance_highlight.services import scene_boundaries
    from dance_highlight.services.config import DanceConfig
    from dance_highlight.services.pipeline import DancePipeline
    class ReachedFace(Exception):pass
    class Face:
        def batch_segment_embeddings(self,*args,**kwargs):raise ReachedFace
    def forbidden(*args,**kwargs):raise AssertionError('anonymous analysis must retain its scene policy')
    monkeypatch.setattr(scene_boundaries,'align_scene_segments_from_source',forbidden)
    rows=records(['main']*31,frames=list(range(0,124,4)))
    pipe=DancePipeline(DanceConfig(min_main_seg_sec=.1),None,Face(),None,None)
    pipe.analyze_video_to_records=lambda *args,**kwargs:(rows,60.,2.1)
    pipe._download_reference_images=lambda *args:{}
    pipe._build_reference_embeddings=lambda *args,**kwargs:{}
    pipe._video_size=lambda *args:(640,480)
    source=tmp_path/'source.mp4';source.write_bytes(b'source')
    with pytest.raises(ReachedFace):pipe.run(tmp_path,source,1)


@pytest.mark.parametrize('fps', [30., 30000/1001, 60000/1001])
def test_subframe_identity_padding_meets_exact_scene_cut_without_unknown_sliver(fps):
    from dance_highlight.services.scene_boundaries import project_main_at_scene_cuts
    cut=100/fps;edge=cut+.0001
    identity=[Segment('main',None,cut-1.,edge,[]),Segment('main',2,edge,cut+6.,[])]
    eligible=[Segment('main',None,cut,cut+6.,[])]
    projected,audit=project_main_at_scene_cuts(identity,eligible,fps=fps,cut_times=[cut])
    assert [(i,s.start,s.end) for i,s in projected]==[(1,cut,cut+6.)]
    assert len(audit['zero_frame_output_parts'])==1
    assert identity[0].end==edge and identity[1].start==edge


@pytest.mark.parametrize('duration_frames', [1,2])
def test_source_frame_sized_unknown_or_member_part_survives_scene_projection(duration_frames):
    from dance_highlight.services.scene_boundaries import project_main_at_scene_cuts
    fps=60000/1001;cut=100/fps;edge=(100+duration_frames)/fps
    identity=[Segment('main',None,cut-1.,edge,[]),Segment('main',2,edge,cut+6.,[])]
    projected,audit=project_main_at_scene_cuts(identity,[Segment('main',None,cut,cut+6.,[])],fps=fps,cut_times=[cut])
    assert [(i,s.start,s.end) for i,s in projected]==[(0,cut,edge),(1,edge,cut+6.)]
    assert not audit['zero_frame_output_parts']


def test_identity_edges_elsewhere_are_not_quantized_to_unverified_cuts():
    from dance_highlight.services.scene_boundaries import project_main_at_scene_cuts
    identity=[Segment('main',None,0.,1.0001,[]),Segment('main',2,1.0001,6.,[])]
    projected,audit=project_main_at_scene_cuts(identity,[Segment('main',None,0.,6.,[])],fps=60.,cut_times=[3.])
    assert [(i,s.start,s.end) for i,s in projected]==[(0,0.,1.0001),(1,1.0001,6.)]
    assert not audit['output_edge_changes']


def test_brightness_flash_with_too_few_matches_cannot_retime_scene(monkeypatch):
    import cv2
    from dance_highlight.services.camera_transitions import classify_transition
    rng=np.random.default_rng(1)
    before=cv2.GaussianBlur(rng.integers(0,256,(400,600,3),dtype=np.uint8),(5,5),0)
    after=cv2.convertScaleAbs(before,alpha=1.,beta=135)
    proof=classify_transition(before,after)
    assert proof['cut'] and proof['structure'].get('reason')=='insufficient_correspondence'
    rows=records(['main','group','group']);main=build_main_evidence_scopes(build_raw_main_segments(rows));groups=build_raw_group_segments(rows)
    a,b,audit=align_scene_segment_boundaries(rows,main,groups,fps=60.,cut_frames=[2],sample_step=4,verify_cut=lambda _:proof)
    assert a[0].end==b[0].start==4/60
    assert not audit['changes']


def test_only_unidentified_output_splits_at_proven_main_handoff_without_duration_floor():
    from types import SimpleNamespace
    from dance_highlight.services.scene_boundaries import split_unidentified_at_handoffs
    original=Segment('main',None,0.,6.,[(0.,'a',1),(2.4,'b',2),(2.5,'b',2)])
    decisions=[SimpleNamespace(reference_id=None),SimpleNamespace(reference_id='A')]
    handoffs=[dict(frame=144,time=2.4),dict(frame=146,time=2.4+2/60)]
    result,audit=split_unidentified_at_handoffs([(0,original),(1,original)],decisions,handoffs)
    assert [(i,r.start,r.end) for i,r in result]==[(0,0.,2.4),(0,2.4,2.4+2/60),(0,2.4+2/60,6.),(1,0.,6.)]
    assert original.start==0. and original.end==6. and len(original.bboxes)==3
    assert len(audit['changes'])==2
    assert result[0][1].bboxes==[(0.,'a',1)]


def test_unknown_continuous_six_seconds_and_outside_or_duplicate_handoffs():
    from types import SimpleNamespace
    from dance_highlight.services.scene_boundaries import split_unidentified_at_handoffs
    segment=Segment('main',None,0.,6.,[]);source=[(0,segment)];decisions=[SimpleNamespace(reference_id=None)]
    result,audit=split_unidentified_at_handoffs(source,decisions,[dict(frame=0,time=0.),dict(frame=60,time=6.)])
    assert result==source and not audit['changes']
    result,audit=split_unidentified_at_handoffs(source,decisions,[dict(frame=2,time=.2)]*2)
    assert [(r.start,r.end) for _,r in result]==[(0.,.2),(.2,6.)]
    assert len(audit['changes'])==1
