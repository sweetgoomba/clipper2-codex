"""A missing descriptor match is not positive evidence of an edit."""
import cv2
import numpy as np
import pytest

from dance_highlight.services.scene_cut_proof import spatial_cut_evidence


def texture(seed):
    image = np.random.default_rng(seed).integers(20, 220, (288, 512, 3), dtype=np.uint8)
    return cv2.GaussianBlur(image, (5, 5), 0)


def test_same_color_distribution_with_replaced_spatial_layout_is_a_cut():
    left, right = texture(1), texture(2)
    proof = spatial_cut_evidence([left] * 5 + [right] * 5)
    assert proof['accepted']
    assert proof['reason'] == 'isolated_spatial_cut'
    assert proof['supporting_tiles'] >= 3


@pytest.mark.parametrize('persistent', [False, True])
def test_clipped_exposure_jump_and_flash_are_not_scene_edges(persistent):
    source = texture(3)
    bright = np.clip(source.astype(np.int16) + 135, 0, 255).astype(np.uint8)
    after = [bright] * 5 if persistent else [bright] + [source] * 4
    assert not spatial_cut_evidence([source] * 5 + after)['accepted']


@pytest.mark.parametrize('dim_gain', [.05, .01])
def test_global_color_lighting_cannot_turn_contrast_inversion_into_a_cut(dim_gain):
    rng = np.random.default_rng(23)
    t = cv2.resize((20 + 215 * rng.integers(0, 2, (72, 128))).astype(np.uint8),
                   (512, 288), interpolation=cv2.INTER_LINEAR)
    base = np.stack((t, np.full_like(t, 120), 255 - t), axis=-1).astype(np.float32)
    before = (base * np.array([1., .6, dim_gain])).astype(np.uint8)
    after = (base * np.array([dim_gain, .6, 1.])).astype(np.uint8)
    assert not spatial_cut_evidence([before] * 5 + [after] * 5)['accepted']


def test_brief_different_frame_return_is_not_a_new_persistent_scene():
    source, flash = texture(4), texture(5)
    assert not spatial_cut_evidence([source] * 5 + [flash] + [source] * 4)['accepted']


def test_continuous_large_zoom_or_blur_is_not_an_isolated_scene_edge():
    source = texture(6)
    frames = [cv2.warpAffine(source, cv2.getRotationMatrix2D((256, 144), 0, 1 + i * .07),
                            (512, 288)) for i in range(10)]
    assert not spatial_cut_evidence(frames)['accepted']
    assert not spatial_cut_evidence([cv2.GaussianBlur(f, (15, 15), 0) for f in frames])['accepted']


def test_single_consistent_camera_transform_is_not_proof_of_an_edit():
    source = texture(7)
    shifted = cv2.warpAffine(source, np.float32([[1, 0, 70], [0, 1, 0]]), (512, 288))
    assert not spatial_cut_evidence([source] * 5 + [shifted] * 5)['accepted']


@pytest.mark.parametrize('case', ['flat', 'missing', 'changed_size', 'two_edges'])
def test_insufficient_or_multiple_transition_evidence_abstains(case):
    a, b, c = texture(8), texture(9), texture(10)
    frames = [a] * 5 + [b] * 5
    if case == 'flat':
        frames = [np.full_like(a, 50)] * 5 + [np.full_like(a, 180)] * 5
    elif case == 'missing':
        frames.pop()
    elif case == 'changed_size':
        frames[4] = a[:100]
    else:
        frames[-3:] = [c] * 3
    assert not spatial_cut_evidence(frames)['accepted']
