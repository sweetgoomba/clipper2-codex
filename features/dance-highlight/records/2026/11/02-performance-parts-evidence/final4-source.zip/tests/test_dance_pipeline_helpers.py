"""Characterization tests for DancePipeline pure helpers used by .run().

The full DancePipeline.run() orchestration needs a real input video plus pose/
face models, so end-to-end behavior belongs in an integration fixture, not here.
These pin the *pure* segment-filtering helpers that run() relies on, so the
Phase 3 (P6) decomposition can be verified to preserve them.

DancePipeline.__new__ is used to obtain an instance without the model-loading
__init__ — these helpers only use `self` to call each other, no heavy state.
"""
from __future__ import annotations

import pytest

from dance_highlight.services.pipeline import DancePipeline
from dance_highlight.services.segment import Segment


@pytest.fixture
def pipe() -> DancePipeline:
    return DancePipeline.__new__(DancePipeline)


def _seg(start: float, end: float, seg_type: str = "main") -> Segment:
    return Segment(seg_type=seg_type, label="x", start=float(start), end=float(end), bboxes=[])


def _ids(out):
    return [(s.start, s.end) for s in out]


def test_segment_overlap_ratio_is_intersection_over_a_duration(pipe):
    assert pipe._segment_overlap_ratio(0, 10, 5, 15) == 0.5   # 5s overlap / 10s duration of a
    assert pipe._segment_overlap_ratio(0, 10, 20, 30) == 0.0  # disjoint
    assert pipe._segment_overlap_ratio(0, 10, -5, 15) == 1.0  # a fully inside b


def test_filter_returns_main_unchanged_when_no_group(pipe):
    main = [_seg(0, 10)]
    # early return: same list object back
    assert pipe._filter_group_like_main_segments(main, []) is main


def test_filter_drops_overlapping_keeps_short_intro_and_non_overlapping(pipe):
    main = [_seg(0, 3), _seg(20, 40), _seg(60, 80)]
    group = [_seg(19, 41, "group")]
    # 0-3: short intro (start<12 & dur<=3.2) -> kept;
    # 20-40: full overlap with group -> dropped;
    # 60-80: no overlap -> kept.
    assert _ids(pipe._filter_group_like_main_segments(main, group)) == [(0.0, 3.0), (60.0, 80.0)]


def test_filter_drops_long_intro_segment_when_overlapping(pipe):
    # 0-10 starts before 12s but dur 10 > keep_short_intro_sec (3.2) -> not protected.
    main = [_seg(0, 10), _seg(60, 80)]
    group = [_seg(0, 10, "group")]
    assert _ids(pipe._filter_group_like_main_segments(main, group)) == [(60.0, 80.0)]


def test_filter_keeps_segment_below_overlap_threshold(pipe):
    main = [_seg(20, 40)]
    group = [_seg(35, 45, "group")]  # overlap 5 / 20 = 0.25 < 0.6 threshold
    assert _ids(pipe._filter_group_like_main_segments(main, group)) == [(20.0, 40.0)]
