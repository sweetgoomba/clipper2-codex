"""Independent source instants are a pair constraint, not a nearest-face rule."""
from dataclasses import replace

import numpy as np
import pytest


def pair_choice_example():
    from test_dance_member_timeline import observation
    anchors = []
    for time, distance in ((0., .3), (.1, .1), (.2, .35)):
        cosine = 1. - distance
        row = replace(observation(time, 'A'), embedding=np.array([cosine, np.sqrt(1. - cosine**2), 0.]))
        anchors.append(('A', row))
    for time in (1., 1.2):
        anchors.append(('B', replace(observation(time, 'B'), embedding=np.array([0., 0., 1.]))))
    query = observation(5., 'A')
    return query, anchors


@pytest.mark.parametrize('reverse', [False, True])
@pytest.mark.parametrize('matcher', ['primary', 'secondary', 'joint'])
def test_independent_pair_can_exclude_the_single_closest_face(matcher, reverse):
    from dance_highlight.services.member_timeline import match_video_anchors
    from dance_highlight.services.secondary_faces import match_secondary_video
    from dance_highlight.services.joint_identity import joint_video_matches
    query, anchors = pair_choice_example()
    if reverse:
        anchors.reverse()
    if matcher == 'primary':
        assert match_video_anchors(query, anchors) == 'A'
    elif matcher == 'secondary':
        result = match_secondary_video(query, anchors, {'A': None, 'B': None})
        assert result['name'] == 'A'
        assert set(result['candidates'][0]['support_frames']) == {0, 6}
    else:
        rows = {r.frame_index: r for _, r in anchors}
        rows[query.frame_index] = query
        vectors = {f: r.embedding.copy() for f, r in rows.items()}
        result = joint_video_matches(rows, vectors,
            [dict(name=n, frame_index=r.frame_index) for n, r in anchors], {'A', 'B'})[query.frame_index]
        assert result['name'] == 'A'
        assert all(set(pair) == {0, 6} for pair in result['support_frames'])


def test_primary_competitor_keeps_its_valid_independent_pair():
    from test_dance_member_timeline import observation
    from dance_highlight.services.member_timeline import match_video_anchors
    query = observation(5., 'A')
    anchors = []
    for name, times_and_distances in (
            ('A', ((0., .3), (.2, .3))),
            ('B', ((1., .31), (1.1, .05), (1.2, .32)))):
        for time, distance in times_and_distances:
            cosine = 1. - distance
            anchors.append((name, replace(observation(time, name),
                embedding=np.array([cosine, np.sqrt(1. - cosine**2), 0.]))))
    # A and B are separated by only .02; B's central best face must not erase
    # its two independent observations and manufacture a confident A label.
    assert match_video_anchors(query, anchors) is None


def test_pair_distance_matches_exhaustive_independent_pairs():
    # Catch a premature return or incorrect temporal-extreme update. The oracle
    # enumerates every pair rather than using the production search algorithm.
    from itertools import combinations, product
    from dance_highlight.services.temporal_support import independent_pair
    times = (0., .05, .1, .2, .35)
    for distances in product((.1, .3, .5), repeat=len(times)):
        values = list(zip(distances, times, range(len(times))))
        eligible = [(a, b) for a, b in combinations(values, 2) if abs(a[1]-b[1]) >= .15]
        expected = min(max(a[0], b[0]) for a, b in eligible)
        forward = independent_pair(values)
        reverse = independent_pair(reversed(values))
        assert forward == reverse
        assert abs(forward[0][1]-forward[1][1]) >= .15
        assert max(v[0] for v in forward) == expected


@pytest.mark.parametrize('times, expected', [
    ((0., .149999), None),
    ((0., .15), .3),
    ((0., 0.), None),
])
def test_independent_pair_requires_actual_source_time_separation(times, expected):
    from dance_highlight.services.temporal_support import independent_pair
    pair = independent_pair([(.1, times[0]), (.3, times[1])])
    assert (max(v[0] for v in pair) if pair else None) == expected
