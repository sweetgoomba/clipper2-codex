"""Restore camera role coverage from frozen, owned identity evidence only."""
from dataclasses import replace

import numpy as np
import pytest

from dance_highlight.services.face_evidence import FaceObservation
from dance_highlight.services.focal_output import restore_focal_output
from dance_highlight.services.reference_matcher import SegmentReferenceDecision
from dance_highlight.services.segment import FrameRec, Segment


def setup_case():
    records = []
    observations = []
    for i in range(11):
        box = np.array([40., 10., 60., 90.])
        visible = i not in (4, 5)
        records.append(FrameRec(i/10, i if visible else None, box if visible else None, False,
            person_bboxes=[box], candidate_main_bbox=box if visible else None,
            candidate_main_id=i if visible else None))
        if visible:
            observations.append(FaceObservation(i*10, i/10, i, tuple(box), tuple(box),
                face_bbox=(45., 12., 55., 22.), embedding=np.array([1., 0.]),
                detector_score=.99, quality=i, association='confirmed'))
    output = dict(segments=[], decisions=[], labels=[], evidence=[], previews=[],
                  preview_sources=[], accurate_indices=[0, 1], anchors=['frozen'], audit=['keep'])
    for index, (start, end) in enumerate([(0., .4), (.6, 1.01)]):
        own = [o for o in observations if start <= o.time_seconds < end]
        output['segments'].append(Segment('main', index, start, end,
            [(o.time_seconds, np.array(o.body_bbox), o.track_id) for o in own]))
        output['decisions'].append(SegmentReferenceDecision('A', 'matched', 'existing'))
        output['labels'].append(index+1)
        output['evidence'].append([(o, 'A') for o in own])
        sources = {o.frame_index: bytes([o.frame_index]) for o in own}
        output['preview_sources'].append((sources, {}))
        output['previews'].append(list(sources.values()))
    episode = dict(start_frame=0, end_frame=100, start_time=0., end_time=1.,
                   visible_targets=[dict(frame=i*10, index=0) for i in range(11) if i not in (4, 5)],
                   role_only_frames=[40, 50])
    joint = {o.frame_index: dict(status='accepted', name='A') for o in observations}
    return output, [episode], records, joint


def restore(case, **kwargs):
    return restore_focal_output(*case, fps=100., cut_frames=[], **kwargs)


def test_verified_camera_episode_joins_occluded_gap_without_invented_faces():
    case = setup_case()
    original_rows = [o for group in case[0]['evidence'] for o, _ in group]
    result, audit = restore(case)
    assert [(s.start, s.end) for s in result['segments']] == [(0., 1.01)]
    assert result['decisions'][0].reference_id == 'A'
    assert [o for o, _ in result['evidence'][0]] == original_rows
    assert {round(t*100) for t, _, _ in result['segments'][0].bboxes} == set(range(0, 110, 10))-{40, 50}
    assert result['anchors'] is case[0]['anchors']
    assert result['audit'] is case[0]['audit']
    assert result['accurate_indices'] == [0]
    assert len(audit['restored']) == 1
    assert len(case[0]['segments']) == 2


def test_explicit_bounds_slice_and_preserve_outside_named_parts():
    case = setup_case()
    result, _ = restore(case, bounds=[(.1, .9)])
    assert [(s.start, s.end) for s in result['segments']] == [(0., .1), (.1, .9), (.9, 1.01)]
    assert [d.reference_id for d in result['decisions']] == ['A', 'A', 'A']
    for segment, evidence, sources in zip(result['segments'], result['evidence'], result['preview_sources']):
        assert all(segment.start <= o.time_seconds < segment.end for o, _ in evidence)
        assert all(segment.start <= f/100 < segment.end for f in sources[0])
    assert result['accurate_indices'] == [0, 1, 2]


@pytest.mark.parametrize('mutation', ['other_decision', 'other_primary', 'other_joint', 'wrong_body', 'occluded_face'])
def test_conflicting_or_unowned_identity_evidence_vetoes_episode(mutation):
    case = setup_case()
    identity, episodes, records, joint = case
    if mutation == 'other_decision':
        identity['decisions'][1] = SegmentReferenceDecision('B', 'matched', 'existing')
    elif mutation == 'other_primary':
        row, _ = identity['evidence'][1][0]
        identity['evidence'][1][0] = (row, 'B')
    elif mutation == 'other_joint':
        joint[60] = dict(status='accepted', name='B')
    elif mutation == 'wrong_body':
        row, name = identity['evidence'][1][0]
        identity['evidence'][1][0] = (replace(row, body_bbox=(0., 0., 20., 50.)), name)
    else:
        row = identity['evidence'][0][0][0]
        identity['evidence'][0].append((replace(row, frame_index=40, time_seconds=.4), 'A'))
    result, audit = restore(case)
    assert result is identity
    assert audit['restored'] == []


def test_joint_support_needs_two_independent_owned_anchors_and_existing_name():
    for mode in ('one', 'adjacent', 'unmatched'):
        case = setup_case()
        if mode == 'one':
            case[3].clear(); case[3][0] = dict(status='accepted', name='A')
        elif mode == 'adjacent':
            case[3].clear(); case[3].update({f: dict(status='accepted', name='A') for f in (0, 10)})
        else:
            case[0]['decisions'] = [SegmentReferenceDecision(None, 'unmatched', 'unknown')]*2
        result, audit = restore(case)
        assert result is case[0]
        assert audit['restored'] == []


def test_real_handoff_and_source_cut_protect_coverage_boundary():
    case = setup_case()
    result, audit = restore(case, handoffs=[dict(previous_time=.3, time=.4)])
    assert result is case[0]
    assert audit['restored'] == []
    result, audit = restore_focal_output(*case, fps=100., cut_frames=[45])
    assert result is case[0]
    assert audit['restored'] == []


def test_visible_target_must_be_the_records_actual_selected_body():
    case = setup_case()
    case[2][6].candidate_main_bbox = np.array([0., 0., 20., 50.])
    result, audit = restore(case)
    assert result is case[0]
    assert audit['restored'] == []


def test_role_only_frame_cannot_keep_a_foreground_main_box():
    case = setup_case()
    case[2][4].main_bbox = np.array([0., 0., 20., 50.])
    result, audit = restore(case)
    assert result is case[0]
    assert audit['restored'] == []


def test_occlusion_context_cannot_span_a_long_hidden_interval():
    case = setup_case()
    for i in range(2, 9):
        case[2][i] = replace(case[2][i], main_bbox=None, main_id=None, candidate_main_bbox=None)
    case[1][0]['visible_targets'] = [v for v in case[1][0]['visible_targets'] if v['frame'] not in range(20, 90, 10)]
    case[1][0]['role_only_frames'] = list(range(20, 90, 10))
    case[0]['evidence'] = [[(o, n) for o, n in group if o.frame_index not in range(20, 90, 10)]
                           for group in case[0]['evidence']]
    for frame in range(20, 90, 10):
        case[3].pop(frame, None)
    result, audit = restore(case)
    assert result is case[0]
    assert audit['restored'] == []


def test_missing_source_rows_cannot_stand_in_for_observed_occlusion():
    case = setup_case()
    case[2][:] = [record for i, record in enumerate(case[2]) if i not in (4, 5)]
    result, audit = restore(case)
    assert result is case[0]
    assert audit['restored'] == []


def test_hidden_foreground_thumbnail_is_not_retained_as_owned_preview():
    case = setup_case()
    case[0]['preview_sources'][0][0][40] = b'foreground'
    result, _ = restore(case)
    assert 40 not in result['preview_sources'][0][0]
    assert b'foreground' not in result['previews'][0]


def test_contrary_accepted_joint_face_in_hidden_frame_vetoes_episode():
    case = setup_case()
    case[3][40] = dict(status='accepted', name='B')
    result, audit = restore(case)
    assert result is case[0]
    assert audit['restored'] == []


def test_following_source_cut_clips_last_sample_duration():
    case = setup_case()
    case[2].append(replace(case[2][-1], t=1.1))
    result, audit = restore_focal_output(*case, fps=100., cut_frames=[105])
    assert audit['restored'][0]['end'] == 1.05
    assert result['segments'][0].end == 1.05


def test_other_named_role_outside_trimmed_episode_is_preserved():
    case = setup_case()
    case[0]['decisions'][0] = SegmentReferenceDecision('B', 'matched', 'existing')
    case[0]['evidence'][0] = [(o, 'B') for o, _ in case[0]['evidence'][0]]
    result, audit = restore(case, bounds=[(.6, 1.01)])
    assert len(audit['restored']) == 1
    assert [(s.start, s.end, d.reference_id) for s, d in zip(result['segments'], result['decisions'])] == [
        (0., .4, 'B'), (.6, 1.01, 'A')]


def test_reviewed_crossing_geometry_restores_only_original_target_body_evidence():
    """Geometry is captured from video; frozen recognition is simulated as A."""
    import json
    from pathlib import Path
    from dance_highlight.services.focal_composition import camera_focal_evidence
    data = json.loads((Path(__file__).parent/'fixtures/dance_focal_composition_reviewed.json').read_text())
    case = data['foreground_crossing_69']
    episodes = camera_focal_evidence(case['rows'], 1920, 1080, case['cuts'])
    episode = episodes[0]
    target = {v['frame']: v['index'] for v in episode['visible_targets']}
    records, observations = [], []
    fps = 60000/1001
    for row in case['rows']:
        boxes = [np.asarray(f['box']) for f in row['features']]
        # Saved feature indices belong to the original person list, which may
        # contain a suppressed body. Reconstruct its index-addressed inventory.
        indexed = [np.array([0., 0., 1., 1.]) for _ in range(max(f['index'] for f in row['features'])+1)]
        for f, box in zip(row['features'], boxes):
            indexed[f['index']] = box
        index = target.get(row['frame'])
        box = indexed[index] if index is not None else None
        records.append(FrameRec(row['time'], index, box, False, person_bboxes=indexed,
                                candidate_main_bbox=box, candidate_main_id=index))
        if box is not None:
            observations.append(FaceObservation(row['frame'], row['time'], index, tuple(box), tuple(box),
                                embedding=np.array([1., 0.]), detector_score=.99, association='confirmed'))
    output = dict(segments=[], decisions=[], labels=[], evidence=[], previews=[], preview_sources=[],
                  accurate_indices=[], anchors=[])
    for i, row in enumerate(observations):
        output['segments'].append(Segment('main', i, row.time_seconds, row.time_seconds+1/fps,
                                         [(row.time_seconds, np.asarray(row.body_bbox), row.track_id)]))
        output['decisions'].append(SegmentReferenceDecision('A', 'matched', 'frozen_test_identity'))
        output['labels'].append(i); output['evidence'].append([(row, 'A')])
        output['previews'].append([]); output['preview_sources'].append(({}, {}))
        output['accurate_indices'].append(i)
    joint = {row.frame_index: dict(status='accepted', name='A') for row in observations}
    result, audit = restore_focal_output(output, episodes, records, joint, fps=fps, cut_frames=case['cuts'])
    assert len(result['segments']) == len(audit['restored']) == 1
    assert audit['restored'][0]['role_only_frames'] == [4184, 4188, 4196, 4200]
    assert len(result['segments'][0].bboxes) == len(observations) == 16
    assert [row for row, _ in result['evidence'][0]] == observations
