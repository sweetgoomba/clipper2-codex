import numpy as np
import pytest
from types import SimpleNamespace

from dance_highlight.services import pipeline
from dance_highlight.services.segment import FrameRec
from dance_highlight.services.face_cluster import FaceClusterService


def test_coverage_gaps_keeps_overlapping_clips_and_finds_uncovered_ranges():
    assert callable(getattr(pipeline, 'coverage_gaps', None))
    assert pipeline.coverage_gaps(6, [(1, 3), (2, 4), (5, 6)]) == [(0, 1), (4, 5)]


def test_frame_diagnostics_records_selected_person_and_group_signal():
    assert callable(getattr(pipeline, 'frame_diagnostics', None))
    record = FrameRec(
        t=2.0, main_id=12, main_bbox=np.array([10, 20, 30, 80]), is_group=True,
        group_bboxes=[np.array([10, 20, 30, 80])],
        person_bboxes=[np.array([10, 20, 30, 80]), np.array([40, 20, 60, 80])],
        face_bboxes=[np.array([12, 22, 20, 33]), np.array([42, 22, 50, 33])],
        group_candidate=True, group_score_gap=0.05, group_area_ratio=1.2,
    )

    assert pipeline.frame_diagnostics([record]) == [{
        't': 2.0, 'main_track_id': 12, 'main_body': [10.0, 20.0, 30.0, 80.0],
        'bodies': [[10.0, 20.0, 30.0, 80.0], [40.0, 20.0, 60.0, 80.0]],
        'faces': [[12.0, 22.0, 20.0, 33.0], [42.0, 22.0, 50.0, 33.0]],
        'group': True, 'group_candidate': True, 'group_score_gap': 0.05,
        'group_area_ratio': 1.2, 'group_bodies': [[10.0, 20.0, 30.0, 80.0]],
        'group_faces': [[12.0, 22.0, 20.0, 33.0]],
    }]


def test_full_frame_face_boxes_use_source_video_coordinates():
    class Detector:
        def setInputSize(self, size):
            assert size == (960, 540)

        def detect(self, _image):
            return None, np.array([[100, 50, 20, 30, 0, 0, 0.9]], dtype=np.float32)

    face = FaceClusterService.__new__(FaceClusterService)
    face._detector = Detector()
    face._recognizer = object()
    face.config = type('Config', (), {'face_min_det_score': 0.5})()

    assert hasattr(face, 'detect_face_boxes')
    boxes = face.detect_face_boxes(np.zeros((1080, 1920, 3), dtype=np.uint8))
    assert len(boxes) == 1
    np.testing.assert_allclose(boxes[0], [200, 100, 240, 160])


def test_video_analysis_keeps_person_boxes_and_sampled_face_boxes(monkeypatch):
    class Capture:
        reads = 0

        def isOpened(self):
            return True

        def get(self, kind):
            return {pipeline.cv2.CAP_PROP_FPS: 30, pipeline.cv2.CAP_PROP_FRAME_COUNT: 1}.get(kind, 0)

        def read(self):
            self.reads += 1
            return (True, np.zeros((80, 100, 3), dtype=np.uint8)) if self.reads == 1 else (False, None)

        def release(self):
            pass

    body = np.array([10, 20, 30, 70], dtype=np.float32)
    face = np.array([12, 22, 20, 32], dtype=np.float32)

    class Selector:
        def __init__(self, **_kwargs):
            self.last_group_member_bboxes = [body]
            self.last_group_candidate = True
            self.last_group_score_gap = 0.04
            self.last_group_area_ratio = 1.2

        def select(self, persons, _shape, *, time_seconds):
            return persons[0], True

    monkeypatch.setattr(pipeline.cv2, 'VideoCapture', lambda _path: Capture())
    monkeypatch.setattr(pipeline, 'MainSelector', Selector)
    monkeypatch.setattr(pipeline, 'TrackAssigner', lambda **_kwargs: SimpleNamespace(assign=lambda *_args: 7))
    worker = pipeline.DancePipeline.__new__(pipeline.DancePipeline)
    worker.config = SimpleNamespace(analyze_skip=1, track_match_iou=0.2, track_ttl_sec=1)
    head=np.array([[14.,24.,.8],[18.,24.,.9]])
    worker.pose = SimpleNamespace(run_pose_on_frame=lambda _frame: [{'bbox': body, 'head_keypoints':head, 'pose_keypoints':np.tile([20.,40.,.9],(17,1))}])
    worker.face = SimpleNamespace(detect_face_boxes=lambda _frame: [face])

    records, fps, duration = worker.analyze_video_to_records('video.mp4')

    assert fps == 30 and duration == 1 / 30
    assert len(records) == 1
    np.testing.assert_allclose(records[0].person_bboxes[0], body)
    np.testing.assert_allclose(records[0].face_bboxes[0], face)
    np.testing.assert_allclose(records[0].person_head_keypoints[0],head)
    assert records[0].person_pose_keypoints[0].shape==(17,3)
    assert records[0].group_candidate is True
    assert records[0].group_score_gap == 0.04


def test_sampled_group_frames_create_a_long_enough_group_segment(monkeypatch):
    class Capture:
        index = 0

        def isOpened(self):
            return True

        def get(self, kind):
            return {pipeline.cv2.CAP_PROP_FPS: 24, pipeline.cv2.CAP_PROP_FRAME_COUNT: 52}.get(kind, 0)

        def read(self):
            if self.index >= 52:
                return False, None
            frame = np.full((100, 100, 3), self.index, dtype=np.uint8)
            self.index += 1
            return True, frame

        def release(self):
            pass

    def person(x1, x2):
        return {
            'bbox': np.array([x1, 10, x2, 90], dtype=np.float32),
            'keypoints': np.tile(np.array([(x1 + x2) / 2, 50], dtype=np.float32), (17, 1)),
        }

    people = [person(10, 40), person(60, 90)]
    monkeypatch.setattr(pipeline.cv2, 'VideoCapture', lambda _path: Capture())
    worker = pipeline.DancePipeline.__new__(pipeline.DancePipeline)
    worker.config = SimpleNamespace(analyze_skip=4, track_match_iou=0.35, track_ttl_sec=1)
    worker.pose = SimpleNamespace(run_pose_on_frame=lambda frame:
        people if int(frame[0, 0, 0]) < 40 else people[:1])
    worker.face = SimpleNamespace(detect_face_boxes=lambda _frame: [])

    records, _, _ = worker.analyze_video_to_records('video.mp4')
    groups = pipeline.smooth_group_segments(
        pipeline.build_raw_group_segments(records), min_group_seg_sec=1.2, merge_gap_sec=0.8)

    assert len(groups) == 1
    assert groups[0].start == pytest.approx(8 / 24)
    assert groups[0].end == pytest.approx(48 / 24)


def test_pose_engine_keeps_measured_head_confidence():
    from dance_highlight.services.pose_engine import PoseEngine
    class Tensor:
        def __init__(self, value): self.value=np.array(value)
        def cpu(self): return self
        def numpy(self): return self.value
    kp=np.zeros((1,17,2),dtype=np.float32)
    scores=np.linspace(.1,.9,17,dtype=np.float32).reshape(1,17)
    result=SimpleNamespace(boxes=SimpleNamespace(xyxy=Tensor([[0,0,100,100]])),
                           keypoints=SimpleNamespace(xy=Tensor(kp),conf=Tensor(scores)))
    engine=PoseEngine.__new__(PoseEngine)
    engine._model=lambda *_args,**_kwargs: [result]
    engine.config=SimpleNamespace(yolo_device='cpu',resolved_yolo_half=lambda:False,yolo_conf=.25,yolo_iou=.7)
    person=engine.run_pose_on_frame(np.zeros((100,100,3)))[0]
    np.testing.assert_allclose(person['head_keypoints'][:,2],scores[0,:5])
    assert person['head_keypoints'].shape==(5,3)
    np.testing.assert_allclose(person['pose_keypoints'][:,2],scores[0])
    assert person['pose_keypoints'].shape==(17,3)
