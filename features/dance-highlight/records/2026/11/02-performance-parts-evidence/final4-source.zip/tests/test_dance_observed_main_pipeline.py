from dataclasses import replace
import numpy as np
import pytest
from dance_highlight.services.segment import FrameRec
from dance_highlight.services.config import DanceConfig
from dance_highlight.services.pipeline import DancePipeline
from dance_highlight.services.reference_matcher import ReferenceEmbeddingSample


@pytest.mark.parametrize('registered',[False,True])
def test_observed_main_precedes_face_evidence_only_for_registered_dance(tmp_path,monkeypatch,registered):
    from dance_highlight.services import observed_main
    a=np.array([0.,0.,100.,300.]);b=a+[200.,0.,200.,0.]
    records=[FrameRec(i/10,1,a,False,person_bboxes=[a,b]) for i in range(61)]
    called=[]
    def refine(rows,*args,**kwargs):
        called.append(True)
        return [replace(r,main_bbox=b,main_id=2) for r in rows],dict(version='observed_main_geometry_v1',reason='complete')
    monkeypatch.setattr(observed_main,'refine_main_roles',refine)
    class ReachedFace(Exception):pass
    class Face:
        def batch_segment_embeddings(self,source,segments,**kwargs):
            expected=b if registered else a
            assert segments and all(np.array_equal(box,expected) for s in segments for _,box,_ in s.bboxes)
            assert all(np.array_equal(r.main_bbox,expected) for r in kwargs['frame_records'])
            raise ReachedFace
    pipe=DancePipeline(DanceConfig(),None,Face(),None,None)
    pipe.analyze_video_to_records=lambda *a,**k:(records,10.,6.1)
    pipe._download_reference_images=lambda *a:{}
    def refs(paths,sample_sink):
        if registered:sample_sink.append(ReferenceEmbeddingSample('A','A','a'*64,100,100,np.array([1.,0.])))
        return {}
    pipe._build_reference_embeddings=refs
    pipe._video_size=lambda *_:(640,480)
    source=tmp_path/'source.mp4';source.write_bytes(b'source')
    with pytest.raises(ReachedFace):pipe.run(tmp_path,source,1)
    assert bool(called)==registered


@pytest.mark.parametrize('registered',[False,True])
def test_separate_scene_observations_do_not_replace_identity_input(tmp_path,monkeypatch,registered):
    from dance_highlight.services import observed_main,native_scene
    body=np.array([100.,100.,180.,250.]);records=[FrameRec(i/10,1,body,False,person_bboxes=[body]) for i in range(61)]
    monkeypatch.setattr(observed_main,'refine_main_roles',lambda rows,*a,**k:(rows,dict(reason='complete',cut_frames=[])))
    scene_calls=[]
    def scene(rows,*args,**kwargs):
        scene_calls.append(rows)
        return [replace(r,main_id=None,main_bbox=None,is_group=True,scene_kind='group',group_bboxes=[body]) for r in rows],dict(version=native_scene.VERSION,reason='complete',changes=[dict(frame=0)])
    monkeypatch.setattr(native_scene,'refine_native_scenes',scene)
    class ReachedFace(Exception):pass
    class Face:
        def batch_segment_embeddings(self,source,segments,**kwargs):
            assert segments and all(np.array_equal(box,body) for s in segments for _,box,_ in s.bboxes)
            assert all(r.main_id==1 and not r.is_group for r in kwargs['frame_records'])
            raise ReachedFace
    pipe=DancePipeline(DanceConfig(),None,Face(),None,None)
    pipe.analyze_video_to_records=lambda *a,**k:(records,10.,6.1)
    pipe._download_reference_images=lambda *a:{}
    def refs(paths,sample_sink):
        if registered:sample_sink.append(ReferenceEmbeddingSample('A','A','a'*64,100,100,np.array([1.,0.])))
        return {}
    pipe._build_reference_embeddings=refs;pipe._video_size=lambda *_:(640,480)
    source=tmp_path/'source.mp4';source.write_bytes(b'source')
    with pytest.raises(ReachedFace):pipe.run(tmp_path,source,1)
    assert bool(scene_calls)==registered
