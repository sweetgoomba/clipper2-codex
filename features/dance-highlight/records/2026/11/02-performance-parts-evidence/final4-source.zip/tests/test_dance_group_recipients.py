"""Together clips belong only to members confirmed in that clip."""

from types import SimpleNamespace

import numpy as np

from dance_highlight.services import pipeline
from dance_highlight.services.reference_matcher import SegmentReferenceDecision
from dance_highlight.services import segment
from dance_highlight.services.segment import Segment


def _seg(kind: str, start: float, end: float) -> Segment:
    return Segment(kind, None, start, end, [])


def _matched(member: str, distance: float) -> SegmentReferenceDecision:
    return SegmentReferenceDecision(member, "matched", "supported_reference", distance)


def test_group_recipients_require_repeated_faces_or_a_matched_overlapping_main():
    result = pipeline.confirmed_group_recipients(
        [_seg("group", 2.0, 4.0)],
        [_seg("main", 2.1, 3.9), _seg("main", 4.1, 5.0)],
        [_matched("D", 0.3), _matched("E", 0.2)],
        [
            (0, 2.2, _matched("A", 0.52)),
            (0, 2.2, _matched("A", 0.51)),
            (0, 2.8, _matched("A", 0.54)),
            (0, 3.2, _matched("B", 0.48)),
            (0, 3.4, _matched("C", 0.58)),
            (0, 3.8, _matched("C", 0.59)),
        ],
    )
    assert result == (("A", "D"),)


def test_group_without_identity_evidence_stays_unassigned():
    result = pipeline.confirmed_group_recipients(
        [_seg("group", 1.0, 2.0)],
        [_seg("main", 1.8, 2.2)],
        [_matched("A", 0.3)],
        [(0, 1.2, SegmentReferenceDecision(None, "unmatched", "distance_exceeded"))],
    )
    assert result == ((),)


def test_group_face_sampling_reads_selected_participant_frames(monkeypatch):
    class Capture:
        index = 0

        def isOpened(self): return True
        def get(self, _prop): return 10.0
        def read(self):
            image = np.full((20, 20, 3), self.index, dtype=np.uint8)
            self.index += 1
            return True, image
        def grab(self):
            self.index += 1
            return True
        def release(self): pass

    monkeypatch.setattr(pipeline.cv2, "VideoCapture", lambda _path: Capture())
    worker = pipeline.DancePipeline.__new__(pipeline.DancePipeline)
    worker.face = SimpleNamespace(group_face_embeddings=lambda frame, _boxes: [
        np.asarray([float(frame[0, 0, 0]), 1.0], dtype=np.float32)
    ])
    box = np.asarray([0, 0, 20, 20], dtype=np.float32)
    recs = [SimpleNamespace(t=t, is_group=True, group_bboxes=[box]) for t in (1.0, 1.2, 1.4)]

    samples = worker._collect_group_face_samples("fake.mp4", [_seg("group", 1, 1.5)], recs)

    assert [(group, t, emb[0]) for group, t, emb in samples] == [
        (0, 1.0, 10.0), (0, 1.2, 12.0), (0, 1.4, 14.0),
    ]


def test_group_selector_remembers_prominent_participant_boxes(monkeypatch):
    monkeypatch.setattr(segment, "main_score", lambda person, *_: person["rank"])
    selector = segment.MainSelector(fps=10)
    selector.group_state = True
    persons = [
        {"bbox": np.asarray([0, 0, 50, 80]), "rank": 0.9},
        {"bbox": np.asarray([50, 0, 100, 80]), "rank": 0.85},
        {"bbox": np.asarray([100, 0, 105, 20]), "rank": 0.1},
    ]
    selector.select(persons, (100, 120, 3))
    assert len(selector.last_group_member_bboxes) == 2
