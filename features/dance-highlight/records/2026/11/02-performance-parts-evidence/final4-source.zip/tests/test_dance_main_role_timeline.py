"""Temporal role tests: synthetic bodies, independent from identity labels."""
from dance_highlight.services.main_role_timeline import choose_roles,extend_near_ties


def rows_at(times,values):
 return [dict(frame=round(t*1000),time=t,features=[dict(index=i,box=[i,0,i+1,1],x=.5,size=s,source='detected') for i,s in enumerate(pair)]) for t,pair in zip(times,values)]


def corresponding(row,person,other):
 return next((p for p in other['features'] if p['index']==person['index']),None)


def select(rows,cuts=()):
 old={r['frame']:dict(candidate_main_bbox=[0,0,1,1]) for r in rows}
 choose_roles(rows,old,1,1,cuts,corresponding)
 return [r['index'] for r in rows]


def test_small_single_observation_advantage_does_not_swap_main():
 rows=rows_at([0,.1,.2,.3,.4],[(1,.9),(1,.9),(1,1.04),(1,.9),(1,.9)])
 assert select(rows)==[0]*5


def test_dominance_threshold_oscillation_does_not_make_an_extra_part():
 rows=rows_at([0,.1,.2,.3,.4],[(1,.9),(1,.9),(1,1.31),(1,.9),(1,.9)])
 assert select(rows)==[0]*5


def test_sustained_handoff_is_assigned_at_first_supported_observation():
 rows=rows_at([0,.1,.2,.3,.4,.5],[(1,.9),(1,.9),(1,1.1),(1,1.1),(1,1.1),(1,1.1)])
 assert select(rows)==[0,0,1,1,1,1]


def test_camera_cut_can_select_new_main_immediately():
 rows=rows_at([0,.1,.2],[(1,.9),(1,1.1),(1,1.1)])
 assert select(rows,[100])==[0,1,1]


def test_missing_incumbent_face_does_not_mean_other_person_is_main():
 rows=rows_at([0,.1,.2,.3],[(1,.9),(None,.9),(None,.9),(1,.9)])
 assert select(rows)==[0]*4


def test_camera_cut_does_not_preserve_an_unmeasured_old_incumbent_over_current_subject():
 rows=rows_at([0,.1,.2],[(1,.9),(None,1.),(None,1.)])
 assert select(rows,[100])==[0,1,1]


def test_later_handoff_cannot_relabel_earlier_missing_incumbent_as_near_tie():
 rows=rows_at([0,.1,.2,.3,.4,.5],[(1,.9),(None,.9),(None,.9),(1,1.2),(1,1.2),(1,1.2)])
 assert select(rows)==[0,0,0,1,1,1]
 extend_near_ties(rows,[],corresponding)
 assert [r['index'] for r in rows]==[0,0,0,1,1,1]


def test_near_tie_extension_never_crosses_unobserved_gap_or_cut():
 for times,cuts in [([0,.233,.433],[]),([0,.1,.3],[50])]:
  rows=rows_at(times,[(1,.99),(1,1.1),(1,1.1)])
  for r,i in zip(rows,[0,1,1]):
   r.update(index=i,box=r['features'][i]['box'],reason='composition')
   for f in r['features']:f['score']=f['size']
  extend_near_ties(rows,cuts,corresponding)
  assert rows[0]['index']==0


def test_unique_close_foreground_face_can_remain_main_near_frame_edge():
 rows=rows_at([0,.1,.2],[(2.,1.),(2.,1.),(2.,1.)])
 for r in rows:
  r['features'][0].update(x=.15,cropped_foreground=True)
 assert select(rows)==[0,0,0]


def test_off_center_full_body_does_not_get_close_foreground_override():
 rows=rows_at([0,.1,.2],[(1.4,1.),(1.4,1.),(1.4,1.)])
 for r in rows:
  r['features'][0].update(x=.15,cropped_foreground=False)
 assert select(rows)==[1,1,1]


def test_mature_pending_handoff_is_backfilled_when_legacy_selection_catches_up():
 rows=rows_at([0,.0667,.1334,.2001,.2668],[(1,.9),(1,1.5),(1,1.5),(1,1.5),(1,1.5)])
 old={r['frame']:dict(candidate_main_bbox=rows[0]['features'][0]['box']) for r in rows}
 old[rows[-1]['frame']]['candidate_main_bbox']=rows[-1]['features'][1]['box']
 def follow(row,person,other):
  if other is rows[-1] and person['index']==0:return None
  return corresponding(row,person,other)
 choose_roles(rows,old,1,1,[],follow)
 assert [r['index'] for r in rows]==[0,1,1,1,1]
