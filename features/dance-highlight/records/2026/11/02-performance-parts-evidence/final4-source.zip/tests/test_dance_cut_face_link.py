import numpy as np
import pytest
from dance_highlight.services.cut_face_link import mutual_face_match, scaled_head_link


def test_cross_cut_requires_both_models_and_bilateral_unique_competition():
    first=np.array([[.8,.25],[.2,.8]])
    second=np.array([[.7,.3],[.3,.7]])
    result=mutual_face_match(first,second,0,1)
    assert result['accepted']
    assert result['primary_distance']==pytest.approx(.25)


@pytest.mark.parametrize('first,second,reason',[
    ([[.1,.25],[.7,.8]],[[.8,.3],[.7,.8]],'competing_face'),
    ([[.8,.25],[.7,.26]],[[.8,.3],[.7,.31]],'ambiguous_face'),
    ([[.8,.25],[.7,.8]],[[.8,.36],[.7,.8]],'weak_face_match'),
    ([[.8,.25],[.7,.8]],[[.3,.3],[.7,.8]],'ambiguous_face'),
    ([[.8,float('nan')],[.7,.8]],[[.8,.3],[.7,.8]],'invalid_face_distances'),
])
def test_weak_or_disagreeing_cross_cut_faces_do_not_link(first,second,reason):
    result=mutual_face_match(np.array(first),np.array(second),0,1)
    assert not result['accepted']
    assert result['reason']==reason


def test_single_visible_face_still_needs_both_absolute_thresholds():
    assert mutual_face_match(np.array([[.2]]),np.array([[.3]]),0,0)['accepted']
    assert not mutual_face_match(np.array([[.2]]),np.array([[.5]]),0,0)['accepted']


def test_fixed_body_overlay_cannot_replace_actual_head_correspondence():
    rng=np.random.default_rng(40)
    old=rng.integers(0,255,(320,320,3),dtype=np.uint8)
    new=rng.integers(0,255,(320,320,3),dtype=np.uint8)
    new[180:230,110:210]=old[180:230,110:210]
    mask=np.ones((320,320),bool)
    assert not scaled_head_link(old,new,mask,mask,(100,30,180,110),(100,30,180,110))['accepted']


def test_same_face_pixels_pass_but_missing_or_outside_mask_faces_do_not():
    import cv2
    rng=np.random.default_rng(14)
    im=cv2.GaussianBlur(rng.integers(0,255,(320,320,3),dtype=np.uint8),(3,3),0)
    mask=np.ones((320,320),bool);box=(100,30,180,110)
    assert scaled_head_link(im,im,mask,mask,box,box)['accepted']
    assert not scaled_head_link(im,im,mask,np.zeros_like(mask),box,box)['accepted']
    assert not scaled_head_link(im,im,mask,mask,None,box)['accepted']


def test_full_face_link_rejects_fixed_overlay_even_when_models_agree():
    from dance_highlight.services.cut_face_link import CutFaceLink
    rng=np.random.default_rng(40)
    old=rng.integers(0,255,(320,320,3),dtype=np.uint8)
    new=rng.integers(0,255,(320,320,3),dtype=np.uint8)
    new[180:230,110:210]=old[180:230,110:210]
    mask=np.ones((320,320),bool)
    linker=CutFaceLink.__new__(CutFaceLink)
    face=dict(points=np.array([[120,40],[150,40],[130,60],[120,80],[150,80]]),
              box=np.array([100,30,180,110]),primary=np.array([1.,0.]),secondary=np.array([1.,0.]))
    linker._faces=lambda *args:[face]
    assert not linker(old,new,mask,mask,0,1)['accepted']
    assert not linker(old,old,mask,mask,0,4)['accepted']
    linker._faces=lambda *args:[face,face]
    assert not linker(old,old,mask,mask,0,1)['accepted']


@pytest.mark.parametrize('reverse',[False,True])
def test_tracker_uses_actual_consecutive_cut_frames_without_inventing_poses(monkeypatch,reverse):
    from dance_highlight.services import mask_tracker as module
    from dance_highlight.services.face_evidence import FaceObservation
    from dance_highlight.services.segment import FrameRec
    image=np.zeros((100,100,3),np.uint8);mask=np.ones((100,100),bool)
    box=np.array([10.,10.,90.,90.]);head=np.array([[30.,20.,.9],[50.,20.,.9]])
    frames=[8,4,0] if reverse else [0,4,8]
    records=[FrameRec(i/20.,1,box,False,person_bboxes=[box],person_head_keypoints=[head]) for i in frames]
    anchor=FaceObservation(frames[0],frames[0]/20.,1,tuple(box),tuple(box),face_bbox=(20.,10.,60.,30.))
    tracker=module.MaskTracker.__new__(module.MaskTracker);tracker.source='unused';tracker.fps=20.;tracker.on_progress=None
    class Capture:
        def __init__(self,*args):pass
        def isOpened(self):return True
        def get(self,prop):return 20.
        def release(self):pass
    monkeypatch.setattr(module.cv2,'VideoCapture',Capture)
    tracker._cuts=lambda *args: {3}
    observed=[]
    def masks(cap,rows,**kwargs):
        for r in rows:
            f=round(r.t*20)
            if f in (2,3):
                assert r.person_head_keypoints==[] and r.person_pose_keypoints==[] and r.main_bbox is None
            yield f,image,mask
    tracker._masks=masks
    tracker._link_cut_faces=lambda old,new,om,nm,of,nf: observed.append((of,nf)) or dict(accepted=True)
    result=tracker(anchor,records,frames[1:])
    assert result['accepted'],result
    assert observed==([(3,2)] if reverse else [(2,3)])


@pytest.mark.parametrize('competitor_inside_mask',[False,True])
def test_invalid_competitor_embedding_is_not_silently_removed(competitor_inside_mask):
    import cv2
    from dance_highlight.services.cut_face_link import CutFaceLink
    linker=CutFaceLink.__new__(CutFaceLink);linker.cache={};linker.minimum_score=.28
    one=np.array([100,30,80,80,120,40,150,40,130,60,120,80,150,80,.99])
    two=one.copy();two[[0,4,6,8,10,12]]+=100
    class Detector:
        def setInputSize(self,*args):pass
        def detect(self,*args):return None,np.array([one,two])
    class Recognizer:
        def alignCrop(self,image,face):return face
        def feature(self,face):return np.array([1.,0.]) if face[0]<190 else np.array([np.nan,0.])
    linker.detector=Detector();linker.primary=Recognizer();linker.secondary=Recognizer()
    rng=np.random.default_rng(14);im=cv2.GaussianBlur(rng.integers(0,255,(320,320,3),dtype=np.uint8),(3,3),0)
    mask=np.ones((320,320),bool)
    if not competitor_inside_mask:mask[:,190:]=False
    result=linker(im,im,mask,mask,0,1)
    assert not result['accepted'],result


def cut_face(x=100,vector=(1.,0.)):
    return dict(points=np.array([[x+20,40],[x+50,40],[x+30,60],[x+20,80],[x+50,80]]),
                box=np.array([x,30,x+80,110]),primary=np.array(vector),secondary=np.array(vector),rotation=0.)


def test_missing_owned_face_retries_both_rotations_and_keeps_competitors(monkeypatch):
    from dance_highlight.services import cut_face_link as module
    linker=module.CutFaceLink.__new__(module.CutFaceLink);linker.cache={}
    target,other=cut_face(),cut_face(210,(0.,1.));calls=[]
    def faces(image,frame,rotation=0):
        calls.append((frame,rotation))
        return [other] if rotation==0 else [target,other]
    linker._faces=faces
    monkeypatch.setattr(module,'scaled_head_link',lambda *a:dict(accepted=True))
    image=np.zeros((320,320,3),np.uint8);mask=np.zeros((320,320),bool);mask[:,:190]=True
    result=linker(image,image,mask,mask,0,1)
    assert result['accepted'],result
    assert result['source_face_count']==result['target_face_count']==2
    assert {(f,a) for f,a in calls if a}=={(0,-30.),(0,30.),(1,-30.),(1,30.)}


def test_expansion_does_not_drop_a_failed_original_competitor(monkeypatch):
    from dance_highlight.services import cut_face_link as module
    linker=module.CutFaceLink.__new__(module.CutFaceLink);linker.cache={}
    target,other=cut_face(),cut_face(210,(0.,1.));invalid=dict(other,primary=None)
    linker._faces=lambda image,frame,rotation=0:[invalid] if rotation==0 else [target,other]
    monkeypatch.setattr(module,'scaled_head_link',lambda *a:dict(accepted=True))
    image=np.zeros((320,320,3),np.uint8);mask=np.zeros((320,320),bool);mask[:,:190]=True
    result=linker(image,image,mask,mask,0,1)
    assert not result['accepted']
    assert result['reason']=='incomplete_face_comparison'


def test_new_distinct_face_inside_mask_cannot_be_merged_as_duplicate(monkeypatch):
    from dance_highlight.services import cut_face_link as module
    linker=module.CutFaceLink.__new__(module.CutFaceLink);linker.cache={}
    a,b=cut_face(),cut_face(130,(0.,1.))
    linker._faces=lambda image,frame,rotation=0:[] if rotation==0 else [a,b]
    monkeypatch.setattr(module,'scaled_head_link',lambda *a:dict(accepted=True))
    im=np.zeros((320,320,3),np.uint8);mask=np.ones((320,320),bool)
    result=linker(im,im,mask,mask,0,1)
    assert not result['accepted']
    assert result['reason']=='unconfirmed_unique_mask_face'


def test_existing_unique_owned_faces_do_not_run_rotation(monkeypatch):
    from dance_highlight.services import cut_face_link as module
    linker=module.CutFaceLink.__new__(module.CutFaceLink);linker.cache={}
    def faces(image,frame,rotation=0):
        assert rotation==0
        return [cut_face()]
    linker._faces=faces
    monkeypatch.setattr(module,'scaled_head_link',lambda *a:dict(accepted=True))
    image=np.zeros((320,320,3),np.uint8);mask=np.ones((320,320),bool)
    assert linker(image,image,mask,mask,0,1)['accepted']


def test_rotated_detection_features_are_aligned_from_original_source_pixels():
    import cv2
    from dance_highlight.services.cut_face_link import CutFaceLink
    linker=CutFaceLink.__new__(CutFaceLink);linker.cache={};linker.minimum_score=.28
    image=np.zeros((320,320,3),np.uint8);image[15:25,20:30]=255
    points=np.array([[120.,40.],[150.,40.],[130.,60.],[120.,80.],[150.,80.]])
    matrix=cv2.getRotationMatrix2D((160.,160.),-30.,1.)
    rotated=cv2.transform(points[None],matrix)[0];lo=rotated.min(axis=0)-10;hi=rotated.max(axis=0)+10
    face=np.r_[lo,hi-lo,rotated.ravel(),.99].astype(np.float32)
    class Detector:
        def setInputSize(self,*args):pass
        def detect(self,im):
            assert not np.array_equal(im,image)
            return None,np.array([face])
    class Recognizer:
        def alignCrop(self,im,value):
            assert im is image
            np.testing.assert_allclose(value[4:14].reshape(5,2),points,atol=.001)
            return im
        def feature(self,im):return np.array([1.,0.])
    linker.detector=Detector();linker.primary=Recognizer();linker.secondary=Recognizer()
    rows=linker._faces(image,0,rotation=-30.)
    assert len(rows)==1
    np.testing.assert_allclose(rows[0]['points'],points,atol=1)


def test_later_candidate_masks_cannot_forget_already_discovered_faces(monkeypatch):
    from dance_highlight.services import cut_face_link as module
    linker=module.CutFaceLink.__new__(module.CutFaceLink);linker.cache={}
    a,b=cut_face(),cut_face(210,(0.,1.))
    linker._faces=lambda image,frame,rotation=0:[a] if rotation==0 else [a,b]
    monkeypatch.setattr(module,'scaled_head_link',lambda *a:dict(accepted=True))
    im=np.zeros((320,320,3),np.uint8);all_people=np.ones((320,320),bool)
    only_rotated=np.zeros((320,320),bool);only_rotated[:,190:]=True
    assert not linker(im,im,all_people,only_rotated,0,1)['accepted']
    result=linker(im,im,all_people,all_people,0,1)
    assert not result['accepted'],result
    assert result['reason']=='unconfirmed_unique_mask_face'


@pytest.mark.parametrize('score,competing,want', [(.89,False,True),(.27,False,False),(.99,True,False)])
def test_cut_link_keeps_detector_candidates_for_ownership_and_face_competition(score,competing,want):
    import cv2
    from dance_highlight.services.cut_face_link import CutFaceLink
    linker=CutFaceLink.__new__(CutFaceLink);linker.cache={};linker.minimum_score=.28
    target=np.array([100,30,80,80,120,40,150,40,130,60,120,80,150,80,score])
    other=target.copy();other[[0,4,6,8,10,12]]+=100;other[-1]=.85
    class Detector:
        def setInputSize(self,*args):pass
        def detect(self,*args):return None,np.array([target,other] if competing else [target])
    class Recognizer:
        def alignCrop(self,image,face):return face
        def feature(self,face):return np.array([1.,0.]) if face[0]<190 else np.array([.98,.2])
    linker.detector=Detector();linker.primary=Recognizer();linker.secondary=Recognizer()
    rng=np.random.default_rng(14)
    image=cv2.GaussianBlur(rng.integers(0,255,(320,320,3),dtype=np.uint8),(3,3),0)
    mask=np.zeros((320,320),bool);mask[:,:190]=True
    result=linker(image,image,mask,mask,0,1)
    assert result['accepted'] is want, result
    if competing:assert result['reason']=='ambiguous_face'
