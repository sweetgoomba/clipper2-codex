import cv2
import numpy as np
import pytest

from dance_highlight.services.sampled_face_link import normalized_head_link, sampled_face_match


def scene(seed=12):
    rng=np.random.default_rng(seed)
    image=cv2.GaussianBlur(rng.integers(0,256,(400,600,3),dtype=np.uint8),(3,3),0)
    mask=np.zeros((400,600),bool);mask[20:380,120:360]=True
    return image,mask,np.array([180.,40.,280.,140.])


def test_same_head_uses_the_same_pixel_support_at_different_native_sizes():
    old,mask,face=scene();matrix=np.float32([[.6,0,150],[0,.6,35]])
    new=cv2.warpAffine(old,matrix,(600,400));nm=cv2.warpAffine(mask.astype(np.uint8),matrix,(600,400)).astype(bool)
    nf=face*.6+[150,35,150,35]
    for args in [(old,new,mask,nm,face,nf),(new,old,nm,mask,nf,face)]:
        proof=normalized_head_link(*args)
        assert proof['accepted'],proof
        assert proof['size']==60


def test_actual_face_replacement_cannot_be_hidden_by_the_surrounding_hair():
    old,mask,face=scene();matrix=np.float32([[1,0,40],[0,1,15]])
    new=cv2.warpAffine(old,matrix,(600,400));nf=face+[40,15,40,15]
    x,y,xx,yy=nf.astype(int);new[y:yy,x:xx]=scene(51)[0][y:yy,x:xx]
    nm=cv2.warpAffine(mask.astype(np.uint8),matrix,(600,400)).astype(bool)
    assert not normalized_head_link(old,new,mask,nm,face,nf)['accepted']


def test_same_body_overlay_does_not_supply_face_pixels():
    old,mask,face=scene();new=scene(15)[0];new[170:300,150:330]=old[170:300,150:330]
    assert not normalized_head_link(old,new,mask,mask,face,face)['accepted']


def test_pixels_need_native_detail_valid_geometry_and_mask_ownership():
    old,mask,face=scene()
    for a,b,am,bm in [(None,face,mask,mask),(face,[1,1,10,10],mask,mask),
                       (face,face,mask,np.zeros_like(mask)),([1,1,float('nan'),30],face,mask,mask)]:
        assert not normalized_head_link(old,old,am,bm,a,b)['accepted']


def test_sampled_models_require_full_matrix_competition_and_both_absolute_limits():
    a=np.array([[.9,.52],[.2,.9]]);b=np.array([[.8,.39],[.3,.8]])
    assert sampled_face_match(a,b,0,1)['accepted']
    for aa,bb in [(np.array([[.4,.52],[.2,.9]]),b),
                  (a,np.array([[.8,.39],[.3,.4]])),
                  (np.array([[.9,.61],[.2,.9]]),b),
                  (np.array([[.9,.55],[.2,.9]]),np.array([[.8,.55],[.3,.8]])),
                  (np.array([[.9,np.nan],[.2,.9]]),b)]:
        assert not sampled_face_match(aa,bb,0,1)['accepted']


@pytest.mark.parametrize('reverse',[False,True])
@pytest.mark.parametrize('head_pass',[False,True])
def test_missing_exact_face_waits_only_for_the_next_original_pose_sample(monkeypatch,reverse,head_pass):
    from dance_highlight.services import mask_tracker as module
    from dance_highlight.services.face_evidence import FaceObservation
    from dance_highlight.services.segment import FrameRec
    image=np.zeros((100,100,3),np.uint8);mask=np.ones((100,100),bool)
    box=np.array([10.,10.,90.,90.]);head=np.array([[30.,20.,.9],[50.,20.,.9]])
    frames=[8,4,0] if reverse else [0,4,8]
    records=[FrameRec(i/20.,1,box,False,person_bboxes=[box],person_head_keypoints=[head]) for i in frames]
    anchor=FaceObservation(frames[0],frames[0]/20.,1,tuple(box),tuple(box),face_bbox=(20.,10.,60.,30.))
    tracker=module.MaskTracker.__new__(module.MaskTracker);tracker.source='unused';tracker.fps=20.;tracker.on_progress=None
    class Capture:
        def __init__(self,*args):pass
        def isOpened(self):return True
        def get(self,prop):return 20.
        def release(self):pass
    monkeypatch.setattr(module.cv2,'VideoCapture',Capture)
    tracker._cuts=lambda *args:{3}
    tracker._masks=lambda cap,rows,**kwargs:((round(r.t*20),image,mask) for r in rows)
    tracker._link_cut_faces=lambda *args:dict(accepted=False,reason='unconfirmed_unique_mask_face',owner_counts=[1,0])
    calls=[]
    def sampled(old,new):
        calls.append((old[0],new[0]))
        assert old[3].person_head_keypoints and new[3].person_head_keypoints
        return dict(accepted=head_pass,reason='test_head')
    tracker._link_sampled_heads=sampled
    result=tracker(anchor,records,frames[1:])
    assert calls==([(4,0)] if reverse else [(0,4)])
    assert result['accepted']==head_pass,result
    if head_pass:
        camera=result['camera'][0]
        assert camera['evidence_frames']==list(calls[0])
        assert {camera['from_frame'],camera['to_frame']}=={2,3}
        assert not camera['exact_rejection']['accepted']


@pytest.mark.parametrize('reason,counts',[('unconfirmed_unique_mask_face',[2,0]),('weak_face_match',[1,1]),('competing_face',[1,1])])
def test_head_fallback_does_not_bypass_multiple_or_conflicting_cut_faces(monkeypatch,reason,counts):
    from dance_highlight.services.mask_tracker import permits_sampled_head_link
    assert not permits_sampled_head_link(dict(accepted=False,reason=reason,owner_counts=counts))


def test_missing_owner_cannot_hide_an_existing_failed_face_embedding():
    from dance_highlight.services.cut_face_link import CutFaceLink
    from dance_highlight.services.mask_tracker import permits_sampled_head_link
    linker=CutFaceLink.__new__(CutFaceLink);linker.cache={}
    points=np.array([[30,30],[50,30],[40,40],[30,50],[50,50]])
    invalid=dict(points=points,box=np.array([20,20,60,60]),primary=None,secondary=np.array([1.,0.]))
    other=dict(points=points+[200,0],box=np.array([220,20,260,60]),primary=np.array([1.,0.]),secondary=np.array([1.,0.]))
    linker._faces=lambda image,frame:[invalid] if frame==0 else [other]
    linker._expanded_faces=lambda image,frame,rows:rows
    image=np.zeros((320,320,3),np.uint8);mask=np.zeros((320,320),bool);mask[:,:180]=True
    proof=linker(image,image,mask,mask,0,1)
    assert not permits_sampled_head_link(proof),proof
    assert proof['reason']=='incomplete_face_comparison'


def test_landmark_alignment_preserves_face_pixels_across_roll_and_zoom():
    from dance_highlight.services.sampled_face_link import landmark_head_link
    old,mask,face=scene()
    landmarks=np.float32([[205,75],[255,75],[230,95],[210,120],[250,120]])
    matrix=cv2.getRotationMatrix2D((230,90),28,.7);matrix[:,2]+=[130,30]
    new=cv2.warpAffine(old,matrix,(600,400));nm=cv2.warpAffine(mask.astype(np.uint8),matrix,(600,400)).astype(bool)
    points=cv2.transform(landmarks[None],matrix)[0]
    corners=cv2.transform(np.float32([[[180,40],[280,40],[280,140],[180,140]]]),matrix)[0]
    nf=np.r_[corners.min(axis=0),corners.max(axis=0)]
    for args in [(old,new,mask,nm,face,nf,landmarks,points),(new,old,nm,mask,nf,face,points,landmarks)]:
        proof=landmark_head_link(*args)
        assert proof['accepted'],proof
    x,y,xx,yy=np.round(nf).astype(int)
    new[y:yy,x:xx]=scene(61)[0][y:yy,x:xx]
    assert not landmark_head_link(old,new,mask,nm,face,nf,landmarks,points)['accepted']


def test_landmark_alignment_rejects_degenerate_or_outside_face_points():
    from dance_highlight.services.sampled_face_link import landmark_head_link
    image,mask,face=scene();valid=np.float32([[205,75],[255,75],[230,95],[210,120],[250,120]])
    for points in (np.full((5,2),np.nan),np.tile([230.,90.],(5,1)),valid+[300,0],valid[:3]):
        assert not landmark_head_link(image,image,mask,mask,face,face,valid,points)['accepted']


@pytest.mark.parametrize('sparse_mask',[False,True])
def test_small_common_interior_patch_cannot_certify_the_whole_face(sparse_mask):
    old=np.full((160,160,3),50,np.uint8);new=np.full_like(old,150)
    patch=np.random.default_rng(17).integers(0,256,(30,30,3),dtype=np.uint8)
    old[65:95,65:95]=patch;new[65:95,65:95]=patch
    if not sparse_mask:
        new[:]=old
    mask=np.ones((160,160),bool)
    if sparse_mask:
        mask[:]=False;mask[67:93,67:93]=True
    proof=normalized_head_link(old,new,mask,mask,[30,30,130,130],[30,30,130,130])
    assert not proof['accepted'],proof


def sampled_link_fixture():
    from dance_highlight.services.sampled_face_link import SampledFaceLink
    from dance_highlight.services.segment import FrameRec
    image,mask,face=scene()
    points=np.float32([[205,75],[255,75],[230,95],[210,120],[250,120]])
    def row(shift,vector):
        return dict(box=face+[shift,0,shift,0],points=(points+[shift,0]).astype(int),
                    landmarks=points+[shift,0],primary=np.array(vector),secondary=np.array(vector))
    rows=[row(0,[1.,0.]),row(260,[0.,1.])]
    bodies=[np.array([120.,20.,360.,380.]),np.array([420.,20.,580.,380.])]
    heads=[np.c_[r['landmarks'][:3],np.ones(3)] for r in rows]
    record=FrameRec(0,1,bodies[0],False,person_bboxes=bodies,person_head_keypoints=heads)
    linker=SampledFaceLink.__new__(SampledFaceLink)
    inventory=[[dict(r) for r in rows],[dict(r) for r in rows]]
    linker._faces=lambda image,frame:inventory[frame]
    return linker,inventory,(0,image,mask,record),(1,image.copy(),mask.copy(),record)


def test_sampled_link_requires_unique_mask_pose_owner_and_all_valid_competitors():
    linker,rows,old,new=sampled_link_fixture()
    assert linker(old,new,0,0)['accepted']
    rows[1][1]['primary']=None
    assert linker(old,new,0,0)['reason']=='incomplete_face_comparison'
    linker,rows,old,new=sampled_link_fixture()
    rows[1][1]['secondary']=np.array([1.,0.])
    assert linker(old,new,0,0)['reason']=='competing_or_ambiguous_sampled_face'
    linker,rows,old,new=sampled_link_fixture()
    new[2][:]=True
    assert linker(old,new,0,0)['reason']=='unconfirmed_sampled_face_ownership'
    linker,rows,old,new=sampled_link_fixture()
    assert linker(old,new,1,1)['reason']=='unconfirmed_sampled_face_ownership'


def test_sampled_link_cannot_pass_replaced_face_with_unchanged_embedding_stubs():
    linker,rows,old,new=sampled_link_fixture()
    new[1][40:140,180:280]=scene(37)[0][40:140,180:280]
    assert linker(old,new,0,0)['reason']=='unconfirmed_face_pixels'
