import numpy as np
from dance_highlight.services.main_face_link import observed_face_target


def person(i,x,cropped=True):
 return dict(index=i,box=[x,0,x+80,200],source='detected',cropped_foreground=cropped,
             head_keypoints=[[x+40,30,.9],[x+30,25,.9],[x+50,25,.9],[x+20,30,.9],[x+60,30,.9]])


def face(x,vector):
 return dict(box=np.array([x+10,10,x+70,80]),points=np.array([[x+30,25],[x+50,25],[x+40,30],[x+32,50],[x+48,50]]),primary=np.array(vector,float),secondary=np.array(vector,float),detector_score=.95)


def fixture():
 a=dict(frame=100,time=1.,features=[person(0,0),person(1,200)])
 b=dict(frame=104,time=1.067,features=[person(0,220),person(1,35)])
 return a,b,[face(0,[1,0]),face(200,[0,1])],[face(220,[0,1]),face(35,[1,0])]


def test_direct_dual_face_can_follow_fast_cropped_body_without_hips():
 a,b,x,y=fixture();target,proof=observed_face_target(a,a['features'][0],b,x,y,[])
 assert target is b['features'][1] and proof['accepted']


def test_other_face_competition_and_failed_competitor_embedding_are_preserved():
 a,b,x,y=fixture();y[0]['primary']=np.array([1,0]);y[0]['secondary']=np.array([1,0])
 assert observed_face_target(a,a['features'][0],b,x,y,[])[0] is None
 a,b,x,y=fixture();y[0]['primary']=None
 assert observed_face_target(a,a['features'][0],b,x,y,[])[0] is None


def test_cut_gap_and_inferred_face_geometry_cannot_use_appearance_fallback():
 a,b,x,y=fixture()
 assert observed_face_target(a,a['features'][0],b,x,y,[102])[0] is None
 b['time']=1.3
 assert observed_face_target(a,a['features'][0],b,x,y,[])[0] is None
 b['time']=1.067;a['features'][0]['source']='repeated_same_pose_geometry'
 assert observed_face_target(a,a['features'][0],b,x,y,[])[0] is None


def test_overlapping_head_ownership_and_distant_matching_face_are_rejected():
 a,b,x,y=fixture();b['features'].append(person(2,35))
 assert observed_face_target(a,a['features'][0],b,x,y,[])[0] is None
 a,b,x,y=fixture();b['features'][1]=person(1,100);y[1]=face(100,[1,0])
 assert observed_face_target(a,a['features'][0],b,x,y,[])[0] is None


def test_another_body_strictly_owns_the_target_so_face_fallback_must_abstain():
 a,b,x,y=fixture()
 def strict(row,person,other):
  return a['features'][1] if row is b and person['index']==1 else None
 target,proof=observed_face_target(a,a['features'][0],b,x,y,[],strict)
 assert target is None and proof['reason']=='conflicting_pose_correspondence'


def test_unobserved_head_overlapping_the_source_or_target_cannot_disappear():
 for side in ('before','after'):
  a,b,x,y=fixture()
  row=a if side=='before' else b
  row['features'].append(dict(index=2,box=[-100,0,180,300],source='missing',head_keypoints=[]))
  target,proof=observed_face_target(a,a['features'][0],b,x,y,[])
  assert target is None and proof['reason']=='unobserved_competing_owner'


def test_existing_forward_pose_match_cannot_be_overridden_by_face_match():
 a,b,x,y=fixture()
 def strict(row,person,other):
  return b['features'][0] if row is a and person['index']==0 else None
 target,proof=observed_face_target(a,a['features'][0],b,x,y,[],strict)
 assert target is None and proof['reason']=='conflicting_pose_correspondence'


def test_low_score_competing_face_still_vetoes_ambiguous_identity():
 a,b,x,y=fixture();y[0]['detector_score']=.3
 y[0]['primary']=np.array([1.,0.]);y[0]['secondary']=np.array([1.,0.])
 target,proof=observed_face_target(a,a['features'][0],b,x,y,[])
 assert target is None and proof['reason']=='unconfirmed_dual_face_competition'


def test_actual_main_face_link_constructs_cut_link_with_existing_models_and_reads_source(tmp_path, monkeypatch):
 from types import SimpleNamespace
 import cv2
 from dance_highlight.services import main_face_link,cut_face_link,face_cluster,face_models
 class Detector:
  calls=0
  def setInputSize(self,size):assert size==(32,24)
  def detect(self,image):
   self.calls+=1
   return None,None
 detector=Detector();primary=object()
 service=SimpleNamespace(_detector=detector,_recognizer=primary,
  config=SimpleNamespace(face_min_det_score=.42),model_provenance={'source':'existing'})
 def unexpected_service(*_):raise AssertionError('must reuse the existing source face models')
 monkeypatch.setattr(face_cluster,'FaceClusterService',unexpected_service)
 monkeypatch.setattr(face_models,'ensure_face_models',lambda **kwargs:{kwargs['specs'][0].name:tmp_path/'secondary.onnx'})
 monkeypatch.setattr(face_models,'read_model_buffer',lambda _:np.zeros(1,np.uint8))
 monkeypatch.setattr(face_models,'sha256_file',lambda _:'secondary-hash')
 monkeypatch.setattr(cut_face_link.cv2,'FaceRecognizerSF',SimpleNamespace(create=lambda *_:object()))
 source=tmp_path/'source.avi';writer=cv2.VideoWriter(str(source),cv2.VideoWriter_fourcc(*'MJPG'),10.,(32,24))
 assert writer.isOpened()
 for value in (0,128):writer.write(np.full((24,32,3),value,np.uint8))
 writer.release()
 link=main_face_link.MainFaceLink(source,service)
 try:
  assert isinstance(link.link,cut_face_link.CutFaceLink)
  assert link.link.detector is detector and link.link.primary is primary
  assert link.link.minimum_score==.42
  assert link.link.provenance['models']==service.model_provenance
  first=link.get(0)
  assert first==[] and link.get(0) is first and detector.calls==1
  assert link.get(1)==[] and detector.calls==2
 finally:link.close()
 assert not link.cap.isOpened()


def test_default_cut_face_link_still_initializes_its_own_models(tmp_path,monkeypatch):
 from types import SimpleNamespace
 from dance_highlight.services import cut_face_link,face_cluster,face_models
 calls=[];service=SimpleNamespace(_detector=object(),_recognizer=object(),
  config=SimpleNamespace(face_min_det_score=.28),model_provenance={})
 monkeypatch.setattr(face_cluster,'FaceClusterService',lambda config:calls.append(config) or service)
 monkeypatch.setattr(face_models,'ensure_face_models',lambda **kwargs:{kwargs['specs'][0].name:tmp_path/'secondary.onnx'})
 monkeypatch.setattr(face_models,'read_model_buffer',lambda _:np.zeros(1,np.uint8))
 monkeypatch.setattr(face_models,'sha256_file',lambda _:'secondary-hash')
 monkeypatch.setattr(cut_face_link.cv2,'FaceRecognizerSF',SimpleNamespace(create=lambda *_:object()))
 link=cut_face_link.CutFaceLink()
 assert len(calls)==1 and link.detector is service._detector
 assert link.primary is service._recognizer and link.minimum_score==.28
