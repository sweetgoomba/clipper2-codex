from types import SimpleNamespace

import cv2
import numpy as np
import pytest

from dance_highlight.services.face_cluster import FaceClusterService
from dance_highlight.services.segment import FrameRec


def scenario():
    body = np.array([20., 10., 140., 190.])
    head = np.array([[80., 65., .99], [65., 50., .99], [95., 70., .99],
                     [45., 45., .9], [115., 80., .9]])
    record = FrameRec(1., 1, body, False, person_bboxes=[body], person_head_keypoints=[head])
    image = np.zeros((200, 160, 3), np.uint8)
    image[40:85, 45:120] = 180
    return image, body, record


class Detector:
    def __init__(self, faces): self.faces, self.calls = iter(faces), 0
    def setInputSize(self, size): pass
    def detect(self, image):
        self.calls += 1
        return None, next(self.faces)


class Recognizer:
    def alignCrop(self, image, face):
        self.image, self.face = image, face
        return np.ones((112,112,3), np.uint8)
    def feature(self, image): return np.array([1.,0.], np.float32)


def service(detector):
    worker = FaceClusterService.__new__(FaceClusterService)
    worker.config = SimpleNamespace(face_min_det_score=.28)
    worker._detector, worker._recognizer = detector, Recognizer()
    return worker


def rotated_detection(score=.95):
    # Eye midpoint is (80,60); measured roll is atan2(20,30).
    return np.array([[40.,30.,80.,60.,60.,50.,100.,50.,80.,65.,65.,75.,95.,75.,score]], np.float32)


def test_weak_face_is_redetected_using_measured_roll_and_aligned_in_source_pixels():
    image, body, record = scenario()
    detector = Detector([None, rotated_detection()]);worker=service(detector)
    candidate, failure = worker._inspect_face(image,source_body=body,pose_record=record,require_pose=True)
    assert failure is None and candidate is not None
    assert detector.calls == 2
    assert candidate.detection_rotation_degrees == pytest.approx(np.degrees(np.arctan2(20.,30.)))
    matrix=cv2.getRotationMatrix2D((80.,60.),candidate.detection_rotation_degrees,1.)
    expected=cv2.transform(rotated_detection()[0,4:14].reshape(1,5,2),cv2.invertAffineTransform(matrix))[0]
    assert np.allclose(candidate.landmarks,expected)
    assert worker._recognizer.image is image  # one source alignment, no double interpolation


@pytest.mark.parametrize('case',['no_pose','uncertain_eye','same_eye','outside_roi','no_roll','ambiguous_body'])
def test_rotation_never_invents_an_unmeasured_head_orientation(case):
    image,body,record=scenario()
    if case=='no_pose':record=None
    elif case=='uncertain_eye':record.person_head_keypoints[0][1,2]=.2
    elif case=='same_eye':record.person_head_keypoints[0][1]=record.person_head_keypoints[0][2]
    elif case=='outside_roi':record.person_head_keypoints[0][1,0]=-10.
    elif case=='no_roll':record.person_head_keypoints[0][1,1]=70.
    elif case=='ambiguous_body':record.person_bboxes.append(body.copy());record.person_head_keypoints.append(record.person_head_keypoints[0].copy())
    detector=Detector([None]);candidate,_=service(detector)._inspect_face(image,source_body=body,pose_record=record,require_pose=True)
    assert candidate is None and detector.calls==1


def test_rotation_does_not_override_a_face_owned_by_two_people():
    image,body,record=scenario()
    record.person_bboxes.append(np.array([140.,10.,159.,190.]))
    record.person_head_keypoints.append(record.person_head_keypoints[0].copy())
    detector=Detector([None,rotated_detection()]);candidate,_=service(detector)._inspect_face(image,source_body=body,pose_record=record,require_pose=True)
    assert candidate is None


def test_confident_original_and_legacy_reference_paths_do_not_rotate():
    image,body,record=scenario();face=rotated_detection()
    for require_pose in [False,True]:
        detector=Detector([face]);candidate,_=service(detector)._inspect_face(image,source_body=body,pose_record=record,require_pose=require_pose)
        assert candidate is not None and detector.calls==1
        assert candidate.detection_rotation_degrees==0.


def test_inverse_axis_aligned_box_cannot_claim_eyes_outside_rotated_detection():
    image = np.zeros((100,100,3),np.uint8)
    body = np.array([20.,10.,80.,95.])
    head = np.array([[50.,50.,0.],[45.669873,52.5,.99],[54.330127,47.5,.99],
                     [40.,50.,0.],[60.,50.,0.]])
    record=FrameRec(1.,1,body,False,person_bboxes=[body],person_head_keypoints=[head])
    # Rotated eyes are (45,50),(55,50), both OUTSIDE the detector's y<=45.
    # The inverse-rotated box's larger AABB happens to contain both eyes.
    face=np.array([[30.,20.,40.,25.,35.,30.,60.,30.,50.,35.,40.,40.,60.,40.,.95]],np.float32)
    detector=Detector([None,face])
    candidate,_=service(detector)._inspect_face(image,source_body=body,pose_record=record,require_pose=True)
    assert candidate is None


def test_rotated_batch_observation_survives_diagnostic_export(monkeypatch, tmp_path):
    """Exercise detection through the real batch/observation/export boundary."""
    import json
    from dance_highlight.services.face_evidence import write_face_evidence
    from dance_highlight.services.segment import Segment

    image, body, record = scenario()
    record.t = 0.
    detector = Detector([None, rotated_detection()])
    worker = service(detector)
    worker.config.face_sample_frames = 1
    worker.config.face_candidate_sample_frames = 1
    monkeypatch.setattr(worker, 'expand_face_roi', lambda *_: (0, 0, 160, 200))

    class Capture:
        def isOpened(self): return True
        def get(self, _): return 30.
        def read(self): return True, image
        def release(self): pass

    monkeypatch.setattr('dance_highlight.services.face_cluster.cv2.VideoCapture', lambda _: Capture())
    segment = Segment('main', 1, 0., 1., [(0., body, 1)])
    results = worker.batch_segment_embeddings(
        'source.mp4', [segment], frame_records=[record],
        evidence_only_indices=frozenset({0}), sample_all_main_frames=True,
    )
    observed = results[0].owned_observations[0]
    assert observed.association == 'confirmed'
    assert observed.detection_rotation_degrees == pytest.approx(np.degrees(np.arctan2(20., 30.)))
    source = tmp_path / 'source.mp4'
    source.write_bytes(b'test source identity')
    output = tmp_path / 'evidence.json'
    write_face_evidence(output, input_video=source, config=worker.config, face_service=worker,
                        results=results, records=[record], references=[])
    saved = json.loads(output.read_text())
    assert saved['segments'][0]['owned_observations'][0]['detection_rotation_degrees'] == observed.detection_rotation_degrees
    assert saved['policy']['pose_face_rotation'] == 'measured_eye_roll_v1'
    assert {'pose_face_rotation', 'cut_face_link', 'sampled_face_link'} <= saved['runtime']['modules'].keys()
