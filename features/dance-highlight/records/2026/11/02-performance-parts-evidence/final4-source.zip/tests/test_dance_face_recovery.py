from dataclasses import replace
import numpy as np

from dance_highlight.services.face_evidence import FaceObservation
from dance_highlight.services.reference_matcher import ReferenceEmbeddingSample, SegmentReferenceDecision
from dance_highlight.services.segment import Segment


def observation(t, vector=(1., 0.), track=1):
    return FaceObservation(round(t*30), t, track, (0.,0.,100.,100.), (0.,0.,100.,100.),
                           face_bbox=(10.,10.,30.,30.), embedding=np.array(vector,dtype=np.float32),
                           association='confirmed')


def run(obs, baseline=None, tracks=(1,)):
    from dance_highlight.services.face_recovery import recover_reference_decision
    refs=[ReferenceEmbeddingSample('A','a','a'*64,100,100,np.array([1.,0.],dtype=np.float32)),
          ReferenceEmbeddingSample('B','b','b'*64,100,100,np.array([0.,1.],dtype=np.float32))]
    seg=Segment('main',1,0.,9.,[(0.,np.array([0.,0.,100.,100.]),t) for t in tracks])
    return recover_reference_decision(
        baseline=baseline or SegmentReferenceDecision(None,'unmatched','distance_exceeded'),
        segment=seg,observations=obs,references=refs,scope_id='main-0',
        analysis_id='test',video_sha256='c'*64,detector_sha256='d'*64,
        recognizer_sha256='e'*64,config_sha256='f'*64,backend_version='test',video_size=(100,100),
        max_distance=.6,
    )


def evidence():
    return [observation(t) for t in (.1,1.,3.1,4.,6.1,8.)]


def test_recovery_requires_repeated_direct_evidence_across_whole_scope():
    decision,audit=run(evidence())
    assert decision.reference_id=='A'
    assert decision.reason=='pose_observation_consensus'
    assert audit['accepted'] is True


def test_recovery_keeps_existing_assignments_and_unproven_scope_unmatched():
    baseline=SegmentReferenceDecision('B','matched','accepted')
    assert run(evidence(),baseline)[0] is baseline
    assert run(evidence()[:4])[0].reference_id is None
    assert run(evidence(),tracks=(1,2))[0].reference_id is None
    assert run([evidence()[0]]*6)[0].reference_id is None


def test_recovery_rejects_competing_names_unowned_faces_and_unmatched_identity_switch():
    assert run(evidence()+[observation(5.,(0.,1.))])[0].reference_id is None
    assert run([replace(o,association='ambiguous') for o in evidence()])[0].reference_id is None
    # No registered name matches this second face. It must still veto scope recovery.
    assert run(evidence()+[observation(5.,(-1.,0.))])[0].reference_id is None


def _match_views(photos, *, association='confirmed'):
    from dance_highlight.services.face_recovery import ReferenceObservationMatcher
    references=[ReferenceEmbeddingSample(name,f'{name}-{index}',sha*64,100,100,
                    np.asarray(vector,np.float32)) for index,(name,sha,vector) in enumerate(photos)]
    matcher=ReferenceObservationMatcher(references=references,analysis_id='test',video_sha256='c'*64,
        detector_sha256='d'*64,recognizer_sha256='e'*64,config_sha256='f'*64,
        backend_version='test',video_size=(100,100),max_distance=.6)
    return matcher.match(replace(observation(1.),association=association),Segment('main',1,0.,2.,[]),'main')


def test_repeated_reference_views_can_identify_face_missed_by_average_reference():
    photos=[('A',sha,(1.,0.)) for sha in ('1','2')]
    photos += [('A',sha,(0.,1.)) for sha in ('3','4','5','6','7')]
    photos += [('B','8',(-1.,0.))]
    match=_match_views(photos)
    assert match.reference_id=='A'
    assert match.reason=='supported_reference_views'


def test_one_photo_or_duplicate_photo_cannot_supply_repeated_reference_views():
    background=[('A',sha,(0.,1.)) for sha in ('3','4','5','6','7')]
    assert _match_views([('A','1',(1.,0.)),*background]).reference_id is None
    assert _match_views([('A','1',(1.,0.)),('A','1',(1.,0.)),*background]).reference_id is None


def test_reference_view_recovery_keeps_competing_names_and_unowned_faces_unresolved():
    photos=[('A',sha,(1.,0.)) for sha in ('1','2')]
    photos += [('A',sha,(0.,1.)) for sha in ('3','4','5','6','7')]
    assert _match_views(photos,association='ambiguous').reference_id is None
    photos += [('B',sha,(1.,0.)) for sha in ('8','9')]
    photos += [('B',sha,(0.,-1.)) for sha in ('a','b','c','d','e')]
    assert _match_views(photos).reference_id is None
