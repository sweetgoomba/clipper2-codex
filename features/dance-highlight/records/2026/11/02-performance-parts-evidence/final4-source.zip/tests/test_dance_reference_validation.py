"""Reference preview and per-job image handling without loading ML models."""

from __future__ import annotations

import base64
import hashlib
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import cv2
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from dance_highlight.app import DanceHighlightPlugin
from dance_highlight.services.config import DanceConfig
from dance_highlight.services.dance_meta import DanceMetaBuilder
from dance_highlight.services.pipeline import DancePipeline


class FakeFace:
    def get_face_embedding(self, image: np.ndarray):
        return np.full(4, 0.5, dtype=np.float32) if image[0, 0, 0] == 255 else None

    def get_face_embedding_from_image_path(self, path: str):
        image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        return self.get_face_embedding(image) if image is not None else None

    def average_embeddings(self, embeddings):
        return np.mean(embeddings, axis=0) if embeddings else None


def _image_bytes(value: int) -> bytes:
    ok, encoded = cv2.imencode(".png", np.full((2, 2, 3), value, dtype=np.uint8))
    assert ok
    return encoded.tobytes()


def _client(face=None) -> TestClient:
    plugin = DanceHighlightPlugin()
    if face is not None:
        plugin._pipeline = SimpleNamespace(face=face)
    app = FastAPI()
    plugin.register_extra_routes(app)
    return TestClient(app)


def test_reference_validation_decodes_image_and_reports_face() -> None:
    response = _client(FakeFace()).post(
        "/dance/reference/validate",
        json={"imageBase64": base64.b64encode(_image_bytes(255)).decode()},
    )

    assert response.status_code == 200
    assert response.json() == {"faceDetected": True}


def test_reference_validation_reports_missing_face_and_invalid_image() -> None:
    client = _client(FakeFace())

    no_face = client.post(
        "/dance/reference/validate",
        json={"imageBase64": base64.b64encode(_image_bytes(0)).decode()},
    )
    invalid_image = client.post(
        "/dance/reference/validate",
        json={"imageBase64": base64.b64encode(b"not an image").decode()},
    )

    assert no_face.status_code == 200
    assert no_face.json() == {"faceDetected": False, "reason": "no_face"}
    assert invalid_image.status_code == 200
    assert invalid_image.json() == {"faceDetected": False, "reason": "invalid_image"}


def test_reference_validation_reports_empty_image_as_invalid() -> None:
    response = _client(FakeFace()).post(
        "/dance/reference/validate", json={"imageBase64": ""},
    )
    assert response.status_code == 200
    assert response.json() == {"faceDetected": False, "reason": "invalid_image"}


@pytest.mark.parametrize("payload,status", [("bad*base64", 400), ("oversized", 413)])
def test_reference_validation_rejects_invalid_or_oversized_base64(payload: str, status: int) -> None:
    if payload == "oversized":
        payload = base64.b64encode(b"x" * (10 * 1024 * 1024 + 1)).decode()
    response = _client(FakeFace()).post(
        "/dance/reference/validate", json={"imageBase64": payload},
    )
    assert response.status_code == status


def test_reference_validation_requires_loaded_face_model() -> None:
    response = _client().post(
        "/dance/reference/validate",
        json={"imageBase64": base64.b64encode(_image_bytes(255)).decode()},
    )
    assert response.status_code == 503


def test_local_selected_images_are_copied_into_job_refs(tmp_path: Path) -> None:
    originals = []
    for index in range(3):
        path = tmp_path / f"selected-{index}.png"
        path.write_bytes(_image_bytes(255))
        originals.append(str(path))
    pipeline = DancePipeline.__new__(DancePipeline)
    pipeline.face = FakeFace()
    project_root = tmp_path / "project"

    paths = pipeline._download_reference_images(project_root, {
        "members": [{"memberName": "사쿠라", "selectedImages": ["https://unused.invalid/photo.jpg"] * 3,
                     "validatedImagePaths": originals}],
    })
    embeddings = pipeline._build_reference_embeddings(paths)

    assert len(paths["사쿠라"]) == 3
    assert all(path.parent == project_root / "refs" / "dance" / "사쿠라" for path in paths["사쿠라"])
    assert [path.read_bytes() for path in paths["사쿠라"]] == [Path(p).read_bytes() for p in originals]
    assert "사쿠라" in embeddings


def test_reference_builder_preserves_each_photo_for_shared_matching(tmp_path: Path) -> None:
    photos = []
    for index in range(3):
        path = tmp_path / f"sample-{index}.png"
        path.write_bytes(_image_bytes(255))
        photos.append(path)
    pipeline = DancePipeline.__new__(DancePipeline)
    pipeline.face = FakeFace()
    samples = []

    embeddings = pipeline._build_reference_embeddings({"사쿠라": photos}, sample_sink=samples)

    assert "사쿠라" in embeddings
    assert len(samples) == 3
    assert [sample.sample_id for sample in samples] == [f"사쿠라/{i}" for i in range(3)]
    assert all(sample.width == 2 and sample.height == 2 for sample in samples)
    assert [sample.image_sha256 for sample in samples] == [
        hashlib.sha256(path.read_bytes()).hexdigest() for path in photos
    ]


def test_fewer_than_three_usable_member_photos_fails_clearly(tmp_path: Path) -> None:
    photos = []
    for index, value in enumerate((255, 255, 0)):
        path = tmp_path / f"selected-{index}.png"
        path.write_bytes(_image_bytes(value))
        photos.append(str(path))
    pipeline = DancePipeline.__new__(DancePipeline)
    pipeline.face = FakeFace()
    paths = pipeline._download_reference_images(tmp_path / "project", {
        "members": [{"memberName": "사쿠라", "validatedImagePaths": photos}],
    })

    with pytest.raises(ValueError, match="사쿠라.*3.*2"):
        pipeline._build_reference_embeddings(paths)


def test_nonfinite_reference_feature_does_not_count_as_usable_photo(tmp_path: Path) -> None:
    photos = []
    for index in range(3):
        path = tmp_path / f"selected-{index}.png"
        path.write_bytes(_image_bytes(255))
        photos.append(path)

    class NonfiniteFace:
        def get_face_embedding_from_image_path(self, path: str):
            return np.array([np.nan, 0], dtype=np.float32) if path.endswith("selected-2.png") else np.array([1, 0], dtype=np.float32)

    pipeline = DancePipeline.__new__(DancePipeline)
    pipeline.face = NonfiniteFace()
    with pytest.raises(ValueError, match="사쿠라.*3.*2"):
        pipeline._build_reference_embeddings({"사쿠라": photos})


def test_missing_local_photo_fails_instead_of_being_ignored(tmp_path: Path) -> None:
    pipeline = DancePipeline.__new__(DancePipeline)
    with pytest.raises(ValueError, match="missing.png"):
        pipeline._download_reference_images(tmp_path / "project", {
            "members": [{"memberName": "사쿠라", "validatedImagePaths": [str(tmp_path / "missing.png")]}],
        })


def test_unmatched_person_display_names_preserve_ids() -> None:
    pipeline = DancePipeline.__new__(DancePipeline)

    assert pipeline._person_display_name("person_1") == "미확인 인물 1"
    assert pipeline._person_display_name("person_12") == "미확인 인물 12"
    assert pipeline._person_display_name("unknown") == "미확인 인물"
    assert pipeline._person_display_name("huh_yunjin") == "huh yunjin"


def test_project_metadata_excludes_reference_sources() -> None:
    meta = DanceMetaBuilder(DanceConfig()).build(
        project_id=1,
        input_video_rel="input.mp4",
        main_items=[],
        group_items=[],
        persons=[],
        stats={},
        dance_setup={
            "artistName": "IVE",
            "members": [{
                "memberName": "원영",
                "selectedImages": ["https://example.test/wonyoung.jpg"],
                "validatedImagePaths": ["/tmp/staged-secret.jpg"],
            }],
        },
    )

    assert meta["dance_setup"]["members"] == [{
        "memberName": "원영",
    }]
