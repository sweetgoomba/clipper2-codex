from dataclasses import replace
import copy
import pytest
from test_dance_mask_continuity import recovery_example
from dance_highlight.services.mask_continuity import recover_mask_names


def accepted_matches(anchors):
    return {a['frame_index']:dict(name=a['name'],status='accepted',reason='joint_video_match') for a in anchors}


def test_frozen_joint_evidence_can_seed_body_proof_without_becoming_gallery_or_face_names():
    original,records,anchors=recovery_example();matches=accepted_matches(anchors)
    before=copy.deepcopy(matches);calls=[]
    def verify(anchor,path,targets):
        calls.append(anchor.frame_index)
        return dict(accepted=True,reason='confirmed_visual_path',support_frames=targets)
    result,audit=recover_mask_names(original,records,'unused',10.,[],joint_matches=matches,verify_track=verify)
    assert [(s.start,s.end) for s in result['segments']]==[(0.,6.)]
    assert result['decisions'][0].reference_id=='A'
    assert audit['recovered_seconds']==pytest.approx(2.)
    assert {a['seed_kind'] for c in audit['candidates'] for a in c['attempts']}=={'joint_face'}
    assert calls==[18,42]
    assert matches==before and original['anchors']==result['anchors']==[]
    assert original['fallback_names']==result['fallback_names']=={}
    assert all(name is None for row,name in result['evidence'][0] if 2<=row.time_seconds<4)


@pytest.mark.parametrize('case',['single','low_score','ambiguous_owner','conflict_status','split_shots','recovered_name_only','body_failure'])
def test_joint_seed_still_requires_original_repeated_faces_and_complete_body_proof(case):
    original,records,anchors=recovery_example();matches=accepted_matches(anchors);cuts=[];calls=[]
    if case=='single':matches={f:m for f,m in matches.items() if f in (18,42)}
    if case=='low_score':original['evidence']=[[(replace(o,detector_score=.89),n) for o,n in rows] for rows in original['evidence']]
    if case=='ambiguous_owner':original['evidence']=[[(replace(o,association='ambiguous'),n) for o,n in rows] for rows in original['evidence']]
    if case=='conflict_status':matches={f:dict(m,status='conflict') for f,m in matches.items()}
    if case=='split_shots':cuts=[17,44]
    if case=='recovered_name_only':
        matches={};original['fallback_names']={f:'A' for f in (15,18,42,45)}
    def verify(*args):
        calls.append(args)
        return dict(accepted=False,reason='unconfirmed_main_ownership')
    result,audit=recover_mask_names(original,records,'unused',10.,[],joint_matches=matches,cut_frames=cuts,verify_track=verify)
    assert result is original and audit['recovered_seconds']==0.
    assert bool(calls) is (case=='body_failure')


def test_original_other_name_inside_unknown_vetoes_joint_seed_recovery():
    original,records,anchors=recovery_example();matches=accepted_matches(anchors)
    direct=[dict(name='B',frame_index=f,time_seconds=f/10) for f in (25,28)];calls=[]
    result,audit=recover_mask_names(original,records,'unused',10.,direct,joint_matches=matches,
        verify_track=lambda *args:calls.append(args) or dict(accepted=True,reason='confirmed_visual_path'))
    assert result is original and calls==[]
    assert all(a['reason']=='conflicting_direct_face_anchor' for c in audit['candidates'] for a in c['attempts'])


def test_single_original_joint_conflict_vetoes_tracking_even_without_repeated_anchor():
    original,records,anchors=recovery_example();matches=accepted_matches(anchors)
    matches[25]=dict(name='B',status='accepted',reason='joint_video_match');calls=[]
    result,audit=recover_mask_names(original,records,'unused',10.,[],joint_matches=matches,
        verify_track=lambda *args:calls.append(args) or dict(accepted=True,reason='confirmed_visual_path'))
    assert result is original and calls==[]
    assert audit['recovered_seconds']==0.
    assert all(a['reason']=='conflicting_direct_face_anchor' for c in audit['candidates'] for a in c['attempts'])
