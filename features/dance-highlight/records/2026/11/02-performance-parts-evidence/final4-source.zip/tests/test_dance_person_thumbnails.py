from __future__ import annotations

import json
from tempfile import TemporaryFile
from types import SimpleNamespace

import cv2
import numpy as np
import pytest

from dance_highlight.services import pipeline as pipeline_module
from dance_highlight.services import person_thumbnails as thumbnails_module
from dance_highlight.services.config import DanceConfig
from dance_highlight.services.dance_meta import DanceMetaBuilder
from dance_highlight.services.pipeline import DancePipeline
from dance_highlight.services.segment import Segment


def _jpeg(color: tuple[int, int, int], size: int = 112) -> bytes:
    okay, encoded = cv2.imencode(".jpg", np.full((size, size, 3), color, dtype=np.uint8))
    assert okay
    return encoded.tobytes()


@pytest.fixture
def run_pipeline(tmp_path, monkeypatch):
    """Keep person assignment, evidence selection and metadata real; replace ML/render IO."""
    segments = [Segment("main", index, index * 2.0, index * 2.0 + 1, [])
                for index in range(5)]
    monkeypatch.setattr(pipeline_module, "build_raw_main_segments", lambda _: segments)
    monkeypatch.setattr(pipeline_module, "build_raw_group_segments", lambda _: [
        Segment("group", None, 11.0, 12.0, []),
    ])
    monkeypatch.setattr(pipeline_module, "smooth_main_segments", lambda rows, **_: rows)
    monkeypatch.setattr(pipeline_module, "smooth_group_segments", lambda rows, **_: rows)

    class Render:
        def extract_clip(self, _video, path, _start, _end):
            path.write_bytes(b"clip")

        def extract_thumbnail(self, _video, path, ts_sec):
            path.write_bytes(b"scene-preview")

    def run(first_person_images=None, *, first_person_thumbnails=None, owned_thumbnails=None,
            forbid_clip_extraction=False):
        red, blue = _jpeg((0, 0, 255)), _jpeg((255, 0, 0))
        if first_person_images is None:
            first_person_images = [red]
        vector_a, vector_b, vector_c = np.eye(3, dtype=np.float32)
        results = [
            SimpleNamespace(seg=segments[0], face_detected=False, track_embeddings=[],
                            track_evidence_images=[[blue]]),
            SimpleNamespace(seg=segments[1], face_detected=True,
                            track_embeddings=[vector_b, vector_a, vector_a],
                            track_evidence_images=[[blue], first_person_images, [red]]),
            SimpleNamespace(seg=segments[2], face_detected=True, track_embeddings=[vector_b],
                            track_evidence_images=[[blue]]),
            SimpleNamespace(seg=segments[3], face_detected=True, track_embeddings=[vector_c],
                            track_evidence_images=[]),
            SimpleNamespace(seg=segments[4], face_detected=True, track_embeddings=[vector_c],
                            track_evidence_images=[[red]]),
        ]
        if first_person_thumbnails is not None:
            results[1].track_thumbnail_images = [[blue], first_person_thumbnails, []]
        if owned_thumbnails is not None:
            results[1].owned_thumbnails = owned_thumbnails
        face = SimpleNamespace(
            batch_segment_embeddings=lambda *_args, **_kwargs: results,
            cluster_embeddings=lambda _values: [20, 10, 10, 20, 30, None],
        )
        config = DanceConfig()
        render = Render()
        if forbid_clip_extraction:
            def reject_scene_extraction(*_args, **_kwargs):
                pytest.fail("Dance source ranges must not extract scene MP4s during analysis")
            render.extract_clip = reject_scene_extraction
        pipeline = DancePipeline(config, None, face, render, DanceMetaBuilder(config))
        pipeline.analyze_video_to_records = lambda *_args, **_kwargs: ([], 30.0, 14.0)
        pipeline._video_size = lambda _path: (640, 480)
        video = tmp_path / "input.mp4"
        video.write_bytes(b"source-video")
        return pipeline.run(tmp_path, video, 42)

    return run


def test_pipeline_persists_only_each_persons_selected_observed_face(run_pipeline, tmp_path):
    result = run_pipeline()
    persons = {person["person_id"]: person for person in result["persons"]}

    assert persons["person_1"].get("person_image_path") == "faces/person_1.jpg"
    assert persons["person_2"].get("person_image_path") == "faces/person_2.jpg"
    assert (tmp_path / "faces/person_1.jpg").read_bytes() == _jpeg((0, 0, 255))
    assert (tmp_path / "faces/person_2.jpg").read_bytes() == _jpeg((255, 0, 0))
    assert "person_image_path" not in persons["person_3"]
    assert "person_image_path" not in persons["unknown"]
    assert len(result["lists"]["main"]) == 4
    assert [item["person_id"] for item in result["lists"]["main"]] == [
        "person_1", "person_2", "person_3", "unknown",
    ]
    saved = json.loads((tmp_path / "json/dance_meta.json").read_text())
    assert saved["persons"] == result["persons"]


def test_pipeline_skips_corrupt_evidence_before_persisting_a_valid_crop(run_pipeline, tmp_path):
    result = run_pipeline([b"", b"not-an-image", _jpeg((0, 255, 0))])
    person = next(person for person in result["persons"] if person["person_id"] == "person_1")

    assert person.get("person_image_path") == "faces/person_1.jpg"
    assert (tmp_path / person["person_image_path"]).read_bytes() == _jpeg((0, 255, 0))


def test_pipeline_persists_larger_selected_display_thumbnail(run_pipeline, tmp_path):
    thumbnail = _jpeg((0, 255, 0), size=256)

    result = run_pipeline(first_person_thumbnails=[thumbnail])

    person = next(person for person in result["persons"] if person["person_id"] == "person_1")
    assert (tmp_path / person["person_image_path"]).read_bytes() == thumbnail


def test_pipeline_falls_back_to_evidence_when_display_thumbnails_are_empty(run_pipeline, tmp_path):
    result = run_pipeline(first_person_thumbnails=[])

    person = next(person for person in result["persons"] if person["person_id"] == "person_1")
    assert (tmp_path / person["person_image_path"]).read_bytes() == _jpeg((0, 0, 255))


def test_pipeline_closes_temporary_display_storage_after_identity_refinement(run_pipeline):
    store_class = getattr(thumbnails_module, 'FaceThumbnailStore', None)
    assert store_class is not None
    with TemporaryFile() as image_file:
        thumbnails = store_class(image_file)
        thumbnails[123] = _jpeg((0, 255, 0), size=256)

        run_pipeline(owned_thumbnails=thumbnails)

        assert image_file.closed


def test_pipeline_does_not_emit_thumbnail_paths_when_image_write_fails(run_pipeline, tmp_path):
    (tmp_path / "faces").write_text("not-a-directory")

    result = run_pipeline()

    assert all("person_image_path" not in person for person in result["persons"])


def test_pipeline_writes_source_ranges_and_previews_without_extracting_scene_videos(
    run_pipeline, tmp_path,
):
    result = run_pipeline(forbid_clip_extraction=True)

    assert result["media_mode"] == "source_ranges"
    assert result["source_video_path"] == "diagnostics/source.mp4"
    assert (tmp_path / result["source_video_path"]).read_bytes() == b"source-video"
    assert not list((tmp_path / "clips").rglob("*.mp4"))
    clips = result["lists"]["main"] + result["lists"]["group"]
    assert [(clip["clip_id"], clip["start"], clip["end"]) for clip in clips] == [
        ("main_0000", 2.0, 3.0), ("main_0001", 4.0, 5.0),
        ("main_0002", 6.0, 7.0), ("main_0003", 8.0, 9.0),
        ("group_0000", 11.0, 12.0),
    ]
    for clip in clips:
        assert "clip_path" not in clip
        assert (tmp_path / clip["thumbnail_path"]).is_file()
    assert {person["person_id"]: person["clip_ids"] for person in result["persons"]} == {
        "person_1": ["main_0000"], "person_2": ["main_0001"],
        "person_3": ["main_0002"], "unknown": ["main_0003"],
    }
    assert all("clip_paths" not in person for person in result["persons"])
    evidence = result["diagnostics"]["clips"]
    assert [item["clip_id"] for item in evidence] == [clip["clip_id"] for clip in clips]
    assert all("clip_path" not in item for item in evidence)
    assert all((tmp_path / item["thumbnail_path"]).is_file() for item in evidence)


def test_source_ranges_retain_the_current_input_when_previous_diagnostics_exist(
    run_pipeline, tmp_path,
):
    diagnostic_source = tmp_path / "diagnostics/source.mp4"
    diagnostic_source.parent.mkdir()
    previous_input = tmp_path / "previous.mp4"
    previous_input.write_bytes(b"previous-analysis-source")
    diagnostic_source.hardlink_to(previous_input)

    result = run_pipeline(forbid_clip_extraction=True)
    (tmp_path / "input.mp4").unlink()

    assert (tmp_path / result["source_video_path"]).read_bytes() == b"source-video"
    assert previous_input.read_bytes() == b"previous-analysis-source"
