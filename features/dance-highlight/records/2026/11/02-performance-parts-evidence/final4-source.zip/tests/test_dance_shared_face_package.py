"""The Dance plugin installs the shared face package in its optional venv."""

from pathlib import Path
import tomllib


ROOT = Path(__file__).resolve().parents[1]


def test_dance_plugin_declares_shared_face_workspace_dependency():
    workspace = tomllib.loads((ROOT / "pyproject.toml").read_text())
    plugin = tomllib.loads((ROOT / "plugins/dance_highlight/pyproject.toml").read_text())

    assert "clipper_face_core" in workspace["tool"]["uv"]["workspace"]["members"]
    assert "clipper-face-core" in plugin["project"]["dependencies"]
    assert plugin["tool"]["uv"]["sources"]["clipper-face-core"] == {"workspace": True}
