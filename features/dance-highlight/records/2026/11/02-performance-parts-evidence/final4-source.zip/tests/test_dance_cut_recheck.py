import numpy as np
import pytest


def recheck(a, b, scores=(.99, .89)):
    from dance_highlight.services.cut_face_link import weak_detection_recheck
    return weak_detection_recheck(np.asarray(a), np.asarray(b), 0, 0, scores)


def test_low_quality_owner_only_permits_additional_validation():
    result = recheck([[.58, .88], [.80, .9]], [[.56, .53], [.76, .9]])
    assert result['eligible']
    from dance_highlight.services.mask_tracker import permits_sampled_head_link
    proof = dict(accepted=False, reason='weak_face_match', sampled_recheck=result)
    assert permits_sampled_head_link(proof)
    assert not proof['accepted']


@pytest.mark.parametrize('scores', [(.99,.99), (.99,None), (.99,float('nan')), (.99,.2)])
def test_score_must_demonstrate_a_valid_but_low_confidence_owner(scores):
    assert not recheck([[.58]], [[.56]], scores)['eligible']


@pytest.mark.parametrize('model,axis', [(0,0),(0,1),(1,0),(1,1)])
def test_strong_opposite_correspondence_vetoes_sampled_a_to_a(model,axis):
    # Endpoint samples may be A->A while the exact intermediate owner is B.
    matrices = [np.array([[.8,.9],[.9,.8]]),np.array([[.8,.9],[.9,.8]])]
    matrices[model][0,1] = .1 if axis==0 else .9
    matrices[model][1,0] = .1 if axis==1 else .9
    result = recheck(*matrices)
    assert not result['eligible']
    assert result['reason']=='strong_competing_face'


@pytest.mark.parametrize('competing', [.15, .21])
@pytest.mark.parametrize('reverse', [False, True])
def test_weak_first_model_cannot_hide_second_models_confident_ambiguity(competing, reverse):
    matrices=[[[.6,.9],[.9,.8]], [[.2,competing],[.9,.8]]]
    if reverse:matrices.reverse()
    assert not recheck(*matrices)['eligible']


@pytest.mark.parametrize('a,b', [([[float('nan')]],[[.6]]), ([[.6]],[[.6,.8]]),
                               ([[.2,.21]],[[.2,.21]]), ([[.2]],[[.2]])])
def test_invalid_ambiguous_or_already_matching_identity_cannot_use_weak_recheck(a,b):
    assert not recheck(a,b)['eligible']


def row(x, vector, score):
    return dict(points=np.array([[x+20,40],[x+50,40],[x+30,60],[x+20,80],[x+50,80]]),
                box=np.array([x,30,x+80,110]), primary=np.array(vector),
                secondary=np.array(vector),rotation=0.,detector_score=score)


def link_fixture(monkeypatch, expanded_other=None):
    from dance_highlight.services import cut_face_link as m
    linker=m.CutFaceLink.__new__(m.CutFaceLink);linker.cache={}
    a=row(100,[1.,0.],.99);b=row(100,[.4,np.sqrt(.84)],.89)
    calls=[]
    def faces(image,frame,rotation=0.):
        calls.append((frame,rotation))
        rows=[a if frame==0 else b]
        return rows + ([expanded_other] if rotation and frame==1 and expanded_other is not None else [])
    linker._faces=faces
    if expanded_other is not None:
        linker.cache[(0,'expanded')]=[a]
        linker.cache[(1,'expanded')]=[b,expanded_other]
    monkeypatch.setattr(m,'scaled_head_link',lambda *a:dict(accepted=True))
    image=np.zeros((320,320,3),np.uint8)
    mask=np.zeros((320,320),bool);mask[:,:190]=True
    return linker,image,mask,calls


def test_unique_low_owner_does_not_require_missing_face_search(monkeypatch):
    from dance_highlight.services.mask_tracker import permits_sampled_head_link
    linker,image,mask,calls=link_fixture(monkeypatch)
    proof=linker(image,image,mask,mask,0,1)
    assert not proof['accepted']
    assert permits_sampled_head_link(proof),proof
    assert not any(r for f,r in calls)


def test_previously_discovered_rotated_competitor_blocks_weak_recheck(monkeypatch):
    from dance_highlight.services.mask_tracker import permits_sampled_head_link
    linker,image,mask,_=link_fixture(monkeypatch,row(210,[1.,0.],.85))
    proof=linker(image,image,mask,mask,0,1)
    assert not proof['accepted']
    assert not permits_sampled_head_link(proof)
    assert proof['sampled_recheck']['reason']=='strong_competing_face'


@pytest.mark.parametrize('other', [row(130,[1.,0.],.85), dict(row(210,[1.,0.],.85),primary=None)])
def test_cached_ambiguous_ownership_and_invalid_features_stay_blocked(monkeypatch,other):
    from dance_highlight.services.mask_tracker import permits_sampled_head_link
    linker,image,mask,_=link_fixture(monkeypatch,other)
    proof=linker(image,image,mask,mask,0,1)
    assert not proof['accepted']
    assert not permits_sampled_head_link(proof)


def test_small_native_face_does_not_lose_all_pixels_in_full_frame_downsampling():
    import cv2
    from dance_highlight.services.cut_face_link import scaled_head_link
    rng=np.random.default_rng(142)
    image=cv2.GaussianBlur(rng.integers(0,255,(1080,1920,3),dtype=np.uint8),(3,3),0)
    mask=np.ones(image.shape[:2],bool);face=(920.,530.,950.,572.)
    proof=scaled_head_link(image,image,mask,mask,face,face)
    assert proof['accepted'],proof
    changed=image.copy()
    changed[530:572,920:950]=rng.integers(0,255,(42,30,3),dtype=np.uint8)
    assert not scaled_head_link(image,changed,mask,mask,face,face)['accepted']


def test_native_face_smaller_than_supported_patch_cannot_be_upscaled_into_evidence():
    import cv2
    from dance_highlight.services.cut_face_link import scaled_head_link
    rng=np.random.default_rng(143)
    image=cv2.GaussianBlur(rng.integers(0,255,(360,640,3),dtype=np.uint8),(3,3),0)
    mask=np.ones(image.shape[:2],bool);face=(300.,100.,310.,111.)
    assert not scaled_head_link(image,image,mask,mask,face,face)['accepted']
